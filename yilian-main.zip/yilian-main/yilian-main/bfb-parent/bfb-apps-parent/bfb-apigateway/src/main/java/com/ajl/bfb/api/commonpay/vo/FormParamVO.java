package com.ajl.bfb.api.commonpay.vo;

import lombok.Data;

@Data
public class FormParamVO {

    private String key;

    private String val;
}
