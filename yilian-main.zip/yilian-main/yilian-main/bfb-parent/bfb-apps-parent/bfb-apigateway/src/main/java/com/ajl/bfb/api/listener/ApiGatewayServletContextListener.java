package com.ajl.bfb.api.listener;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

/**
 * ApiGatewayServletContextListener
 *
 * @author ben
 * @date 2018/11/22
 * @Description
 */
@WebListener
public class ApiGatewayServletContextListener implements ServletContextListener{
    private static Logger logger = LogManager.getLogger(ApiGatewayServletContextListener.class);
    @Override
    public void contextInitialized(ServletContextEvent servletContextEvent) {
        logger.info("服务器初始化=============================================");
    }

    @Override
    public void contextDestroyed(ServletContextEvent servletContextEvent) {
        logger.info("服务器停止=========================================");
    }
}
