package com.ajl.bfb.api.withdraw.vo;

import com.ajl.bfb.api.common.vo.BaseResponseVO;
import lombok.Data;

@Data
public class QueryAccountResponseVO extends BaseResponseVO {


    private String cashBalance;

    private String totalBalance;

}

