package com.ajl.bfb.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.data.neo4j.Neo4jDataAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;
import org.springframework.boot.autoconfigure.transaction.TransactionAutoConfiguration;
import org.springframework.boot.autoconfigure.web.MultipartAutoConfiguration;
import org.springframework.boot.web.servlet.ServletComponentScan;
import org.springframework.boot.web.support.SpringBootServletInitializer;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.context.annotation.ImportResource;
import org.springframework.context.annotation.PropertySource;
import org.springframework.scheduling.annotation.EnableAsync;

/**
 * Created by admin on 2018-02-07 0007.
 */
@SuppressWarnings("ALL")
@SpringBootApplication(scanBasePackages = {"com.hippo.framework", "com.ajl.bfb"})
@EnableAutoConfiguration(exclude = {
        DataSourceAutoConfiguration.class,
        Neo4jDataAutoConfiguration.class,//排除
        TransactionAutoConfiguration.class,//排除
        HibernateJpaAutoConfiguration.class,//排除
        MultipartAutoConfiguration.class //排除
})
@ImportResource("classpath:spring-transaction.xml")
@PropertySource(value = {
        "classpath:/env/${spring.profiles.active}/jdbc.properties",
        "classpath:/env/${spring.profiles.active}/redis.properties",
}, encoding = "utf-8")
@EnableAspectJAutoProxy(proxyTargetClass = true)
@ServletComponentScan
@EnableAsync
public class ApiGatewayApplicationStarter extends SpringBootServletInitializer {

    public static void main(String[] args) {
        SpringApplication.run(ApiGatewayApplicationStarter.class, args);
    }
}
