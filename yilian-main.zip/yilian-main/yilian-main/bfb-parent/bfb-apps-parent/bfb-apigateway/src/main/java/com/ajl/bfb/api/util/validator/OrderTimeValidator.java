package com.ajl.bfb.api.util.validator;

import com.ajl.bfb.api.commonpay.vo.CreatePaymentOrderRequestVO;
import com.ajl.bfb.core.exception.ParameterVerificationException;
import org.apache.commons.lang3.time.DateUtils;

import java.text.ParseException;

/**
 * Created by admin on 2018-06-25 0025.
 */
public class OrderTimeValidator {

    public static boolean checkOrderTimeFormat(String timeStr) {
        try {
            DateUtils.parseDate(timeStr, new String[]{CreatePaymentOrderRequestVO.ORDER_TIME_FORMAT});
            return true;
        } catch (ParseException e) {
            throw new ParameterVerificationException("参数校验失败.订单时间格式有误.正确格式:" + CreatePaymentOrderRequestVO.ORDER_TIME_FORMAT);
        }
    }

}
