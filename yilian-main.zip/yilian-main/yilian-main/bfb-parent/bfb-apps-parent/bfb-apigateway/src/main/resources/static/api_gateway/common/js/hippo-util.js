var hippo = {};

String.prototype.trim=function()
{
    return this.replace(/(^\s*)|(\s*$)/g, '');
}

String.prototype.isEmpty=function() {
    return this.trim() == "";
}


hippo.controlCheckAll = function() {
    if ($("#controlCheckAll").prop('checked')) {
        $(".checkAll").prop('checked', true)
    } else {
        $(".checkAll").removeAttr("checked");
    }
}


hippo.goback = function () {


    if (document.referrer != null && document.referrer != '') {
        window.location.href=document.referrer;
    } else {
        window.history.go(-1);
    }
}


hippo.limitInteger = function(id) {

    $("#" + id).keydown(function (e) {
        var code = parseInt(e.keyCode);
        if (code >= 96 && code <= 105 || code >= 48 && code <= 57 || code == 8) {
            return true;
        } else {
            return false;
        }
    });


    $("#" + id).bind("input propertychange", function () {
        if (isNaN(parseFloat($(this).val())) || parseFloat($(this).val()) <= 0) $(this).val("");
    })
}


hippo.limitFloat = function(id){
    $("#" + id).keyup(function (e) {
        this.value = this.value.replace(/[^\d.]/g,"");
        this.value = this.value.replace(/^\./g,"");
        this.value = this.value.replace(/\.{2,}/g,".");
        this.value = this.value.replace(".","$#$").replace(/\./g,"").replace("$#$",".");
        this.value = this.value.replace(/^(\-)*(\d+)\.(\d\d).*$/,'$1$2.$3');
    });

    $("#" + id).bind("input propertychange", function () {
        if (isNaN(parseFloat($(this).val())) || parseFloat($(this).val()) <= 0) $(this).val("");
    })
}

hippo.limitMoney = function(id) {
    var e = document.getElementById(id);
    $(e).bind("input propertychange", function () {
        hippo.validateMoney(id);
    })
}


hippo.validateMoney =function(id) {
    var e = document.getElementById(id);

    var num = 2;
    var regu = /^[0-9]+\.?[0-9]*$/;
    if (e.value != "") {
        if (!regu.test(e.value)) {
            ;
            e.value = e.value.substring(0, e.value.length - 1);
            e.focus();
        } else {
            if (num == 0) {
                if (e.value.indexOf('.') > -1) {
                    e.value = e.value.substring(0, e.value.length - 1);
                    e.focus();
                }
            }
            if (e.value.indexOf('.') > -1) {
                if (e.value.split('.')[1].length > num) {
                    e.value = e.value.substring(0, e.value.length - 1);
                    e.focus();
                }
            }
        }
    }
}

hippo.validateForm = function (formId) {
    var targetForm = $("#" + formId);



    var inputEls = targetForm.find('input[hippo_required]');
    var selectEls = targetForm.find('select[hippo_required]');

    var allInputElements = $.merge(inputEls,selectEls);
    for (var i = 0, len = allInputElements.length; i < len; i++) {
        if ($(allInputElements[i]).val().isEmpty()) {




            layer.tips($(allInputElements[i]).attr('hippo_error_msg'), $(allInputElements[i]), {
                tips: [2, '#0FA6D8'],
                tipsMore: true,
                time:3000
             });

            $(allInputElements[i]).focus();
            return false;
        }
    }
    return true;
}



hippo.tips = function (adsorptiveElement,msg) {
    layer.tips(msg, adsorptiveElement, {
        tips: [3, '#0FA6D8'],
        tipsMore: true,
        time:3000
    });
}

hippo.msg = function (msg) {
    layer.msg(msg);
}


hippo.warning = function(msg) {
    layer.alert(msg, {title:'警告',icon: 5})
}





var hippoLayerLoadingIndex = -1;
$.ajaxSetup({
    cache:false,
    timeout: 10000,
    beforeSend: function () {





        try {
            hippoLayerLoadingIndex = layer.load();
        } catch (e) {}
    },
    ajaxComplete:function () {
    },
    complete: function (jqXHR, textStatus, errorMsg) {

        try {
            layer.close(hippoLayerLoadingIndex);
        } catch (e) {}
        showSystemError(jqXHR, textStatus, errorMsg);
    }, error: function (jqXHR, textStatus, errorMsg) {



        console.log("hippo pay ajax error");

    },ajaxError:function () {
        console.log("hippo pay ajaxError error");
        new $.zui.Messager('请求异常(ajaxError)，请联系管理员', {
            time:60000,
            type: 'danger'
        }).show();
    }
});

function showSystemError(jqXHR, textStatus, errorMsg) {
    try {
        var stCode = JSON.parse(jqXHR.responseText).statusCode;

        if((typeof jqXHR.responseText == "string")
            && (stCode == "UNKNOWN_EXCEPTION"
                || stCode == "UNAUTHORIZED"
                || stCode == "NO_PERMISSION")) {
            new $.zui.Messager(JSON.parse(jqXHR.responseText).message, {
                time:60000,
                type: 'danger'
            }).show();
            return false;
        }

    } catch (e) {}
}


