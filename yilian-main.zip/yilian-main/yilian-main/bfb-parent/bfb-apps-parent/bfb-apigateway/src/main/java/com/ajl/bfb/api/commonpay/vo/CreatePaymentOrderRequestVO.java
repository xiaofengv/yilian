package com.ajl.bfb.api.commonpay.vo;

import com.ajl.bfb.api.common.vo.BaseRequestVO;
import lombok.Data;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotBlank;

import java.io.Serializable;

@Data
public class CreatePaymentOrderRequestVO extends BaseRequestVO implements Serializable {


    @NotBlank(message = "支付类型不能为空")
    private String paymentType;

    @NotBlank(message = "商户订单号不能为空")
    @Length(min = 1, max = 50,message = "商户订单号长度限制{min}-{max}")
    private String mchOrderNo;


    @NotBlank(message = "订单日期不能为空")
    private String orderTime;


    @NotBlank(message = "商品名称不能为空")
    @Length(min = 1, max = 50,message = "商品字符长度限制{min}-{max}")
    private String goodsName;

    @NotBlank(message = "交易金额不能为空")
    @Length(min = 1, max = 20,message = "交易金额位数限制{min}-{max}")
    private String amount;

    @NotBlank(message = "请求IP地址不能为空")
    @Length(min = 1, max = 20,message = "交易金额位数限制{min}-{max}")
    private String clientIp;


    private String bankCode;


    private String frontReturnUrl;


    @NotBlank(message = "后台回调地址不能为空")
    @Length(min = 1, max = 500,message = "回调地址长度数限制{min}-{max}")
    private String notifyUrl;


    @Length(min = 0, max = 50,message = "买家ID长度数限制{min}-{max}")
    private String buyerId;

    @Length(min = 0, max = 50,message = "买家姓名长度数限制{min}-{max}")
    private String buyerName;

    @Length(min = 0, max = 100,message = "商品信息长度数限制{min}-{max}")
    private String goodsInfo;

    @Length(min = 0, max = 8,message = "商品数量长度数限制{min}-{max}")
    private String goodsNum;

    @Length(min = 0, max = 200,message = "商品数量长度数限制{min}-{max}")
    private String remark;

    @Length(min = 0, max = 50,message = "商品数量长度数限制{min}-{max}")
    private String buyerContact;


    private String extendParams;


    private Integer alipayAccId;


    private String channelAccountNo;
}
