package com.ajl.bfb.api.commonpay.vo;

import com.ajl.bfb.api.common.vo.BaseResponseVO;
import lombok.Data;

@Data
public class QueryPaymentOrderResponseVO extends BaseResponseVO {
    private Integer totalFee;

    private String orderStatus;

    private String orderDesc;
}
