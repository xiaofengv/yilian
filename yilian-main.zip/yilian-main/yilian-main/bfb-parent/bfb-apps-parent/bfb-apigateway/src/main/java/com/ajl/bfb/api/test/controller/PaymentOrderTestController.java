package com.ajl.bfb.api.test.controller;

import cn.hutool.core.date.DateUtil;
import com.ajl.bfb.api.commonpay.controller.CommonQrCodeOrderController;
import com.ajl.bfb.api.commonpay.controller.QueryPaymentOrderController;
import com.ajl.bfb.api.commonpay.vo.*;
import com.ajl.bfb.api.test.vo.ChannelAccountVO;
import com.ajl.bfb.api.util.ChannelAccountViewUtils;
import com.ajl.bfb.core.constants.*;
import com.ajl.bfb.core.exception.ParameterVerificationException;
import com.ajl.bfb.core.util.BeanUtils;
import com.ajl.bfb.core.util.MapSignUtils;
import com.ajl.bfb.core.util.MoneyUtils;
import com.ajl.bfb.core.util.SignUtils;
import com.ajl.bfb.pay.PaymentValidException;
import com.ajl.bfb.pay.payment.PaymentServiceException;
import com.ajl.bfb.repo.channel.model.Channel;
import com.ajl.bfb.repo.channel.model.ChannelAccount;
import com.ajl.bfb.repo.channel.model.ChannelQuery;
import com.ajl.bfb.repo.channel.service.IChannelAccountService;
import com.ajl.bfb.repo.channel.service.IChannelService;
import com.ajl.bfb.repo.ip.model.IPObject;
import com.ajl.bfb.repo.ip.model.IPVO;
import com.ajl.bfb.repo.merchant.model.Merchant;
import com.ajl.bfb.repo.merchant.service.IMerchantService;
import com.google.gson.Gson;
import com.hippo.framework.util.AddressUtils;
import com.hippo.framework.util.JsonUtils;
import com.hippo.framework.util.net.HttpException;
import com.hippo.framework.util.net.HttpUtils;
import com.hippo.framework.util.security.MD5Utils;
import net.sf.json.JSONArray;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.net.URLEncoder;
import java.util.*;
import java.util.stream.Collectors;

import static cn.hutool.core.date.DatePattern.PURE_DATETIME_FORMAT;


@Controller
@RequestMapping(value = "/api_gateway/pay/test/order")
public class PaymentOrderTestController {
    private static Logger logger = LogManager.getLogger(PaymentOrderTestController.class);
    @Autowired
    private CommonQrCodeOrderController commonQrCodeOrderController;
    @Autowired
    private QueryPaymentOrderController queryPaymentOrderController;
    @Autowired
    private IMerchantService merchantService;

    @Autowired
    private IChannelAccountService channelAccountService;

    @Autowired
    private IChannelService channelService;

    @RequestMapping(value = "/testDaifu")
    public String testDaifu(Model model, CreatePaymentOrderRequestVO orderRequestVO, HttpServletRequest request) throws HttpException {
        CreatePaymentOrderRequestVO param = new CreatePaymentOrderRequestVO();
        param.setPaymentType(orderRequestVO.getPaymentType()); // 支付类型
        param.setMchOrderNo(System.currentTimeMillis() + "");// 商户订单号
        param.setGoodsName(orderRequestVO.getGoodsName()); // 商品名称
        param.setAmount(MoneyUtils.yuan2fee(new BigDecimal(orderRequestVO.getAmount())).intValue() + "");// 金额【元】
        String ip = HttpUtils.getRemoteAddr(request);
        param.setClientIp(ip);//IP地址
        Map<String, String> params = new HashMap<>();
        params.put("channelAcc",orderRequestVO.getChannelAccountNo());
        params.put("merchantNo", orderRequestVO.getMerchantNo());
        params.put("nonceStr", "123");
        params.put("mchOrderNo", String.valueOf((new Date()).getTime()));
        params.put("orderTime", DateUtil.format(new Date(), PURE_DATETIME_FORMAT));
        params.put("amount", "500");
        params.put("payeeName", "张三");
        params.put("payeeBankCode", "01030000");
        params.put("payeeBankAccount", "123123212312");
        params.put("bankAccType", "PRIVATE");
        params.put("unionBankCode", "unionBankCode"); // 银联号
        params.put("payeeIdCardNo", "payeeIdCardNo"); // 收款人身份证号
        params.put("payeePhone", "18566998756"); // 收款人身份证号
        params.put("bankDetailName", "bankDetailName"); // 收款人身份证号

        String privatekey = "OOJGMB93KWWSJK6P63PF";
        String sign = MD5Utils.MD5Encode(MapSignUtils.createSignStr("appkey", privatekey, new String[]{"sign"}, params)).toLowerCase(Locale.ROOT);
        params.put("sign", sign);
        model.addAttribute("testParam", param);
        Map<String, String> paramMap = BeanUtils.getObjectFieldVal(param, false);
        paramMap.remove("sign");

        List<String[]> list = new ArrayList<>();
        for (Map.Entry<String, String> entry : paramMap.entrySet()) {
            list.add(new String[]{entry.getKey(), entry.getValue() == null ? "" : entry.getValue()});
        }
        model.addAttribute("testParam", list);
//
//        logger.info("request:{}", JsonUtils.obj2String(params));
//        model.addAttribute("channels",channels);
//        model.addAttribute("testParam", param);
//        String resultStr = HttpUtils.doPostWithJson("http://localhost:8080/admin/withdraw/batch_withdraw_list", JsonUtils.mapToJson(params));
//        logger.info("response:{}", resultStr);
        return "api_gateway/test/jump";
    }

    @RequestMapping(value = "/testpage")
    public String testPage(Model model) {
        model.addAttribute("payTypeList", PaymentTypeEnum.values());
        ChannelAccount ca = new ChannelAccount();
        ca.setStatus("ON");
        List<ChannelAccount> channelAccounts = channelAccountService.findAllChannelAccounts(ca);
        List<ChannelAccountVO> channelAccountVOS = toAccountVO(channelAccounts);
        Map<String, List<ChannelAccountVO>> channelVOMap = channelAccountVOS.stream().collect(Collectors.groupingBy(channelAccountVO -> channelAccountVO.getChannelName()));
        model.addAttribute("channelVOMap", channelVOMap);
        return "api_gateway/test/common_qr_order";
    }

    @RequestMapping(value = "/alih5test/{linkid}")
    public String alih5test(@PathVariable("linkid") String linkid, Model model) {
        model.addAttribute("linkid", linkid);
        return "api_gateway/test/alih5test";
    }

    @RequestMapping(value = "/testpage_inner")
    public String testPage3(Model model) {
        model.addAttribute("payTypeList", PaymentTypeEnum.values());
        List<ChannelAccount> channelAccounts = channelAccountService.findAllChannelAccounts(null);
        List<ChannelAccountVO> channelAccountVOS = toAccountVO(channelAccounts);
        List<ChannelAccountVO> channelAccountVOS2 = new ArrayList<>();

        List<Channel> channels = channelService.findChannels(new ChannelQuery());
        Map<Integer, Channel> listc = channels.stream().collect(Collectors.toMap(Channel::getId, c -> c));

        for (ChannelAccountVO channelAccountVO : channelAccountVOS) {
            if (ReadyStatusEnum.valueOf(channelAccountVO.getStatus()) == ReadyStatusEnum.ON && listc.get(channelAccountVO.getChannelId()).getStatus().equalsIgnoreCase("ON")) {
                channelAccountVOS2.add(channelAccountVO);
            }
        }
        Map<String, List<ChannelAccountVO>> channelVOMap = channelAccountVOS2.stream().collect(Collectors.groupingBy(channelAccountVO -> channelAccountVO.getChannelName()));
        model.addAttribute("channelVOMap", channelVOMap);
        return "api_gateway/test/common_qr_order";
    }

    @RequestMapping(value = "/testpage2")
    public String testPage2(Model model) {
        model.addAttribute("payTypeList", PaymentTypeEnum.values());
        model.addAttribute("alipayUserid", "12321321");
        model.addAttribute("alipayMoney", "1110");
        model.addAttribute("alipayRemark", "73hfjdkhfjkds7283473");

        model.addAttribute("outTime", 180 + "");
        model.addAttribute("encodeAlipayUrl", "http://www.baidu.com");
        model.addAttribute("qrPayUrl", "http://www.baidu.com");
        model.addAttribute("alipayUrl", "http://www.baidu.com");
        model.addAttribute("isMobile", "true");
        model.addAttribute("amount", "1.2");
        model.addAttribute("linkid", "fjdsklfjsdklfji23478923");
        return "api_gateway/pay/alipay_run_inner_test";
    }

    @RequestMapping(value = "/common_qr")
    public String commonQr(Model model, CreatePaymentOrderRequestVO orderRequestVO, HttpServletRequest request) {
        CreatePaymentOrderRequestVO param = new CreatePaymentOrderRequestVO();
        param.setPaymentType(orderRequestVO.getPaymentType()); // 支付类型
        param.setMchOrderNo(System.currentTimeMillis() + "");// 商户订单号
        param.setGoodsName(orderRequestVO.getGoodsName()); // 商品名称
        param.setAmount(MoneyUtils.yuan2fee(new BigDecimal(orderRequestVO.getAmount())).intValue() + "");// 金额【元】
        String ip = HttpUtils.getRemoteAddr(request);
//        saveIp(ip);
        param.setClientIp(ip);//IP地址
        param.setFrontReturnUrl("http://www.baidu.com");//
        param.setNotifyUrl("http://www.baidu.com");
        param.setBuyerId("123");
        param.setBuyerName("张三");
        param.setGoodsInfo(orderRequestVO.getGoodsName());
        param.setGoodsNum("1");
        param.setRemark(orderRequestVO.getGoodsName());
        param.setBuyerContact("13166666666");
        param.setOrderTime(DateFormatUtils.format(new Date(), "yyyyMMddHHmmss"));
        param.setMerchantNo(orderRequestVO.getMerchantNo());
        param.setNonceStr(System.currentTimeMillis() + "");
        param.setChannelAccountNo(orderRequestVO.getChannelAccountNo());
        model.addAttribute("testParam", param);
        Map<String, String> paramMap = BeanUtils.getObjectFieldVal(param, false);
        paramMap.remove("sign");

        List<String[]> list = new ArrayList<>();
        for (Map.Entry<String, String> entry : paramMap.entrySet()) {
            list.add(new String[]{entry.getKey(), entry.getValue() == null ? "" : entry.getValue()});
        }
        model.addAttribute("testParam", list);
        return "api_gateway/test/jump";
    }

    private void setCountryAndCity(IPVO ipvo) {
        IPVO temp = getAddresses(ipvo.getIp());
        ipvo.setCountry(temp.getCountry());
        ipvo.setRegion(temp.getRegion());
        ipvo.setCity(temp.getCity());
        ipvo.setIsp(temp.getIsp());
    }

    private IPVO getAddresses(String ip) {
        String ipResult = AddressUtils.getAddressFromIp138(ip);
        IPVO ipvo = null;
        if (StringUtils.isNotEmpty(ipResult)) {
            ipvo = jiexiIpAddress(ipResult);
        }
        if (ipvo != null) {
            return ipvo;
        }
        String content = "ip=" + ip;
        String returnStr = null;
        //先从TB获取，若获取失败，则从360获取
        try {
            returnStr = AddressUtils.getAddressesFromTB(content);
            if (StringUtils.isNotEmpty(returnStr)) {
                IPObject ipVo = new Gson().fromJson(returnStr, IPObject.class);
                if (ipVo != null && ipVo.getCode().equals("0")) {
                    return ipVo.getData();
                }
            }
        } catch (UnsupportedEncodingException e) {
            logger.info("从TB获取IP对应的城市异常");
        }
        return new IPVO();
    }

    private IPVO jiexiIpAddress(String ipInfo) {
        IPVO ipAddress = new IPVO();
        Map m = JsonUtils.json2map(ipInfo);
        String ret = m.get("ret").toString();
        if (ret.equals("ok")) {
            String ip = m.get("ip").toString();
            String data = m.get("data").toString();
            JSONArray jsonArr = JSONArray.fromObject(data);//转换成JSONArray 格式
            List<String> addresss = JSONArray.toList(jsonArr);
            ipAddress.setCountry(addresss.get(0));
            ipAddress.setIp(ip);
            ipAddress.setRegion(addresss.get(1));
            ipAddress.setCity(addresss.get(2));
            ipAddress.setIsp(addresss.get(3));
        } else {
            return null;
        }
        return ipAddress;
    }

    @RequestMapping(value = "/query")
    public String toQuery() {

        return "api_gateway/test/query_order";
    }

    @RequestMapping(value = "/do_query")
    @ResponseBody
    public QueryPaymentOrderResponseVO doQuery(QueryPaymentOrderRequestVO requestVO, String appKey) throws Exception {
        requestVO.setNonceStr(System.currentTimeMillis() + "");

        String sign = SignUtils.createSign(appKey, requestVO);
        requestVO.setSign(sign);

        return queryPaymentOrderController.query(requestVO);
    }

    @RequestMapping(value = "/do_common_qr")
    public String doCommonQr(Model model, CreatePaymentOrderRequestVO createPaymentOrderVO,
                             HttpServletRequest request) throws PaymentServiceException, UnsupportedEncodingException {
        Merchant merchant = merchantService.findByMerchantNo(createPaymentOrderVO.getMerchantNo());
        if (merchant == null) {
            throw new PaymentServiceException("商户不存在");
        }
        String sign = SignUtils.createSign(merchant.getSecretKey(), createPaymentOrderVO);
        createPaymentOrderVO.setSign(sign);
        try {
            String paymentType = createPaymentOrderVO.getPaymentType();
            CreatePaymentOrderResponseOtcVO otcPayOrder = null;
            CreatePaymentOrderResponseVO payOrder = new CreatePaymentOrderResponseVO();
            if (paymentType.equals(PaymentTypeEnum.OTC_ALIPAY.name()) ||
                    paymentType.equals(PaymentTypeEnum.OTC_WEIXIN.name()) ||
                    paymentType.equals(PaymentTypeEnum.OTC_BANK.name()) ||
                    paymentType.equals(PaymentTypeEnum.OTC_QQ.name())) {
                otcPayOrder = commonQrCodeOrderController.otcCreatePayOrder(createPaymentOrderVO, request);
                if (otcPayOrder != null) {
                    payOrder.setReturnMsg(otcPayOrder.getReturnMsg());
                    payOrder.setReturnCode(otcPayOrder.getReturnCode());
                    payOrder.setResultDesc(otcPayOrder.getResultDesc());
                    payOrder.setResultCode(otcPayOrder.getResultCode());
                    payOrder.setPayUrl(otcPayOrder.getPayUrl());
                    payOrder.setUrlType(otcPayOrder.getUrlType());
                }
            } else {
                payOrder = commonQrCodeOrderController.createPayOrder(createPaymentOrderVO, request);
            }
            model.addAttribute("msg", payOrder.getReturnMsg() + "|" + payOrder.getResultDesc());
            model.addAttribute("payUrl", payOrder.getPayUrl());

            if (payOrder.getReturnCode().equals(ReturnCodeEnum.FAIL.name())
                    || PaymentResultCodeEnum.FAIL.name().equals(payOrder.getResultCode())) {
                return "api_gateway/test/pay_fail";
            }
            UrlTypeEnum urlType = UrlTypeEnum.valueOf(payOrder.getUrlType());
            if (urlType == UrlTypeEnum.QR_CODE) {
                String encodePayUrl = URLEncoder.encode(payOrder.getPayUrl(), "UTF-8");
                model.addAttribute("qrPayUrl", encodePayUrl);
                return "api_gateway/test/qr_code_result";
            } else if (urlType == UrlTypeEnum.LINK_FORWORD_QR) {
                String[] linkArray = payOrder.getPayUrl().split("payUrl=");
                String[] payUrlArray = linkArray[1].split("&linkid");
                String encodePayUrl = URLEncoder.encode(payUrlArray[0], "UTF-8");
                String payType = "微信";
                if (paymentType.equals("ALIPAY_QRCODE")) {
                    payType = "支付宝";
                }
                int orderAmount = Integer.valueOf(createPaymentOrderVO.getAmount());
                model.addAttribute("amount", MoneyUtils.fee2yuan(orderAmount));
                model.addAttribute("payType", payType);
                model.addAttribute("qrPayUrl", encodePayUrl);
                return "api_gateway/test/link_forword_result";
            } else if (urlType == UrlTypeEnum.URL || urlType == UrlTypeEnum.PURL || urlType == UrlTypeEnum.H5_MULTIPLE_JUMP) {
                return "api_gateway/test/url_result";
            } else if (urlType == UrlTypeEnum.HTML) {
                return "api_gateway/test/html_result";
            } else if (urlType == UrlTypeEnum.ALI_QR_CODE) {
                String encodePayUrl = URLEncoder.encode(payOrder.getPayUrl(), "UTF-8");
                model.addAttribute("qrPayUrl", encodePayUrl);
                return "api_gateway/test/qr_code_result";
            } else {
                throw new PaymentServiceException("无法识别的urlType:" + urlType.getDesc());
            }
        } catch (PaymentServiceException | PaymentValidException | ParameterVerificationException e) {
            logger.error("创建测试订单失败", e);
            model.addAttribute("msg", e.getMessage());
        } catch (Throwable e) {
            logger.error("创建测试订单失败", e);
            model.addAttribute("msg", "未知的程序异常." + (e.getMessage() == null ? "" : e.getMessage().replace("com.ajl.bfb", "")));
        }
        return "api_gateway/test/pay_fail";
    }

    private List<ChannelAccountVO> toAccountVO(List<ChannelAccount> accounts) {
        ChannelQuery channelQuery = new ChannelQuery();
        List<Channel> channels = channelService.findChannels(channelQuery);
        Map<Integer, String> channelMap = channels.stream().collect(Collectors.toMap(Channel::getId, Channel::getName));
        List<ChannelAccountVO> channelAccountVOS = ChannelAccountViewUtils.toVO(accounts);
        for (ChannelAccountVO acc : channelAccountVOS) {
            acc.setChannelName(channelMap.get(acc.getChannelId()));
        }
        return channelAccountVOS;
    }
}
