package com.ajl.bfb.api.common.controller;

import com.ajl.bfb.api.common.vo.BaseResponseVO;
import com.ajl.bfb.api.config.ApiGatewayExceptionHandlerAdvice;
import com.ajl.bfb.core.constants.ReturnCodeEnum;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@Controller
@RequestMapping(value="/api_gateway/error")
public class ApiGatewayErrorController {

    private static final Logger logger = LogManager.getLogger(ApiGatewayErrorController.class);




    @RequestMapping(path = "/ajax-http404")
    @ResponseBody
    public BaseResponseVO ajaxHttp404(HttpServletRequest request, HttpServletResponse response) {
        response.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
        BaseResponseVO r = new BaseResponseVO();
        r.setNonceStr(System.currentTimeMillis() + "");
        r.setReturnCode(ReturnCodeEnum.FAIL.name());
        r.setReturnMsg("你访问的资源不存在");
        return r;
    }

    @RequestMapping(path = "/ajax-http500")
    @ResponseBody
    public BaseResponseVO ajaxHttp500(HttpServletRequest request, HttpServletResponse response) {
        Object exception = request.getAttribute(ApiGatewayExceptionHandlerAdvice.EXCEPTION_KEY);
        response.setStatus(HttpStatus.OK.value());
        BaseResponseVO r = new BaseResponseVO();
        r.setNonceStr(System.currentTimeMillis() + "");
        r.setReturnCode(ReturnCodeEnum.FAIL.name());
        r.setReturnMsg(exception == null?"": extractErrorMsg((Throwable)exception));
        return r;
    }

    private String extractErrorMsg(Throwable exception) {
        if (StringUtils.isNotBlank(exception.getMessage())) {
            return exception.getMessage();
        }
        return "未知的程序异常.";
    }

}
