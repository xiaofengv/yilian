package com.ajl.bfb.api.commonpay.vo;

import com.ajl.bfb.api.common.vo.BaseResponseVO;
import lombok.Data;

import java.io.Serializable;

@Data
public class CreatePaymentOrderResponseOtcVO extends BaseResponseVO implements Serializable {



    private String platformOrderNo;

    private String mchOrderNo;


    private String resultCode;

    private String resultDesc;

    private String payUrl;


    private String urlType;

    private String feedbackUrl;

}
