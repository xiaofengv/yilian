package com.ajl.bfb.api.commonpay.util;

/**
 * Created by Administrator on 2019/5/27.
 */
public class AlipaySignKey {
    public static String yy_key="MIIEvAIBADANBgkqhkiG9w0BAQEFAASCBKYwggSiAgEAAoIBAQCgcPnGD6LoCoKr\n" +
            "EbduF0JKVOMEWLxwcSVbsRwi/mlbi+VA19o8rjcNBK37CZJ1ZOQpGXN5ztMuAz+8\n" +
            "4Ql9NGD8IG0/V9LOuL63tRsvQSlo4cnOfGFGitZrjXeSJze3M82RlvMuDQ66ML8Y\n" +
            "kuMaDXOcKLe+9dxcmGjUJht0MRSz9+lrg2hiW7T9N3KoUeZvfbD/yV8rSvt4Dnqb\n" +
            "fkS/X4LUgpUgmatz4S4Ezk6LLZDaF3e+yWWgblDRDnRs10IQSnb9wj2zSJGBqGXo\n" +
            "/dC6bpS8go49mEldITzERUEYynrVtaM14YaUm6AwAUiMtBLSt9d1GecCZ711FQiW\n" +
            "23zxc1ORAgMBAAECggEAIB09AbYTh5rC+Pb83l5teG9xWWdhoKglMCtNVHvUHuzr\n" +
            "oIUUO90rS8HKCVurIzBksw1THeiWQLmJwobQ3WzklNLwyyMLITG9iwwHOvgyD7pS\n" +
            "KLCgz/vuW2zfqDONZXBLD39Fgcw/TGmBdqvAJXDX2UQVM3YG+8nOAdj22dURLcx6\n" +
            "gytruiK8kXj9N+i/l3uPzluP396jmDmEIMH7PyQTViTGjVwq4AQjajxfjRlDSDqc\n" +
            "Y/2QdhAs2S3nIl988+IMpoY/wfQHyQqn2iKsn3pIldxsOTNbXh3b7aqy5b5M+Sur\n" +
            "Od/YUNib21iqsmdha5u/g3DA3XuFpS37CIdulD9SmQKBgQDU7PT7SDw1lFXrBjoO\n" +
            "b7UdNfVk07sOdnfc2V22x6+coB+RlAmeLWB1tBDXovB53HwG3EE3ooy65kO2rJeG\n" +
            "CCbA9nntntxcvrHmTUGNbn1Ubeiw2t0UEzs1MeQI6z3SMBDHT0Hp3WKhGQMNerHV\n" +
            "yB39I+iXpsMQvsaVtWYRpxljCwKBgQDA5fLzagJUCvuMsIj2oiqOrU8nMvEVMMsa\n" +
            "7FsZmJ9XT26/mDf+rKoabixQlvYqDCDpog4BgSC4CtI6moiUCbheAPsk8oJrYhS6\n" +
            "w01I6f9hAvrGhW/8UIx+O7hc+ZOhl8aSzlNh2C9rmFRUsUBC1m8DvoLqnbbNP+9J\n" +
            "446mbXsFUwKBgBmyIvp0RDffF+NOFBGL75p/2YZ6eteK+nofjUyymoHXXRfvep2p\n" +
            "MjviKCot0sGSFzGowQIazsr7YO6Zs4uMTkj5Ncu0YTmcFdIKPr/3to5K2UsGjqmO\n" +
            "jJWl2LQu134XKN80tGqpue5hG1o0FWQMS3oyLC6pBF9v9n04sAGvXcPzAoGAInUx\n" +
            "OBA4yECJ/PDQFpaTWZdV61+rNyjXL0EHaQQdeqBC3VDYt9KqNDx4CBFfedVez71W\n" +
            "GSiy6o1sTnGqch9mYsx0EH6Nk5cast4OYTcDmpXIrEvL3FubLTWH0nv2xkfxfeoD\n" +
            "dRgEKIk2j0Z2fzoE7LtMcZKow/Nm0GEo60vlTOcCgYAZoVSKpxaXrg5L/ZBLSDE3\n" +
            "r8VApPTaRTAtQJeYM+/fZ/X6H4LWRUE7pa2OCe1vMXKDHc1wDMINPfiPx3wXsNn8\n" +
            "WkYKyGC1bggN8BMGwbjv1nG5fNnpx2OR7+FOHNPs95sZJPfZwZ+5bMS6BZsetfTj\n" +
            "sGTrr7ethjdMVp3WXAWFJQ==";
    public static String zfb_key="MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAm61cdpstmdGT4iVi3iHhDu6KyeFU6th964nrkTiDaYMaUsGzozVzVzfBQjjMIlA2CjSRoUqQW6wr0tv7logbWKy6g86UvmUCI4fy8O4/SjqZrcqvamTj4TG+iOd9Rt+us+terXPcE1bOBU/sq4jT+OioEBk2OCZACW4QYlMDZNhWKPtfAt3xgKzzGZ0GdGbOfZxV2pdxaG4xFENch1ehJh7dOFsLQ9szb2vl3ZmSAaJkeLG32+GaiSGEZB5cdl6XJ3XJUD5vZI/yT7IPAJvvubZZd/DZXqc54JexNGDYClsRYy4awTzzcEP4qWk0s6nh7mwjvxUKyrd8gUzIZfe4jQIDAQAB";

    public static String new_privatekey = "MIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQCNYh//CyrRhtnXTYM9i7sBpNUbiNG4F803rA33mvSFRraBjvR1+ANYCvYx39fn1M2maAmYkGToLSc5/P0+/lEoTzWYtMGq7p1bDlT78JQr64aBk8vrlJvVUE4nOyaCiUjb9JbPzrsOi2/+BJrn0cskCYOO+0w0r7BednYsusdoT0QfjklriYf1vX+hNRzZjoaQN2mpkGHvGFpETn34TRlDJW9Dvt3qfywbd0bqAtfde4F+IKztdLstQh9A31SjsOF/+sflMVM1lNRf9fMntRy0cjU/Dez2xhlutfzuod6pwhtpMaeVoHCMXOnwWB6OAJtCDpAD/JjNwJMGJowHkERBAgMBAAECggEBAIiJufK5mylsPNazkcoPNpN41yHXOQm7WsGoFHkKGZjYWIq4PxfqY3hUZbx2u3C1T8Gj+Zhv4jNi394dl4iNXF08WbtW3S2xcR+tsJ76kG318BkVXbrt8qzH+CHk+uTXphhdloOr13RNbuN3GQ5FyhPMaFPeFpNPFFm1t5ys6MSvUNB4F4hBhthR5wHFYWBFGrS50MZ9WdzngqZB2Ar3Dxok7ei07HoSf2PX3Dv7Lw669WxyaIkgnhC00LvJELuT4cScBvKCvVdhmIsR8PfpOYHHv7pIXkG7IGQooFHFlgv14ZVFhzo9g5gNaSdj9MWgSMOeKxYDR0/wf5MBzw6af5ECgYEAwPRHWEFl2b8etdwslNrwTbeeURTITp3BrUypg9qBsNglbSIhBmBU5wL0OPGRhKFW27rA2vNDBTY0EPcbmtfTkPwYB3ywUQTDJifriLtxmCVGjXkSdJBCewd7geAJsJ5TAuQ5NDayRN3zsa5LvqL5cKAzwXEgmgLTu2cudH7i2/0CgYEAu5Qt+0Vr3zJVc04bNaXTEEPkf1BlPC5wPqRgQjAEGYLR3WwO0ynKIIFJo2DWZpTj5tF4nGXKHlDWh+vUJ1fluObQg+2VXd6ubzO/R3jpPGl3w7TpruAizT2wLLMJWracTnPInmiVEn77R/DGild7McBinNJgp9YkZlHdi6u7QpUCgYEAjco0Lz+Hd7ZA/AS6Yfxs/79BwHVUKKk2rIGcQ78q9GgxQHwG5qedXFDIZJvngh4JNNiMZZjDFC5bnmfnyiZ1WqJVihLvgenM+dn18/lCJTqnGMjybeOgZsX91Vdr53TArWxGOP9EiuTK8jORh5o9UKz4u1rFSUdwjdLpyUOAs4UCgYBAB6Xmhtz6tHDMylWpa3Bvte0ytFvKPkPcbjnZfhB4MNq4jaFF3Zb8n4VmerDVFW/yI4DbSjfDP27ruMmToIJvKoL09c2t3EyI8w4RNKnREGNsb73xDttyWeNgbsD7sSgL86QAxsxUIvpdpUfwg0ovQm+m/n017XhBYSKSAc4LPQKBgEcqEeUKZQ2RuzKUZuv07rmUL9ey275BI+pPUDmMkyPA/7w9vtCcjsnj+mgBcgVfGtR7pDrZj8lGvxMS1ZOJLvG8Kmjee63RA9o/mJGGoFiRBGOek1B+BwchQ8+ZEpuZhAivkN0TYJUZjN3/E61JMKfgMDm/WbBamklyw1naZcVS";
    public static String new_zfb_key = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAm61cdpstmdGT4iVi3iHhDu6KyeFU6th964nrkTiDaYMaUsGzozVzVzfBQjjMIlA2CjSRoUqQW6wr0tv7logbWKy6g86UvmUCI4fy8O4/SjqZrcqvamTj4TG+iOd9Rt+us+terXPcE1bOBU/sq4jT+OioEBk2OCZACW4QYlMDZNhWKPtfAt3xgKzzGZ0GdGbOfZxV2pdxaG4xFENch1ehJh7dOFsLQ9szb2vl3ZmSAaJkeLG32+GaiSGEZB5cdl6XJ3XJUD5vZI/yT7IPAJvvubZZd/DZXqc54JexNGDYClsRYy4awTzzcEP4qWk0s6nh7mwjvxUKyrd8gUzIZfe4jQIDAQAB\n";
}
