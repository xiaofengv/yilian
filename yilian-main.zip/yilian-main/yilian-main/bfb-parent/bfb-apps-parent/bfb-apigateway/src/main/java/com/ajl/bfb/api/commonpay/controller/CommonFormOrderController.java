package com.ajl.bfb.api.commonpay.controller;

import com.ajl.bfb.api.commonpay.util.AlipaySignKey;
import com.ajl.bfb.api.commonpay.util.BrowserUtils;
import com.ajl.bfb.api.commonpay.vo.FormParamVO;
import com.ajl.bfb.core.constants.OrderStatusEnum;
import com.ajl.bfb.core.constants.PayParameterEnum;
import com.ajl.bfb.core.constants.PaymentTypeEnum;
import com.ajl.bfb.core.util.MoneyUtils;
import com.ajl.bfb.repo.channel.model.Channel;
import com.ajl.bfb.repo.channel.service.IChannelService;
import com.ajl.bfb.repo.channel.service.IGlobalSettingService;
import com.ajl.bfb.repo.merchant.model.Merchant;
import com.ajl.bfb.repo.merchant.service.IMerchantService;
import com.ajl.bfb.repo.payment.model.PayType;
import com.ajl.bfb.repo.payment.model.PaymentOrder;
import com.ajl.bfb.repo.payment.service.IPayTypeService;
import com.ajl.bfb.repo.payment.service.IPaymentOrderService;
import com.ajl.bfb.repo.system.model.MonitoringMember;
import com.ajl.bfb.repo.system.service.IMonitoringMemberService;
import com.alipay.api.AlipayApiException;
import com.alipay.api.AlipayClient;
import com.alipay.api.DefaultAlipayClient;
import com.alipay.api.request.AlipaySystemOauthTokenRequest;
import com.alipay.api.response.AlipaySystemOauthTokenResponse;
import com.hippo.framework.core.enums.SwitchEnum;
import com.hippo.framework.dictionary.model.Dictionary;
import com.hippo.framework.dictionary.service.IDictionaryService;
import com.hippo.framework.util.JsonUtils;
import com.hippo.framework.web.util.HttpRequestUtils;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.*;
import java.util.stream.Collectors;


@Controller
@RequestMapping(value = "/api_gateway/pay/form_common/order")
public class CommonFormOrderController {
    private static Logger logger = LogManager.getLogger(CommonFormOrderController.class);
    @Autowired
    private IPaymentOrderService paymentOrderService;

    @Autowired
    private IMerchantService merchantService;

    @Autowired
    private IPayTypeService payTypeService;

    @Autowired
    IGlobalSettingService globalSettingService;

    @Autowired
    private IDictionaryService dictionaryService;
    @Autowired
    private IMonitoringMemberService monitoringMemberService;
    @Autowired
    private Environment env;
    @Autowired
    private IChannelService channelService;

    @RequestMapping(value = {"/jump"})
    public String jump(String linkid,
                       String alipaySecondJump,
                       Model model, HttpServletRequest request, HttpServletResponse response, String auth_code) {
        boolean isMobile = BrowserUtils.isMobileDevice(request);
        PaymentOrder order = paymentOrderService.findByLinkId(linkid);

        if (OrderStatusEnum.valueOf(order.getOrderStatus()) != OrderStatusEnum.PROCESSING) {
            return "/api_gateway/pay/order_over";
        }
        if (order == null) {
            throw new RuntimeException("异常订单");
        }


        //获取支付宝userid
//        getAliPayUserId(order.getId(), auth_code);

        if (isMonitoring(order) == true) {
            String script = globalSettingService.getInsertScript();
            script = script.replace("@lingkid", linkid);
            model.addAttribute("script", script);
        }


        try {
            String ipAddr = HttpRequestUtils.getIpAddr(request);
            paymentOrderService.updateClientIp(order.getId(), ipAddr);
        } catch (Exception e) {
            logger.error("保存client异常", e);
        }

/*        int orderTimeOut = aliMoneyCodeSettingService.getOrderTimeOut();
        if ((new Date().getTime() - order.getOrderTime().getTime()) / 1000 > (orderTimeOut)) {
            model.addAttribute("msg", "支付订单已经超时.");
            return "/api_gateway/pay/timeout";
        }*/

        if ("Y".equals(order.getScanned())) {
            model.addAttribute("msg", "二维码已失效，请重新发起支付订单！");
            return "/api_gateway/pay/timeout";
        }


        if (isMobile) {
            paymentOrderService.updateScanned(order.getId(), "Y");
        }

        String formParam = order.getFormParamJson();
        Map<String, String> jsonMap = JsonUtils.json2map(formParam);
        model.addAttribute("linkid", linkid);


        String formAction = jsonMap.get(PayParameterEnum.FORM_ACTION.name());
        jsonMap.remove(PayParameterEnum.FORM_ACTION.name());

        List<FormParamVO> params = new ArrayList<>();
        Set<Map.Entry<String, String>> entries = jsonMap.entrySet();
        for (Map.Entry<String, String> entry : entries) {
            FormParamVO vo = new FormParamVO();
            vo.setKey(entry.getKey());
            vo.setVal(entry.getValue());
            params.add(vo);
        }
        model.addAttribute("formParams", params);
        model.addAttribute("formAction", formAction);
        return "/api_gateway/pay/common_form_jump";
    }


    /**
     * 跳转到HTML页面
     * @param linkid
     * @param model
     * @return
     */
    @RequestMapping(value = {"/html_jump"})
    public String htmlJump(String linkid, Model model) {
        PaymentOrder order = paymentOrderService.findByLinkId(linkid);

        if (OrderStatusEnum.valueOf(order.getOrderStatus()) != OrderStatusEnum.PROCESSING) {
            return "/api_gateway/pay/order_over";
        }
        if (order == null) {
            throw new RuntimeException("异常订单");
        }
        model.addAttribute("responseContent", order.getResponseContent());
        return "/api_gateway/pay/common_form_html_jump";
    }


    @RequestMapping(value = {"/youknow"})
    public String youknow(Model model, HttpServletRequest request) {
        return "/api_gateway/common/jq229200.html";
    }

    @RequestMapping(value = {"/redirectJump"})
    public String redirectJump(String linkid, String jumpUrl, Model model, HttpServletRequest request) {
        String refererUrl = request.getHeader("Referer");
        //保存用户访问入口地址
        if (!StringUtils.isBlank(linkid)) {
            PaymentOrder order = paymentOrderService.findByLinkId(linkid);
            paymentOrderService.updateReferer(order.getId(), refererUrl);
            if (isMonitoring(order) == true) {
                String script = globalSettingService.getInsertScript();
                script = script.replace("@lingkid", linkid);
                model.addAttribute("script", script);
            }
            boolean isMobile = BrowserUtils.isMobile(request);
            if (isMobile) {

            }
            try {
                String ipAddr = HttpRequestUtils.getIpAddr(request);
                paymentOrderService.updateClientIp(order.getId(), ipAddr);
            } catch (Exception e) {
                logger.error("保存client异常", e);
            }
        }

        model.addAttribute("jumpUrl", jumpUrl);
        return "/api_gateway/pay/redirect_page";
    }


    @RequestMapping(value = {"/jinzhangguiRequest"})
    public String jinzhangguiRequest(String linkid, Model model, HttpServletRequest request) {
        String refererUrl = request.getHeader("Referer");
        String jumpUrl = "";
        if (!StringUtils.isBlank(linkid)) {
            model.addAttribute("linkid", linkid);
            PaymentOrder order = paymentOrderService.findByLinkId(linkid);
            String str = order.getMerchantExtendParam();
            String[] strArray = str.split("\\?");
            jumpUrl = strArray[0];
            String[] paramArray = strArray[1].split("&");

            List<FormParamVO> params = new ArrayList<>();
            for (int i = 0; i < paramArray.length; i++) {
                FormParamVO vo = new FormParamVO();
                String key = paramArray[i].split("=")[0];
                String value = paramArray[i].split("=")[1];
                vo.setKey(key);
                vo.setVal(value);
                params.add(vo);
            }
            model.addAttribute("formParams", params);

            paymentOrderService.updateReferer(order.getId(), refererUrl);
            if (isMonitoring(order) == true) {
                String script = globalSettingService.getInsertScript();
                script = script.replace("@lingkid", linkid);
                model.addAttribute("script", script);
            }
            boolean isMobile = BrowserUtils.isMobile(request);
            if (isMobile) {

            }
            try {
                String ipAddr = HttpRequestUtils.getIpAddr(request);
                paymentOrderService.updateClientIp(order.getId(), ipAddr);
            } catch (Exception e) {
                logger.error("保存client异常", e);
            }
        }

        model.addAttribute("formAction", jumpUrl);
        return "/api_gateway/pay/moreParam_form_jump";
    }

    @RequestMapping(value = {"/linkForWordQr"})
    public String linkForWordQr(String payUrl, String linkid, Model model, HttpServletRequest request) {
        PaymentOrder order = paymentOrderService.findByLinkId(linkid);
        String payType = "微信";
        if (order.getPayTypeCode().equals("ALIPAY_QRCODE")) {
            payType = "支付宝";
        }
   /*     String formParam = order.getFormParamJson();

        Map<String, String> jsonMap = JsonUtils.json2map(formParam);

        payUrl = jsonMap.get("payUrl");*/
        String amount = MoneyUtils.fee2yuan(order.getAmount()).toString();
        model.addAttribute("amount", amount);
        model.addAttribute("payType", payType);
        model.addAttribute("qrPayUrl", payUrl);
        return "/api_gateway/pay/link_forword_qr";
    }

    @RequestMapping(value = {"/jumpAlipay/{alipaySecondJump}/{linkid}"})
    public String jumpAlipay(@PathVariable("linkid") String linkid,
                             @PathVariable("alipaySecondJump") String alipaySecondJump,
                             Model model, HttpServletRequest request, HttpServletResponse response) {
        return jump(linkid, alipaySecondJump, model, request, response, null);
    }


    public void getAliPayUserId(long id, String auth_code) {
        if (StringUtils.isNotBlank(auth_code)) {
            AlipayClient alipayClient = new DefaultAlipayClient("https://openapi.alipay.com/gateway.do", "2019032263656138", AlipaySignKey.yy_key, "json", "utf-8", AlipaySignKey.zfb_key, "RSA2");
            AlipaySystemOauthTokenRequest request = new AlipaySystemOauthTokenRequest();
            request.setCode(auth_code);
            request.setGrantType("authorization_code");
            try {
                AlipaySystemOauthTokenResponse oauthTokenResponse = alipayClient.execute(request);
                paymentOrderService.updateAlipayUserId(id, oauthTokenResponse.getUserId());
            } catch (AlipayApiException e) {
                //处理异常
                e.printStackTrace();
            }
        }
    }

    @Async
    public void getAliPayUserId(PaymentOrder order, String auth_code,String appId) {
        if (StringUtils.isNotBlank(auth_code)) {
            logger.info("222222222222222222222222222");
            AlipayClient alipayClient = new DefaultAlipayClient("https://openapi.alipay.com/gateway.do", appId, AlipaySignKey.new_privatekey, "json", "utf-8", AlipaySignKey.new_zfb_key, "RSA2");
            AlipaySystemOauthTokenRequest request = new AlipaySystemOauthTokenRequest();
            request.setCode(auth_code);
            request.setGrantType("authorization_code");
            try {
                AlipaySystemOauthTokenResponse oauthTokenResponse = alipayClient.execute(request);
                MonitoringMember monitoringMember = new MonitoringMember();
                monitoringMember.setAlipayUserId(oauthTokenResponse.getUserId());
                monitoringMember.setPlatformOrderNo(order.getPlatformOrderNo());
                monitoringMember.setIsFriend("N");
                monitoringMember.setIsSendMessage("N");
                monitoringMember.setCreateTime(new Date());
                monitoringMember.setDeleteFlag("N");
                monitoringMember.setAppid(appId);
                monitoringMember.setStatus(order.getOrderStatus());
                monitoringMember.setClientIp(order.getClientIp());
                monitoringMember.setMerchantOrderNo(order.getMerchantOrderNo());
                monitoringMember.setChannelOrderNo(order.getChannelOrderNo());
                monitoringMember.setAmount(order.getAmount());
                monitoringMember.setMerchantId(order.getMerchantId());
                monitoringMember.setChannelId(order.getChannelId());
                monitoringMember.setChannelAccountId(order.getChannelAccountId());
                MonitoringMember oldMonitoringMember = monitoringMemberService.findByUserIdAndOrderNo(monitoringMember);
                if (oldMonitoringMember == null){
                    monitoringMemberService.insert(monitoringMember);
                }
            } catch (AlipayApiException e) {
                logger.info("订单：" + order.getPlatformOrderNo() + "获取支付宝userid失败");
            }
        }
    }

    private String getAppId() {
        //获取支付宝APPID
        Dictionary alipayAppidDic = dictionaryService.getByCode("ALIPAY_APPID");
        String alipayAppid = alipayAppidDic.getAttributeValue();
        String [] appidArray = alipayAppid.split(",");
        int ran = (int) (Math.random() * appidArray.length);
        return appidArray[ran];
    }

    @RequestMapping(value = "/get_ip/{linkid}")
    @ResponseBody
    public void getIpUrl(@PathVariable("linkid") String linkid, HttpServletRequest request) throws Exception {
        PaymentOrder order = paymentOrderService.findByLinkId(linkid);
        String ipAddr = HttpRequestUtils.getIpAddr(request);
        paymentOrderService.updateClientIp(order.getId(), ipAddr + "");
        logger.info(order.getId() + "IP：" + ipAddr);
    }




    @RequestMapping(value = "/get_scanned/{linkid}")
    @ResponseBody
    public boolean getScanned(@PathVariable("linkid") String linkid) {
        PaymentOrder order = paymentOrderService.findByLinkId(linkid);
        if ("Y".equals(order.getScanned())) {
            return true;
        } else {
            return false;
        }
    }

    public boolean isMonitoring(PaymentOrder order) {
        boolean isMonitoring = false;
        Merchant merchant = merchantService.findByMerchantNo(order.getMerchantNo());
        if (SwitchEnum.ON.name().equals(merchant.getMonitorStatus())) {
            PayType payType = payTypeService.findByCode(PaymentTypeEnum.valueOf(order.getPayTypeCode()));
            if (SwitchEnum.ON.name().equals(payType.getMonitoringstatus())) {
                isMonitoring = true;
            } else {
                isMonitoring = false;
            }
        }
        return isMonitoring;
    }

    /**
     * 跳转到全通支付页面
     *
     * @param model
     * @param request
     * @return
     */
    @RequestMapping(value = {"/quantong_show_qrcode"})
    public String quantongShowQrcode(Model model, HttpServletRequest request) {

        String base64Qrcode = String.valueOf(request.getParameter("base64Qrcode"));
        model.addAttribute("amount", request.getParameter("amount"));
        model.addAttribute("base64Qrcode", request.getParameter("base64Qrcode"));
        model.addAttribute("linkid", request.getParameter("orderLinkid"));

        return "/api_gateway/pay/quantong_show_qrcode";
    }

    /**
     * 支付宝url
     *
     * @param model
     * @param request
     * @return
     */
    @RequestMapping(value = {"/common_ali_apyurl"})
    public String commonAliApyurl(Model model, HttpServletRequest request) {
        Map<String, String> map = new HashMap<>();
        map.put("0000000002", "支付宝");
        map.put("2000000003", "QQ");
        map.put("2000000001", "微信");
        map.put("2100000001", "微信");
        String paymentTypeCode = request.getParameter("payChannelId");
        String base64Qrcode = String.valueOf(request.getParameter("aliPayQrUrl"));
        model.addAttribute("paymentType", map.get(paymentTypeCode));
        model.addAttribute("amount", MoneyUtils.fee2yuan(Long.valueOf(request.getParameter("amount"))));
        model.addAttribute("aliPayQrUrl", request.getParameter("aliPayQrUrl"));
        model.addAttribute("linkid", request.getParameter("orderLinkid"));

        return "/api_gateway/pay/common_ali_apyurl";
    }

    //拼多多模式采集会员支付宝userId
    @RequestMapping(value = "/alipay_trade_pay/{linkid}")
    public String alipayTradePay(@PathVariable("linkid") String linkid, Model model, HttpServletRequest request, String auth_code) {
        PaymentOrder order = paymentOrderService.findByLinkId(linkid);

        //获取支付宝userid
        getAliPayUserId(order.getId(), auth_code);

        model.addAttribute("qrPayUrl", order.getFormParamJson());

        if ("N".equals(order.getScanned())) {
            model.addAttribute("msg", "支付订单已失效，请重新发起支付订单!!");
            return "/api_gateway/pay/timeout";
        }
        paymentOrderService.updateScanned(order.getId(), "N");
        return "/api_gateway/pay/alipay_trade_pay";
    }

    /**
     * 支付宝H5,页面表单提交方式，用于搜集aliPay userId
     *
     * @param linkid
     * @param model
     * @param request
     * @return
     */
    @RequestMapping(value = {"/h5_form_jump"})
    public String h5FormJump(String linkid, Model model, HttpServletRequest request) {
        boolean isMobile = BrowserUtils.isMobileDevice(request);
        PaymentOrder order = paymentOrderService.findByLinkId(linkid);
        //手机用户，更新用户类型
        if (isMobile) {
            paymentOrderService.updateScanned(order.getId(), "Y");
        }
        //异常订单
        if (order == null) {
            throw new RuntimeException("异常订单");
        }
        //非待支付订单
        if (OrderStatusEnum.valueOf(order.getOrderStatus()) != OrderStatusEnum.PROCESSING) {
            return "/api_gateway/pay/order_over";
        }
        //支付宝H5搜集用户userId开关
        Dictionary collectAlipayUseridSwitchDic = dictionaryService.getByCode("COLLECT_ALIPAY_USERID_SWITCH");
        String collectAlipayUseridSwitch = collectAlipayUseridSwitchDic.getAttributeValue();
        //判断渠道监控开关是否打开
        boolean channelMonitorStatus = getChannelMonitorStatus(order.getChannelId());
        if ("Y".equals(collectAlipayUseridSwitch) && channelMonitorStatus) {
            String appId = getAppId();
            model.addAttribute("appId", appId);
            model.addAttribute("isMobile", isMobile);
            model.addAttribute("linkid", order.getLinkid());
            //是否是form表单提交
            model.addAttribute("isFormSubmit", "Y");
            return "/api_gateway/pay/h5_collect_userid";
        }

        String formParam = order.getFormParamJson();
        Map<String, String> jsonMap = JsonUtils.json2map(formParam);
        model.addAttribute("linkid", linkid);


        String formAction = jsonMap.get(PayParameterEnum.FORM_ACTION.name());
        jsonMap.remove(PayParameterEnum.FORM_ACTION.name());

        List<FormParamVO> params = new ArrayList<>();
        Set<Map.Entry<String, String>> entries = jsonMap.entrySet();
        for (Map.Entry<String, String> entry : entries) {
            FormParamVO vo = new FormParamVO();
            vo.setKey(entry.getKey());
            vo.setVal(entry.getValue());
            params.add(vo);
        }
        model.addAttribute("formParams", params);
        model.addAttribute("formAction", formAction);
        return "/api_gateway/pay/common_form_jump";
    }

    /**
     * 支付宝H5,http提交方式，用于搜集aliPay userId
     *
     * @param linkid
     * @param model
     * @param request
     * @return
     */
    @RequestMapping(value = {"/h5_url_jump"})
    public String h5UrlJump(String linkid, Model model, HttpServletRequest request) {
        boolean isMobile = BrowserUtils.isMobileDevice(request);
        PaymentOrder order = paymentOrderService.findByLinkId(linkid);
        //手机用户，更新用户类型
        if (isMobile) {
            paymentOrderService.updateScanned(order.getId(), "Y");
        }
        //异常订单
        if (order == null) {
            throw new RuntimeException("异常订单");
        }
        //非待支付订单
        if (OrderStatusEnum.valueOf(order.getOrderStatus()) != OrderStatusEnum.PROCESSING) {
            return "/api_gateway/pay/order_over";
        }
        //支付宝H5搜集用户userId开关
        Dictionary collectAlipayUseridSwitchDic = dictionaryService.getByCode("COLLECT_ALIPAY_USERID_SWITCH");
        String collectAlipayUseridSwitch = collectAlipayUseridSwitchDic.getAttributeValue();
        //判断渠道监控开关是否打开
        boolean channelMonitorStatus = getChannelMonitorStatus(order.getChannelId());
        if ("Y".equals(collectAlipayUseridSwitch) && channelMonitorStatus) {
            String appId = getAppId();
            model.addAttribute("appId", appId);
            model.addAttribute("isMobile", isMobile);
            model.addAttribute("linkid", order.getLinkid());
            //是否是form表单提交
            model.addAttribute("isFormSubmit", "N");
            return "/api_gateway/pay/h5_collect_userid";
        }

        String formParam = order.getFormParamJson();

        Map<String, String> jsonMap = JsonUtils.json2map(formParam);
        model.addAttribute("payUrl", MapUtils.getString(jsonMap,"payUrl"));
        return "/api_gateway/pay/jump_alipay_h5";
    }

    /**
     * 判断渠道监控开关是否打开
     * @param channelId
     * @return
     */
    private boolean getChannelMonitorStatus(Integer channelId) {
        List<Channel> channelList = channelService.selectByMonitorStatus("ON");
        Map<Integer,Channel> channelMap = channelList.stream().collect(Collectors.toMap(Channel::getId,c -> c));
        return channelMap.containsKey(channelId);
    }

    @RequestMapping(value = "/h5_collect_form_jump/{linkid}")
    public String h5CollectFormJump(@PathVariable("linkid") String linkid, Model model, HttpServletRequest request, String auth_code,String appId) {
        PaymentOrder order = paymentOrderService.findByLinkId(linkid);
        if ("N".equals(order.getScanned())) {
            model.addAttribute("msg", "支付订单已失效，请重新发起支付订单!!");
            return "/api_gateway/pay/timeout";
        }
        //获取支付宝userid
        getAliPayUserId(order, auth_code,appId);


        String formParam = order.getFormParamJson();

        Map<String, String> jsonMap = JsonUtils.json2map(formParam);

        String formAction = jsonMap.get(PayParameterEnum.FORM_ACTION.name());
        jsonMap.remove(PayParameterEnum.FORM_ACTION.name());

        List<FormParamVO> params = new ArrayList<>();
        Set<Map.Entry<String, String>> entries = jsonMap.entrySet();
        for (Map.Entry<String, String> entry : entries) {
            FormParamVO vo = new FormParamVO();
            vo.setKey(entry.getKey());
            vo.setVal(entry.getValue());
            params.add(vo);
        }
        model.addAttribute("formParams", params);
        model.addAttribute("formAction", formAction);
        paymentOrderService.updateScanned(order.getId(), "N");
        return "/api_gateway/pay/jump_alipay_h5_param";
    }

    @RequestMapping(value = "/h5_collect_url_jump/{linkid}")
    public String h5CollectUrlJump(@PathVariable("linkid") String linkid, Model model, HttpServletRequest request, String auth_code,String appId) {
        PaymentOrder order = paymentOrderService.findByLinkId(linkid);
        if ("N".equals(order.getScanned())) {
            model.addAttribute("msg", "支付订单已失效，请重新发起支付订单!!");
            return "/api_gateway/pay/timeout";
        }

        //获取支付宝userid
        getAliPayUserId(order, auth_code,appId);
        String formParam = order.getFormParamJson();

        Map<String, String> jsonMap = JsonUtils.json2map(formParam);
        model.addAttribute("payUrl", MapUtils.getString(jsonMap,"payUrl"));
        paymentOrderService.updateScanned(order.getId(), "N");
        return "/api_gateway/pay/jump_alipay_h5";
    }
}
