
$(function(){
    var currentMenuCodeInCookie =  $.cookie('currentMenuCode');
    console.log('currentMenuCodeInCookie::' + currentMenuCodeInCookie);
    if (currentMenuCodeInCookie == null || currentMenuCodeInCookie == '') {
        console.log('cannot found currentMenuCode in cookie');
        return;
    }
    $("li[currentMenuCode]").each(function(){
        if(currentMenuCodeInCookie == $(this).attr('currentMenuCode')) {

            $(this).addClass('active');

            $(this).parent().parent().addClass('open');
        }
    });


    $("#treeMenu").children("li").each(function(){
        var subMenus = $(this).find("li[currentMenuCode]");
        if (subMenus.length == 0) {
            $(this).hide();
        }
    });
});