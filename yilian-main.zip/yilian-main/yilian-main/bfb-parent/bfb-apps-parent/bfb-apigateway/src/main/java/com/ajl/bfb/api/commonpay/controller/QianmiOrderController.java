package com.ajl.bfb.api.commonpay.controller;

import com.ajl.bfb.api.commonpay.vo.FormParamVO;
import com.ajl.bfb.core.cache.RedisService;
import com.ajl.bfb.core.constants.OrderStatusEnum;
import com.ajl.bfb.repo.channel.service.IGlobalSettingService;
import com.ajl.bfb.repo.payment.model.PaymentOrder;
import com.ajl.bfb.repo.payment.service.IPaymentOrderService;
import com.alibaba.fastjson.JSON;
import com.hippo.framework.util.JsonUtils;
import com.hippo.framework.web.util.WebPathUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;


@Controller
@RequestMapping(value = "/api_gateway/qianmi")
public class QianmiOrderController {
    private static Logger logger = LogManager.getLogger(QianmiOrderController.class);
    @Autowired
    private IPaymentOrderService paymentOrderService;

    @Autowired
    IGlobalSettingService globalSettingService;

    @Autowired
    private RedisService redisService;

    private final String rdk = "QM_";
    // redis缓存时间（分钟）
    private final int REDIS_TIMES_MINUTES = 10;

    /**
     * 跳转到HTML展示二维码
     * @param linkid
     * @param model
     * @return
     */
    @RequestMapping(value = {"/qianmi_jump"})
    public String qianmiJump(String linkid, Model model, HttpServletRequest request) {
        // 将数据存储在redis10分钟
        String redisKey = rdk + linkid;
        if(redisService.existsKey(redisKey)){
            String result = redisService.getKeyForValue(redisKey);
            PaymentOrder order = JSON.parseObject(result,PaymentOrder.class);
        }else{
            PaymentOrder order = paymentOrderService.findByLinkId(linkid);
            redisService.setKeyForValue(redisKey, JSON.toJSON(order).toString(), REDIS_TIMES_MINUTES, TimeUnit.MINUTES);
        }
        String servicePath = WebPathUtils.getWebBasePath(request);
        //String servicePath = "http://helloword.natapp1.cc";
        model.addAttribute("payUrlCode", servicePath + "/api_gateway/qianmi/qianmi_pay/?linkid=" + linkid);
        return "/api_gateway/pay/qianmi_jump";
    }

    /**
     * 解析二维码跳转到收银台执行支付
     * @param linkid
     * @param model
     * @return
     */
    @RequestMapping(value = {"/qianmi_pay"})
    public String qianmiPay(String linkid, Model model) {
        String redisKey = rdk + linkid;
        if(!redisService.existsKey(redisKey)){
            // 订单已经超时
            return "/api_gateway/pay/order_over";
        }
        String result = redisService.getKeyForValue(redisKey);
        PaymentOrder order = JSON.parseObject(result,PaymentOrder.class);
        // 查询订单信息，将订单数据存储在页面表单元素中提交
        if (OrderStatusEnum.valueOf(order.getOrderStatus()) != OrderStatusEnum.PROCESSING) {
            return "/api_gateway/pay/order_over";
        }
        if (order == null) {
            throw new RuntimeException("异常订单");
        }
        // 讲请求参数取出来遍历放在表单提交的键上
        String resultStr = order.getResponseContent();
        Map<String,String> resultMap = JsonUtils.json2map(resultStr);
        String formAction = resultMap.get("hostUrl");
        resultMap.remove("hostUrl");

        List<FormParamVO> params = new ArrayList<>();
        Set<Map.Entry<String, String>> entries = resultMap.entrySet();
        for (Map.Entry<String, String> entry : entries) {
            FormParamVO vo = new FormParamVO();
            vo.setKey(entry.getKey());
            vo.setVal(entry.getValue());
            params.add(vo);
        }
        model.addAttribute("formParams", params);
        model.addAttribute("formAction", formAction);
        return "/api_gateway/pay/qianmi_common_form_jump";
    }


}
