package com.ajl.bfb.api.listener;

import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;

/**
 * ApiGatewayApplicationStartupListener
 *
 * @author ben
 * @date 2018/11/24
 * @Description
 */
public class ApiGatewayApplicationStartupListener implements ApplicationListener<ContextRefreshedEvent> {

    @Override
    public void onApplicationEvent(ContextRefreshedEvent event){
    }


}
