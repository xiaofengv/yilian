package com.ajl.bfb.api.servlet;

import com.ajl.bfb.api.commonpay.util.HttpsProxcyUtils;
import com.ajl.bfb.core.constants.PayParameterEnum;
import com.ajl.bfb.repo.payment.model.PaymentOrder;
import com.ajl.bfb.repo.payment.service.IPaymentOrderService;
import com.hippo.framework.util.JsonUtils;
import com.hippo.framework.web.util.HttpRequestUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Map;

/**
 * Created by Administrator on 2018/10/20.
 */
@WebServlet(urlPatterns="/api_gateway/pay/form_common/order/request")
@Service
public class UpStreamRequestServlet extends HttpServlet {

    private static Logger logger = LogManager.getLogger(UpStreamRequestServlet.class);

    @Autowired
    private IPaymentOrderService paymentOrderService;

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String linkid = req.getParameter("linkid");
        logger.info("内部链接跳转linkid:::" + linkid);
        PaymentOrder order = paymentOrderService.findByLinkId(linkid);

        try {
            String ipAddr = HttpRequestUtils.getIpAddr(req);
            paymentOrderService.updateClientIp(order.getId(), ipAddr);
        } catch (Exception e) {
            logger.error("保存client异常", e);
        }
        String formParam = order.getFormParamJson();
        Map<String, String> jsonMap = JsonUtils.json2map(formParam);
        String formAction = jsonMap.get(PayParameterEnum.FORM_ACTION.name());
        jsonMap.remove(PayParameterEnum.FORM_ACTION.name());


        String responseStr = HttpsProxcyUtils.sendPost(formAction,getUrlParamsByMap(jsonMap),true);
        resp.setCharacterEncoding("gb2312");
        PrintWriter pw = resp.getWriter();
        pw.println(responseStr);
        pw.flush();
        pw.close();

    }

    /**
     * 将map转换成url
     * @param map
     * @return
     */
    public static String getUrlParamsByMap(Map<String, String> map) {
        if (map == null) {
            return "";
        }
        StringBuffer sb = new StringBuffer();
        for (Map.Entry<String, String> entry : map.entrySet()) {
            sb.append(entry.getKey() + "=" + entry.getValue());
            sb.append("&");
        }
        String s = sb.toString();
        if (s.endsWith("&")) {
            s = StringUtils.substringBeforeLast(s, "&");
        }
        return s;
    }

}
