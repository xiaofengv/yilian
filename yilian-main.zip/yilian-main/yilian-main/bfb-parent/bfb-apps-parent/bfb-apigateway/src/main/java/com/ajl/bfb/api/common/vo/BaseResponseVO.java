package com.ajl.bfb.api.common.vo;

import com.ajl.bfb.core.util.IgnoreSign;
import lombok.Data;

import java.io.Serializable;

@Data
public class BaseResponseVO implements Serializable {


    private String returnCode;


    private String returnMsg;

    private String nonceStr;

    @IgnoreSign
    private String sign;
}
