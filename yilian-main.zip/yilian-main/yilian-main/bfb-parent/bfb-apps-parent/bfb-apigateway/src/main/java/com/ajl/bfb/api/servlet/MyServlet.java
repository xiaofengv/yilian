package com.ajl.bfb.api.servlet;

/**
 * Created by Administrator on 2018/5/22.
 */

import com.ajl.bfb.core.util.SignUtils;
import com.ajl.bfb.common.payment.model.PaymentNotifyRequest;
import org.apache.commons.beanutils.BeanUtils;
import org.springframework.stereotype.Service;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.lang.reflect.InvocationTargetException;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;


@WebServlet(name="merchantNotifyServletTest",urlPatterns="/merchantNotify/myServlet")
@Service
public class MyServlet extends HttpServlet {

    private static final long serialVersionUID = 8031133938454140403L;

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        final String appkey = "EDJU9ICCNSRDZEBOFCYV";
        Map<String, String> transMap = new HashMap<>();
        Enumeration<String> enu = req.getParameterNames();
        String t = null;
        while (enu.hasMoreElements()) {
            t = enu.nextElement();
            transMap.put(t, req.getParameter(t));
        }
        PaymentNotifyRequest notify = new PaymentNotifyRequest();
        try {
            BeanUtils.populate(notify, transMap);
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }

        notify.setSign(null);

        boolean signResult = SignUtils.checkSign(appkey,notify,transMap.get("sign"));
        if (signResult){
            PrintWriter out = resp.getWriter();
            out.print("SUCCESS");
            out.flush();
            out.close();
        }
    }

}

