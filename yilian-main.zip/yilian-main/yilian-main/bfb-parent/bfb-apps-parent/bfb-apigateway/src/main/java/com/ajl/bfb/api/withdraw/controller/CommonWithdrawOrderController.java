package com.ajl.bfb.api.withdraw.controller;

import com.ajl.bfb.api.util.validator.OrderTimeValidator;
import com.ajl.bfb.api.withdraw.vo.CreateWithdrawOrderRequestVO;
import com.ajl.bfb.api.withdraw.vo.CreateWithdrawOrderResponseVO;
import com.ajl.bfb.common.withdraw.model.CreateWithdrawOrderRequest;
import com.ajl.bfb.core.constants.*;
import com.ajl.bfb.core.exception.ParameterVerificationException;
import com.ajl.bfb.core.util.SignUtils;
import com.ajl.bfb.pay.IPayLogService;
import com.ajl.bfb.pay.payment.IPaymentService;
import com.ajl.bfb.pay.payment.PaymentServiceException;
import com.ajl.bfb.pay.withdraw.IWithdrawFacade;
import com.ajl.bfb.pay.withdraw.model.CreateWithdrawOrderResult;
import com.ajl.bfb.repo.merchant.FundException;
import com.ajl.bfb.repo.merchant.model.Merchant;
import com.ajl.bfb.repo.merchant.service.IMerchantService;
import com.ajl.bfb.repo.withdraw.WithdrawException;
import com.ajl.bfb.repo.withdraw.model.ManualWithdrawOrder;
import com.hippo.framework.util.JsonUtils;
import com.hippo.framework.util.NumberUtils;
import com.hippo.framework.util.net.HttpUtils;
import com.hippo.framework.util.validation.ValidationUtils;
import org.apache.commons.lang3.EnumUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.Date;
import java.util.HashMap;


@Controller
@RequestMapping(value = "/api_gateway/withdraw/common/order")
public class CommonWithdrawOrderController {

    private static Logger logger = LogManager.getLogger(CommonWithdrawOrderController.class);

    @Autowired
    private IPaymentService paymentService;
    @Autowired
    private IWithdrawFacade withdrawFacade;
    @Autowired
    private IPayLogService payLogService;

    @Autowired
    private IMerchantService merchantService;


    @RequestMapping(value = {"/create", "/withdraw"})
    @ResponseBody
    public CreateWithdrawOrderResponseVO createOrder(@RequestBody CreateWithdrawOrderRequestVO orderRequestVO,
                                                     HttpServletRequest request)
            throws ParameterVerificationException, WithdrawException, PaymentServiceException {
        logger.info("[before]创建代付订单:" + JsonUtils.obj2String(orderRequestVO));
        long startTime = System.currentTimeMillis();

        Merchant merchant = preCheck(orderRequestVO);

        final String secretKey = merchant.getSecretKey();
        final String mchId = orderRequestVO.getMerchantNo();
        final String clientIp = HttpUtils.getRemoteAddr(request);
        try {

            CreateWithdrawOrderRequest withdrawOrder = createOrderReq(orderRequestVO, clientIp);

            CreateWithdrawOrderResult withdrawResult = withdrawFacade.createApiOrder(withdrawOrder, PaymentTypeEnum.API_WITHDRAW);
            CreateWithdrawOrderResponseVO responseVO = createReponse(secretKey, withdrawResult);

            payLogService.saveMerchantRequestLog(withdrawResult.getPlatformOrderNo(),
                    JsonUtils.obj2String(orderRequestVO), JsonUtils.obj2String(responseVO));
            logger.info("[after]创建代付订单.共耗时:" + (System.currentTimeMillis() - startTime) + "ms:" + JsonUtils.obj2String(responseVO));
            return responseVO;
        } catch (Throwable e) {
            logger.error("下单失败.", e);
            throw e;
        }
    }



    @RequestMapping(value="/create_manual_order")
    @ResponseBody
    public CreateWithdrawOrderResponseVO addOrder(@RequestBody CreateWithdrawOrderRequestVO orderRequestVO,
                                                  HttpServletRequest request) throws IOException, WithdrawException, FundException {
        logger.info("[before]创建提现订单:" + JsonUtils.obj2String(orderRequestVO));

        Merchant merchant = preCheck(orderRequestVO);

        final String secretKey = merchant.getSecretKey();

        ManualWithdrawOrder order = new ManualWithdrawOrder();
        order.setPayeeBankCode(BankCodeEnum.valueOfCode(orderRequestVO.getPayeeBankCode()));
        order.setBankDetailName(orderRequestVO.getBankDetailName());
        order.setCity(orderRequestVO.getCity());
        order.setPayeeBankAccount(orderRequestVO.getPayeeBankAccount());
        order.setPayeeIdCardNo(orderRequestVO.getPayeeIdCardNo());
        order.setPayeeName(orderRequestVO.getPayeeName());
        order.setPayeePhone(orderRequestVO.getPayeePhone());
        order.setProvince(orderRequestVO.getProvince());
        order.setUnionBankCode(orderRequestVO.getUnionBankCode());
        order.setCallbackUrl(orderRequestVO.getNotifyUrl());
        try {
            Merchant mch = merchantService.findByMerchantNo(orderRequestVO.getMerchantNo());

            String requestIP = HttpUtils.getRemoteAddr(request);
            order.setRequestIP(requestIP);
            order.setMerchantId(mch.getId());
            order.setBankAccType(BankAccTypeEnum.PRIVATE);
            order.setAmount(Integer.valueOf(orderRequestVO.getAmount()));
            order.setPayeeBankCode(BankCodeEnum.valueOfCode(orderRequestVO.getPayeeBankCode()));
            order.setMerchantOrderNo(orderRequestVO.getMchOrderNo());
            order.setCreateOrderTime(new Date());


            if (StringUtils.isNotBlank(order.getProvince())) {
                order.setProvince(orderRequestVO.getProvince());
            }
            if (StringUtils.isNotBlank(order.getCity())) {
                order.setCity(orderRequestVO.getCity());
            }
            String error = ValidationUtils.validate(order);
            if (error != null) {
                throw new WithdrawException(error);
            }
            order.setWithdrawType(WithdrawTypeEnum.MANUAL);
            String manualOrderNo = withdrawFacade.createManualOrder(order);


            CreateWithdrawOrderResponseVO rsp = new CreateWithdrawOrderResponseVO();
            rsp.setPlatformOrderNo(manualOrderNo);
            rsp.setMerchantOrderNo(orderRequestVO.getMchOrderNo());
            rsp.setResultCode(WithdrawResultCodeEnum.PROCESSING.name());
            rsp.setResultDesc(WithdrawResultCodeEnum.PROCESSING.getDesc());

            rsp.setReturnCode(ReturnCodeEnum.SUCCESS.name());
            rsp.setReturnMsg("请求成功");
            rsp.setNonceStr(System.currentTimeMillis() + "");
            rsp.setSign(SignUtils.createSign(secretKey, rsp));
            return rsp;
        } catch (Throwable e) {
            logger.error("api发起提现订单异常", e);
            throw e;
        }
    }

    /**
     * api代付订单
     *
     * @param orderRequestVO
     * @param request
     * @return
     * @throws IOException
     * @throws WithdrawException
     * @throws FundException
     */
    @RequestMapping(value="/api_withdraw_order")
    @ResponseBody
    public CreateWithdrawOrderResponseVO apiWithdrawOrder(@RequestBody CreateWithdrawOrderRequestVO orderRequestVO,
                                                  HttpServletRequest request) throws IOException, WithdrawException, FundException {
        logger.info("[before]创建api代付订单:" + JsonUtils.obj2String(orderRequestVO));

        Merchant merchant = preCheck(orderRequestVO);

        final String secretKey = merchant.getSecretKey();

        ManualWithdrawOrder order = new ManualWithdrawOrder();
        order.setPayeeBankCode(BankCodeEnum.valueOfCode(orderRequestVO.getPayeeBankCode()));
        order.setBankDetailName(orderRequestVO.getBankDetailName());
        order.setCity(orderRequestVO.getCity());
        order.setPayeeBankAccount(orderRequestVO.getPayeeBankAccount());
        order.setPayeeIdCardNo(orderRequestVO.getPayeeIdCardNo());
        order.setPayeeName(orderRequestVO.getPayeeName());
        order.setPayeePhone(orderRequestVO.getPayeePhone());
        order.setProvince(orderRequestVO.getProvince());
        order.setUnionBankCode(orderRequestVO.getUnionBankCode());
        order.setCallbackUrl(orderRequestVO.getNotifyUrl());
        try {
            Merchant mch = merchantService.findByMerchantNo(orderRequestVO.getMerchantNo());

            String requestIP = HttpUtils.getRemoteAddr(request);
            order.setRequestIP(requestIP);
            order.setMerchantId(mch.getId());
            order.setBankAccType(BankAccTypeEnum.PRIVATE);
            order.setAmount(Integer.valueOf(orderRequestVO.getAmount()));
            order.setPayeeBankCode(BankCodeEnum.valueOfCode(orderRequestVO.getPayeeBankCode()));
            order.setMerchantOrderNo(orderRequestVO.getMchOrderNo());
            order.setCreateOrderTime(new Date());


            if (StringUtils.isNotBlank(order.getProvince())) {
                order.setProvince(orderRequestVO.getProvince());
            }
            if (StringUtils.isNotBlank(order.getCity())) {
                order.setCity(orderRequestVO.getCity());
            }
            String error = ValidationUtils.validate(order);
            if (error != null) {
                throw new WithdrawException(error);
            }
            order.setWithdrawType(WithdrawTypeEnum.API);
            String manualOrderNo = withdrawFacade.createManualOrder(order);

            CreateWithdrawOrderResponseVO rsp = new CreateWithdrawOrderResponseVO();
            rsp.setPlatformOrderNo(manualOrderNo);
            rsp.setMerchantOrderNo(orderRequestVO.getMchOrderNo());
            rsp.setResultCode(WithdrawResultCodeEnum.PROCESSING.name());
            rsp.setResultDesc(WithdrawResultCodeEnum.PROCESSING.getDesc());

            rsp.setReturnCode(ReturnCodeEnum.SUCCESS.name());
            rsp.setReturnMsg("请求成功");
            rsp.setNonceStr(System.currentTimeMillis() + "");
            rsp.setSign(SignUtils.createSign(secretKey, rsp));
            return rsp;
        } catch (Throwable e) {
            logger.error("api发起提现订单异常", e);
            throw e;
        }
    }


    private CreateWithdrawOrderResponseVO createReponse(String secretKey, CreateWithdrawOrderResult withdrawResult) {
        CreateWithdrawOrderResponseVO rsp = new CreateWithdrawOrderResponseVO();
        rsp.setPlatformOrderNo(withdrawResult.getPlatformOrderNo());
        rsp.setMerchantOrderNo(withdrawResult.getMerchantOrderNo());
        rsp.setResultCode(withdrawResult.getResultCode().name());
        rsp.setResultDesc(withdrawResult.getResultDesc());

        rsp.setReturnCode(ReturnCodeEnum.SUCCESS.name());
        rsp.setReturnMsg("请求成功");
        rsp.setNonceStr(System.currentTimeMillis() + "");
        rsp.setSign(SignUtils.createSign(secretKey, rsp));
        return rsp;
    }

    private CreateWithdrawOrderRequest createOrderReq(CreateWithdrawOrderRequestVO orderRequestVO, String clientIp) {
        CreateWithdrawOrderRequest withdrawOrder = new CreateWithdrawOrderRequest();
        withdrawOrder.setAmount(Integer.valueOf(orderRequestVO.getAmount()));
        withdrawOrder.setOrderTime(new Date());
        withdrawOrder.setClientIp(clientIp);
        withdrawOrder.setMerchantOrderNo(orderRequestVO.getMchOrderNo());
        withdrawOrder.setMerchantNo(orderRequestVO.getMerchantNo());

        withdrawOrder.setBankAccType(BankAccTypeEnum.valueOf(orderRequestVO.getBankAccType()));
        withdrawOrder.setPayeeName(orderRequestVO.getPayeeName());
        withdrawOrder.setPayeeBankCode(BankCodeEnum.valueOfCode(orderRequestVO.getPayeeBankCode()));
        withdrawOrder.setPayeeBankAccount(orderRequestVO.getPayeeBankAccount());
        withdrawOrder.setPayeeIdCardNo(orderRequestVO.getPayeeIdCardNo());
        withdrawOrder.setPayeePhone(orderRequestVO.getPayeePhone());

        withdrawOrder.setProvince(orderRequestVO.getProvince());
        withdrawOrder.setCity(orderRequestVO.getCity());
        withdrawOrder.setBankDetailName(orderRequestVO.getBankDetailName());

        withdrawOrder.setNotifyUrl(orderRequestVO.getNotifyUrl());
        withdrawOrder.setOrderRemark(orderRequestVO.getRemark());
        if (StringUtils.isBlank(orderRequestVO.getUnionBankCode())) {
            withdrawOrder.setUnionBankCode(withdrawOrder.getPayeeBankCode().getUnionCode());
        } else {
            withdrawOrder.setUnionBankCode(orderRequestVO.getUnionBankCode());
        }

        if (StringUtils.isBlank(orderRequestVO.getExtendsParams())) {
            withdrawOrder.setExtendParams(new HashMap<>());
        } else {
            withdrawOrder.setExtendParams(JsonUtils.json2map(orderRequestVO.getExtendsParams()));
        }
        return withdrawOrder;
    }

    private Merchant preCheck(CreateWithdrawOrderRequestVO orderRequestVO) throws ParameterVerificationException {
        String error = ValidationUtils.validate(orderRequestVO);
        if (error != null) {
            throw new ParameterVerificationException("参数校验失败." + error);
        }

        if (!NumberUtils.isInteger(orderRequestVO.getAmount())) {
            throw new ParameterVerificationException("参数校验失败:金额格式有误");
        }
        if (Integer.valueOf(orderRequestVO.getAmount()) <= 0) {
            throw new ParameterVerificationException("参数校验失败.金额必须>0");
        }

        OrderTimeValidator.checkOrderTimeFormat(orderRequestVO.getOrderTime());

        try {
            BankCodeEnum.valueOfCode(orderRequestVO.getPayeeBankCode());
        } catch (Throwable e) {
            throw new ParameterVerificationException(e.getMessage() == null ?
                    StringUtils.substring(ExceptionUtils.getStackTrace(e), 0, 200) : e.getMessage());
        }

        BankAccTypeEnum bankAccTypeEnum = EnumUtils.getEnum(BankAccTypeEnum.class, orderRequestVO.getBankAccType());
        if (bankAccTypeEnum == null) {
            throw new ParameterVerificationException("无效的账号类型,可选值必须为以下之一:PUBLIC,PRIVATE");
        }
        if (bankAccTypeEnum == BankAccTypeEnum.PUBLIC && StringUtils.isBlank(orderRequestVO.getUnionBankCode())) {
            throw new ParameterVerificationException("对公账号时，联行号必填");
        }

        final String mchId = orderRequestVO.getMerchantNo();
        final String sign = orderRequestVO.getSign();

        Merchant merchant = paymentService.getMerchant(mchId);
        if (merchant == null) {
            throw new ParameterVerificationException("该商户不存在");
        }

        boolean checkSignResult = SignUtils.checkSign(merchant.getSecretKey(), orderRequestVO, sign);
        if (!checkSignResult) {
            throw new ParameterVerificationException("签名校验不通过");
        }
        return merchant;
    }
}
