package com.ajl.bfb.api.commonpay.controller;

import com.ajl.bfb.api.commonpay.vo.QueryPaymentOrderRequestVO;
import com.ajl.bfb.api.commonpay.vo.QueryPaymentOrderResponseVO;
import com.ajl.bfb.common.exception.QueryOrderException;
import com.ajl.bfb.common.payment.model.QueryPaymentOrderResponse;
import com.ajl.bfb.core.constants.ResultCodeEnum;
import com.ajl.bfb.core.constants.ReturnCodeEnum;
import com.ajl.bfb.core.exception.ParameterVerificationException;
import com.ajl.bfb.core.util.SignUtils;
import com.ajl.bfb.pay.payment.IPaymentFacade;
import com.ajl.bfb.pay.payment.IPaymentService;
import com.ajl.bfb.pay.payment.PaymentMerchantNotifyException;
import com.ajl.bfb.pay.payment.model.QueryPaymentOrderParam;
import com.ajl.bfb.repo.merchant.model.Merchant;
import com.hippo.framework.util.JsonUtils;
import com.hippo.framework.util.validation.ValidationUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * Created by admin on 2018-05-16 0016.
 */
@Controller
@RequestMapping(value = "/api_gateway/query/")
public class QueryPaymentOrderController {
    private static Logger logger = LogManager.getLogger(QueryPaymentOrderController.class);
    @Autowired
    private IPaymentFacade paymentFacadeService;
    @Autowired
    private IPaymentService paymentService;

    @RequestMapping(value = "/payment_order")
    @ResponseBody
    public QueryPaymentOrderResponseVO query(@RequestBody QueryPaymentOrderRequestVO requestVO)
            throws ParameterVerificationException, PaymentMerchantNotifyException, QueryOrderException {
        logger.info("[before]订单查询:" + JsonUtils.obj2String(requestVO));
        //输入参数检查
        Merchant merchant = preCheck(requestVO);
        String secretKey = merchant.getSecretKey();

        QueryPaymentOrderParam queryParam = new QueryPaymentOrderParam();
        queryParam.setMerchantNo(requestVO.getMerchantNo());
        queryParam.setMerchantOrderNo(requestVO.getMchOrderNo());
        //调用查询服务
        QueryPaymentOrderResponse queryResult = paymentFacadeService.query(queryParam);
        QueryPaymentOrderResponseVO responseVO = createResponse(queryResult, secretKey);
        logger.info("[after]订单查询:" + responseVO);
        return responseVO;
    }

    private Merchant preCheck(QueryPaymentOrderRequestVO requestVO) {
        //参数校验
        String error = ValidationUtils.validate(requestVO);
        if (error != null) {
            throw new ParameterVerificationException("参数校验失败." + error);
        }
        if (StringUtils.isBlank(requestVO.getMchOrderNo())) {
            throw new ParameterVerificationException("商户订单号不能为空");
        }
        Merchant merchant = paymentService.getMerchant(requestVO.getMerchantNo());
        if (merchant == null) {
            throw new ParameterVerificationException("该商户不存在");
        }
        final String secretKey = merchant.getSecretKey();
        //签名校验
        boolean checkSignResult = SignUtils.checkSign(merchant.getSecretKey(), requestVO, requestVO.getSign());
        if (!checkSignResult) {
            throw new ParameterVerificationException("签名校验不通过");
        }
        return merchant;
    }

    private QueryPaymentOrderResponseVO createResponse(QueryPaymentOrderResponse queryRsp, String secretKey) {
        QueryPaymentOrderResponseVO rsp = new QueryPaymentOrderResponseVO();
        if (queryRsp.getResultCode() == ResultCodeEnum.SUCCESS) {
            rsp.setReturnCode(ReturnCodeEnum.SUCCESS.name());
            rsp.setReturnMsg("请求成功");
            rsp.setTotalFee(queryRsp.getTotalFee());
            rsp.setOrderStatus(queryRsp.getOrderStatus().name());
            rsp.setOrderDesc(queryRsp.getOrderDesc());
        } else {
            rsp.setReturnCode(ReturnCodeEnum.FAIL.name());
            rsp.setReturnMsg(queryRsp.getResultMsg());
        }
        rsp.setNonceStr(System.currentTimeMillis() + "");
        rsp.setSign(SignUtils.createSign(secretKey, rsp));
        return rsp;
    }


}
