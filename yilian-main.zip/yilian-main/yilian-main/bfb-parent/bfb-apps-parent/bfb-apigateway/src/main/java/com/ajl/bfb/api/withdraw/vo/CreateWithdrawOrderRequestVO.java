package com.ajl.bfb.api.withdraw.vo;

import com.ajl.bfb.api.common.vo.BaseRequestVO;
import lombok.Data;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotBlank;

import java.io.Serializable;

@Data
public class CreateWithdrawOrderRequestVO extends BaseRequestVO implements Serializable {


    @NotBlank(message = "订单日期不能为空")
    private String orderTime;

    @NotBlank(message = "商户订单号不能为空")
    @Length(min = 1, max = 50,message = "商户订单号长度限制{min}-{max}")
    private String mchOrderNo;

    @NotBlank(message = "交易金额不能为空")
    private String amount;

    @Length(min = 0, max = 50,message = "付款摘要长度限制{min}-{max}")
    private String remark;

    @Length(min = 0, max = 500,message = "后台回调地址长度限制{min}-{max}")
    private String notifyUrl;

    @NotBlank(message = "收款人姓名不能为空")
    @Length(min = 0, max = 20,message = "收款人姓名长度限制{min}-{max}")
    private String payeeName;

    @NotBlank(message = "收款银行编码不能为空")
    private String payeeBankCode;

    @NotBlank(message = "收款银行账号不能为空")
    @Length(min = 1, max = 30,message = "银行账号长度限制{min}-{max}")
    private String payeeBankAccount;


    @NotBlank(message = "账号类型不能为空")
    private String bankAccType;

    @Length(min = 0, max = 30,message = "联行号长度限制{min}-{max}")
    private String unionBankCode;

    @Length(min = 0, max = 20,message = "收款人身份证号长度限制{min}-{max}")
    private String payeeIdCardNo;

    @Length(min = 0, max = 15,message = "收款人手机号长度限制{min}-{max}")
    private String payeePhone;

    private String province;

    private String city;

    private String bankDetailName;

    private String extendsParams;
}
