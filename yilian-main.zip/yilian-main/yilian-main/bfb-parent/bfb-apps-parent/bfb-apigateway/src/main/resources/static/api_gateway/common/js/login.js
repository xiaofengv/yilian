function login() {

    if ($("#userName").val().trim() == "") {
        hippo.warning("请输入用户名")
        return false;
    }

    if ($("#password").val().trim()  == "") {
        hippo.warning("请输入密码")
        return false;
    }

    if ($("#verifyCode").val().trim()  == "") {
        hippo.warning("请输入验证码")
        return false;
    }


    $("#loginForm").ajaxSubmit( {
        url: getWebPath() + '/admin/sys/login',
        type: 'POST',
        dataType: 'json',
        success: function (data) {
            if (data.statusCode == 'SUCCESS') {
                new $.zui.Messager(data.message, {
                    type: 'success'
                }).show();
                window.location.href = getWebPath() + "/admin/common/home";
            } else {
                new $.zui.Messager(data.message, {
                    type: 'warning'
                }).show();

                changeVerifyCode();
            }
        }


    });
}



function changeVerifyCode() {
    $("#verifyCodeImg").attr("src", $("#verifyCodeImg").attr("src")+ "1");
}