package com.ajl.bfb.api.listener;

import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextStoppedEvent;

/**
 * ApiGatewayApplicationStartupListener
 *
 * @author ben
 * @date 2018/11/24
 * @Description
 */
public class ApiGatewayApplicationStopListener implements ApplicationListener<ContextStoppedEvent> {

    @Override
    public void onApplicationEvent(ContextStoppedEvent contextStoppedEvent) {
    }
}
