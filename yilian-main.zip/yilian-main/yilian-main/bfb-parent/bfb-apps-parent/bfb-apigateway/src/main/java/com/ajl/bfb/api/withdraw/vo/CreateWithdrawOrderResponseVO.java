package com.ajl.bfb.api.withdraw.vo;

import com.ajl.bfb.api.common.vo.BaseResponseVO;
import lombok.Data;

import java.io.Serializable;

@Data
public class CreateWithdrawOrderResponseVO extends BaseResponseVO implements Serializable {



    private String platformOrderNo;

    private String merchantOrderNo;


    private String resultCode;

    private String resultDesc;

}
