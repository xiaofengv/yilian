package com.ajl.bfb.api.commonpay.controller;

import com.ajl.bfb.repo.payment.service.IPaymentOrderService;
import com.alipay.api.AlipayApiException;
import com.alipay.api.AlipayClient;
import com.alipay.api.DefaultAlipayClient;
import com.alipay.api.request.AlipaySystemOauthTokenRequest;
import com.alipay.api.response.AlipaySystemOauthTokenResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * Created by Administrator on 2019/5/10.
 */
@Controller
@RequestMapping(value = "/api_gateway/reload_otcaccount")
public class ReloadOtcAccountController {

    @Autowired
    private IPaymentOrderService paymentOrderService;

    private static String yy_key="MIIEvAIBADANBgkqhkiG9w0BAQEFAASCBKYwggSiAgEAAoIBAQCgcPnGD6LoCoKr\n" +
            "EbduF0JKVOMEWLxwcSVbsRwi/mlbi+VA19o8rjcNBK37CZJ1ZOQpGXN5ztMuAz+8\n" +
            "4Ql9NGD8IG0/V9LOuL63tRsvQSlo4cnOfGFGitZrjXeSJze3M82RlvMuDQ66ML8Y\n" +
            "kuMaDXOcKLe+9dxcmGjUJht0MRSz9+lrg2hiW7T9N3KoUeZvfbD/yV8rSvt4Dnqb\n" +
            "fkS/X4LUgpUgmatz4S4Ezk6LLZDaF3e+yWWgblDRDnRs10IQSnb9wj2zSJGBqGXo\n" +
            "/dC6bpS8go49mEldITzERUEYynrVtaM14YaUm6AwAUiMtBLSt9d1GecCZ711FQiW\n" +
            "23zxc1ORAgMBAAECggEAIB09AbYTh5rC+Pb83l5teG9xWWdhoKglMCtNVHvUHuzr\n" +
            "oIUUO90rS8HKCVurIzBksw1THeiWQLmJwobQ3WzklNLwyyMLITG9iwwHOvgyD7pS\n" +
            "KLCgz/vuW2zfqDONZXBLD39Fgcw/TGmBdqvAJXDX2UQVM3YG+8nOAdj22dURLcx6\n" +
            "gytruiK8kXj9N+i/l3uPzluP396jmDmEIMH7PyQTViTGjVwq4AQjajxfjRlDSDqc\n" +
            "Y/2QdhAs2S3nIl988+IMpoY/wfQHyQqn2iKsn3pIldxsOTNbXh3b7aqy5b5M+Sur\n" +
            "Od/YUNib21iqsmdha5u/g3DA3XuFpS37CIdulD9SmQKBgQDU7PT7SDw1lFXrBjoO\n" +
            "b7UdNfVk07sOdnfc2V22x6+coB+RlAmeLWB1tBDXovB53HwG3EE3ooy65kO2rJeG\n" +
            "CCbA9nntntxcvrHmTUGNbn1Ubeiw2t0UEzs1MeQI6z3SMBDHT0Hp3WKhGQMNerHV\n" +
            "yB39I+iXpsMQvsaVtWYRpxljCwKBgQDA5fLzagJUCvuMsIj2oiqOrU8nMvEVMMsa\n" +
            "7FsZmJ9XT26/mDf+rKoabixQlvYqDCDpog4BgSC4CtI6moiUCbheAPsk8oJrYhS6\n" +
            "w01I6f9hAvrGhW/8UIx+O7hc+ZOhl8aSzlNh2C9rmFRUsUBC1m8DvoLqnbbNP+9J\n" +
            "446mbXsFUwKBgBmyIvp0RDffF+NOFBGL75p/2YZ6eteK+nofjUyymoHXXRfvep2p\n" +
            "MjviKCot0sGSFzGowQIazsr7YO6Zs4uMTkj5Ncu0YTmcFdIKPr/3to5K2UsGjqmO\n" +
            "jJWl2LQu134XKN80tGqpue5hG1o0FWQMS3oyLC6pBF9v9n04sAGvXcPzAoGAInUx\n" +
            "OBA4yECJ/PDQFpaTWZdV61+rNyjXL0EHaQQdeqBC3VDYt9KqNDx4CBFfedVez71W\n" +
            "GSiy6o1sTnGqch9mYsx0EH6Nk5cast4OYTcDmpXIrEvL3FubLTWH0nv2xkfxfeoD\n" +
            "dRgEKIk2j0Z2fzoE7LtMcZKow/Nm0GEo60vlTOcCgYAZoVSKpxaXrg5L/ZBLSDE3\n" +
            "r8VApPTaRTAtQJeYM+/fZ/X6H4LWRUE7pa2OCe1vMXKDHc1wDMINPfiPx3wXsNn8\n" +
            "WkYKyGC1bggN8BMGwbjv1nG5fNnpx2OR7+FOHNPs95sZJPfZwZ+5bMS6BZsetfTj\n" +
            "sGTrr7ethjdMVp3WXAWFJQ==";
    private static String zfb_key="MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAm61cdpstmdGT4iVi3iHhDu6KyeFU6th964nrkTiDaYMaUsGzozVzVzfBQjjMIlA2CjSRoUqQW6wr0tv7logbWKy6g86UvmUCI4fy8O4/SjqZrcqvamTj4TG+iOd9Rt+us+terXPcE1bOBU/sq4jT+OioEBk2OCZACW4QYlMDZNhWKPtfAt3xgKzzGZ0GdGbOfZxV2pdxaG4xFENch1ehJh7dOFsLQ9szb2vl3ZmSAaJkeLG32+GaiSGEZB5cdl6XJ3XJUD5vZI/yT7IPAJvvubZZd/DZXqc54JexNGDYClsRYy4awTzzcEP4qWk0s6nh7mwjvxUKyrd8gUzIZfe4jQIDAQAB";


    @RequestMapping(value ={"/goalipay"} )
    public String gogogoogo(Model model, String auth_code) throws AlipayApiException {
        AlipayClient alipayClient = new DefaultAlipayClient("https://openapi.alipay.com/gateway.do", "2019032263656138", yy_key, "json", "utf-8", zfb_key, "RSA2");
        AlipaySystemOauthTokenRequest request = new AlipaySystemOauthTokenRequest();
        request.setCode(auth_code);
        request.setGrantType("authorization_code");
        try {
            AlipaySystemOauthTokenResponse oauthTokenResponse = alipayClient.execute(request);
            model.addAttribute("user_Id",oauthTokenResponse.getUserId());

        } catch (AlipayApiException e) {
            //处理异常
            e.printStackTrace();
        }
        model.addAttribute("auth_code",auth_code);
        return "/api_gateway/test/testalipay";
    }

}
