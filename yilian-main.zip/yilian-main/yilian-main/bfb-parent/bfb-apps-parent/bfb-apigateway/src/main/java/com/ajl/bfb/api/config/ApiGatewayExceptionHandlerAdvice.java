package com.ajl.bfb.api.config;

import com.ajl.bfb.core.exception.PayBaseException;
import com.ajl.bfb.core.exception.PayBaseRuntimeException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;


@ControllerAdvice(basePackages = "com.ajl.bfb.api")
public class ApiGatewayExceptionHandlerAdvice {

    public static final String EXCEPTION_KEY = "exception";
    private static Logger logger = LogManager.getLogger(ApiGatewayExceptionHandlerAdvice.class);

    @ExceptionHandler(value=Throwable.class)
    public ModelAndView exception(Throwable exception,HttpServletRequest request){
        logger.error("request uri:" + request.getRequestURI());
        logger.error("bfb pay程序异常", exception);

        request.setAttribute("error",extractErrorMsg(exception));
        ModelAndView mav = new ModelAndView();
        mav.addObject(EXCEPTION_KEY, exception);

        mav.setViewName("forward:/api_gateway/error/ajax-http500");
        return mav;
    }

    private String extractErrorMsg(Throwable exception) {
        if ((exception instanceof PayBaseException)
                || (exception instanceof PayBaseRuntimeException) ) {
            return exception.getMessage();
        }
        return "未知的程序异常";
    }
}
