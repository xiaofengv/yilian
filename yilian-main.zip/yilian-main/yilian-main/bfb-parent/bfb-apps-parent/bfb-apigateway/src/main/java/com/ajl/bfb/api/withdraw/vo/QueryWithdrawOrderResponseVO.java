package com.ajl.bfb.api.withdraw.vo;

import com.ajl.bfb.api.common.vo.BaseResponseVO;
import lombok.Data;

@Data
public class QueryWithdrawOrderResponseVO extends BaseResponseVO {

    private Integer totalFee;


    private String orderStatus;

    private String orderDesc;

}
