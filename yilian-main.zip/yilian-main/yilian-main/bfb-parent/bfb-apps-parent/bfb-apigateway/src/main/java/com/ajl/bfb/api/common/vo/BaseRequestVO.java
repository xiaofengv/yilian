package com.ajl.bfb.api.common.vo;

import com.ajl.bfb.core.util.IgnoreSign;
import lombok.Data;
import org.hibernate.validator.constraints.NotBlank;

import java.io.Serializable;

@Data
public class BaseRequestVO implements Serializable {

    public static final String ORDER_TIME_FORMAT = "yyyyMMddHHmmss";


    @NotBlank(message = "商户号不能为空")
    private String merchantNo;

    @NotBlank(message = "随机字符串不能为空")
    private String nonceStr;


    @IgnoreSign
    private String sign;
}
