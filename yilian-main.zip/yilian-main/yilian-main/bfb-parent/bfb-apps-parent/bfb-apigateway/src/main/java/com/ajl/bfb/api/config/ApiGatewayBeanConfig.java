package com.ajl.bfb.api.config;

import com.ajl.bfb.api.listener.ApiGatewayApplicationStartupListener;
import com.ajl.bfb.api.listener.ApiGatewayApplicationStopListener;
import com.hippo.framework.util.SnowflakeIdWorker;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.multipart.MultipartResolver;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;


@Configuration
public class ApiGatewayBeanConfig {

    @Bean
    public SnowflakeIdWorker getSnowflakeIdWorker() {
        SnowflakeIdWorker idWorker = new SnowflakeIdWorker(0, 0);
        return idWorker;
    }


    @Bean(name = "multipartResolver")
    public MultipartResolver multipartResolver(){
        CommonsMultipartResolver resolver = new CommonsMultipartResolver();
        resolver.setDefaultEncoding("UTF-8");
        resolver.setResolveLazily(true);
        resolver.setMaxInMemorySize(40960);
        resolver.setMaxUploadSize(50*1024*1024);
        return resolver;
    }

    @Bean(name = "apiGatewayApplicationStartupListener")
    public ApiGatewayApplicationStartupListener createAppStartupListener() {
        return new ApiGatewayApplicationStartupListener();
    }

    @Bean(name = "apiGatewayApplicationStopListener")
    public ApiGatewayApplicationStopListener createAppStopListener() {
        return new ApiGatewayApplicationStopListener();
    }


}
