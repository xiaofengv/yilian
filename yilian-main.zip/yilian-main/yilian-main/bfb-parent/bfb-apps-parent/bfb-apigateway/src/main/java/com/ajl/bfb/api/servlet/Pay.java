package com.ajl.bfb.api.servlet;


import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.net.URLEncoder;


//@WebServlet(name = "Pay")
public class Pay extends HttpServlet {
    private static Logger logger = LogManager.getLogger(Pay.class);
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String url = "https://pay.heepay.com/Payment/Index.aspx";
        //请求参数
        String version = "1";               //当前接口版本号
        String agent_id = "1664502";       //商户id
        String agent_bill_id = SmallTools.getDate("yyyyMMddHHmmss")+"hykj";//商户内部订单号
        String agent_bill_time = SmallTools.getDate("yyyyMMddHHmmss");//提交单据的时间yyyyMMddHHmmss
        String pay_type = "64";              //支付类型 64
        String pay_amt = "0.01";             //订单总金额
        String notify_url = "http://";      //异步通知地址
        String return_url = "http://";      //支付完成同步跳转地址
        String user_ip = "168.166.23.1";   //用户IP
        String goods_name = URLEncoder.encode("名称测试","gbk");//商品名称
        String goods_num = "1";             //商品数量
        String goods_note = URLEncoder.encode("说明测试","gbk");//商品说明
        String remark = URLEncoder.encode("remark测试","gbk"); //商户自定义字段，异步通知时原样返回
        String sign_type = "MD5";           //签名方式MD5
        String key = "4B05A95416DB4184ACEE4313";//密钥
        String sign = "";                   //MD5签名结果
        //组织签名串
        StringBuilder sign_sb = new StringBuilder();
        sign_sb.append("version")            .append("=").append(version)             .append("&")
                .append("agent_id")          .append("=").append(agent_id)            .append("&")
                .append("agent_bill_id")    .append("=").append(agent_bill_id)       .append("&")
                .append("agent_bill_time")  .append("=").append(agent_bill_time) 		.append("&")
                .append("pay_type")          .append("=").append(pay_type)				.append("&")
                .append("pay_amt")           .append("=").append(pay_amt)		    	.append("&")
                .append("notify_url")       .append("=").append(notify_url)		    .append("&")
                .append("return_url")       .append("=").append(return_url)			.append("&")
                .append("user_ip")          .append("=").append(user_ip)				.append("&")
                .append("key")               .append("=").append(key);
        logger.info("签名参数："+sign_sb.toString());
        sign = SmallTools.MD5en(sign_sb.toString());
        logger.info("签名结果："+sign);
        //请求参数
        StringBuilder requestParams = new StringBuilder();
        requestParams.append("version")       .append("=").append(version)            .append("&")
                .append("agent_id")          .append("=").append(agent_id)            .append("&")
                .append("agent_bill_id")    .append("=").append(agent_bill_id)       .append("&")
                .append("agent_bill_time")  .append("=").append(agent_bill_time) 		.append("&")
                .append("pay_type")          .append("=").append(pay_type)				.append("&")
                .append("pay_amt")           .append("=").append(pay_amt)		    	.append("&")
                .append("notify_url")       .append("=").append(notify_url)		    .append("&")
                .append("return_url")       .append("=").append(return_url)			.append("&")
                .append("user_ip")          .append("=").append(user_ip)				.append("&")
                .append("goods_name")       .append("=").append(goods_name)			.append("&")
                .append("goods_num")        .append("=").append(goods_num)			.append("&")
                .append("goods_note")       .append("=").append(goods_note)			.append("&")
                .append("remark")           .append("=").append(remark)				.append("&")
                .append("sign_type")        .append("=").append(sign_type)			.append("&")
                .append("sign")              .append("=").append(sign);
        logger.info("请求参数："+requestParams.toString());
        response.sendRedirect(url+"?"+requestParams.toString());

    }
}
