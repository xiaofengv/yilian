package com.ajl.bfb.api.commonpay.controller;

import com.ajl.bfb.api.commonpay.vo.CreatePaymentOrderRequestVO;
import com.ajl.bfb.api.commonpay.vo.CreatePaymentOrderResponseOtcVO;
import com.ajl.bfb.api.commonpay.vo.CreatePaymentOrderResponseVO;
import com.ajl.bfb.api.util.validator.OrderTimeValidator;
import com.ajl.bfb.common.payment.model.CreatePaymentOrderRequest;
import com.ajl.bfb.core.constants.BankCodeEnum;
import com.ajl.bfb.core.constants.PaymentTypeEnum;
import com.ajl.bfb.core.constants.ReturnCodeEnum;
import com.ajl.bfb.core.constants.UrlTypeEnum;
import com.ajl.bfb.core.exception.ParameterVerificationException;
import com.ajl.bfb.core.util.SignUtils;
import com.ajl.bfb.pay.IPayLogService;
import com.ajl.bfb.pay.payment.IPaymentFacade;
import com.ajl.bfb.pay.payment.IPaymentService;
import com.ajl.bfb.pay.payment.PaymentServiceException;
import com.ajl.bfb.pay.payment.model.CreatePaymentOrderResult;
import com.ajl.bfb.repo.ip.model.IPVO;
import com.ajl.bfb.repo.ip.service.IIPService;
import com.ajl.bfb.repo.merchant.model.Merchant;
import com.ajl.bfb.repo.payment.service.IPaymentOrderResponseService;
import com.hippo.framework.util.JsonUtils;
import com.hippo.framework.util.NumberUtils;
import com.hippo.framework.util.net.HttpUtils;
import com.hippo.framework.util.validation.ValidationUtils;
import com.hippo.framework.web.util.WebPathUtils;
import org.apache.commons.lang3.EnumUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import java.util.Date;
import java.util.regex.Pattern;

/**
 * 统一扫码下单
 * Created by admin on 2018-04-23 0023.
 */
@Controller
@RequestMapping(value = "/api_gateway/pay/order")
public class CommonQrCodeOrderController {

    private static Logger logger = LogManager.getLogger(CommonQrCodeOrderController.class);
    @Autowired
    private IPaymentFacade paymentFacadeService;
    @Autowired
    private IPaymentService paymentService;
    @Autowired
    private IPayLogService payLogService;
    @Autowired
    private IIPService iipService;
    @Autowired
    private IPaymentOrderResponseService paymentOrderResponseService;

    @RequestMapping(value = { "/create", "/payment" })
    @ResponseBody
    public CreatePaymentOrderResponseVO createPayOrder(@RequestBody CreatePaymentOrderRequestVO createPaymentOrderVO, HttpServletRequest request)
            throws PaymentServiceException {
        long startTime = System.currentTimeMillis();
        String ip = createPaymentOrderVO.getClientIp();
        //检查IP合法性
        boolean isLegalIP = checkIp(ip);
        if (!isLegalIP){
            ip = HttpUtils.getRemoteAddr(request);
        }
        if (chekBlacklist(ip)){
            logger.info(ip + "存在恶意刷单行为，已被列入黑名单");
            throw new ParameterVerificationException("存在恶意刷单行为，已被限制下单。如有疑问，请联系客服！");
        }
        logger.info("[before]创建支付订单:请求IP:{},请求参数{}", ip + ":" + JsonUtils.obj2StringNoEscaping(createPaymentOrderVO));
        Merchant merchant = preCheck(createPaymentOrderVO);
        logger.info("[before]创建支付订单:商户:{}",merchant.getMerchantNo());
        //logger.info("[before]创建支付订单:" + HttpUtils.getRemoteAddr(request) + ":" + JsonUtils.obj2StringNoEscaping(createPaymentOrderVO));
        /**
         * 1.检查参数合法性, 这里只做通用字段的校验，具体实现类，要做具体校验保障
         */
        final String secretKey = merchant.getSecretKey();
//        final String clientIp = HttpUtils.getRemoteAddr(request);
        //构造service需要的参数
        String serverPath = WebPathUtils.getWebBasePath(request);
        CreatePaymentOrderRequest orderRequest = createRequestParam(createPaymentOrderVO, ip,serverPath);
        CreatePaymentOrderResponseVO responseVO = null;
        /**
         * 3.请求上游接口
         */
        try {
            CreatePaymentOrderResult orderResult = paymentFacadeService.createOrder(orderRequest);
            responseVO = createReponse(secretKey, orderResult);
            //4.保存请求日志
            payLogService.saveMerchantRequestLog(orderResult.getPlatformOrderNo(),
                    JsonUtils.obj2String(createPaymentOrderVO),
                    JsonUtils.obj2String(responseVO));
        } catch (Throwable e) {
            logger.error("下单失败.",e);
            throw e;
        }
        long responseTime = System.currentTimeMillis() - startTime;
        paymentOrderResponseService.update(responseVO.getPlatformOrderNo(),responseTime);
        logger.info("[after]创建支付订单.共耗时:" + responseTime + "ms:" + JsonUtils.obj2StringNoEscaping(responseVO));
        return responseVO;
    }

    private boolean chekBlacklist(String ip) {
        IPVO  whiteIP = iipService.selectWhitelistByIp(ip);
        if (whiteIP != null){
            return false;
        }
        IPVO blackIP = iipService.selectBlacklistByIp(ip);
        if (blackIP != null){
            return true;
        }
        return false;
    }

    private boolean checkIp(String ip) {
        if (StringUtils.isEmpty(ip) || "127.0.0.1".equals(ip) || "0:0:0:0:0:0:0:1".equals(ip) || "192.168.0.1".equals(ip)){
            return false;
        }
        String regix = "((([1-9]?|1\\d)\\d|2([0-4]\\d|5[0-5]))\\.){3}(([1-9]?|1\\d)\\d|2([0-4]\\d|5[0-5]))";
        Pattern ipPattern = Pattern.compile(regix);
        boolean flag = ipPattern.matcher(ip).matches();
        return flag;
    }

    @RequestMapping(value = { "/otc_create", "/otc_payment" })
    @ResponseBody
    public CreatePaymentOrderResponseOtcVO otcCreatePayOrder(@RequestBody CreatePaymentOrderRequestVO createPaymentOrderVO, HttpServletRequest request)
            throws PaymentServiceException {
        String ip = createPaymentOrderVO.getClientIp();
        boolean isLegalIP = checkIp(ip);
        if (!isLegalIP){
            ip = HttpUtils.getRemoteAddr(request);
        }
        if (chekBlacklist(ip)){
            logger.info("存在恶意刷单行为，已被列入黑名单");
            throw new ParameterVerificationException("存在恶意刷单行为，已被限制下单。如有疑问，请联系客服！");
        }
        logger.info("[before]创建支付订单:请求IP:{},请求参数{}", ip + ":" + JsonUtils.obj2StringNoEscaping(createPaymentOrderVO));
        Merchant merchant = preCheck(createPaymentOrderVO);
        logger.info("[before]创建otc支付订单:商户:{}",merchant.getMerchantNo());
        //logger.info("[before]创建支付订单:" + HttpUtils.getRemoteAddr(request) + ":" + JsonUtils.obj2StringNoEscaping(createPaymentOrderVO));
        long startTime = System.currentTimeMillis();
        /**
         * 1.检查参数合法性, 这里只做通用字段的校验，具体实现类，要做具体校验保障
         */
        final String secretKey = merchant.getSecretKey();
//        final String clientIp = HttpUtils.getRemoteAddr(request);
        //构造service需要的参数
        String serverPath = WebPathUtils.getWebBasePath(request);
        CreatePaymentOrderRequest orderRequest = createRequestParam(createPaymentOrderVO, ip,serverPath);
        CreatePaymentOrderResponseOtcVO responseVO = null;
        /**
         * 3.请求上游接口
         */
        try {
            CreatePaymentOrderResult orderResult = paymentFacadeService.createOrder(orderRequest);
            responseVO = createOtcReponse(secretKey, orderResult);
            //4.保存请求日志
            payLogService.saveMerchantRequestLog(orderResult.getPlatformOrderNo(),
                    JsonUtils.obj2String(createPaymentOrderVO),
                    JsonUtils.obj2String(responseVO));
        } catch (Throwable e) {
            logger.error("下单失败.",e);
            throw e;
        }
        logger.info("[after]创建支付订单.共耗时:" + (System.currentTimeMillis() - startTime) + "ms:" + JsonUtils.obj2StringNoEscaping(responseVO));
        return responseVO;
    }


    /**
     * 前置校验，检查参数合法性，商户信息合法性
     * @param createPaymentOrderVO
     * @return
     * @throws ParameterVerificationException
     */
    private Merchant preCheck(CreatePaymentOrderRequestVO createPaymentOrderVO) throws ParameterVerificationException {
        String error = ValidationUtils.validate(createPaymentOrderVO);
        if (error != null) {
            throw new ParameterVerificationException("参数校验失败." + error);
        }
        if(!NumberUtils.isInteger(createPaymentOrderVO.getAmount())) {
            throw new ParameterVerificationException("参数校验失败.金额格式非法");
        }
        if (Integer.valueOf(createPaymentOrderVO.getAmount()) <= 0) {
            throw new ParameterVerificationException("参数校验失败.金额必须>0");
        }

        OrderTimeValidator.checkOrderTimeFormat(createPaymentOrderVO.getOrderTime());
        PaymentTypeEnum paymentType = EnumUtils.getEnum(PaymentTypeEnum.class, createPaymentOrderVO.getPaymentType());
        if (paymentType == null) {
            throw new ParameterVerificationException("参数校验失败.无法识别支付类型:");
        }

        final String mchId = createPaymentOrderVO.getMerchantNo();
        final String sign = createPaymentOrderVO.getSign();

        //商户号
        Merchant merchant = paymentService.getMerchant(mchId);
        if (merchant == null) {
            throw new ParameterVerificationException("该商户不存在");
        }
        if (createPaymentOrderVO.getGoodsNum()!=null) {
            if(!NumberUtils.isInteger(createPaymentOrderVO.getGoodsNum())) {
                throw new ParameterVerificationException("参数校验失败.商品数量非法");
            }
        }

        //检查银行编码
        if (StringUtils.isNotBlank(createPaymentOrderVO.getBankCode())) {
            BankCodeEnum bankCode = BankCodeEnum.valueOfCode(createPaymentOrderVO.getBankCode());
            if (bankCode == null) {
                throw new ParameterVerificationException("无法识别的银行编码");
            }
        }

        /**
         * 2.检查签名
         */
        boolean checkSignResult = SignUtils.checkSign(merchant.getSecretKey(), createPaymentOrderVO, sign);
        if (!checkSignResult) {
            throw new ParameterVerificationException("签名校验失败");
        }
        return merchant;
    }

    private CreatePaymentOrderRequest createRequestParam(CreatePaymentOrderRequestVO payOrder,String clientIp, String serverPath) {
        CreatePaymentOrderRequest orderRequest = new CreatePaymentOrderRequest();
        orderRequest.setMerchantNo(payOrder.getMerchantNo());
        orderRequest.setPaymentType(PaymentTypeEnum.valueOf(payOrder.getPaymentType()));
        orderRequest.setOrderTime(new Date());
        orderRequest.setGoodsName(payOrder.getGoodsName());
        orderRequest.setAmount(Integer.valueOf(payOrder.getAmount()));
        orderRequest.setClientIp(clientIp);
        orderRequest.setFrontReturnUrl(payOrder.getFrontReturnUrl());
        orderRequest.setNotifyUrl(payOrder.getNotifyUrl());
        orderRequest.setMerchantOrderNo(payOrder.getMchOrderNo());
        orderRequest.setBuyerId(payOrder.getBuyerId());
        orderRequest.setBuyerName(payOrder.getBuyerName());
        orderRequest.setGoodsInfo(payOrder.getGoodsInfo());
        orderRequest.setAlipayAccId(payOrder.getAlipayAccId());
        if (StringUtils.isNotBlank(payOrder.getGoodsNum())) {
            orderRequest.setGoodsNum(Integer.valueOf(payOrder.getGoodsNum()));
        } else {
            orderRequest.setGoodsNum(1);
        }
        orderRequest.setRemark(payOrder.getRemark());
        orderRequest.setPlatformServerPath(serverPath);
        orderRequest.setBuyerContact(payOrder.getBuyerContact());
        if (StringUtils.isNotBlank(payOrder.getBankCode())) {
            orderRequest.setBankCode(BankCodeEnum.valueOfCode(payOrder.getBankCode()));
        }
        orderRequest.setChannelAccountNo(payOrder.getChannelAccountNo());
        return orderRequest;
    }

    private CreatePaymentOrderResponseVO createReponse(String secretKey, CreatePaymentOrderResult orderResult) {
        CreatePaymentOrderResponseVO rsp = new CreatePaymentOrderResponseVO();
        rsp.setReturnCode(ReturnCodeEnum.SUCCESS.name());
        rsp.setReturnMsg("请求成功");

        rsp.setMchOrderNo(orderResult.getMerchantOrderNo());
        rsp.setPlatformOrderNo(orderResult.getPlatformOrderNo());
        rsp.setResultCode(orderResult.getResultCode().name());
        rsp.setResultDesc(orderResult.getResultDesc());
        rsp.setPayUrl(orderResult.getPayUrl());
        rsp.setUrlType(orderResult.getUrlType().name());
        if (orderResult.getUrlType().equals(UrlTypeEnum.PURL) || orderResult.getUrlType().equals(UrlTypeEnum.H5_MULTIPLE_JUMP)){
            rsp.setUrlType(UrlTypeEnum.URL.name());
        }

        rsp.setNonceStr(System.currentTimeMillis() + "");
        rsp.setSign(SignUtils.createSign(secretKey, rsp));
        return rsp;
    }

    /**
     * OTC返回feedbackurl
     * @param secretKey
     * @param orderResult
     * @return
     */
    private CreatePaymentOrderResponseOtcVO createOtcReponse(String secretKey, CreatePaymentOrderResult orderResult) {
        CreatePaymentOrderResponseOtcVO rsp = new CreatePaymentOrderResponseOtcVO();
        rsp.setReturnCode(ReturnCodeEnum.SUCCESS.name());
        rsp.setReturnMsg("请求成功");

        rsp.setMchOrderNo(orderResult.getMerchantOrderNo());
        rsp.setPlatformOrderNo(orderResult.getPlatformOrderNo());
        rsp.setResultCode(orderResult.getResultCode().name());
        rsp.setResultDesc(orderResult.getResultDesc());
        rsp.setPayUrl(orderResult.getPayUrl());
        rsp.setUrlType(orderResult.getUrlType().name());
        rsp.setNonceStr(System.currentTimeMillis() + "");

        rsp.setFeedbackUrl(orderResult.getFeedbackUrl());
        rsp.setSign(SignUtils.createSign(secretKey, rsp));
        return rsp;
    }





}
