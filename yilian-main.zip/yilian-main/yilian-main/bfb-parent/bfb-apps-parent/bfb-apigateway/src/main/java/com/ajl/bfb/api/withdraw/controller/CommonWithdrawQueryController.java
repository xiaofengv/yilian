package com.ajl.bfb.api.withdraw.controller;

import com.ajl.bfb.api.common.vo.BaseRequestVO;
import com.ajl.bfb.api.withdraw.vo.QueryAccountResponseVO;
import com.ajl.bfb.api.withdraw.vo.QueryWithdrawOrderRequestVO;
import com.ajl.bfb.api.withdraw.vo.QueryWithdrawOrderResponseVO;
import com.ajl.bfb.common.exception.QueryAccountException;
import com.ajl.bfb.common.exception.QueryOrderException;
import com.ajl.bfb.common.withdraw.model.QueryWithdrawOrderResponse;
import com.ajl.bfb.core.constants.ResultCodeEnum;
import com.ajl.bfb.core.constants.ReturnCodeEnum;
import com.ajl.bfb.core.exception.ParameterVerificationException;
import com.ajl.bfb.core.util.SignUtils;
import com.ajl.bfb.pay.withdraw.IWithdrawFacade;
import com.ajl.bfb.pay.withdraw.WithdrawMerchantNotifyException;
import com.ajl.bfb.pay.withdraw.model.AccountBalance;
import com.ajl.bfb.pay.withdraw.model.QueryWithdrawOrderParam;
import com.ajl.bfb.repo.merchant.FundException;
import com.ajl.bfb.repo.merchant.model.Merchant;
import com.ajl.bfb.repo.merchant.service.IMerchantAccountService;
import com.ajl.bfb.repo.merchant.service.IMerchantService;
import com.hippo.framework.util.JsonUtils;
import com.hippo.framework.util.validation.ValidationUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * 提现订单查询
 * Created by admin on 2018-06-18 0018.
 */
@Controller
@RequestMapping(value = "/api_gateway/query")
public class CommonWithdrawQueryController {
    private static Logger logger = LogManager.getLogger(CommonWithdrawQueryController.class);
    @Autowired
    private IMerchantService merchantService;
    @Autowired
    private IWithdrawFacade withdrawFacade;
    @Autowired
    private IMerchantAccountService merchantAccountService;

    @RequestMapping(value = "/withdraw_order")
    @ResponseBody
    public QueryWithdrawOrderResponseVO queryWithdrawOrder(@RequestBody QueryWithdrawOrderRequestVO reqVO) throws FundException, QueryOrderException, WithdrawMerchantNotifyException {
        logger.info("[before]查询代付订单:request:data:" + JsonUtils.obj2String(reqVO));
        //参数检查
        Merchant merchant = preCheck(reqVO);
        QueryWithdrawOrderParam param = new QueryWithdrawOrderParam();
        param.setMerchantNo(reqVO.getMerchantNo());
        param.setMerchantOrderNo(reqVO.getMchOrderNo());
        QueryWithdrawOrderResponse queryRsp = withdrawFacade.queryWithdrawOrder(param);
        QueryWithdrawOrderResponseVO rspVO = new QueryWithdrawOrderResponseVO();
        if (queryRsp.getResultCode() == ResultCodeEnum.SUCCESS) {
            rspVO.setReturnCode(ReturnCodeEnum.SUCCESS.name());
            rspVO.setReturnMsg("查询成功");
            rspVO.setOrderStatus(queryRsp.getOrderStatus().name());
            rspVO.setOrderDesc(rspVO.getOrderDesc());
        } else {
            rspVO.setReturnCode(ReturnCodeEnum.FAIL.name());
            rspVO.setReturnMsg(queryRsp.getResultMsg());
            return rspVO;
        }
        rspVO.setTotalFee(queryRsp.getTotalFee());
        rspVO.setNonceStr(System.currentTimeMillis()+"");
        rspVO.setSign(SignUtils.createSign(merchant.getSecretKey(), rspVO));
        logger.info("[after]查询代付订单:response:data:" + JsonUtils.obj2String(rspVO));
        return rspVO;
    }

    /**
     * 查询商户余额
     * @param reqVO
     * @return
     * @throws QueryAccountException
     */
    @RequestMapping(value = "/mch_account")
    @ResponseBody
    public QueryAccountResponseVO queryBalance(@RequestBody BaseRequestVO reqVO) throws QueryAccountException {
        Merchant merchant = preCheck(reqVO);
        int merchantId = merchant.getId();

        AccountBalance accountBalance = withdrawFacade.queryMerchantAccount(merchantId);
        long withdrawBalance =  merchantAccountService.getMerchantWithdrawBalance(merchant.getId());

        QueryAccountResponseVO vo = new QueryAccountResponseVO();
        vo.setCashBalance(withdrawBalance + "");
        vo.setTotalBalance(accountBalance.getTotalBalance().toString());
        vo.setNonceStr(System.currentTimeMillis() + "");
        vo.setReturnCode(ReturnCodeEnum.SUCCESS.name());
        vo.setReturnMsg("查询成功");
        vo.setSign(SignUtils.createSign(merchant.getSecretKey(), vo));
        return vo;
    }

    /**
     * 前置校验，检查参数合法性，商户信息合法性
     * @return
     * @throws ParameterVerificationException
     */
    private Merchant preCheck(BaseRequestVO reqVO) throws ParameterVerificationException {
        String error = ValidationUtils.validate(reqVO);
        if (error != null) {
            throw new ParameterVerificationException("参数校验失败." + error);
        }
        //商户号
        final String mchId = reqVO.getMerchantNo();
        final String sign = reqVO.getSign();

        Merchant merchant = merchantService.findByMerchantNo(reqVO.getMerchantNo());
        if (merchant == null) {
            throw new ParameterVerificationException("该商户不存在");
        }
        /**
         * 2.检查签名
         */
        boolean checkSignResult = SignUtils.checkSign(merchant.getSecretKey(), reqVO, sign);
        if (!checkSignResult) {
            throw new ParameterVerificationException("签名校验失败");
        }
        return merchant;
    }
}
