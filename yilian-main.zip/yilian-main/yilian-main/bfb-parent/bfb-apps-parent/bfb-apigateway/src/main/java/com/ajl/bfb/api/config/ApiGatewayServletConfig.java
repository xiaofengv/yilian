package com.ajl.bfb.api.config;

import com.ajl.bfb.api.servlet.BarCode2DServlet;
import com.hippo.framework.web.servlet.ParameterFilter;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Created by admin on 2018-02-15 0015.
 */
@Configuration
public class ApiGatewayServletConfig {

    @Bean
    public FilterRegistrationBean indexFilterRegistration() {
        //去掉请求参数的前后空格
        FilterRegistrationBean registration = new FilterRegistrationBean(new ParameterFilter());
        registration.addUrlPatterns("/*");
        //多个用;号隔开
        registration.addInitParameter(ParameterFilter.EXCLUDE_URI_KEY, "/api_gateway/callback/pay/hfb_callback");
        registration.setOrder(0);
        return registration;
    }


    /**
     * 后台登录验证码
     * @return BarCode2DServlet
     */
    @Bean("qrCodeImgServlet")
    public ServletRegistrationBean loginVerifyCodeImgRegistration() {
        ServletRegistrationBean registration = new ServletRegistrationBean(new BarCode2DServlet());
        registration.addUrlMappings("/qr_code_image");
        registration.setName("qrCodeImgServlet");
        return registration;
    }

      /*
    @Bean
    public ServletListenerRegistrationBean servletListenerRegistrationBean(){
        ServletListenerRegistrationBean servletListenerRegistrationBean = new ServletListenerRegistrationBean();
        servletListenerRegistrationBean.setListener(new IndexListener());
        return servletListenerRegistrationBean;
    }*/

}
