package com.ajl.bfb.api.withdraw.vo;

import com.ajl.bfb.api.common.vo.BaseRequestVO;
import lombok.Data;

@Data
public class QueryWithdrawOrderRequestVO extends BaseRequestVO {

    private String mchOrderNo;

}
