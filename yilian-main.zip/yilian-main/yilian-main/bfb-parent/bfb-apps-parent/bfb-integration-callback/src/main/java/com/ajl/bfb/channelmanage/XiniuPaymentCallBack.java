package com.ajl.bfb.channelmanage;

import com.ajl.bfb.common.payment.model.PaymentCallbackResponse;
import com.ajl.bfb.core.constants.ChannelCodeEnum;
import com.ajl.bfb.core.constants.OrderStatusEnum;
import com.ajl.bfb.pay.IPayLogService;
import com.ajl.bfb.pay.payment.IPaymentCallbackProxy;
import com.ajl.bfb.repo.channel.model.Channel;
import com.ajl.bfb.repo.channel.service.IChannelService;
import com.ajl.bfb.repo.payment.model.PaymentOrder;
import com.ajl.bfb.repo.payment.service.IPaymentOrderService;
import com.alibaba.fastjson.JSON;
import com.hippo.framework.util.JsonUtils;
import com.hippo.framework.util.net.HttpUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.InputStream;
import java.util.Map;


@Controller
@RequestMapping(value = "/api_gateway/callback/pay")
public class XiniuPaymentCallBack {
    private static Logger logger = LogManager.getLogger(XiniuPaymentCallBack.class);
    @Autowired
    private IPaymentOrderService paymentOrderService;
    @Autowired
    private IPayLogService payLogService;
    @Autowired
    private IPaymentCallbackProxy paymentCallbackProxy;
    @Autowired
    private IChannelService channelService;
    @RequestMapping(value = "/xiniu")
    public void callback(HttpServletRequest request, HttpServletResponse httpResponse) throws IOException {
        InputStream in=request.getInputStream();
        int size=request.getContentLength();
        byte[] reqBodyBytes = readBytes(in, size);
        String json = new String(reqBodyBytes);
        logger.info("[before]xiniu支付订单回调:" + json);
        Map m= (Map) JSON.parse(json);
        String orderid = MapUtils.getString(m,"tradeNo");
        String returncode = MapUtils.getString(m,"status");
        PaymentOrder order = paymentOrderService.findByPlatformOrderNo(orderid);

        //校验回调IP
        Channel channel = channelService.findChannelByCode(ChannelCodeEnum.XMS.name());
        String ip = HttpUtils.getRemoteAddr(request);
        logger.info("回调IP:" + ip);
        String notifyIp = channel.getNotifyIp();
        if (StringUtils.isNotEmpty(notifyIp) && !notifyIp.contains(ip)){
            logger.info("IP非法请求，请求IP没有配置白名单，订单号:" + orderid);
            throw new RuntimeException("IP非法请求，请求IP没有配置白名单，订单号:" + orderid);
        }
//        payLogService.saveNotifyLog(orderid, json,"");

        if (order == null) {
            logger.error("没找到对应的订单:" + orderid);
            throw new RuntimeException("没找到对应的订单:" + orderid);
        }
        //过滤重复回调
        if(order.getOrderStatus().equals(OrderStatusEnum.SUCCESS)){
            logger.info("订单" + orderid + "已经处理");
            callbackChannel(httpResponse, orderid);
        }
        try {
            if (returncode.equals("4")) {
                PaymentCallbackResponse rsp = new PaymentCallbackResponse();
                rsp.setOrderStatus(OrderStatusEnum.SUCCESS);
                rsp.setOrderDesc("处理成功");
                rsp.setTotalFee(0);
                rsp.setPlateformOrderNo(order.getPlatformOrderNo());
                rsp.setResponseContent(JsonUtils.obj2String(m));
                paymentCallbackProxy.doCallback(rsp, true);
                callbackChannel(httpResponse, orderid);
                logger.info("xiniu.订单支付回调处理成功,订单号:{}", orderid);
            }
        } catch (Throwable e) {
            throw new RuntimeException("xiniu.支付订单构回调处理异常", e);
        }
    }
    private final byte[] readBytes(InputStream is, int contentLen) {
        if (contentLen > 0) {
            int readLen = 0;
            int readLengthThisTime = 0;
            byte[] message = new byte[contentLen];
            try {
                while (readLen != contentLen) {
                    readLengthThisTime = is.read(message, readLen, contentLen - readLen);
                    if (readLengthThisTime == -1) {
                        break;
                    }
                    readLen += readLengthThisTime;
                }
                return message;
            } catch (IOException e) {
            }
        }
        return new byte[]{};
    }
    private void callbackChannel(HttpServletResponse httpResponse, String orderNo) throws IOException {
        String html = "ok";
        httpResponse.getWriter().write(html);
        httpResponse.getWriter().flush();
        httpResponse.getWriter().close();
        logger.info("xiniu.支付回调上游成功:" + orderNo);
    }

}
