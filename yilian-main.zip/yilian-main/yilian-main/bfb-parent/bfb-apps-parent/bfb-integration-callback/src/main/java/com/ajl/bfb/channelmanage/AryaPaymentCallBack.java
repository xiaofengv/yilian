package com.ajl.bfb.channelmanage;

import com.ajl.bfb.common.payment.model.PaymentCallbackResponse;
import com.ajl.bfb.core.constants.ChannelCodeEnum;
import com.ajl.bfb.core.constants.OrderStatusEnum;
import com.ajl.bfb.pay.IPayLogService;
import com.ajl.bfb.pay.payment.IPaymentCallbackProxy;
import com.ajl.bfb.repo.channel.model.Channel;
import com.ajl.bfb.repo.channel.service.IChannelService;
import com.ajl.bfb.repo.payment.model.PaymentOrder;
import com.ajl.bfb.repo.payment.service.IPaymentOrderService;
import com.ajl.bfb.util.CallbackUtils;
import com.hippo.framework.util.JsonUtils;
import com.hippo.framework.util.net.HttpUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Map;


@Controller
@RequestMapping(value = "/api_gateway/callback/pay")
public class AryaPaymentCallBack {
    private static Logger logger = LogManager.getLogger(AryaPaymentCallBack.class);
    @Autowired
    private IPaymentOrderService paymentOrderService;
    @Autowired
    private IPayLogService payLogService;
    @Autowired
    private IPaymentCallbackProxy paymentCallbackProxy;
    @Autowired
    private IChannelService channelService;

    @RequestMapping(value = "/arya")
    public void callback(HttpServletRequest request, HttpServletResponse httpResponse) throws IOException {
        String rspParamJson = JsonUtils.obj2StringNoEscaping(request.getParameterMap());
        Map<String, String> rspMap = CallbackUtils.getParameters(request);
        logger.info("[before]arya订单回调:" + rspParamJson);

        String orderNo = request.getParameter("ordernumber");

        //校验回调IP
        Channel channel = channelService.findChannelByCode(ChannelCodeEnum.ARYA.name());
        String ip = HttpUtils.getRemoteAddr(request);
        logger.info("arya回调IP:" + ip);
        String notifyIp = channel.getNotifyIp();
        if (StringUtils.isNotEmpty(notifyIp) && !notifyIp.contains(ip)){
            logger.info("IP非法请求，请求IP没有配置白名单，订单号:" + orderNo);
            throw new RuntimeException("IP非法请求，请求IP没有配置白名单，订单号:" + orderNo);
        }

        String returncode = request.getParameter("orderstatus");
        PaymentOrder order = paymentOrderService.findByPlatformOrderNo(orderNo);
        payLogService.saveNotifyLog(orderNo, rspParamJson,"");

        if (order == null) {
            logger.error("没找到对应的订单:" + orderNo);
            throw new RuntimeException("没找到对应的订单:" + orderNo);
        }
        //过滤重复回调
        if(order.getOrderStatus().equals(OrderStatusEnum.SUCCESS)){
            logger.info("订单" + orderNo + "已经处理");
            callbackChannel(httpResponse, orderNo);
        }
        try {
            if (returncode.equals("1")) {
                PaymentCallbackResponse rsp = new PaymentCallbackResponse();
                rsp.setOrderStatus(OrderStatusEnum.SUCCESS);
                rsp.setOrderDesc("处理成功");
                rsp.setTotalFee(0);
                rsp.setPlateformOrderNo(order.getPlatformOrderNo());
                rsp.setResponseContent(JsonUtils.obj2String(rspMap));
                paymentCallbackProxy.doCallback(rsp, true);
                callbackChannel(httpResponse, orderNo);
                logger.info("arya订单支付回调处理成功,订单号:{}", orderNo);
            }
        } catch (Throwable e) {
            throw new RuntimeException("arya订单回调处理异常", e);
        }
    }

    private void callbackChannel(HttpServletResponse httpResponse, String orderNo) throws IOException {
        String html = "ok";
        httpResponse.getWriter().write(html);
        httpResponse.getWriter().flush();
        httpResponse.getWriter().close();
        logger.info("arya支付回调上游成功:" + orderNo);
    }

}
