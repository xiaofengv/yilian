package com.ajl.bfb.channelmanage;

import com.ajl.bfb.common.payment.model.PaymentCallbackResponse;
import com.ajl.bfb.core.constants.OrderStatusEnum;
import com.ajl.bfb.pay.payment.IPaymentCallbackProxy;
import com.ajl.bfb.util.CallbackUtils;
import com.hippo.framework.util.JsonUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Map;

@Controller
@RequestMapping(value = "/api_gateway/callback")
public class LanMaoPaymentCallBack {

    private static Logger logger = LogManager.getLogger(LanMaoPaymentCallBack.class);

    @Autowired
    private IPaymentCallbackProxy paymentCallbackProxy;

    /**
     * 易付宝回调地址
     * @param request
     * @param response
     */
    @RequestMapping(value = "/pay/lanmao")
    public void callback(HttpServletRequest request, HttpServletResponse response) {
        String rspParamJson = JsonUtils.obj2StringNoEscaping(request.getParameterMap());
        logger.info("[before]懒猫:" + rspParamJson);
        Map<String, String> rspMap = CallbackUtils.getParameters(request);
        String out_trade_no = request.getParameter("out_trade_no");//商户订单【订单】
        String status = request.getParameter("callbacks");

        try {
            if (status.equals("CODE_SUCCESS")) {
                PaymentCallbackResponse rsp = new PaymentCallbackResponse();
                rsp.setOrderStatus(OrderStatusEnum.SUCCESS);
                rsp.setOrderDesc("处理成功");
                rsp.setTotalFee(0);
                rsp.setPlateformOrderNo(out_trade_no);
                rsp.setResponseContent(JsonUtils.obj2String(rspMap));
                paymentCallbackProxy.doCallback(rsp, true);
                callbackChannel(response, out_trade_no);
                logger.info("懒猫.订单支付回调处理成功,订单号:" + out_trade_no);
            }
        } catch (Throwable e) {
            throw new RuntimeException("懒猫.支付订单构回调处理异常", e);
        }
    }

    //通知上游回调成功
    private void callbackChannel(HttpServletResponse httpResponse, String orderNo) throws IOException {
        String html = "success";
        httpResponse.getWriter().write(html);
        httpResponse.getWriter().flush();
        httpResponse.getWriter().close();
        logger.info("懒猫.支付回调上游成功:" + orderNo);
    }

}
