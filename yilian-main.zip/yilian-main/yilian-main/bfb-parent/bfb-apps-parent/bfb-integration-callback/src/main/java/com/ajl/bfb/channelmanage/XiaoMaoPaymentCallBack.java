package com.ajl.bfb.channelmanage;

import com.ajl.bfb.common.payment.model.PaymentCallbackResponse;
import com.ajl.bfb.core.constants.OrderStatusEnum;
import com.ajl.bfb.pay.payment.IPaymentCallbackProxy;
import com.ajl.bfb.repo.payment.model.PaymentOrder;
import com.ajl.bfb.repo.payment.service.IPaymentOrderService;
import com.alibaba.fastjson.JSON;
import org.apache.commons.collections.MapUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.ServletInputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Map;

/**
 * 对接小猫通道
 */
@Controller
@RequestMapping(value = "/api_gateway/callback/pay")
public class XiaoMaoPaymentCallBack {

    private static Logger logger = LogManager.getLogger(XiaoMaoPaymentCallBack.class);

    @Autowired
    private IPaymentCallbackProxy paymentCallbackProxy;

    @Autowired
    private IPaymentOrderService paymentOrderService;

    @RequestMapping(value = "/xiaomao")
    public void callback(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("text/plain");
        response.setCharacterEncoding("utf-8");
        // 获取所有提交参数
        BufferedReader br = new BufferedReader(new InputStreamReader((ServletInputStream) request.getInputStream(), "utf-8"));
        StringBuffer sb = new StringBuffer();
        String temp;
        while ((temp = br.readLine()) != null) {
            sb.append(temp);
        }
        br.close();
        String result = sb.toString();
        logger.info("小猫回调返回参数：" + result);
        Map rspMap = (Map) JSON.parse(result);


        String orderNo = MapUtils.getString(rspMap,"outOrderId");
        String orderStatus = MapUtils.getString(rspMap,"partnerOrderStatus");

        //查询平台订单信息
        PaymentOrder order = paymentOrderService.findByPlatformOrderNo(orderNo);

        if (order == null) {
            logger.error("没找到对应的订单:" + orderNo);
            throw new RuntimeException("没找到对应的订单:" + orderNo);
        }
        //过滤重复回调
        if(order.getOrderStatus().equals(OrderStatusEnum.SUCCESS)){
            logger.info("订单" + orderNo + "已经处理");
            callbackChannel(response, orderNo);
        }
        try {
            if (orderStatus.equals("SUCCESS")) {
                PaymentCallbackResponse rsp = new PaymentCallbackResponse();
                rsp.setOrderStatus(OrderStatusEnum.SUCCESS);
                rsp.setOrderDesc("处理成功");
                rsp.setTotalFee(0);
                rsp.setPlateformOrderNo(orderNo);
                rsp.setResponseContent(result);
                paymentCallbackProxy.doCallback(rsp, true);
                callbackChannel(response, orderNo);
                logger.info("小猫订单支付回调处理成功,订单号:" + orderNo);
            }
        } catch (Throwable e) {
            throw new RuntimeException("小猫支付订单构回调处理异常", e);
        }
    }

    //通知上游回调成功
    private void callbackChannel(HttpServletResponse httpResponse, String orderNo) throws IOException {
        String html = "SUCCESS";
        httpResponse.getWriter().write(html);
        httpResponse.getWriter().flush();
        httpResponse.getWriter().close();
        logger.info("小猫回调上游成功:" + orderNo);
    }

}
