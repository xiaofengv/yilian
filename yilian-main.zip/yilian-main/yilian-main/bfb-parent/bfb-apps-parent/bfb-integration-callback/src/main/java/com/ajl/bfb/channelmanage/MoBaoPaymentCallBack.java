package com.ajl.bfb.channelmanage;

import com.ajl.bfb.common.payment.model.PaymentCallbackResponse;
import com.ajl.bfb.core.constants.OrderStatusEnum;
import com.ajl.bfb.pay.IPayLogService;
import com.ajl.bfb.pay.payment.IPaymentCallbackProxy;
import com.ajl.bfb.repo.payment.model.PaymentOrder;
import com.ajl.bfb.repo.payment.service.IPaymentOrderService;
import com.ajl.bfb.util.CallbackUtils;
import com.hippo.framework.util.JsonUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Map;


@Controller
@RequestMapping(value = "/api_gateway/callback/pay")
public class MoBaoPaymentCallBack {
    private static Logger logger = LogManager.getLogger(MoBaoPaymentCallBack.class);
    @Autowired
    private IPaymentOrderService paymentOrderService;
    @Autowired
    private IPayLogService payLogService;
    @Autowired
    private IPaymentCallbackProxy paymentCallbackProxy;

    @RequestMapping(value = "/mobao")
    public void callback(HttpServletRequest request, HttpServletResponse httpResponse) throws IOException {
        String rspParamJson = JsonUtils.obj2StringNoEscaping(request.getParameterMap());
        Map<String, String> rspMap = CallbackUtils.getParameters(request);
        logger.info("[before]摩宝支付.订单回调:" + rspParamJson);
        String orderid = request.getParameter("orderNo");
        String tradeStatus = request.getParameter("orderStatus");
        PaymentOrder order = paymentOrderService.findByPlatformOrderNo(orderid);

        payLogService.saveNotifyLog(orderid, rspParamJson,"");

        if (order == null) {
            logger.error("没找到对应的订单:" + orderid);
            throw new RuntimeException("没找到对应的订单:" + orderid);
        }
        //过滤重复回调
        if(order.getOrderStatus().equals(OrderStatusEnum.SUCCESS)){
            logger.info("订单" + orderid + "已经处理");
            callbackChannel(httpResponse, orderid);
        }
        try {
            if (tradeStatus.equals("1")) {
                PaymentCallbackResponse rsp = new PaymentCallbackResponse();
                rsp.setOrderStatus(OrderStatusEnum.SUCCESS);
                rsp.setOrderDesc("处理成功");
                rsp.setTotalFee(0);
                rsp.setPlateformOrderNo(order.getPlatformOrderNo());
                rsp.setResponseContent(JsonUtils.obj2String(rspMap));
                paymentCallbackProxy.doCallback(rsp, true);
                callbackChannel(httpResponse, orderid);
                logger.info("摩宝支付.订单支付回调处理成功,订单号:{}", orderid);
            }
        } catch (Throwable e) {
            throw new RuntimeException("摩宝支付.订单构回调处理异常", e);
        }
    }

    private void callbackChannel(HttpServletResponse httpResponse, String orderNo) throws IOException {
        String html = "SUCCESS";
        httpResponse.getWriter().write(html);
        httpResponse.getWriter().flush();
        httpResponse.getWriter().close();
        logger.info("摩宝支付.支付回调上游成功:" + orderNo);
    }

}
