package com.ajl.bfb.channelmanage;

import com.ajl.bfb.common.payment.model.PaymentCallbackResponse;
import com.ajl.bfb.core.constants.OrderStatusEnum;
import com.ajl.bfb.pay.payment.IPaymentCallbackProxy;
import com.ajl.bfb.pay.payment.PaymentMerchantNotifyException;
import com.alibaba.fastjson.JSONObject;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;


@Controller
@RequestMapping(value = "/api_gateway/callback/pay")
public class LaiBaoPaymentCallBack {
    private static Logger logger = LogManager.getLogger(LaiBaoPaymentCallBack.class);
    @Autowired
    private IPaymentCallbackProxy paymentCallbackProxy;

    @RequestMapping(value = "/laibao")
    public void callback(HttpServletRequest request, HttpServletResponse httpResponse) throws IOException, PaymentMerchantNotifyException {
        httpResponse.setContentType("text/plain");
        httpResponse.setCharacterEncoding("utf-8");
        // 获取所有提交参数
        BufferedReader br = new BufferedReader(new InputStreamReader(request.getInputStream(), "utf-8"));
        StringBuffer sb = new StringBuffer("");
        String temp;
        while ((temp = br.readLine()) != null) {
            sb.append(temp);
        }
        br.close();
        String result = sb.toString();
        logger.info("莱宝回调参数：" + result);//打印接受到的JSON参数
        // 开始解析JSON
        if (result != null && !result.equals("")) {
            JSONObject js = JSONObject.parseObject(sb.toString());
            Map<String, Object> post = new HashMap();
            post.put("trade_no", js.getString("trade_no"));
            post.put("total_fee", js.getString("total_fee"));
            post.put("out_trade_no", js.getString("out_trade_no"));
            post.put("tradingfee", js.getString("tradingfee"));
            post.put("paysucessdate", js.getString("paysucessdate"));

            logger.info("莱宝回调验签通过");//打印接受到的JSON参数
            PaymentCallbackResponse rsp = new PaymentCallbackResponse();
            rsp.setOrderStatus(OrderStatusEnum.SUCCESS);
            rsp.setOrderDesc("处理成功");
            rsp.setTotalFee(0);
            rsp.setPlateformOrderNo(js.getString("out_trade_no"));
            rsp.setResponseContent(js.toJSONString());
            paymentCallbackProxy.doCallback(rsp, true);
            httpResponse.getWriter().write("success");
            //}
        }
    }
}
