package com.ajl.bfb.channelmanage;

import com.ajl.bfb.common.payment.model.PaymentCallbackResponse;
import com.ajl.bfb.core.constants.ChannelCodeEnum;
import com.ajl.bfb.core.constants.OrderStatusEnum;
import com.ajl.bfb.pay.payment.IPaymentCallbackProxy;
import com.ajl.bfb.repo.channel.model.Channel;
import com.ajl.bfb.repo.channel.service.IChannelService;
import com.ajl.bfb.repo.payment.model.PaymentOrder;
import com.ajl.bfb.repo.payment.service.IPaymentOrderService;
import com.ajl.bfb.util.CallbackUtils;
import com.hippo.framework.util.JsonUtils;
import com.hippo.framework.util.net.HttpUtils;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Map;


@Controller
@RequestMapping(value = "/api_gateway/callback/pay")
public class DnyPaymentCallBack {

    private static Logger logger = LogManager.getLogger(DnyPaymentCallBack.class);

    @Autowired
    private IPaymentCallbackProxy paymentCallbackProxy;

    @Autowired
    private IPaymentOrderService paymentOrderService;
    @Autowired
    private IChannelService channelService;

    @RequestMapping(value = "/dny")
    public void callback(HttpServletRequest request, HttpServletResponse response) throws IOException {
        logger.info("东南亚回调");
        String rspParamJson = JsonUtils.obj2StringNoEscaping(request.getParameterMap());
        Map<String, String> rspMap = CallbackUtils.getParameters(request);
        logger.info("[before]东南亚订单回调:" + rspMap);

        String orderNo = MapUtils.getString(rspMap,"outtradeno");
        String returncode = MapUtils.getString(rspMap,"paystatus");

        //校验回调IP
        Channel channel = channelService.findChannelByCode(ChannelCodeEnum.DNY.name());
        String ip = HttpUtils.getRemoteAddr(request);
        logger.info("东南亚回调IP:" + ip);
        String notifyIp = channel.getNotifyIp();
        if (StringUtils.isNotEmpty(notifyIp) && !notifyIp.contains(ip)){
            logger.info("IP非法请求，请求IP没有配置白名单，订单号:" + orderNo);
            throw new RuntimeException("IP非法请求，请求IP没有配置白名单，订单号:" + orderNo);
        }
        //查询平台订单信息
        PaymentOrder order = paymentOrderService.findByPlatformOrderNo(orderNo);

        if (order == null) {
            logger.error("没找到对应的订单:" + orderNo);
            throw new RuntimeException("没找到对应的订单:" + orderNo);
        }
        //过滤重复回调
        if(order.getOrderStatus().equals(OrderStatusEnum.SUCCESS)){
            logger.info("订单" + orderNo + "已经处理");
            callbackChannel(response, orderNo);
        }
        try {
            if (returncode.equals("4")) {
                PaymentCallbackResponse rsp = new PaymentCallbackResponse();
                rsp.setOrderStatus(OrderStatusEnum.SUCCESS);
                rsp.setOrderDesc("处理成功");
                rsp.setTotalFee(0);
                rsp.setPlateformOrderNo(orderNo);
                rsp.setResponseContent(rspParamJson);
                paymentCallbackProxy.doCallback(rsp, true);
                callbackChannel(response, orderNo);
                logger.info("东南亚订单支付回调处理成功,订单号:" + orderNo);
            }
        } catch (Throwable e) {
            throw new RuntimeException("东南亚支付订单构回调处理异常", e);
        }
    }

    //通知上游回调成功
    private void callbackChannel(HttpServletResponse httpResponse, String orderNo) throws IOException {
        String html = "success";
        httpResponse.getWriter().write(html);
        httpResponse.getWriter().flush();
        httpResponse.getWriter().close();
        logger.info("东南亚回调上游成功:" + orderNo);
    }

}
