package com.ajl.bfb.channelmanage;

import com.ajl.bfb.common.payment.model.PaymentCallbackResponse;
import com.ajl.bfb.core.constants.OrderStatusEnum;
import com.ajl.bfb.pay.payment.IPaymentCallbackProxy;
import com.ajl.bfb.repo.payment.model.PaymentOrder;
import com.ajl.bfb.repo.payment.service.IPaymentOrderService;
import com.ajl.bfb.util.CallbackUtils;
import com.hippo.framework.util.JsonUtils;
import org.apache.commons.collections.MapUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Map;


@Controller
@RequestMapping(value = "/api_gateway/callback/pay")
public class FuPayPaymentCallBack {

    private static Logger logger = LogManager.getLogger(FuPayPaymentCallBack.class);

    @Autowired
    private IPaymentCallbackProxy paymentCallbackProxy;

    @Autowired
    private IPaymentOrderService paymentOrderService;

    @RequestMapping(value = "/fupay")
    public void callback(HttpServletRequest request, HttpServletResponse response,String orderid,String opstate) throws IOException {
/*        String rspParamJson = JsonUtils.obj2StringNoEscaping(request.getParameterMap());
        Map<String, String> rspMap = CallbackUtils.getParameters(request);
        logger.info("[before]fupay订单回调:" + rspParamJson);
        */
//        String orderNo = MapUtils.getString(rspMap,"orderid");
//        String returncode = MapUtils.getString(rspMap,"opstate");
        logger.info("fupay回调单号:" + orderid);
        logger.info("fupay回调状态:" + opstate);
        //查询平台订单信息
        PaymentOrder order = paymentOrderService.findByPlatformOrderNo(orderid);

        if (order == null) {
            logger.error("没找到对应的订单:" + orderid);
            throw new RuntimeException("没找到对应的订单:" + orderid);
        }
        //过滤重复回调
        if(order.getOrderStatus().equals(OrderStatusEnum.SUCCESS)){
            logger.info("订单" + orderid + "已经处理");
            callbackChannel(response, orderid);
        }
        try {
            if (opstate.equals("0")) {
                PaymentCallbackResponse rsp = new PaymentCallbackResponse();
                rsp.setOrderStatus(OrderStatusEnum.SUCCESS);
                rsp.setOrderDesc("处理成功");
                rsp.setTotalFee(0);
                rsp.setPlateformOrderNo(orderid);
                rsp.setResponseContent(orderid+"/"+opstate);
                paymentCallbackProxy.doCallback(rsp, true);
                callbackChannel(response, orderid);
                logger.info("fupay订单支付回调处理成功,订单号:" + orderid);
            }
        } catch (Throwable e) {
            throw new RuntimeException("fupay支付订单构回调处理异常", e);
        }
    }

    //通知上游回调成功
    private void callbackChannel(HttpServletResponse httpResponse, String orderNo) throws IOException {
        String html = "opstate=0";
        httpResponse.getWriter().write(html);
        httpResponse.getWriter().flush();
        httpResponse.getWriter().close();
        logger.info("fupay回调上游成功:" + orderNo);
    }

}
