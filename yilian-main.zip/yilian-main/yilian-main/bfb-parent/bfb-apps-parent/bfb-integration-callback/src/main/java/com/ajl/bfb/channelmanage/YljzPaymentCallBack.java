package com.ajl.bfb.channelmanage;

import com.ajl.bfb.common.payment.model.PaymentCallbackResponse;
import com.ajl.bfb.core.constants.ChannelCodeEnum;
import com.ajl.bfb.core.constants.OrderStatusEnum;
import com.ajl.bfb.pay.IPayLogService;
import com.ajl.bfb.pay.payment.IPaymentCallbackProxy;
import com.ajl.bfb.repo.channel.model.Channel;
import com.ajl.bfb.repo.channel.service.IChannelAccountService;
import com.ajl.bfb.repo.channel.service.IChannelService;
import com.ajl.bfb.repo.payment.model.PaymentOrder;
import com.ajl.bfb.repo.payment.service.IPaymentOrderService;
import com.alibaba.fastjson.JSON;
import com.hippo.framework.util.JsonUtils;
import com.hippo.framework.util.net.HttpUtils;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.ServletInputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Map;

/**
 * 支付回调服务
 */
@Controller
@RequestMapping(value = "/api_gateway/callback/pay")
public class YljzPaymentCallBack {

    private static Logger logger = LogManager.getLogger(YljzPaymentCallBack.class);

    @Autowired
    private IPayLogService payLogService;
    @Autowired
    private IPaymentCallbackProxy paymentCallbackProxy;
    @Autowired
    private IPaymentOrderService paymentOrderService;

    @Autowired
    private IChannelAccountService channelAccountService;
    @Autowired
    private IChannelService channelService;
    /**
     * 回调地址
     * @param request
     * @param response
     */
    @RequestMapping(value = "/yljz")
    public void callback(HttpServletRequest request, HttpServletResponse response) throws IOException{
        logger.info("易连橘子回调回begin");
        response.setContentType("text/plain");
        response.setCharacterEncoding("utf-8");

        // 获取所有提交参数
        BufferedReader br = new BufferedReader(new InputStreamReader((ServletInputStream) request.getInputStream(), "utf-8"));
        StringBuffer sb = new StringBuffer();
        String temp;
        while ((temp = br.readLine()) != null) {
            sb.append(temp);
        }
        br.close();
        String result = sb.toString();
        logger.info("易连橘子回调回参数：" + result);
        Map rspMap = (Map) JSON.parse(result);
        String merchantOrderNo = MapUtils.getString(rspMap,"order_no");
        String status = MapUtils.getString(rspMap,"status");


        //校验回调IP
        Channel channel = channelService.findChannelByCode(ChannelCodeEnum.YLJZ.name());
        String ip = HttpUtils.getRemoteAddr(request);
        logger.info("易连橘子回调IP:" + ip);
        String notifyIp = channel.getNotifyIp();
        if (StringUtils.isNotEmpty(notifyIp) && !notifyIp.contains(ip)){
            logger.info("IP非法请求，请求IP没有配置白名单，订单号:" + merchantOrderNo);
            throw new RuntimeException("IP非法请求，请求IP没有配置白名单，订单号:" + merchantOrderNo);
        }
        //根据渠道编码、商户号查秘钥
//        ChannelAccount channelAccount = channelAccountService.findChannelAccountByAccountAndChannelCode(ChannelCodeEnum.NJZ.name(),fxid);
//        String privateKey = channelAccount.getPrivateKey();
//        String sign = MD5Utils.MD5Encode(fxstatus+fxid+fxddh+fxfee+privateKey);
//        if (!sign.equals(fxsign)){
//            logger.error("验签不通过，订单号:" + fxddh);
//            throw new RuntimeException("验签不通过，订单号:" + fxddh);
//        }
        //查询平台订单信息
        PaymentOrder order = paymentOrderService.findByPlatformOrderNo(merchantOrderNo);

        if (order == null) {
            logger.error("没找到对应的订单:" + merchantOrderNo);
            throw new RuntimeException("没找到对应的订单:" + merchantOrderNo);
        }
        //过滤重复回调
        if(order.getOrderStatus().equals(OrderStatusEnum.SUCCESS)){
            logger.info("订单" + merchantOrderNo + "已经处理");
            callbackChannel(response, merchantOrderNo);
        }

        try {
            if (status.equals("10000")) {
                PaymentCallbackResponse rsp = new PaymentCallbackResponse();
                rsp.setOrderStatus(OrderStatusEnum.SUCCESS);
                rsp.setOrderDesc("处理成功");
                rsp.setTotalFee(0);
                rsp.setPlateformOrderNo(merchantOrderNo);
                rsp.setResponseContent(result);
                paymentCallbackProxy.doCallback(rsp, true);
                callbackChannel(response, merchantOrderNo);
                logger.info("新橘子订单支付回调处理成功,订单号:" + merchantOrderNo);
            }
        } catch (Throwable e) {
            throw new RuntimeException("易连橘子.支付订单构回调处理异常", e);
        }
    }

    //通知上游回调成功
    private void callbackChannel(HttpServletResponse httpResponse, String orderNo) throws IOException {
        logger.info("易连橘子回调响应开始" + orderNo);
        String html = "success";
        httpResponse.getWriter().write(html);
        httpResponse.getWriter().flush();
        httpResponse.getWriter().close();
        logger.info("易连橘子.支付回调上游成功:" + orderNo);
    }

}
