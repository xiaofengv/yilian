package com.ajl.bfb.channelmanage;

import com.ajl.bfb.common.payment.model.PaymentCallbackResponse;
import com.ajl.bfb.core.constants.ChannelCodeEnum;
import com.ajl.bfb.core.constants.OrderStatusEnum;
import com.ajl.bfb.pay.payment.IPaymentCallbackProxy;
import com.ajl.bfb.repo.channel.model.Channel;
import com.ajl.bfb.repo.channel.model.ChannelAccount;
import com.ajl.bfb.repo.channel.service.IChannelAccountService;
import com.ajl.bfb.repo.channel.service.IChannelService;
import com.ajl.bfb.repo.payment.model.PaymentOrder;
import com.ajl.bfb.repo.payment.service.IPaymentOrderService;
import com.ajl.bfb.util.CallbackUtils;
import com.hippo.framework.util.JsonUtils;
import com.hippo.framework.util.net.HttpUtils;
import com.hippo.framework.util.security.MD5Utils;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;


@Controller
@RequestMapping(value = "/api_gateway/callback/pay")
public class JinLiPaymentCallBack {

    private static Logger logger = LogManager.getLogger(JinLiPaymentCallBack.class);

    @Autowired
    private IPaymentCallbackProxy paymentCallbackProxy;

    @Autowired
    private IPaymentOrderService paymentOrderService;

    @Autowired
    private IChannelAccountService channelAccountService;
    @Autowired
    private IChannelService channelService;

    @RequestMapping(value = "/jinli")
    public void callback(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String rspParamJson = JsonUtils.obj2StringNoEscaping(request.getParameterMap());
        Map<String, String> rspMap = CallbackUtils.getParameters(request);
        logger.info("[before]锦鲤回调返回参数:" + rspMap);
        String fxstatus = MapUtils.getString(rspMap,"status");
        String fxddh = MapUtils.getString(rspMap,"out_order_sn");
        //校验回调IP
        Channel channel = channelService.findChannelByCode(ChannelCodeEnum.JINLI.name());
        String ip = HttpUtils.getRemoteAddr(request);
        logger.info("锦鲤回调IP:" + ip);
        String notifyIp = channel.getNotifyIp();
        if (StringUtils.isNotEmpty(notifyIp) && !notifyIp.contains(ip)){
            logger.info("IP非法请求，请求IP没有配置白名单，订单号:" + fxddh);
            throw new RuntimeException("IP非法请求，请求IP没有配置白名单，订单号:" + fxddh);
        }
        //查询平台订单信息
        PaymentOrder order = paymentOrderService.findByPlatformOrderNo(fxddh);

        if (order == null) {
            logger.error("没找到对应的订单:" + fxddh);
            throw new RuntimeException("没找到对应的订单:" + fxddh);
        }
        //过滤重复回调
        if(order.getOrderStatus().equals(OrderStatusEnum.SUCCESS)){
            logger.info("订单" + fxddh + "已经处理");
            callbackChannel(response, fxddh);
        }
        try {
            if (fxstatus.equals("1")) {
                PaymentCallbackResponse rsp = new PaymentCallbackResponse();
                rsp.setOrderStatus(OrderStatusEnum.SUCCESS);
                rsp.setOrderDesc("处理成功");
                rsp.setTotalFee(0);
                rsp.setPlateformOrderNo(fxddh);
                rsp.setResponseContent(rspParamJson);
                paymentCallbackProxy.doCallback(rsp, true);
                callbackChannel(response, fxddh);
                logger.info("锦鲤订单支付回调处理成功,订单号:" + fxddh);
            }
        } catch (Throwable e) {
            throw new RuntimeException("锦鲤支付订单回调处理异常", e);
        }
    }

    //通知上游回调成功
    private void callbackChannel(HttpServletResponse httpResponse, String orderNo) throws IOException {
        String html = "success";
        httpResponse.getWriter().write(html);
        httpResponse.getWriter().flush();
        httpResponse.getWriter().close();
        logger.info("锦鲤回调上游成功:" + orderNo);
    }

    public static void main(String[] args) {
//        订单状态+商务号+商户订单号+支付金额+商户秘钥
//        String sign = MD5Utils.MD5Encode("1"+"2020102"+"686160669153689600"+"500.00"+"ddumFadLxtsWjcgCbicMrrMNJBfPjuih");
//        System.out.printf(sign);
        Map<String,String> map = new HashMap<>();
        map.put("fxid","2020102");
        map.put("fxddh","686160669153689600");
        map.put("fxorder","123456");
        map.put("fxdesc","test");
        map.put("fxfee","500.00");
        map.put("fxattch","1");
        map.put("fxstatus","1");
        map.put("fxtime","1583639006612");
        map.put("fxsign","ebf28c76a9f45cac414329b1bd3d51f9");
    }
}