package com.ajl.bfb.channelmanage;

import com.ajl.bfb.common.payment.model.PaymentCallbackResponse;
import com.ajl.bfb.core.constants.ChannelCodeEnum;
import com.ajl.bfb.core.constants.OrderStatusEnum;
import com.ajl.bfb.pay.payment.IPaymentCallbackProxy;
import com.ajl.bfb.repo.channel.model.Channel;
import com.ajl.bfb.repo.channel.service.IChannelAccountService;
import com.ajl.bfb.repo.channel.service.IChannelService;
import com.ajl.bfb.repo.payment.model.PaymentOrder;
import com.ajl.bfb.repo.payment.service.IPaymentOrderService;
import com.hippo.framework.util.net.HttpUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;


@Controller
@RequestMapping(value = "/api_gateway/callback/pay")
public class SywcPaymentCallBack {

    private static Logger logger = LogManager.getLogger(SywcPaymentCallBack.class);

    @Autowired
    private IPaymentCallbackProxy paymentCallbackProxy;

    @Autowired
    private IPaymentOrderService paymentOrderService;

    @Autowired
    private IChannelAccountService channelAccountService;
    @Autowired
    private IChannelService channelService;

    @RequestMapping(value = "/sywc")
    public void callback(String OrderNo,String Status,HttpServletRequest request, HttpServletResponse response) throws IOException {
        logger.info("[before]十月围城回调");
        logger.info("十月围城回调返回参数:" + OrderNo);
        String requestFlow = OrderNo.substring(8,OrderNo.length());
        String state = Status;
        //校验回调IP
        Channel channel = channelService.findChannelByCode(ChannelCodeEnum.SYWC.name());
        String ip = HttpUtils.getRemoteAddr(request);
        logger.info("十月围城回调IP:" + ip);
        String notifyIp = channel.getNotifyIp();
        if (StringUtils.isNotEmpty(notifyIp) && !notifyIp.contains(ip)){
            logger.error("IP非法请求，请求IP没有配置白名单，订单号:" + requestFlow);
            throw new RuntimeException("IP非法请求，请求IP没有配置白名单，订单号:" + requestFlow);
        }
        //查询平台订单信息
        PaymentOrder order = paymentOrderService.findByPlatformOrderNo(requestFlow);

        if (order == null) {
            logger.error("没找到对应的订单:" + requestFlow);
            throw new RuntimeException("没找到对应的订单:" + requestFlow);
        }
        //过滤重复回调
        if(order.getOrderStatus().equals(OrderStatusEnum.SUCCESS)){
            logger.info("订单" + requestFlow + "已经处理");
            callbackChannel(response, requestFlow);
        }
        try {
            if (state.equals("1")) {
                PaymentCallbackResponse rsp = new PaymentCallbackResponse();
                rsp.setOrderStatus(OrderStatusEnum.SUCCESS);
                rsp.setOrderDesc("处理成功");
                rsp.setTotalFee(0);
                rsp.setPlateformOrderNo(requestFlow);
                rsp.setResponseContent(requestFlow+state);
                paymentCallbackProxy.doCallback(rsp, true);
                callbackChannel(response, requestFlow);
                logger.info("十月围城订单支付回调处理成功,订单号:" + requestFlow);
            }
        } catch (Throwable e) {
            throw new RuntimeException("十月围城支付订单回调处理异常", e);
        }
    }

    //通知上游回调成功
    private void callbackChannel(HttpServletResponse httpResponse, String orderNo) throws IOException {
        String html = "success";
        httpResponse.getWriter().write(html);
        httpResponse.getWriter().flush();
        httpResponse.getWriter().close();
        logger.info("十月围城回调上游成功:" + orderNo);
    }
}