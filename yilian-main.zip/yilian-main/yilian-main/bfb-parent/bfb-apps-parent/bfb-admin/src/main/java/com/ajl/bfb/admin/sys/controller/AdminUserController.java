package com.ajl.bfb.admin.sys.controller;

import com.ajl.bfb.admin.common.web.AdminUserUtils;
import com.ajl.bfb.repo.merchant.model.Merchant;
import com.ajl.bfb.repo.merchant.service.IMerchantService;
import com.hippo.framework.auth.admin.model.SysUser;
import com.hippo.framework.auth.admin.service.ISysUserService;
import com.hippo.framework.util.security.BCryptUtils;
import com.hippo.framework.web.ResponseCode;
import com.hippo.framework.web.ResponseResult;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;


@Controller
@RequestMapping("/admin/sys_user_setting")
public class AdminUserController {

    @Autowired
    private ISysUserService sysUserService;
    @Autowired
    private IMerchantService merchantService;

    @RequestMapping("/to_update_pwd")
    public String toUpdatePwd() {
        return "admin/sys/update_password";
    }

    @RequestMapping("/update_pwd")
    @ResponseBody
    public ResponseResult updatePassword(String oldPwd, String newPwd, HttpServletRequest request) {
        if (StringUtils.isBlank(oldPwd) || StringUtils.isBlank(newPwd)) {
            return new ResponseResult(ResponseCode.FAIL, "请填写旧密码,新密码", "");
        }
        SysUser loginUser = AdminUserUtils.getCurrentLoginUser(request);
        SysUser oldUser = sysUserService.findById(loginUser.getId());
        boolean checkResult = BCryptUtils.compareBcrypt(oldPwd, oldUser.getPassword());
        if (!checkResult) {
            return new ResponseResult(ResponseCode.FAIL, "旧密码有误", "");
        }
        sysUserService.updatePassword(oldUser.getId(), BCryptUtils.bcrypt(newPwd));
        return new ResponseResult(ResponseCode.SUCCESS, "修改成功", "");
    }


    @RequestMapping("/to_update_secondpwd")
    public String toUpdateSecondPwd() {
        return "admin/sys/update_second_password";
    }

    @RequestMapping("/update_secondpwd")
    @ResponseBody
    public ResponseResult updateSecondPassword(String oldPwd, String newPwd, HttpServletRequest request) {
        if (StringUtils.isBlank(oldPwd) || StringUtils.isBlank(newPwd)) {
            return new ResponseResult(ResponseCode.FAIL, "请填写旧密码,新密码", "");
        }
        SysUser loginUser = AdminUserUtils.getCurrentLoginUser(request);
        SysUser oldUser = sysUserService.findById(loginUser.getId());
        boolean checkResult = BCryptUtils.compareBcrypt(oldPwd, oldUser.getSecondPassword());
        if (!checkResult) {
            return new ResponseResult(ResponseCode.FAIL, "旧密码有误", "");
        }
        sysUserService.updateSecondPassword(oldUser.getId(), BCryptUtils.bcrypt(newPwd));
        return new ResponseResult(ResponseCode.SUCCESS, "修改成功", "");
    }


    @RequestMapping("/init_account")
    @ResponseBody

    public ResponseResult initAccount(HttpServletRequest request) {

        SysUser sysUser = AdminUserUtils.getCurrentLoginUser(request);
        Merchant merchant = merchantService.findByUserId(sysUser.getId());
        if(merchant!=null){
            return new ResponseResult(ResponseCode.FAIL, "账户已经初始化！", "");
        }
        merchantService.initMerchantAccount(sysUser.getUserName(),sysUser.getPassword(),sysUser.getId());
        return new ResponseResult(ResponseCode.SUCCESS, "账户初始化成功！", "");
    }
}
