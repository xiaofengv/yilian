package com.ajl.bfb.admin.system.vo;

import com.ajl.bfb.core.constants.OrderStatusEnum;
import com.ajl.bfb.core.constants.PaymentTypeEnum;
import com.ajl.bfb.repo.system.model.QueryMonitoringOrderParam;
import com.hippo.framework.util.DateUtils;
import org.apache.commons.lang3.StringUtils;


public class QueryMonitoringOrderParamVO extends QueryMonitoringOrderParam {

    private String orderStatusStr;

    private String paymentTypeCode;

    public String getPaymentTypeCode() {
        return paymentTypeCode;
    }

    public void setPaymentTypeCode(String paymentTypeCode) {
        this.paymentTypeCode = paymentTypeCode;
        if (StringUtils.isNotBlank(paymentTypeCode)) {
            this.setPaymentType(PaymentTypeEnum.valueOf(paymentTypeCode));
        }
    }

    public String getStartTimeStr() {
        if (getStartTime() == null) {
            return "";
        } else {
            return DateUtils.format2short(getStartTime());
        }
    }

    public String getEndTimeStr() {
        if (getEndTime() == null) {
            return "";
        } else {
            return DateUtils.format2short(getEndTime());
        }
    }

    public String getOrderStatusStr() {
        return orderStatusStr;
    }

    public void setOrderStatusStr(String orderStatusStr) {
        this.orderStatusStr = orderStatusStr;
        if (StringUtils.isNotBlank(orderStatusStr)) {
            this.setOrderStatus(OrderStatusEnum.valueOf(orderStatusStr));
        }
    }
}
