package com.ajl.bfb.merchantadmin.payment.controller;

import com.ajl.bfb.admin.payment.controller.PaymentOrderController;
import com.ajl.bfb.admin.payment.vo.QueryOrderParamVO;
import com.ajl.bfb.core.constants.MerchantUserTypeEnum;
import com.ajl.bfb.merchantadmin.common.web.MerchantAdminUserUtils;
import com.ajl.bfb.repo.export.service.IExportService;
import com.ajl.bfb.repo.merchant.model.Merchant;
import com.ajl.bfb.repo.payment.model.PaymentOrder;
import com.ajl.bfb.repo.payment.service.IPaymentOrderService;
import com.github.pagehelper.PageInfo;
import com.hippo.framework.web.ResponseResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@Controller
@RequestMapping(value="/merchant_admin/payment_order")
public class MerchantPaymentOrderController {

    @Autowired
    private PaymentOrderController delegateController;
    @Autowired
    private IPaymentOrderService paymentOrderService;
    @Autowired
    private IExportService merchantPaymentOrderExportService;

    @RequestMapping("/list")
    public String list(Model model, QueryOrderParamVO queryOrderParam, String timeType,HttpServletRequest request) {
        Merchant merchant = MerchantAdminUserUtils.getLoginMerchant(request);
        model.addAttribute("userType",merchant.getUserType());
        MerchantUserTypeEnum userType = MerchantUserTypeEnum.valueOf(merchant.getUserType());
        if (userType == MerchantUserTypeEnum.MERCHANT) {
            queryOrderParam.setMerchantId(merchant.getId());
        } else if (userType == MerchantUserTypeEnum.AGENT) {
            queryOrderParam.setAgentid(merchant.getId());
        } else {
            throw new RuntimeException("不能识别的MerchantUserType:" + userType);
        }
        delegateController.list(model, queryOrderParam,timeType);
        return "merchant_admin/payment_order/list";
    }

    @RequestMapping("/fail_detail/{orderId}")
    public String failOrderDetail(@PathVariable("orderId") long orderId, Model model) {
        delegateController.failOrderDetail(orderId, model);
        return "merchant_admin/payment_order/detail";
    }

    @RequestMapping("/detail/{orderId}")
    public String orderDetail(@PathVariable("orderId") long orderId, Model model, HttpServletRequest request) {

        delegateController.orderDetail(orderId, model);
        return "merchant_admin/payment_order/detail";
    }

    @RequestMapping("/fail_list")
    public String failList(Model model, QueryOrderParamVO queryOrderParam, HttpServletRequest request) {
        queryOrderParam.setMerchantNo(MerchantAdminUserUtils.getLoginMerchantNo(request));
        delegateController.failList(model, queryOrderParam);
        return "merchant_admin/payment_order/fail_list";
    }


    @RequestMapping("/sync_order_status/{orderId}")
    @ResponseBody
    public ResponseResult syncOrderStatus(@PathVariable("orderId")long orderId, HttpServletRequest request) throws Exception {
        checkAuth(orderId, request);
        return delegateController.syncOrderStatus(orderId);
    }


    @RequestMapping("/notify_merchant/{platformOrderNo}")
    @ResponseBody
    public ResponseResult notifyMerchant(@PathVariable("platformOrderNo")String platformOrderNo) {
        return delegateController.notifyMerchant(platformOrderNo);
    }

    private void checkAuth(long orderId, HttpServletRequest request) {
        PaymentOrder order = paymentOrderService.findById(orderId);
        Merchant merchant = MerchantAdminUserUtils.getLoginMerchant(request);
        MerchantUserTypeEnum userType = MerchantUserTypeEnum.valueOf(merchant.getUserType());
        if (userType == MerchantUserTypeEnum.MERCHANT) {
            if (!order.getMerchantNo().equals(merchant.getMerchantNo())) {
                throw new RuntimeException("未找到属于该商户的订单");
            }
        } else if (userType == MerchantUserTypeEnum.AGENT) {
            if (!order.getAgentid().equals(merchant.getId())) {
                throw new RuntimeException("未找到属于该代理商的订单");
            }
        }
    }


    @RequestMapping(value="/export")
    public void export(Model model, QueryOrderParamVO param, HttpServletResponse response, HttpServletRequest request) throws Exception {
        param.setMerchantId(MerchantAdminUserUtils.getLoginMerchant(request).getId());
        PageInfo<PaymentOrder> page = paymentOrderService.findPage(param);
        param.setTotal(page.getTotal());
        merchantPaymentOrderExportService.export(response,param);
    }
}
