package com.ajl.bfb.task;

import com.ajl.bfb.repo.system.service.IMonitoringPaymentOrderService;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;


@Component("monitoringTask")
public class MonitoringTask {

    private static Logger logger = LogManager.getLogger(MonitoringTask.class);
    @Autowired
    private IMonitoringPaymentOrderService monitoringPaymentOrderService;

    @Scheduled(cron = "50 59 23 * * ?")
    public void run() {
        logger.info("[begin]同步开始------------------");
        monitoringPaymentOrderService.syncMonitoringOrder(null);
        logger.info("[end]同步结束----------------------");
    }
}
