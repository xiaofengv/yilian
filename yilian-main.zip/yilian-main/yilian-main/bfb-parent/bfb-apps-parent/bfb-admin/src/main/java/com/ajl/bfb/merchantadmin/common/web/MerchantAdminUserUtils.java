package com.ajl.bfb.merchantadmin.common.web;

import com.ajl.bfb.repo.merchant.model.Merchant;
import com.hippo.framework.auth.admin.model.SysUser;

import javax.servlet.http.HttpServletRequest;


public class MerchantAdminUserUtils {


    public static void setSessionUser(Merchant merchant, HttpServletRequest request) {
        SysUser user = new SysUser();
        user.setUserName(merchant.getMerchantNo());
        user.setId(merchant.getId());
        request.getSession().setAttribute(MerchantAdminSessionKey.LOGIN_USER, user);
        request.getSession().setAttribute(MerchantAdminSessionKey.LOGIN_MERCHANT, merchant);
    }

    public static Merchant getLoginMerchant(HttpServletRequest request) {
        return (Merchant) request.getSession().getAttribute(MerchantAdminSessionKey.LOGIN_MERCHANT);
    }

    public static String getLoginMerchantNo(HttpServletRequest request) {
        return ((Merchant) request.getSession().getAttribute(MerchantAdminSessionKey.LOGIN_MERCHANT)).getMerchantNo();
    }

}
