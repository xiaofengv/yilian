package com.ajl.bfb.admin.report.controller;

import com.ajl.bfb.admin.channelaccount.util.ChannelAccountViewUtils;
import com.ajl.bfb.admin.channelaccount.vo.ChannelAccountVO;
import com.ajl.bfb.repo.channel.model.Channel;
import com.ajl.bfb.repo.channel.model.ChannelAccount;
import com.ajl.bfb.repo.channel.model.ChannelQuery;
import com.ajl.bfb.repo.channel.service.IChannelAccountService;
import com.ajl.bfb.repo.channel.service.IChannelService;
import com.ajl.bfb.repo.report.model.QueryParam;
import com.ajl.bfb.repo.report.service.IReportService;
import com.ajl.bfb.repo.report.service.ReportService;
import com.github.pagehelper.PageInfo;
import com.hippo.framework.auth.admin.OperationAuth;
import com.hippo.framework.core.PagingParameter;
import com.hippo.framework.util.DateUtils;
import org.apache.http.HttpRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;


@Controller
@RequestMapping("/admin/batch_withdraw")
public class BatchWithdrawReportController {
    @Autowired
    private IReportService reportService;
    @Autowired
    private IChannelAccountService channelAccountService;
    @Autowired
    private IChannelService channelService;

    @RequestMapping("/total_report")
    @OperationAuth(name = "代付每日总报表", authCode = "batch_withdraw.total_report", group = "代付订单管理")
    public String totalReport(QueryParam queryParam, Model model, PagingParameter pageParam, HttpRequest request){
        initParam(queryParam);


        queryParam.setStartDay(ReportService.getDay(queryParam.getStartTime()));
        queryParam.setEndDay(ReportService.getDay(queryParam.getEndTime()));
        HashMap reportTotal = reportService.reportQueryByTotal(queryParam,"batchWithdrawReport");
        PageInfo<HashMap> report = reportService.reportQueryByPage(queryParam,pageParam,"batchWithdrawReport");
        model.addAttribute("reportTotal", reportTotal);
        model.addAttribute("queryParam", queryParam);
        model.addAttribute("pageInfo",report);
        return "/admin/report/batchWithdrawReport";
    }


    @RequestMapping("/batchWithdrawChannelAccDayReport")
    @OperationAuth(name = "通道每日报表", authCode = "batch_withdraw.batchWithdrawChannelAccDayReport", group = "代付订单管理")
    public String batchWithdrawChannelAccDayReport(QueryParam queryParam, Model model, PagingParameter pageParam, HttpRequest request){
        initParam(queryParam);
        queryParam.setStartDay(ReportService.getDay(queryParam.getStartTime()));
        queryParam.setEndDay(ReportService.getDay(queryParam.getEndTime()));

        PageInfo<HashMap> report = reportService.reportQueryByPage(queryParam,pageParam,"batchWithdrawChannelAccDayReport");

        model.addAttribute("queryParam", queryParam);
        model.addAttribute("pageInfo",report);



        List<ChannelAccount> channelAccounts = channelAccountService.findAllChannelAccounts(null);
        List<ChannelAccountVO> channelAccountVOS = toAccountVO(channelAccounts);
        Map<String,List<ChannelAccountVO>> channelVOMap = channelAccountVOS.stream().collect(Collectors.groupingBy(channelAccountVO->channelAccountVO.getChannelName()));
        model.addAttribute("channelVOMap",channelVOMap);
        return "/admin/report/batchWithdrawChannelAccDayReport";
    }

    private List<ChannelAccountVO> toAccountVO(List<ChannelAccount> accounts) {
        List<Channel> channels = channelService.findChannels(new ChannelQuery());
        Map<Integer,String> channelMap = channels.stream().collect(Collectors.toMap(Channel::getId,Channel::getName));
        List<ChannelAccountVO> channelAccountVOS = ChannelAccountViewUtils.toVO(accounts);
        for (ChannelAccountVO acc : channelAccountVOS) {
            acc.setChannelName(channelMap.get(acc.getChannelId()));
        }
        return channelAccountVOS;
    }


    private void initParam(QueryParam queryParam) {

        if (queryParam.getStartTime() == null) {
            queryParam.setEndTime(DateUtils.getDateEnd(new Date()));
            queryParam.setStartTime(DateUtils.getDateStart(org.apache.commons.lang3.time.DateUtils.addDays(new Date(),-30)));
        }else{
            queryParam.setStartTime(DateUtils.getDateStart(queryParam.getStartTime()));
            queryParam.setEndTime(DateUtils.getDateEnd(queryParam.getEndTime()));
        }

    }

}
