package com.ajl.bfb.merchantadmin.withdraw.controller;

import com.ajl.bfb.repo.meta.model.Area;
import com.ajl.bfb.repo.meta.service.IRegionDataService;
import com.hippo.framework.web.ResponseCode;
import com.hippo.framework.web.ResponseResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;


@Controller
@RequestMapping(value="/merchant_admin/region")
public class MerchantRegionController {

    @Autowired
    private IRegionDataService regionDataService;

    @RequestMapping(value="/provinces")
    @ResponseBody
    public ResponseResult getAllProvinces() {
        List<Area> allProvinces = regionDataService.getAllProvinces();
        return new ResponseResult(ResponseCode.SUCCESS, "查询成功", allProvinces);
    }

    @RequestMapping(value="/citys/{provinceCode}")
    @ResponseBody
    public ResponseResult getCitys(@PathVariable("provinceCode")int provinceCode) {
        List<Area> citys = regionDataService.getCitys(provinceCode);
        return new ResponseResult(ResponseCode.SUCCESS, "查询成功", citys);
    }
}
