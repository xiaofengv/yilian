package com.ajl.bfb.admin.system.vo;

import com.ajl.bfb.core.constants.OrderStatusEnum;
import com.ajl.bfb.repo.system.model.QueryMonitoringMemberParam;
import com.hippo.framework.util.DateUtils;

public class QueryMonitoringMemberParamVO extends QueryMonitoringMemberParam {
    private String orderStatusStr;
    public String getStartTimeStr() {
        if (getStartTime() == null) {
            return "";
        } else {
            return DateUtils.format2short(getStartTime());
        }
    }

    public String getEndTimeStr() {
        if (getEndTime() == null) {
            return "";
        } else {
            return DateUtils.format2short(getEndTime());
        }
    }

    public String getOrderStatusStr() {
        return OrderStatusEnum.valueOf(orderStatusStr).getDesc();
    }

    public void setOrderStatusStr(String orderStatusStr) {
        this.orderStatusStr = orderStatusStr;
    }
}
