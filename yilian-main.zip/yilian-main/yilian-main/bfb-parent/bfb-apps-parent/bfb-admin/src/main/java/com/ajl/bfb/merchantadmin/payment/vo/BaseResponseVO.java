package com.ajl.bfb.merchantadmin.payment.vo;

import com.ajl.bfb.core.util.IgnoreSign;

import java.io.Serializable;


public class BaseResponseVO implements Serializable {


    private String returnCode;


    private String returnMsg;

    private String nonceStr;

    @IgnoreSign
    private String sign;

    public String getNonceStr() {
        return nonceStr;
    }

    public void setNonceStr(String nonceStr) {
        this.nonceStr = nonceStr;
    }

    public String getSign() {
        return sign;
    }

    public void setSign(String sign) {
        this.sign = sign;
    }

    public String getReturnCode() {
        return returnCode;
    }

    public void setReturnCode(String returnCode) {
        this.returnCode = returnCode;
    }

    public String getReturnMsg() {
        return returnMsg;
    }

    public void setReturnMsg(String returnMsg) {
        this.returnMsg = returnMsg;
    }
}
