package com.ajl.bfb.admin.common.web.freemarker;

import com.ajl.bfb.core.util.MoneyUtils;
import freemarker.template.TemplateMethodModelEx;
import freemarker.template.TemplateModelException;

import java.util.List;


public class Fee2yuanMethod implements TemplateMethodModelEx {

    @Override
    public Object exec(List arguments) throws TemplateModelException {
        if (arguments == null || arguments.isEmpty() || arguments.get(0) == null) {
            return "";
        }
        try {
            long amount = Long.valueOf(arguments.get(0).toString());
            return MoneyUtils.fee2yuan(amount);
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }

    }
}
