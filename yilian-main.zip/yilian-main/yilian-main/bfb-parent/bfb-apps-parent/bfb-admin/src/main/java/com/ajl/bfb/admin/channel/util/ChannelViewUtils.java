package com.ajl.bfb.admin.channel.util;

import com.ajl.bfb.admin.channel.vo.ChannelVO;
import com.ajl.bfb.admin.channelpaytype.util.ChannelPayTypeViewUtils;
import com.ajl.bfb.admin.channelpaytype.vo.ChannelPayTypeVO;
import com.ajl.bfb.core.util.MoneyUtils;
import com.ajl.bfb.repo.channel.model.Channel;
import org.springframework.beans.BeanUtils;

import java.util.ArrayList;
import java.util.List;


public class ChannelViewUtils {

    public static ChannelVO toVO(Channel channel) {
        ChannelVO vo = new ChannelVO();
        BeanUtils.copyProperties(channel, vo);

        vo.setCardMaxYuan(MoneyUtils.fee2yuan(channel.getCardMax()).intValue());
        vo.setDayMaxAmountYuan(MoneyUtils.fee2yuan(channel.getDayMaxAmount()).longValue());
        vo.setIncomeTotalMaxYuan(MoneyUtils.fee2yuan(channel.getIncomeTotalMax()).longValue());

        if (channel.getChannelPayTypeList() != null) {
            List<ChannelPayTypeVO> channelPayTypeVOS = ChannelPayTypeViewUtils.toVO(channel.getChannelPayTypeList());
            vo.setChannelPayTypeVOS(channelPayTypeVOS);
        }
        return vo;
    }

    public static List<ChannelVO> toVO(List<Channel> channels) {
        List<ChannelVO> vos = new ArrayList<>();
        for (Channel channel : channels) {
            vos.add(toVO(channel));
        }
        return vos;
    }
}
