package com.ajl.bfb.merchantadmin.config;

import com.ajl.bfb.admin.common.web.CurrentMenuInterceptor;
import com.ajl.bfb.merchantadmin.MerchantAdminConstants;
import com.ajl.bfb.merchantadmin.common.web.MerchantAdminSessionKey;
import com.ajl.bfb.merchantadmin.sys.interceptor.MerchantSecondPwdVerifierInterceptor;
import com.hippo.framework.auth.admin.web.support.DefaultAuthenticationInterceptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

/**
 * Created by admin on 2018-02-07 0007.
 */
@SuppressWarnings("ALL")
@Configuration
public class MerchantWebMvcConfig extends WebMvcConfigurerAdapter {
    @Autowired
    MerchantSecondPwdVerifierInterceptor merchantSecondPwdVerifierInterceptor;

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(new CurrentMenuInterceptor()).addPathPatterns("/merchant_admin/**");
        registry.addInterceptor(createManagerAuthInterceptor()).addPathPatterns("/merchant_admin/**")
                .excludePathPatterns("/merchant_admin/sys/**")
                .excludePathPatterns("/merchant_admin/error/**");
        registry.addInterceptor(merchantSecondPwdVerifierInterceptor)
                .addPathPatterns("/merchant_admin/withdraw/import_order");
    }

    private DefaultAuthenticationInterceptor createManagerAuthInterceptor() {
        DefaultAuthenticationInterceptor ai = new DefaultAuthenticationInterceptor();
        ai.setLoginUri(MerchantAdminConstants.LOGIN_URI);
        ai.setLoginUserSessionKey(MerchantAdminSessionKey.LOGIN_USER);
        ai.setNoPermissionRedirectUri(MerchantAdminConstants.NO_PERMISSION_URI);
//        ai.setUserAuthoritiesSessionKey(MerchantAdminSessionKey.USER_AUTHORITY);
        return ai;
    }


    @Override
    public void addViewControllers(ViewControllerRegistry registry) {
        registry.addViewController("/merchant_admin").setViewName("forward:/merchant_admin/sys/to-login");
        registry.setOrder(Ordered.HIGHEST_PRECEDENCE);
        super.addViewControllers(registry);
    }




}
