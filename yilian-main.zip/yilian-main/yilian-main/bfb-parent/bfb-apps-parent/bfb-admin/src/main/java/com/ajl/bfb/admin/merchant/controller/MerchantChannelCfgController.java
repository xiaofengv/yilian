package com.ajl.bfb.admin.merchant.controller;

import com.ajl.bfb.core.constants.PaymentTypeEnum;
import com.ajl.bfb.repo.channel.model.Channel;
import com.ajl.bfb.repo.channel.model.ChannelPayType;
import com.ajl.bfb.repo.channel.service.IChannelPayTypeService;
import com.ajl.bfb.repo.channel.service.IChannelService;
import com.ajl.bfb.repo.merchant.MerchantException;
import com.ajl.bfb.repo.merchant.model.Merchant;
import com.ajl.bfb.repo.merchant.model.MerchantFindParam;
import com.ajl.bfb.repo.merchant.service.IMerchantChannelService;
import com.ajl.bfb.repo.merchant.service.IMerchantService;
import com.hippo.framework.core.enums.OpenStatusEnum;
import com.hippo.framework.web.ResponseCode;
import com.hippo.framework.web.ResponseResult;
import org.apache.commons.lang3.EnumUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;


@Controller
@RequestMapping("/admin/merchant_channel")
public class MerchantChannelCfgController {
    @Autowired
    private IChannelPayTypeService channelPayTypeService;
    @Autowired
    private IChannelService channelService;
    @Autowired
    private IMerchantChannelService merchantChannelService;
    @Autowired
    private IMerchantService merchantService;

    @RequestMapping(value = "/merchant_to_channel_config/{merchantId}/{payTypeCode}")
    public String merchantToChannelConfig(@PathVariable("merchantId") Integer merchantId, @PathVariable("payTypeCode")String payTypeCode,Model model){

        List<Channel> channels = channelService.findAvailableChannelByPayType(EnumUtils.getEnum(PaymentTypeEnum.class,payTypeCode));
        model.addAttribute("channels",channels);

        List<Channel> mechannelChannels = merchantChannelService.findMerchantChannel(merchantId,PaymentTypeEnum.valueOf(payTypeCode));
        List<Integer> configChannels = mechannelChannels.stream().map(Channel::getId).collect(Collectors.toList());
        model.addAttribute("configChannels",configChannels);
        model.addAttribute("merchantId");
        model.addAttribute("payTypeCode");
        return "/admin/merchant_pay_type/channel_config";
    }

    @RequestMapping(value = "/save/{merchantId}/{payTypeCode}")
    @ResponseBody
    public ResponseResult save(@PathVariable("merchantId") Integer merchantId, @PathVariable("payTypeCode")String payTypeCode,@RequestBody ArrayList<Integer> channels) throws MerchantException {

        List<ChannelPayType> channelPayTypes = channelPayTypeService.findChannelsPayType(channels,EnumUtils.getEnum(PaymentTypeEnum.class,payTypeCode.toUpperCase()));
        List<Integer> channelPayTypeIds = channelPayTypes.stream().map(ChannelPayType::getId).collect(Collectors.toList());
        merchantChannelService.saveMerchantChannels(merchantId,payTypeCode,channelPayTypeIds);
        return new ResponseResult(ResponseCode.SUCCESS, "设置成功!", null);
    }



    @RequestMapping(value = "/channel_to_merchant_config/{channelPaytypeId}")
    public String channelToMerchantConfig(@PathVariable("channelPaytypeId") int channelPaytypeId, MerchantFindParam findParam,Model model){

        List<Merchant> openMerchants = merchantChannelService.findMerchantByChannelPaymentTypeId(channelPaytypeId);
        List<Integer> openMerchantIds = openMerchants.stream().map(Merchant::getId).collect(Collectors.toList());
        List<Merchant> merchants = merchantService.findMerchant(findParam);

        merchants.forEach(merchant -> merchant.setStatus(openMerchantIds.contains(merchant.getId())?OpenStatusEnum.Y.name():OpenStatusEnum.N.name()));
        model.addAttribute("merchants", merchants);
        model.addAttribute("channelPaytypeId",channelPaytypeId);
        return "/admin/channel_pay_type/merchant_config";
    }


    @RequestMapping(value = "/channelToMerchant/turn_on/{merchantId}/{channelPayTypeId}")
    @ResponseBody
    public ResponseResult channelToMerchantTurnOn(@PathVariable("merchantId") Integer merchantId, @PathVariable("channelPayTypeId")Integer channelPayTypeId){
        merchantChannelService.insertMerchantChannel(merchantId,channelPayTypeId);
        return new ResponseResult(ResponseCode.SUCCESS, "设置成功!", null);
    }


    @RequestMapping(value = "/channelToMerchant/turn_off/{merchantId}/{channelPayTypeId}")
    @ResponseBody
    public ResponseResult channelToMerchantTurnOff(@PathVariable("merchantId") Integer merchantId, @PathVariable("channelPayTypeId")Integer channelPayTypeId){
        merchantChannelService.deleteMerchantChannel(merchantId,channelPayTypeId);
        return new ResponseResult(ResponseCode.SUCCESS, "设置成功!", null);
    }

}
