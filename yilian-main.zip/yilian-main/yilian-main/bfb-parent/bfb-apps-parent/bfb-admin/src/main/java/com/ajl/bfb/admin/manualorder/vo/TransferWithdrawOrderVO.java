package com.ajl.bfb.admin.manualorder.vo;


import com.ajl.bfb.repo.withdraw.model.TransferWithdrawOrder;

import java.math.BigDecimal;


public class TransferWithdrawOrderVO extends TransferWithdrawOrder {

    private String payeeBankCodeStr;

    private Integer amountYuan;

    private BigDecimal platformCostYuan;

    public String getPayeeBankCodeStr() {
        return payeeBankCodeStr;
    }

    public void setPayeeBankCodeStr(String payeeBankCodeStr) {
        this.payeeBankCodeStr = payeeBankCodeStr;
    }

    public Integer getAmountYuan() {
        return amountYuan;
    }

    public void setAmountYuan(Integer amountYuan) {
        this.amountYuan = amountYuan;
    }

    public BigDecimal getPlatformCostYuan() {
        return platformCostYuan;
    }

    public void setPlatformCostYuan(BigDecimal platformCostYuan) {
        this.platformCostYuan = platformCostYuan;
    }
}
