package com.ajl.bfb.admin.system.controller;

import com.ajl.bfb.repo.channel.service.IGlobalSettingService;
import com.hippo.framework.auth.admin.OperationAuth;
import com.hippo.framework.operation.log.LogOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/admin/system/script")
public class ScriptController {
    @Autowired
    IGlobalSettingService globalSettingService;

    @RequestMapping(value="/toinsertscript")
    @OperationAuth(name = "插入脚本", authCode = "merchant.admin", group = "插入脚本")
    public String toInsertScript(Model model) {
        String script = globalSettingService.getInsertScript();
        model.addAttribute("script",script);
        return "/admin/system/merchant/updatescript";
    }
    @RequestMapping("updateScript")
    @LogOperation(name = "系统参数设置",module = "系统参数设置")
    public String updateScript(Model model,String script){
        globalSettingService.updateInsertScript(script);
        return toInsertScript(model);
    }
}