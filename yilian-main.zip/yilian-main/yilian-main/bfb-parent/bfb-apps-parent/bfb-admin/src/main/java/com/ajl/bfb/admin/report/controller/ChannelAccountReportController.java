package com.ajl.bfb.admin.report.controller;

import com.ajl.bfb.admin.channelaccount.util.ChannelAccountViewUtils;
import com.ajl.bfb.admin.channelaccount.vo.ChannelAccountVO;
import com.ajl.bfb.common.payment.IQueryAccountBalanceService;
import com.ajl.bfb.common.payment.model.QueryAccountBalancequest;
import com.ajl.bfb.core.constants.ChannelCodeEnum;
import com.ajl.bfb.pay.payment.IPaymentServiceFactory;
import com.ajl.bfb.repo.channel.model.*;
import com.ajl.bfb.repo.channel.service.IChannelAccountService;
import com.ajl.bfb.repo.channel.service.IChannelService;
import com.ajl.bfb.repo.channelstat.service.IChannelAccountDayStatService;
import com.ajl.bfb.repo.channelstat.service.IChannelAccountInstanceService;
import com.ajl.bfb.repo.merchant.service.IMerchantService;
import com.ajl.bfb.repo.payment.service.IPayTypeService;
import com.ajl.bfb.repo.payment.service.IPaymentOrderService;
import com.ajl.bfb.repo.stat.service.IPaymentOrderStatService;
import com.github.pagehelper.PageInfo;
import com.hippo.framework.auth.admin.OperationAuth;
import com.hippo.framework.util.DateUtils;
import com.hippo.framework.web.ResponseCode;
import com.hippo.framework.web.ResponseResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;


@Controller
@RequestMapping("/admin/report")
public class ChannelAccountReportController {
    @Autowired
    private IChannelService channelService;

    @Autowired
    private IChannelAccountDayStatService channelAccountDayStatService;

    @Autowired
    private IPaymentOrderStatService paymentOrderStatService;

    @Autowired
    private IMerchantService merchantService;

    @Autowired
    private IPaymentOrderService paymentOrderService;

    @Autowired
    private IChannelAccountService channelAccountService;

    @Autowired
    private IChannelAccountInstanceService channelAccountInstanceService;

    @Autowired
    private IPaymentServiceFactory paymentServiceFactory;

    @Autowired
    private IPayTypeService payTypeService;

    @RequestMapping("/channel_bak")
    @OperationAuth(name = "通道总收款", authCode = "channel.total_report", group = "通道报表")
    public String channelReportBak(ChannelAccountReportParam queryParam, Model model){
        List<Channel> channels= channelService.findChannels(new ChannelQuery());
        model.addAttribute("channels",channels);

        PageInfo<HashMap> channelStats =  channelAccountDayStatService.queryChannelStat(queryParam);
        model.addAttribute("queryParam",queryParam);
        model.addAttribute("pageInfo",channelStats);
        return "/admin/report/channel/channelStatReport";
    }


    @RequestMapping("/channel")
    @OperationAuth(name = "通道总收款", authCode = "channel.total_report", group = "通道报表")
    public String channelReport(ChannelAccountReportParam queryParam, Model model){
        queryParam.setStartTime(DateUtils.getDateStart(queryParam.getStartTime()));
        queryParam.setEndTime(DateUtils.getDateEnd(queryParam.getEndTime()));
        List<Channel> channels= channelService.findChannels(new ChannelQuery());
        model.addAttribute("channels",channels);
        Map<Integer,String> channelMap = channels.stream().collect(Collectors.toMap(Channel::getId,Channel::getName));
        model.addAttribute("channelMap",channelMap);
        List<ChannelAccount> channelAccounts = channelAccountService.findAllChannelAccounts(null);
        Map<Integer,String> channelAccMap = channelAccounts.stream().collect(Collectors.toMap(ChannelAccount::getId,ChannelAccount::getName));
        model.addAttribute("channelAccMap",channelAccMap);
        PageInfo<HashMap> channelStats =  channelAccountDayStatService.queryChannelStat(queryParam);
        model.addAttribute("queryParam",queryParam);
        model.addAttribute("pageInfo",channelStats);
        return "/admin/report/channel/channelStatReport";
    }

    @RequestMapping("/channel_account_stat")
    @OperationAuth(name = "通道每日报表", authCode = "channel.channel_account_stat", group = "通道报表")
    public String channelAccountStat(ChannelAccountReportParam queryParam, Model model){
        queryParam.setStartTime(DateUtils.getDateStart(queryParam.getStartTime()));
        queryParam.setEndTime(DateUtils.getDateEnd(queryParam.getEndTime()));
        List<Channel> channels= channelService.findChannels(new ChannelQuery());
        model.addAttribute("channels",channels);
        Map<Integer,String> channelMap = channels.stream().collect(Collectors.toMap(Channel::getId,Channel::getName));
        model.addAttribute("channelMap",channelMap);
        List<ChannelAccount> channelAccounts = channelAccountService.findAllChannelAccounts(null);
        Map<Integer,String> channelAccMap = channelAccounts.stream().collect(Collectors.toMap(ChannelAccount::getId,ChannelAccount::getName));
        model.addAttribute("channelAccMap",channelAccMap);
        PageInfo<HashMap> channelAccountStats = channelAccountDayStatService.queryChannelAccountStat(queryParam);
        model.addAttribute("queryParam",queryParam);
        model.addAttribute("pageInfo",channelAccountStats);
        return "/admin/report/channel/channelAccountStatReport";
    }

    @RequestMapping("/withdraw_channel_account_stat")
    @OperationAuth(name = "通道报表", authCode = "channel.report", group = "通道报表")
    public String withdrawChannelAccountStat(ChannelAccountReportParam queryParam, Model model){
        if(queryParam.getEndTime()!=null){
            queryParam.setEndTime(DateUtils.getDateEnd(queryParam.getEndTime()));
        }

        List<ChannelAccount> channelAccounts = channelAccountService.findAllChannelAccounts(null);
        List<ChannelAccountVO> channelAccountVOS = toAccountVO(channelAccounts);
        Map<String,List<ChannelAccountVO>> channelVOMap = channelAccountVOS.stream().collect(Collectors.groupingBy(channelAccountVO->channelAccountVO.getChannelName()));
        model.addAttribute("channelVOMap",channelVOMap);


        PageInfo<HashMap> channelAccountStats = channelAccountDayStatService.queryWithdrawChannelAccountStat(queryParam);
        model.addAttribute("queryParam",queryParam);
        model.addAttribute("pageInfo",channelAccountStats);
        return "/admin/report/channel/withdrawChannelAccountStatReport";
    }
    @RequestMapping("/query_account_balance")
    @OperationAuth(name = "同步上游余额", authCode = "channel.query_account_balance", group = "通道报表")
    @ResponseBody
    public ResponseResult queryAccountBalance(int channelAccountId){
        channelAccountInstanceService.updateByAccountBalance(channelAccountId,0);
        return new ResponseResult(ResponseCode.SUCCESS, "同步成功", "1");
    }

    private List<ChannelAccountVO> toAccountVO(List<ChannelAccount> accounts) {
        List<Channel> channels = channelService.findChannels(new ChannelQuery());
        Map<Integer,String> channelMap = channels.stream().collect(Collectors.toMap(Channel::getId,Channel::getName));
        List<ChannelAccountVO> channelAccountVOS = ChannelAccountViewUtils.toVO(accounts);
        for (ChannelAccountVO acc : channelAccountVOS) {
            acc.setChannelName(channelMap.get(acc.getChannelId()));
        }
        return channelAccountVOS;
    }


    @RequestMapping("/channel_account_billing")
    @OperationAuth(name = "通道报表", authCode = "channel.report", group = "通道报表")
    public String channelAccountReport(ChannelAccountReportParam queryParam, Model model){
        queryParam.setEndTime(DateUtils.getDateEnd(queryParam.getEndTime()));
        List<Channel> channels= channelService.findChannels(new ChannelQuery());
        model.addAttribute("channels",channels);
        PageInfo<ChannelAccountStat> channelAccountStats = channelAccountDayStatService.queryChannelAccountBilling(queryParam);
        model.addAttribute("queryParam",queryParam);
        model.addAttribute("pageInfo",channelAccountStats);
        return "/admin/report/channel/channelAccountBillingReport";
    }

}
