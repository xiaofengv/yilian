var manual_order = {};

manual_order.export = function () {
    $('#searchForm').attr("action",getWebPath() + "/admin/manual_payment_order/export");
    $('#searchForm').submit();
    $('#searchForm').attr("action",getWebPath() + "/admin/manual_payment_order/list");
}

$(function () {
    $(".limitMoney").each(function (index, el) {
        hippo.limitMoney(el.id);
    });

});

manual_order.checkForm = function() {
    return hippo.validateForm('addManualOrderForm');
}



manual_order.close = function(){
    $('.close',window.parent.document).trigger("click");
}

//手工订单新增或更新保存
manual_order.save = function(){
    if (!manual_order.checkForm()) {
        return;
    }

    $("#addManualOrderForm").ajaxSubmit(function(response) {
        if(response.statusCode=="SUCCESS"){
            $('#errorMsgDiv').hide();
            new $.zui.Messager(response.message, {
                type: 'success' // 定义颜色主题
            }).show();

            window.parent.location.href =  window.parent.document.getElementById('searchForm').action;
        }else{
            hippo.warning(response.message);
        }
    });
}


//合作商利润结算
manual_order.addSupplierProfitSettlementOrder = function(){
    if (!manual_order.checkForm()) {
        return;
    }

    $("#addManualOrderForm").ajaxSubmit(function(response) {
        if(response.statusCode=="SUCCESS"){
            $('#errorMsgDiv').hide();
            new $.zui.Messager(response.message, {
                type: 'success' // 定义颜色主题
            }).show();
            $('.close',window.parent.document).trigger("click");
        }else{
            hippo.warning(response.message);
        }
    });

}


manual_order.audit = function(status){
    $("input[name='status']").val(status);
    var showmsg="";
    if("SUCCESS"==status){
        showmsg="确定要审核通过吗?";
    }else{
        showmsg="确定要驳回审核吗?";
    }

    layer.confirm(
        showmsg,
        {icon: 0, title:'提示'},
        function(index, layero){
            layer.close(index);
            if (!hippo.validateForm('auditManualOrderForm')) {
                return;
            }

            $("#auditManualOrderForm").ajaxSubmit(function(response) {
                if(response.statusCode=="SUCCESS"){
                    $('#errorMsgDiv').hide();
                    new $.zui.Messager(response.message, {
                        type: 'success' // 定义颜色主题
                    }).show();

                    window.parent.location.href =  window.parent.document.getElementById('searchForm').action;
                }else{
                    hippo.warning(response.message);
                }
            });
        }
    );
}

manual_order.b2cProcess=function (id) {
    window.open(getWebPath()+"/merchant_admin/manual_payment_order/to_process/"+id);
}
manual_order.orderProcess = function(bizType,orderid,status){
    var showmsg="";
    if("SUCCESS"==status){
        showmsg="确定要结算吗?";
    }else{
        showmsg="确定要取消吗?";
    }

    layer.confirm(
        showmsg,
        {icon: 0, title:'提示'},
        function(index, layero){
            layer.close(index);
            if (!hippo.validateForm('processManualOrderForm')) {
                return;
            }
            var processRemark = $("input[name='processRemark']").val();
            var secondPwd = $("input[name='_secondPasswordVerifier']").val();
            $.post(getWebPath()+"/admin/manual_order/process", {id:orderid,status: status,processRemark:processRemark,_secondPasswordVerifier:secondPwd }, function(response) {
                if(response.statusCode=='SUCCESS'){
                    new $.zui.Messager(response.message, {
                        type: 'success'
                    }).show();
                    window.parent.location.href =  window.parent.document.getElementById('searchForm').action;
                }else{
                    hippo.warning(response.message);
                }
            }, "json")
        }
    );
}

//资金转换订单导出
manual_order.exportTransferFundOrder = function () {
    $('#searchForm').attr("action",getWebPath() + "/admin/manual_order/exportTransferFundOrder");
    $('#searchForm').submit();
}

//中转下发订单导出
manual_order.exportTransferWithdrawOrder = function () {
    $('#searchForm').attr("action",getWebPath() + "/admin/transfer_withdraw/export");
    $('#searchForm').submit();
}