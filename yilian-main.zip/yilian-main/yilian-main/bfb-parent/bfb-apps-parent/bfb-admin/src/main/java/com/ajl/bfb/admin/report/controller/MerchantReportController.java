package com.ajl.bfb.admin.report.controller;

import com.ajl.bfb.admin.common.web.AdminUserUtils;
import com.ajl.bfb.core.constants.MerchantUserTypeEnum;
import com.ajl.bfb.core.constants.PaymentTypeEnum;
import com.ajl.bfb.core.constants.StatBizTypeEnum;
import com.ajl.bfb.repo.channel.model.Channel;
import com.ajl.bfb.repo.channel.model.ChannelAccount;
import com.ajl.bfb.repo.channel.model.ChannelAccountDetail;
import com.ajl.bfb.repo.channel.model.ChannelQuery;
import com.ajl.bfb.repo.channel.service.IChannelAccountService;
import com.ajl.bfb.repo.channel.service.IChannelService;
import com.ajl.bfb.repo.channelstat.service.IChannelAccountInstanceService;
import com.ajl.bfb.repo.fund.service.IFinanceFacadeService;
import com.ajl.bfb.repo.merchant.model.Merchant;
import com.ajl.bfb.repo.merchant.model.MerchantAccount;
import com.ajl.bfb.repo.merchant.model.MerchantAccountDetail;
import com.ajl.bfb.repo.merchant.model.MerchantFindParam;
import com.ajl.bfb.repo.merchant.service.IMerchantAccountService;
import com.ajl.bfb.repo.merchant.service.IMerchantService;
import com.ajl.bfb.repo.payment.service.IPaymentOrderService;
import com.ajl.bfb.repo.stat.model.*;
import com.ajl.bfb.repo.stat.service.IMerchantAccountStatService;
import com.ajl.bfb.repo.stat.service.IPaymentOrderStatService;
import com.github.pagehelper.PageInfo;
import com.hippo.framework.auth.admin.OperationAuth;
import com.hippo.framework.auth.admin.model.SysUser;
import com.hippo.framework.util.DateUtils;
import org.apache.commons.lang3.EnumUtils;
import org.apache.http.HttpRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;


@Controller
@RequestMapping("/admin/report")
public class MerchantReportController {
    @Autowired
    private IChannelService channelService;

    @Autowired
    private IPaymentOrderStatService paymentOrderStatService;

    @Autowired
    private IMerchantService merchantService;

    @Autowired
    private IMerchantAccountService merchantAccountService;

    @Autowired
    private IMerchantAccountStatService merchantAccountStatService;

    @Autowired
    private IFinanceFacadeService financeFacadeService;

    @Autowired
    IChannelAccountService channelAccountService;

    @Autowired
    private IChannelAccountInstanceService channelAccountInstanceService;
    @Autowired
    private IPaymentOrderService paymentOrderService;

    @RequestMapping("/merchant_billing_stat")
    @OperationAuth(name = "通道用户分类统计", authCode = "platform.merchant_billing_stat", group = "平台报表")
    public String dayReport(QueryPaymentOrderStatParam queryOrderParam, Model model,HttpRequest request){
        initParam(queryOrderParam);
        model.addAttribute("queryParam", queryOrderParam);

        PageInfo<PaymentOrderStat> page = paymentOrderStatService.findPaymentOrderStatByPage(queryOrderParam);
        model.addAttribute("pageInfo", page);

        PaymentOrderStat paymentOrderSumStat = paymentOrderStatService.paymentOrderSumStat(queryOrderParam);
        model.addAttribute("sum", paymentOrderSumStat);

        List<Channel> channels = channelService.findChannels(new ChannelQuery());
        model.addAttribute("channels", channels);
        model.addAttribute("channelMap",channels.stream().collect(Collectors.toMap(Channel::getId,Channel::getName)));

        model.addAttribute("bizTypeEnums", StatBizTypeEnum.values());
        Map<String,String> biztypeMap = Arrays.stream(StatBizTypeEnum.values()).collect(Collectors.toMap(StatBizTypeEnum::name,StatBizTypeEnum::getDesc));
        model.addAttribute("biztypeMap", biztypeMap);


        List<Merchant> merchants = merchantService.findMerchant(new MerchantFindParam());
        model.addAttribute("merchants", merchants);
        model.addAttribute("merchantMap",merchants.stream().collect(Collectors.toMap(Merchant::getId,Merchant::getMerchantName)));


        List<QueryPaymentOrderStatParam.GroupBy> groupByList =  EnumUtils.getEnumList(QueryPaymentOrderStatParam.GroupBy.class);
        groupByList.remove(QueryPaymentOrderStatParam.GroupBy.statBizType);
        model.addAttribute("groups",groupByList);

        model.addAttribute("paymentTypeList", PaymentTypeEnum.values());
        model.addAttribute("payTypeMap", Arrays.stream(PaymentTypeEnum.values()).collect(Collectors.toMap(PaymentTypeEnum::name,PaymentTypeEnum::getDesc)));

        List<ChannelAccount> channelAccounts = channelAccountService.findAllChannelAccounts(null);
        Map<Integer,String> channelAccMap = channelAccounts.stream().collect(Collectors.toMap(ChannelAccount::getId,ChannelAccount::getName));
        model.addAttribute("channelAccMap",channelAccMap);
        return "/admin/report/paymentStatReport";
    }

    @RequestMapping("/paytype_profit_report")
    @OperationAuth(name = "收款方式利润统计", authCode = "platform.paytype_profit_report", group = "平台报表")
    public String paytypeProfitReport(QueryPaymentOrderStatParam queryOrderParam, Model model,HttpRequest request){
        initParam(queryOrderParam);
        model.addAttribute("queryParam", queryOrderParam);
        queryOrderParam.setStatBizType(StatBizTypeEnum.PAYMENT.name());
        List<QueryPaymentOrderStatParam.GroupBy> groupby = new ArrayList<>();
        groupby.add(QueryPaymentOrderStatParam.GroupBy.payTypeCode);
        queryOrderParam.setGroupby(groupby);

        PageInfo<PaymentOrderStat> page = paymentOrderStatService.findPaymentOrderStatByPage(queryOrderParam);
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
        SimpleDateFormat dateFormat1 = new SimpleDateFormat("yyyy-MM-dd");
        page.getList().forEach(t -> {
            try {
                t.setStarttime(dateFormat1.format(dateFormat.parse(t.getStatDay().toString())));
                t.setEndtime(dateFormat1.format(org.apache.commons.lang3.time.DateUtils.addDays(dateFormat.parse(t.getStatDay().toString()),1)));
            } catch (ParseException e) {
                e.printStackTrace();
            }
        });
        model.addAttribute("pageInfo", page);

        List<Channel> channels = channelService.findChannels(new ChannelQuery());
        model.addAttribute("channels", channels);
        model.addAttribute("channelMap",channels.stream().collect(Collectors.toMap(Channel::getId,Channel::getName)));

        model.addAttribute("bizTypeEnums", StatBizTypeEnum.values());
        Map<String,String> biztypeMap = Arrays.stream(StatBizTypeEnum.values()).collect(Collectors.toMap(StatBizTypeEnum::name,StatBizTypeEnum::getDesc));
        model.addAttribute("biztypeMap", biztypeMap);


        List<Merchant> merchants = merchantService.findMerchant(new MerchantFindParam());
        model.addAttribute("merchants", merchants);
        model.addAttribute("merchantMap",merchants.stream().collect(Collectors.toMap(Merchant::getId,Merchant::getMerchantName)));


        List<QueryPaymentOrderStatParam.GroupBy> groupByList =  EnumUtils.getEnumList(QueryPaymentOrderStatParam.GroupBy.class);
        groupByList.remove(QueryPaymentOrderStatParam.GroupBy.statBizType);
        model.addAttribute("groups",groupByList);

        model.addAttribute("paymentTypeList", PaymentTypeEnum.values());
        model.addAttribute("payTypeMap", Arrays.stream(PaymentTypeEnum.values()).collect(Collectors.toMap(PaymentTypeEnum::name,PaymentTypeEnum::getDesc)));

        List<ChannelAccount> channelAccounts = channelAccountService.findAllChannelAccounts(null);
        Map<Integer,String> channelAccMap = channelAccounts.stream().collect(Collectors.toMap(ChannelAccount::getId,ChannelAccount::getName));
        model.addAttribute("channelAccMap",channelAccMap);
        return "/admin/report/paytypeStatReport";
    }


    @RequestMapping("/merchant_stat")
    @OperationAuth(name = "下游账务统计", authCode = "merchant.merchant_stat", group = "商户报表")
    public String merchantStat(QueryMerchantAccountParam queryParam, Model model, HttpRequest request){
        queryParam.setPageSize(1000);
        queryParam.setUserType(MerchantUserTypeEnum.MERCHANT.name());
        PageInfo<MerchantAccountStat> merchantAccountStatPageInfo = merchantAccountStatService.findMerchantAccountStatByPage(queryParam);

        List<MerchantAccountStat> merchantAccountStats = merchantAccountStatPageInfo.getList();
        for (MerchantAccountStat merchantAccountStat : merchantAccountStats) {
            merchantAccountStat.setAvaliableAmount(financeFacadeService.getMerchantCashBalance(merchantAccountStat.getMerchantId()));
            MerchantAccount merchantAccount = merchantAccountService.getByMerchantId(merchantAccountStat.getMerchantId());
            merchantAccountStat.setFreezeAmount(merchantAccount.getFreezeAmountTotal());
        }
        model.addAttribute("pageInfo",merchantAccountStatPageInfo);
        return "/admin/report/merchant/merchantAccountStatReport";
    }
    @RequestMapping("/merchant_pay_success_rate")
    public String merchantPaySuccessRate(QueryMerchantPaySuccess param, Model model){
        param.setStartTime(DateUtils.plusDays(DateUtils.getDateStart2(new Date()), 0));
        param.setEndTime(DateUtils.getDateEnd2(new Date()));
        List<QueryMerchantPaySuccess> list = paymentOrderService.merchantPaySuccessRate(param);
        model.addAttribute("list",list);
        model.addAttribute("queryParam",param);
        ChannelQuery channelQuery = new ChannelQuery();
//        channelQuery.setStatus("ON");
        List<Channel> channels = channelService.findChannels(channelQuery);
        model.addAttribute("channels", channels);
        model.addAttribute("paymentTypeList", PaymentTypeEnum.values());
        return "/admin/report/merchant/merchantPaySuccessRate";
    }
    @RequestMapping("/merchant_account_state_byday")
    @OperationAuth(name = "下游每日统计报表", authCode = "merchant.merchant_account_state_byday", group = "商户报表")
    public String merchantAccountStatByday(QueryMerchantAccountParam queryParam, Model model, HttpRequest request){
        queryParam.setStartTime(DateUtils.getDateStart(queryParam.getStartTime()));
        queryParam.setEndTime(DateUtils.getDateEnd(queryParam.getEndTime()));
        queryParam.setUserType(MerchantUserTypeEnum.MERCHANT.name());
        PageInfo<HashMap> merchantAccountStatPageInfo = merchantAccountStatService.merchantAccountStatByday(queryParam);
        model.addAttribute("pageInfo",merchantAccountStatPageInfo);
        model.addAttribute("queryParam",queryParam);
        List<Merchant> merchants = merchantService.findMerchant(null);
        Map<Integer,String> merchantMap =  merchants.stream().collect(Collectors.toMap(Merchant::getId,Merchant::getMerchantName));
        model.addAttribute("merchantMap",merchantMap);
        return "/admin/report/merchant/merchantAccountBillingReport";
    }

    private void initParam(QueryPaymentOrderStatParam queryOrderParam) {
        if(queryOrderParam.getGroupby() == null){
            List<QueryPaymentOrderStatParam.GroupBy> groups = new ArrayList<>();
            groups.add(QueryPaymentOrderStatParam.GroupBy.statBizType);
            queryOrderParam.setGroupby(groups);
        }else{
            queryOrderParam.getGroupby().add(QueryPaymentOrderStatParam.GroupBy.statBizType);
        }

        if("Y".equals(queryOrderParam.getViewDetail())){
            Optional<QueryPaymentOrderStatParam.GroupBy> queryMaxGroup=queryOrderParam.getGroupby().stream().max((x, y)->{return x.getOrderNo() > y.getOrderNo() ? 1 : -1;});
            Optional<QueryPaymentOrderStatParam.GroupBy> max=Arrays.stream(QueryPaymentOrderStatParam.GroupBy.values()).max((x, y)->{return x.getOrderNo() > y.getOrderNo() ? 1 : -1;});
            List<QueryPaymentOrderStatParam.GroupBy> groups = Arrays.stream(QueryPaymentOrderStatParam.GroupBy.values()).sorted((x, y)->{return x.getOrderNo() > y.getOrderNo() ? 1 : -1;}).collect(Collectors.toList());

            QueryPaymentOrderStatParam.GroupBy detailGroup = null;
            QueryPaymentOrderStatParam.GroupBy currentGroup = null;

            Iterator<QueryPaymentOrderStatParam.GroupBy> iterator = groups.iterator();
            for(groups.iterator();iterator.hasNext();){
                currentGroup = iterator.next();
                if(currentGroup.equals(queryMaxGroup.get())){
                    break;
                }
            }

            if(!currentGroup.equals(max.get())){
                detailGroup = iterator.next();
                queryOrderParam.getGroupby().add(detailGroup);

                switch (detailGroup){
                    case statDay:queryOrderParam.setStartDay(null);break;
                    case channelId:queryOrderParam.setChannelId(null);break;
                    case merchantId:queryOrderParam.setMerchantId(null);break;
                    case payTypeCode:queryOrderParam.setPaymentTypeCode(null);break;
                }
            }
        }
    }


    @RequestMapping("/merchant_balance")
    @OperationAuth(name = "下游账户余额", authCode = "platform.merchant_balance", group = "平台报表")
    public String merchantBalance(QueryMerchantAccountParam queryParam, Model model, HttpServletRequest request){
        MerchantFindParam findParam = new MerchantFindParam();
        findParam.setUserType(MerchantUserTypeEnum.MERCHANT);
        SysUser loginUser = AdminUserUtils.getCurrentLoginUser(request);
        if (loginUser.getUserName().equals("zhongzhuan")) {
            Merchant merchantUser = merchantService.findByUserId(loginUser.getId());
            findParam.setMerchantNo(merchantUser.getMerchantNo());
        }
        List<Merchant> merchants = merchantService.findAllMerchant(findParam);
        Map<Integer,Merchant> merchantMap = merchants.stream().collect(Collectors.toMap(Merchant::getId,t->t));
        List<MerchantAccountDetail> merchantAccountDetails = new ArrayList<>();
        for (Merchant merchant : merchants) {
            MerchantAccountDetail merchantAccountDetail = merchantAccountService.getMerchantAccountDetail(merchant.getId());
            merchantAccountDetails.add(merchantAccountDetail);
        }

        merchantAccountDetails.sort((a,b) -> a.getWithdrawBalance().intValue() - b.getWithdrawBalance().intValue());
        Collections.reverse(merchantAccountDetails);

        model.addAttribute("merchantAccountDetails",merchantAccountDetails);
        model.addAttribute("merchantMap",merchantMap);
        return "/admin/report/merchant/merchantBalanceReport";
    }


    @RequestMapping("/platment_user_balance")
    @OperationAuth(name = "用户余额报表", authCode = "platform.userBalanceReport", group = "平台报表")
    public String platmentUserBalance(QueryMerchantAccountParam queryParam, Model model, HttpRequest request){
        MerchantFindParam findParam = new MerchantFindParam();
        findParam.setUserType(MerchantUserTypeEnum.PLATMENTUSER);
        List<Merchant> merchants = merchantService.findAllMerchant(findParam);
        Map<Integer,Merchant> merchantMap = merchants.stream().collect(Collectors.toMap(Merchant::getId,t->t));
        List<MerchantAccountDetail> merchantAccountDetails = new ArrayList<>();
        for (Merchant merchant : merchants) {
            MerchantAccountDetail merchantAccountDetail = merchantAccountService.getMerchantAccountDetail(merchant.getId());
            merchantAccountDetails.add(merchantAccountDetail);
        }

        model.addAttribute("merchantAccountDetails",merchantAccountDetails);
        model.addAttribute("merchantMap",merchantMap);
        return "/admin/report/merchant/platmentUserBalanceReport";
    }

    @RequestMapping("/channel_account_balance")
    @OperationAuth(name = "通道账户余额统计", authCode = "platform.channel_account_balance", group = "平台报表")
    public String channelAccountBalance(QueryMerchantAccountParam queryParam, Model model, HttpRequest request){
        //查询所有未删除的上游通道号
        List<ChannelAccount> accounts = channelAccountService.findAllChannelAccounts(null);
        List<ChannelAccountDetail> channelAccountDetails = new ArrayList<>();
        for (ChannelAccount account : accounts) {
            ChannelAccountDetail accDetail = channelAccountInstanceService.getMerchantAccountDetail(account.getId());
            channelAccountDetails.add(accDetail);
        }
        channelAccountDetails.sort((a,b) -> a.getTotalCashBalance().intValue() - b.getTotalCashBalance().intValue());
        Collections.reverse(channelAccountDetails);
        Map<Integer,ChannelAccount> channelAccountMap = accounts.stream().collect(Collectors.toMap(ChannelAccount::getId,t->t));
        model.addAttribute("channelAccountMap", channelAccountMap);
        model.addAttribute("channelAccountDetails", channelAccountDetails);
        List<Channel> channels= channelService.findChannels(new ChannelQuery());
        Map<Integer,String> channelMap = channels.stream().collect(Collectors.toMap(Channel::getId,Channel::getName));
        model.addAttribute("channelMap",channelMap);
        return "/admin/report/merchant/channelAccountBalance";
    }

}
