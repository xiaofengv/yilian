package com.ajl.bfb.task;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.annotation.PostConstruct;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;


public abstract class AbstractSyncTask {

    private static Logger logger = LogManager.getLogger(AbstractSyncTask.class);

    private Map<String,Lock> locks = new HashMap<>();

    @PostConstruct
    public void initLock() {
        locks.put(getLockKey(), new ReentrantLock());
    }

    public void doTask() {
        Lock lock = locks.get(getLockKey());
        try {
            int lockTime = 3 * 1000;
            boolean tryLock = lock.tryLock(lockTime, TimeUnit.MILLISECONDS);
            if(!tryLock) {
                logger.warn(this.getClass().getName() + "任务撞车.");
                return;
            }
            run();
        } catch (Throwable e) {
        } finally {
            try {
                lock.unlock();
            } catch (Throwable e) {
                e.printStackTrace();
            }
        }
    }

    private String getLockKey() {
        return getClass().getName();
    }

    public abstract void run();

}
