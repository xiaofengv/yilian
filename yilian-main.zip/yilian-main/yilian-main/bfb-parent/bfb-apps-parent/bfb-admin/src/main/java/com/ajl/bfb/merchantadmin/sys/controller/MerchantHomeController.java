package com.ajl.bfb.merchantadmin.sys.controller;

import com.ajl.bfb.merchantadmin.common.web.MerchantAdminUserUtils;
import com.ajl.bfb.repo.merchant.model.Merchant;
import com.ajl.bfb.repo.merchant.service.IMerchantService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;



@Controller
@RequestMapping("/merchant_admin/common")
public class MerchantHomeController {

    @Autowired
    private IMerchantService merchantService;

    @RequestMapping("/parent_home")
    public String parent_home(Model model, HttpServletRequest request) {
        Merchant merchant = MerchantAdminUserUtils.getLoginMerchant(request);
        model.addAttribute("userName",merchant.getMerchantNo());
        return "/merchant_admin/sys/parent_home";
    }

    @RequestMapping("/home")
    public String home(Model model, HttpServletRequest request) {
        Merchant merchant = MerchantAdminUserUtils.getLoginMerchant(request);
        model.addAttribute("userType",merchant.getUserType());
        return "/merchant_admin/sys/home";
    }

    @RequestMapping("/nopermission")
    public String noPermission() {
        return "/merchant_admin/sys/nopermission";
    }

}
