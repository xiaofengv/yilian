package com.ajl.bfb.admin.merchant.controller;

import com.ajl.bfb.admin.merchant.vo.UpdateMerchantPayTypeAccConfigVO;
import com.ajl.bfb.core.constants.PaymentTypeEnum;
import com.ajl.bfb.core.constants.RateTypeEnum;
import com.ajl.bfb.core.constants.ReadyStatusEnum;
import com.ajl.bfb.core.util.RateUtils;
import com.ajl.bfb.repo.channel.model.Channel;
import com.ajl.bfb.repo.channel.model.ChannelAccPayType;
import com.ajl.bfb.repo.channel.model.ChannelAccount;
import com.ajl.bfb.repo.channel.model.ChannelQuery;
import com.ajl.bfb.repo.channel.service.IChannelAccPayTypeService;
import com.ajl.bfb.repo.channel.service.IChannelAccountService;
import com.ajl.bfb.repo.channel.service.IChannelService;
import com.ajl.bfb.repo.merchant.model.MerchantPayType;
import com.ajl.bfb.repo.merchant.model.MerchantPayTypeAccount;
import com.ajl.bfb.repo.merchant.service.IMerchantPayTypeAccountService;
import com.ajl.bfb.repo.merchant.service.IMerchantPayTypeService;
import com.hippo.framework.web.ResponseCode;
import com.hippo.framework.web.ResponseResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;


@Controller
@RequestMapping("/admin/merchant_pay_type_acc")
public class MerchantPayTypeAccController {

    @Autowired
    private IMerchantPayTypeService merchantPayTypeService;
    @Autowired
    private IMerchantPayTypeAccountService merchantPayTypeAccountService;
    @Autowired
    private IChannelService channelService;
    @Autowired
    private IChannelAccountService channelAccountService;
    @Autowired
    private IChannelAccPayTypeService channelAccPayTypeService;


    @RequestMapping(value="/to_config")
    public String toConfigPayTypeAcc(int merchantPayTypeId, Model model) {
        MerchantPayType payType = merchantPayTypeService.findById(merchantPayTypeId);
        List<MerchantPayTypeAccount> merchantPayTypeAccs = merchantPayTypeAccountService.findMerchantPayTypeAcc(payType.getMerchantId(), PaymentTypeEnum.valueOf(payType.getPayTypeCode()));


        List<Channel> allChannels = channelService.findChannels(new ChannelQuery());

        Map<Integer, String> rateMap = new HashMap<>();

        List<Channel> channels = new ArrayList<>();
        for (Channel channel : allChannels) {
            List<ChannelAccount> accounts = channelAccountService.findByChannelId(channel.getId());

            List<ChannelAccount> openedAccs = accounts.stream().filter(
                    acc -> (acc.getPayments()!=null && acc.getPayments().contains(payType.getPayTypeCode()) )  )
                    .collect(Collectors.toList());
            channel.setChannelAccountList(openedAccs);

            for (ChannelAccount openedAcc : openedAccs) {
                ChannelAccPayType accPayType = channelAccPayTypeService.findByPaymentType(openedAcc.getId(), PaymentTypeEnum.valueOf(payType.getPayTypeCode()));
                rateMap.put(openedAcc.getId(), RateUtils.rate2percent(accPayType.getRate()).toString() + RateTypeEnum.valueOf(accPayType.getRateType()).getViewDesc());
            }
            if (!openedAccs.isEmpty()) {
                channels.add(channel);
            }
        }
        Map<Integer, MerchantPayTypeAccount> accountMap = merchantPayTypeAccs.stream().collect(Collectors.toMap(MerchantPayTypeAccount::getChannelAccountId, acc -> acc));

        for (Channel channel : allChannels) {
            for (ChannelAccount account : channel.getChannelAccountList()) {
                if (accountMap.get(account.getId()) != null) {
                    account.setStatus(ReadyStatusEnum.ON.name());
                } else {
                    account.setStatus(ReadyStatusEnum.OFF.name());
                }
            }
        }
        model.addAttribute("rateMap", rateMap);
        model.addAttribute("payType", PaymentTypeEnum.valueOf(payType.getPayTypeCode()));
        model.addAttribute("merchantId", payType.getMerchantId());
        model.addAttribute("channelList", channels);
        return "admin/merchant_paytype_acc/config";
    }

    @RequestMapping(value="/update_config")
    @ResponseBody
    public ResponseResult configPayTypeAcc(UpdateMerchantPayTypeAccConfigVO accConfigVO, Model model) {
        if (accConfigVO.getAccountIdList() == null) {
            accConfigVO.setAccountIdList(new ArrayList<>());
        }
        merchantPayTypeAccountService.save(accConfigVO.getMerchantId(), PaymentTypeEnum.valueOf(accConfigVO.getPayTypeCode()), accConfigVO.getAccountIdList());
        return new ResponseResult(ResponseCode.SUCCESS, "保存成功", "");
    }


    @RequestMapping(value="/update_config2")
    @ResponseBody
    public ResponseResult configPayTypeAcc2(int channelAccountId, int merchant_id, String pay_type, Model model) {
        merchantPayTypeAccountService.save2(merchant_id, PaymentTypeEnum.valueOf(pay_type), channelAccountId);
        return new ResponseResult(ResponseCode.SUCCESS, "保存成功", "");
    }

}
