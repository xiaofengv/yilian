package com.ajl.bfb.admin.sys.controller;

import com.ajl.bfb.admin.channelaccount.util.ChannelAccountViewUtils;
import com.ajl.bfb.admin.channelaccount.vo.ChannelAccountVO;
import com.ajl.bfb.admin.common.web.AdminUserUtils;
import com.ajl.bfb.core.constants.ReadyStatusEnum;
import com.ajl.bfb.core.constants.StatBizTypeEnum;
import com.ajl.bfb.repo.channel.model.*;
import com.ajl.bfb.repo.channel.service.IChannelAccountService;
import com.ajl.bfb.repo.channel.service.IChannelService;
import com.ajl.bfb.repo.channelstat.service.IChannelAccountDayStatService;
import com.ajl.bfb.repo.fund.service.IFinanceFacadeService;
import com.ajl.bfb.repo.merchant.model.Merchant;
import com.ajl.bfb.repo.merchant.model.MerchantAccountDetail;
import com.ajl.bfb.repo.merchant.service.IMerchantAccountService;
import com.ajl.bfb.repo.merchant.service.IMerchantService;
import com.ajl.bfb.repo.payment.model.PayType;
import com.ajl.bfb.repo.payment.service.IPayTypeService;
import com.ajl.bfb.repo.report.service.IReportService;
import com.ajl.bfb.repo.stat.model.PaymentOrderStat;
import com.ajl.bfb.repo.stat.model.QueryPaymentOrderStatParam;
import com.ajl.bfb.repo.stat.service.IPaymentOrderStatService;
import com.github.pagehelper.PageInfo;
import com.hippo.framework.auth.admin.model.SysUser;
import com.hippo.framework.web.ResponseCode;
import com.hippo.framework.web.ResponseResult;
import org.apache.commons.lang3.EnumUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Collectors;

/**
 *
 * Created by admin on 2018-01-29 0029.
 */

@Controller
@RequestMapping("/admin/common")
public class HomeController {
    @Autowired
    private IMerchantAccountService merchantAccountService;
    @Autowired
    private IMerchantService merchantService;
    @Autowired
    private IChannelAccountDayStatService channelAccountDayStatService;
    @Autowired
    private IPaymentOrderStatService paymentOrderStatService;
    @Autowired
    private IPayTypeService payTypeService;
    @Autowired
    private IReportService reportService;



    /**
     * @param request 请求参数
     * @param model
     * @see org.springframework.ui.Model
     * @return
     */
    @RequestMapping("/home")
    public String home(HttpServletRequest request,Model model) {
        SysUser sysUser = AdminUserUtils.getCurrentLoginUser(request);
        model.addAttribute("sysUser",sysUser);
        //登录用户
        Merchant merchant = merchantService.findByUserId(sysUser.getId());
        if(merchant!=null){
            MerchantAccountDetail mchAcc = merchantAccountService.getMerchantAccountDetail(merchant.getId());
            model.addAttribute("mchAcc", mchAcc);
            model.addAttribute("merchant", merchant);
        }

        //平台汇总统计
        HashMap totalMap = reportService.reportQueryByTotal(null,"channelAccountTotalStat");
        if (null != totalMap) {
            //支付统计
            model.addAttribute("paymentOrderTotal", ((BigDecimal) totalMap.get("totalInCome")).add((BigDecimal) totalMap.get("totalManualIncome")));

            //代付统计
            model.addAttribute("withdrawOrderTotal", ((BigDecimal) totalMap.get("totalWithdraw")).add((BigDecimal) totalMap.get("totalManualWithdraw")));

            //平台总收款
            model.addAttribute("totalPaymentAmount", totalMap.get("totalInCome"));

            //充值统计
            model.addAttribute("rechargeOrderTotal", totalMap.get("totalManualIncome"));

            //平台总代付
            model.addAttribute("totalWithdrawAmount", ((BigDecimal) totalMap.get("totalManualWithdraw")).add((BigDecimal) totalMap.get("totalWithdraw")));

            //平台支付总费用
            int totalPlatmentCost = ((BigDecimal) totalMap.get("totalPaymentCost")).add((BigDecimal) totalMap.get("totalManualIncomeCost")).intValue();
            //平台代付总费用
            int totalWithdrawCost = ((BigDecimal) totalMap.get("totalWithdrawCost")).add((BigDecimal) totalMap.get("totalManualWithdrawCost")).intValue();
            //平台总代理费用
            int totalAgentCost = ((BigDecimal) totalMap.get("totalAgentCost")).intValue();
            model.addAttribute("totalAgentCost", totalAgentCost);
            //平台总利润
            int totalProfit = ((BigDecimal) totalMap.get("totalProfit")).intValue();
            model.addAttribute("totalProfit", totalProfit);
            //平台总手续费
            int totalCost = totalPlatmentCost + totalWithdrawCost;
            model.addAttribute("totalCost", totalCost);
            //平台总余额
            BigDecimal totalBalance = ((BigDecimal) totalMap.get("totalInCome")).add
                    ((BigDecimal) totalMap.get("totalManualIncome")).subtract
                    ((BigDecimal) totalMap.get("totalWithdraw")).subtract
                    ((BigDecimal) totalMap.get("totalPaymentCost")).subtract
                    ((BigDecimal) totalMap.get("totalWithdrawCost")).subtract
                    ((BigDecimal) totalMap.get("totalManualWithdraw")).subtract
                    ((BigDecimal) totalMap.get("totalManualIncomeCost")).subtract
                    ((BigDecimal) totalMap.get("totalManualWithdrawCost"));
            model.addAttribute("totalBalance", totalBalance);
            //平台总通道介绍费
            int totalIntroducerProfit = ((BigDecimal) totalMap.get("totalIntroducerProfit")).intValue();
            model.addAttribute("totalIntroducerCost", totalIntroducerProfit);
        }
        //今日，昨日收款统计
        ChannelStat todayStat = channelAccountDayStatService.queryChannelStatByDay(getDay(new Date()));
        ChannelStat tomorrowStat = channelAccountDayStatService.queryChannelStatByDay(getDay(DateUtils.addDays(new Date(),-1)));
        model.addAttribute("todayStat", todayStat);
        model.addAttribute("tomorrowStat", tomorrowStat);

        //按支付方式统计今日收款
        QueryPaymentOrderStatParam queryOrderParam = new QueryPaymentOrderStatParam();
        //加默认时间当天，没有时间的时候
        queryOrderParam.setStartTime(com.hippo.framework.util.DateUtils.getDateStart(new Date()));
        queryOrderParam.setEndTime(com.hippo.framework.util.DateUtils.getDateEnd(new Date()));
        //payTypeCode 分组
        queryOrderParam.setGroupby(Arrays.asList(QueryPaymentOrderStatParam.GroupBy.payTypeCode));
        queryOrderParam.setPageSize(100);
        queryOrderParam.setPageNum(1);

        //统计当日收款业务，按支付类型统计
        queryOrderParam.setStatBizType(StatBizTypeEnum.PAYMENT.name());  //只针对支付业务统计
        PageInfo<PaymentOrderStat> page = paymentOrderStatService.findPaymentOrderStatByPage(queryOrderParam);
        model.addAttribute("paymentOrderStats", page.getList());
        Map<String,String> paytypeMap = payTypeService.getAll().stream().collect(Collectors.toMap(PayType::getCode,PayType::getName));
        model.addAttribute("paytypeMap", paytypeMap);

        //按业务类型分组统计当日所有业务
        queryOrderParam.setStatBizType(null);
        queryOrderParam.setGroupby(Arrays.asList(QueryPaymentOrderStatParam.GroupBy.statBizType));
        //当前页统计记录
        PageInfo<PaymentOrderStat> bizTypeStat = paymentOrderStatService.findPaymentOrderStatByPage(queryOrderParam);
        model.addAttribute("bizTypeStat", bizTypeStat);
        //统计汇总
        PaymentOrderStat bizTypeSumStat = paymentOrderStatService.paymentOrderSumStat(queryOrderParam);
        model.addAttribute("sum", bizTypeSumStat);
        Map<String,String> biztypeMap = Arrays.stream(StatBizTypeEnum.values()).collect(Collectors.toMap(StatBizTypeEnum::name,StatBizTypeEnum::getDesc));
        model.addAttribute("biztypeMap", biztypeMap);

        return "/admin/sys/home";
    }


    @RequestMapping("/parent_home")
    public String parent_home(HttpServletRequest request, Model model) {
        SysUser sysUser = AdminUserUtils.getCurrentLoginUser(request);
        model.addAttribute("userName",sysUser.getUserName());
        return "/admin/sys/parent_home";
    }

    @Autowired
    private IChannelService channelService;
    @Autowired
    private IChannelAccountService channelAccountService;
    @Autowired
    private IFinanceFacadeService financeFacadeService;

    @RequestMapping("/check_balance")
    @ResponseBody
    public ResponseResult check_balance(HttpServletRequest request, Model model) {

        List<Channel> channels = channelService.findChannels(new ChannelQuery());
        List<ChannelAccount> accounts = channelAccountService.findChannelAccounts(new ChannelAccount());
        List<ChannelAccountVO> accountsVO = ChannelAccountViewUtils.toVO(accounts);
        List<ReadyStatusEnum> status = EnumUtils.getEnumList(ReadyStatusEnum.class);
        Map<String,ReadyStatusEnum> statusMap = EnumUtils.getEnumMap(ReadyStatusEnum.class);

        StringBuffer sb1 = new StringBuffer();
        Map<Integer, Channel> channelMap = channels.stream().collect(Collectors.toMap(Channel::getId, c -> c));

        Map<Integer,String> ccMap = new HashMap<>();

        for (ChannelAccountVO accountVO : accountsVO) {
            Channel c = channelMap.get(accountVO.getChannelId());
            if (channelMap.get(accountVO.getChannelId()).getType() != Channel.ChannelType.PAYMENT) {
                continue;
            }
            accountVO.setChannelName(channelMap.get(accountVO.getChannelId()).getName());
            long channelAccCashBalance = financeFacadeService.getChannelAccountTotalBalance(accountVO.getId());
            if (c.getCardMax() >0 && channelAccCashBalance >= c.getCardMax() ) {
                sb1.append("通道[" + c.getName() + "]收款号:" + accountVO.getAccount() + ":余额为:" + (channelAccCashBalance/100)+"元</br>");
                ccMap.put(c.getId(), c.getName());
            }
        }

        List<String> list = new ArrayList<>();
        for (Map.Entry<Integer, String> ee : ccMap.entrySet()) {
            list.add("通道[" + ee.getValue()+  "]存留的余额超标");
        }
        Map<String,String> r = new HashMap<>();
        r.put("msg1", sb1.toString());
        r.put("msg2", StringUtils.join(list, ","));
        r.put("warning", list.isEmpty()?"0":"1");
        return new ResponseResult(ResponseCode.SUCCESS, "ok",r);
    }

    @RequestMapping("/nopermission")
    public String noPermission() {
        return "/admin/sys/nopermission";
    }

    @RequestMapping("/second_pwd")
    public String secondPwd(){
        return "/admin/sys/second_pwd";
    }


    private int getDay(Date statDate) {
        return Integer.valueOf(DateFormatUtils.format(statDate, "yyyyMMdd"));
    }
}
