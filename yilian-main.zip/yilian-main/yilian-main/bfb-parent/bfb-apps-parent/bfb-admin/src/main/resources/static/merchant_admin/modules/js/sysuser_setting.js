var sysuser_setting = {};


//登录密码新增或更新保存
sysuser_setting.save = function () {
    if (!hippo.validateForm("addForm")) {
        return;
    }

    $("#addForm").ajaxSubmit(function (response) {
        if (response.statusCode == "SUCCESS") {
            hippo.msg(response.message);
            window.setTimeout(function () {
                window.top.location.href=getWebPath()+"/merchant_admin/sys/logout";
            }, 500);
        } else {
            hippo.msg(response.message);
        }
    });
}


//二次密码新增或更新保存
sysuser_setting.update_secondpwd = function () {
    if (!hippo.validateForm("addForm")) {
        return;
    }

    $("#addForm").ajaxSubmit(function (response) {
        if (response.statusCode == "SUCCESS") {
            hippo.msg(response.message);
            window.setTimeout(function () {
                window.top.location.href=getWebPath()+"/merchant_admin/sys/logout";
            }, 500);
        } else {
            hippo.msg(response.message);
        }
    });
}

sysuser_setting.close = function () {
    $('.close', window.parent.document).trigger("click");
}








