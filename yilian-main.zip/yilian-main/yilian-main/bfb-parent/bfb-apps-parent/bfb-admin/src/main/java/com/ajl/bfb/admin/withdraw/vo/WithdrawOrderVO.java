package com.ajl.bfb.admin.withdraw.vo;

import com.ajl.bfb.core.constants.*;
import com.ajl.bfb.repo.withdraw.model.WithdrawOrder;


public class WithdrawOrderVO extends WithdrawOrder {

    private String merchantName;

    private TransferPaymentStatusEnum transferPaymentStatus;

    private Boolean validRequestIP;

    private Boolean validPayeeBankAccount;

    private String channelName;

    private String channelAccName;

    private String channelAcc;

    public String getPayeeBankCodeStr() {
        try {
            BankCodeEnum bankCode = BankCodeEnum.valueOfCode(getPayeeBankCode());
            return bankCode.getBankName();
        } catch (Throwable e) {
            e.printStackTrace();
        }
        return "无法识别!";
    }

    public String getPayeeBankName() {
           return BankCodeEnum.valueOfCode(getPayeeBankCode()).getBankName();
    }

    public String getMerchantName() {
        return merchantName;
    }

    public void setMerchantName(String merchantName) {
        this.merchantName = merchantName;
    }

    public String getAuditStatusStr() {
        return AuditStatusEnum.valueOf(getAuditStatus()).getDesc();
    }

    public String getOrderStatusStr() {
        return OrderStatusEnum.valueOf(getOrderStatus()).getDesc();
    }

    public String getWithdrawTypeStr() {
        return WithdrawTypeEnum.valueOf(getWithdrawType()).getDesc();
    }

    public TransferPaymentStatusEnum getTransferPaymentStatus() {
        return transferPaymentStatus;
    }

    public void setTransferPaymentStatus(TransferPaymentStatusEnum transferPaymentStatus) {
        this.transferPaymentStatus = transferPaymentStatus;
    }

    public Boolean getValidRequestIP() {
        return validRequestIP;
    }

    public void setValidRequestIP(Boolean validRequestIP) {
        this.validRequestIP = validRequestIP;
    }

    public Boolean getValidPayeeBankAccount() {
        return validPayeeBankAccount;
    }

    public void setValidPayeeBankAccount(Boolean validPayeeBankAccount) {
        this.validPayeeBankAccount = validPayeeBankAccount;
    }

    public String getChannelName() {
        return channelName;
    }

    public void setChannelName(String channelName) {
        this.channelName = channelName;
    }

    public String getChannelAccName() {
        return channelAccName;
    }

    public void setChannelAccName(String channelAccName) {
        this.channelAccName = channelAccName;
    }

    public String getChannelAcc() {
        return channelAcc;
    }

    public void setChannelAcc(String channelAcc) {
        this.channelAcc = channelAcc;
    }
}
