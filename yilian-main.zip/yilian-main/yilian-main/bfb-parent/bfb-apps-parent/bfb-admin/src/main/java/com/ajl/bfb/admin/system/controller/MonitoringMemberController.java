package com.ajl.bfb.admin.system.controller;

import com.ajl.bfb.core.constants.OrderStatusEnum;
import com.ajl.bfb.core.lock.PaymentOrderLock;
import com.ajl.bfb.core.util.MoneyUtils;
import com.ajl.bfb.itg.util.ZipUtils;
import com.ajl.bfb.repo.channel.model.Channel;
import com.ajl.bfb.repo.channel.model.ChannelAccount;
import com.ajl.bfb.repo.channel.model.ChannelQuery;
import com.ajl.bfb.repo.channel.service.IChannelAccountService;
import com.ajl.bfb.repo.channel.service.IChannelService;
import com.ajl.bfb.repo.merchant.model.Merchant;
import com.ajl.bfb.repo.merchant.service.IMerchantService;
import com.ajl.bfb.repo.system.model.QueryMonitoringMemberParam;
import com.ajl.bfb.repo.system.service.IMonitoringMemberService;
import com.github.pagehelper.PageInfo;
import com.hippo.framework.auth.admin.OperationAuth;
import com.hippo.framework.dictionary.model.Dictionary;
import com.hippo.framework.dictionary.service.IDictionaryService;
import com.hippo.framework.util.DateUtils;
import com.icexls.IceExcel;
import com.icexls.IceExcelConfig;
import com.icexls.NumberType;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.net.URLEncoder;
import java.util.*;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/admin/system/member")
public class MonitoringMemberController {
    @Autowired
    private IMonitoringMemberService monitoringMemberService;
    @Autowired
    private IMerchantService merchantService;
    @Autowired
    private IChannelService channelService;
    @Autowired
    private PaymentOrderLock paymentOrderLock;
    @Autowired
    private IDictionaryService dictionaryService;
    @Autowired
    private IChannelAccountService channelAccountService;
    @Value("${export.alipayment.order}")
    private String exportPath;
    private static final String formart = "alipays://platformapi/startapp?appId=09999988&actionType=toAccount&goBack=NO&amount=0.01&userId=%s&memo=%s";

    @RequestMapping("/list")
    @OperationAuth(name = "支付订单管理", authCode = "payment_order.list", group = "支付订单管理")
    public String monitoringMemberList(Model model, QueryMonitoringMemberParam queryParam) {
        initQueryParam(queryParam);
        PageInfo<QueryMonitoringMemberParam> page = monitoringMemberService.findListAndSuccessRate(queryParam);
        List<QueryMonitoringMemberParam> list = page.getList();
        List<Channel> channels = channelService.findChannels(new ChannelQuery());
        model.addAttribute("channels", channels);
        page.setList(transformVO(list, channels));
        model.addAttribute("pageInfo", page);
        model.addAttribute("totalNum",page.getTotal());
        resetParam(queryParam);
        model.addAttribute("queryParam", queryParam);
        model.addAttribute("orderStatusList", OrderStatusEnum.values());
        return "admin/system/merchant/monitoringMemberList";
    }

    private void resetParam(QueryMonitoringMemberParam queryParam) {
        if (queryParam.getAmountStart() != null && queryParam.getAmountStart() > 0){
            queryParam.setAmountStart(queryParam.getAmountStart() / 100);
        }
        if (queryParam.getAmountEnd() != null && queryParam.getAmountEnd() > 0){
            queryParam.setAmountEnd(queryParam.getAmountEnd() / 100);
        }
        if (queryParam.getTotalAmountStart() != null && queryParam.getTotalAmountStart() > 0){
            queryParam.setTotalAmountStart(queryParam.getTotalAmountStart() / 100);
        }
        if (queryParam.getTotalAmountEnd() != null && queryParam.getTotalAmountEnd() > 0){
            queryParam.setTotalAmountEnd(queryParam.getTotalAmountEnd() / 100);
        }

        if (queryParam.getSuccessAmountStart() != null && queryParam.getSuccessAmountStart() > 0){
            queryParam.setSuccessAmountStart(queryParam.getSuccessAmountStart() / 100);
        }
        if (queryParam.getSuccessAmountEnd() != null && queryParam.getSuccessAmountEnd() > 0){
            queryParam.setSuccessAmountEnd(queryParam.getSuccessAmountEnd() / 100);
        }
    }

    private List<QueryMonitoringMemberParam> transformVO(List<QueryMonitoringMemberParam> list, List<Channel> channels) {
        if (list.isEmpty()) {
            return Collections.EMPTY_LIST;
        }
        List<Integer> merchantIds = list.stream().map(QueryMonitoringMemberParam::getMerchantId).distinct().collect(Collectors.toList());
        List<Merchant> mchs = merchantService.findByIds(merchantIds);
        Map<Integer, Merchant> merchantMap = mchs.stream().collect(Collectors.toMap(Merchant::getId, m -> m));
        Map<Integer, Channel> channelMap = channels.stream().collect(Collectors.toMap(Channel::getId, m -> m));
        List<Integer> channelAccountIds = list.stream().map(QueryMonitoringMemberParam::getChannelAccountId).distinct().collect(Collectors.toList());
        List<ChannelAccount> channelAccounts = channelAccountService.findByIds(channelAccountIds);
        Map<Integer,ChannelAccount> channelAccountMap = channelAccounts.stream().collect(Collectors.toMap(ChannelAccount::getId,c -> c));
        Dictionary informationTextDic = dictionaryService.getByCode("INFORMATION_TEXT");
        String informationText = informationTextDic.getAttributeValue();
        for (QueryMonitoringMemberParam monitoringMember : list) {
            Merchant merchant = merchantMap.get(monitoringMember.getMerchantId());
            Channel channel = channelMap.get(monitoringMember.getChannelId());
            ChannelAccount channelAccount = channelAccountMap.get(monitoringMember.getChannelAccountId());
            monitoringMember.setMerchantName(merchant.getMerchantName());
            monitoringMember.setMerchantNo(merchant.getMerchantNo());
            monitoringMember.setChannelName(channel.getName());
            monitoringMember.setChannelAccount(channelAccount.getAccount());
            String qrUrl = "qr_code_image?content=" + URLEncoder.encode(String.format(formart, monitoringMember.getAlipayUserId(), informationText));
            monitoringMember.setQrUrl(qrUrl);
        }
        return list;
    }

    private void initQueryParam(QueryMonitoringMemberParam queryParam) {
        if (queryParam.getStartTime() == null) {
            queryParam.setStartTime(DateUtils.plusDays(DateUtils.getDateStart2(new Date()), 0));
            queryParam.setEndTime(DateUtils.getDateEnd2(new Date()));
        }
        if (StringUtils.isEmpty(queryParam.getIsAlipay())) {
            queryParam.setIsAlipay("Y");
        }
        queryParam.setPageSize(20);
        if (queryParam.getAmountStart() != null && queryParam.getAmountStart() > 0){
            queryParam.setAmountStart(queryParam.getAmountStart() * 100);
        }
        if (queryParam.getAmountEnd() != null && queryParam.getAmountEnd() > 0){
            queryParam.setAmountEnd(queryParam.getAmountEnd() * 100);
        }

        if (queryParam.getTotalAmountStart() != null && queryParam.getTotalAmountStart() > 0){
            queryParam.setTotalAmountStart(queryParam.getTotalAmountStart() * 100);
        }
        if (queryParam.getTotalAmountEnd() != null && queryParam.getTotalAmountEnd() > 0){
            queryParam.setTotalAmountEnd(queryParam.getTotalAmountEnd() * 100);
        }

        if (queryParam.getSuccessAmountStart() != null && queryParam.getSuccessAmountStart() > 0){
            queryParam.setSuccessAmountStart(queryParam.getSuccessAmountStart() * 100);
        }
        if (queryParam.getSuccessAmountEnd() != null && queryParam.getSuccessAmountEnd() > 0){
            queryParam.setSuccessAmountEnd(queryParam.getSuccessAmountEnd() * 100);
        }
        if (StringUtils.isNotEmpty(queryParam.getOrderStatus())){
            if ("SUCCESS".equals(queryParam.getOrderStatus())){
                queryParam.setProcessingNum(0);
            }else if ("PROCESSING".equals(queryParam.getOrderStatus())){
                queryParam.setSuccessNum(0);
            }else {
                queryParam.setPartPay(0);
            }
        }
        if (StringUtils.isNotEmpty(queryParam.getMerchantNo())){
            Merchant merchant = merchantService.findByMerchantNo(queryParam.getMerchantNo());
            queryParam.setMerchantId(merchant.getId());
        }
        if (StringUtils.isNotEmpty(queryParam.getChannelAccount())){
            ChannelAccount channelAccount = channelAccountService.findChannelAccountByAccount(queryParam.getChannelAccount());
            queryParam.setChannelAccountId(channelAccount.getId());
        }
    }

    @RequestMapping("export")
    public String export(QueryMonitoringMemberParam queryOrderParam, HttpServletResponse response) throws Exception {
        initQueryParam(queryOrderParam);
        String isAlipay = queryOrderParam.getIsAlipay();
        String reqId = System.currentTimeMillis() + "";
        String objId = 999998891 + "";
        try {

            if (!paymentOrderLock.getLock(objId, reqId)) {
                throw new Exception("其他用户正在导出，请稍后再试...");
            }

            if (queryOrderParam.getStartTime() == null && queryOrderParam.getEndTime() == null) {
                throw new RuntimeException("起始时间，结束时间不能为空");
            }

            final int pageSize = 100;
            final int oneSheetRows = 100000;
            String excelExportFilePath = exportPath + "/" + System.currentTimeMillis();

            List<String> allExcels = new ArrayList<>();
            queryOrderParam.setPageSize(pageSize);
            PageInfo<QueryMonitoringMemberParam> page = monitoringMemberService.findListAndSuccessRate(queryOrderParam);
            List<QueryMonitoringMemberParam> orders = new ArrayList<>();

            int pages = page.getPages();
            int pageNum = 1;
            for (int i = 0; i < pages; i++) {
                pageNum = i + 1;
                queryOrderParam.setPageNum(pageNum);
                List<QueryMonitoringMemberParam> ordersList = monitoringMemberService.findListAndSuccessRate(queryOrderParam).getList();
                orders.addAll(ordersList);
                if (orders.size() >= oneSheetRows) {
                    String excelFile = export2excel(orders, excelExportFilePath, isAlipay);
                    allExcels.add(excelFile);
                    orders = new ArrayList<>();
                }
            }
            if (!orders.isEmpty()) {
                String excelFile = export2excel(orders, excelExportFilePath, isAlipay);
                allExcels.add(excelFile);
                orders = new ArrayList<>();
            }
            response.addHeader("Content-Disposition", "attachment;filename=member.zip");
            response.setContentType("application/octet-stream");
            ZipUtils.toZip(excelExportFilePath, response.getOutputStream(), true);
            new File(excelExportFilePath).delete();
        } finally {
            paymentOrderLock.releaseLock(objId, reqId);
        }
        return null;
    }
    private String export2excel(List<QueryMonitoringMemberParam> orders, String exportFilePath, String isAlipay) {
        new File(exportFilePath).mkdirs();
        String xlsFile = exportFilePath + "/" + System.currentTimeMillis() + ".xls";
        String[] title = null;
        if (isAlipay.equals("Y")) {
            title = new String[]{"支付宝userId","采集次数","成功次数","成功率", "下单总金额","成功总金额","最近一笔金额","下游", "下游号", "上游", "上游收款号", "下游订单号", "平台订单号", "上游订单号", "订单金额", "订单状态", "监控时间"};
        } else {
            title = new String[]{"微信openId", "下游", "下游号", "上游", "上游收款号", "下游订单号", "平台订单号", "上游订单号", "订单金额", "订单状态", "监控时间"};
        }

        String[][] datas = new String[orders.size() + 1][title.length];
        datas[0] = title;

        List<Integer> merchantIds = orders.stream().map(QueryMonitoringMemberParam::getMerchantId).distinct().collect(Collectors.toList());
        List<Merchant> mchs = merchantService.findByIds(merchantIds);
        Map<Integer, Merchant> merchantMap = mchs.stream().collect(Collectors.toMap(Merchant::getId, m -> m));
        List<Channel> channels = channelService.findChannels(new ChannelQuery());
        Map<Integer, Channel> channelMap = channels.stream().collect(Collectors.toMap(Channel::getId, m -> m));
        List<Integer> channelAccountIds = orders.stream().map(QueryMonitoringMemberParam::getChannelAccountId).distinct().collect(Collectors.toList());
        List<ChannelAccount> channelAccounts = channelAccountService.findByIds(channelAccountIds);
        Map<Integer,ChannelAccount> channelAccountMap = channelAccounts.stream().collect(Collectors.toMap(ChannelAccount::getId,c -> c));

        for (int i = 0; i < orders.size(); i++) {
            int j = i + 1;
            QueryMonitoringMemberParam vo = orders.get(i);
            Merchant merchant = merchantMap.get(vo.getMerchantId());
            Channel channel = channelMap.get(vo.getChannelId());
            ChannelAccount channelAccount = channelAccountMap.get(vo.getChannelAccountId());
            if (isAlipay.equals("Y")) {
                datas[j][0] = vo.getAlipayUserId();
            } else {
                datas[j][0] = vo.getWeixinOpenId();
            }
            datas[j][1] = vo.getTotalNum().toString();
            datas[j][2] = vo.getSuccessNum().toString();
            String successRate = vo.getSuccessRate().toString();
            if (StringUtils.isNotEmpty(successRate) && successRate.indexOf(".") != 0){
                int begin = successRate.indexOf(".")+1;
                int end = successRate.length();
                String newStr = successRate.substring(begin,end);
                int mantissa = Integer.valueOf(newStr).intValue();
                if (mantissa == 0){
                    successRate = successRate.substring(0,successRate.indexOf("."));
                }
            }
            datas[j][3] = successRate+"%";
            datas[j][4] = MoneyUtils.fee2yuan(Integer.valueOf(vo.getTotalAmount()==null?0:vo.getTotalAmount())).toString();
            datas[j][5] = MoneyUtils.fee2yuan(Integer.valueOf(vo.getSuccessAmount()==null?0:vo.getSuccessAmount())).toString();
            datas[j][6] = MoneyUtils.fee2yuan(Integer.valueOf(vo.getAmount()==null?0:vo.getAmount())).toString();
            datas[j][7] = merchant.getMerchantName();
            datas[j][8] = vo.getMerchantNo();
            datas[j][9] = channel.getName();
            datas[j][10] = channelAccount.getAccount();
            datas[j][11] = vo.getMerchantOrderNo();
            datas[j][12] = vo.getPlatformOrderNo();
            datas[j][13] = vo.getChannelOrderNo();
            datas[j][14] = MoneyUtils.fee2yuan(Integer.valueOf(vo.getAmount())) + "";
            datas[j][15] = OrderStatusEnum.valueOf(vo.getOrderStatus()).getDesc();
            datas[j][16] = DateUtils.format2long(vo.getCreateTime());
        }
        IceExcel iceXls = new IceExcel(xlsFile);
        IceExcelConfig.setSheet(iceXls, "监控数据");
        IceExcelConfig.setNumberType(iceXls, NumberType.STRING);
        iceXls.setData(datas);
        return xlsFile;
    }
}
