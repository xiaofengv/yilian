package com.ajl.bfb.admin.common.web;

import com.hippo.framework.web.util.CookieUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class CurrentMenuInterceptor extends HandlerInterceptorAdapter {

    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        String currentMenuCode = request.getParameter("currentMenuCode");
        if (StringUtils.isNotBlank(currentMenuCode)) {
            CookieUtils.addCookie(response, "currentMenuCode", currentMenuCode, 0);
        }
        return true;
    }
}