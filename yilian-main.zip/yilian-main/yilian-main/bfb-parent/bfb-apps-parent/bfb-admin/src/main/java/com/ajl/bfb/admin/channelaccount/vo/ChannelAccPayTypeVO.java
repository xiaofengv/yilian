package com.ajl.bfb.admin.channelaccount.vo;

import com.ajl.bfb.core.constants.PaymentTypeEnum;
import com.ajl.bfb.core.constants.RateTypeEnum;
import com.ajl.bfb.repo.channel.model.ChannelAccPayType;

import java.math.BigDecimal;


public class ChannelAccPayTypeVO extends ChannelAccPayType {

    private BigDecimal channelPayTypeRatePercent;


    private BigDecimal ratePercent;

    public String getPayTypeName() {
        return PaymentTypeEnum.valueOf(getPayTypeCode()).getDesc();
    }

    public String getRateTypeStr() {
        return RateTypeEnum.valueOf(getRateType()).getViewDesc();
    }

    public BigDecimal getChannelPayTypeRatePercent() {
        return channelPayTypeRatePercent;
    }

    public void setChannelPayTypeRatePercent(BigDecimal channelPayTypeRatePercent) {
        this.channelPayTypeRatePercent = channelPayTypeRatePercent;
    }

    public BigDecimal getRatePercent() {
        return ratePercent;
    }

    public void setRatePercent(BigDecimal ratePercent) {
        this.ratePercent = ratePercent;
    }
}
