package com.ajl.bfb.task;

import com.ajl.bfb.admin.notice.component.NotifyComponent;
import com.ajl.bfb.core.constants.AuditStatusEnum;
import com.ajl.bfb.core.constants.ManualBizTypeEnum;
import com.ajl.bfb.core.constants.OrderStatusEnum;
import com.ajl.bfb.core.constants.TargetTypeEnum;
import com.ajl.bfb.repo.manualorder.ManualOrderException;
import com.ajl.bfb.repo.manualorder.model.ManualOrder;
import com.ajl.bfb.repo.manualorder.model.ManualOrderQueryParam;
import com.ajl.bfb.repo.manualorder.service.IManualOrderService;
import com.ajl.bfb.repo.merchant.model.Merchant;
import com.ajl.bfb.repo.merchant.service.IMerchantAccountService;
import com.ajl.bfb.repo.merchant.service.IMerchantService;
import com.github.pagehelper.PageInfo;
import com.hippo.framework.dictionary.model.Dictionary;
import com.hippo.framework.dictionary.service.IDictionaryService;
import com.hippo.framework.util.CollectionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import java.math.BigDecimal;
import java.util.Date;
import static com.ajl.bfb.core.util.MoneyUtils.fee2yuan;
import static com.ajl.bfb.core.util.MoneyUtils.yuan2fee;

/**
 * 将商户的提现余额自动转成代付余额
 * 自动生成转换订单前提：提现余额>10000 且当前商户没有处理中的资金转换订单
 * 生成转换订单
 */
@Component("transferToWithdrawTask")
public class TransferToWithdrawTask extends AbstractSyncTask {
    private static Logger logger = LogManager.getLogger(TransferToWithdrawTask.class);

    @Autowired
    private IMerchantAccountService merchantAccountService;
    @Autowired
    private IManualOrderService manualOrderService;
    @Autowired
    private IMerchantService merchantService;
    @Autowired
    private NotifyComponent notifyComponent;
    @Autowired
    private IDictionaryService dictionaryService;

    @Scheduled(fixedDelay=600000)  //10分钟一次
    public void run() {
        try {
            logger.info("[before]开始资金转换...");
            BigDecimal minAmount = new BigDecimal(10000);  //余额要大于1万
//            Integer[] merchantids = {155,157,39};  //下游商户列表  AXWR110155  ,G3XQO10039
            //需要自动转换代付资金的商户列表，通过字典表配置
            Dictionary dictionary = dictionaryService.getByCode("MERCHANT_LIST");
            String attributeValue = dictionary.getAttributeValue();
            String[] merchantIds = attributeValue.split(",");

            int count=0;
            for (String merchantid : merchantIds) {
                Merchant merchant = merchantService.findById(new Integer(merchantid));
                if(null==merchant){
                    continue;
                }
                ManualOrderQueryParam param = new ManualOrderQueryParam();
                param.setBizType(ManualBizTypeEnum.TRANSFER_TO_WITHDRAW.name());
                param.setTarget(TargetTypeEnum.MERCHANT.name());
                param.setMerchantAcc(merchant.getMerchantNo());
                param.setStatus(OrderStatusEnum.PROCESSING.name());
                param.setAuditStatus(AuditStatusEnum.AUDITING.name());
                PageInfo<ManualOrder> manualOrderPageInfo =  manualOrderService.getManualOrderList(param);

                //还有处理中的转换订单暂时不生成
                if(CollectionUtils.isNotEmpty(manualOrderPageInfo.getList())){
                    continue;
                }


                //可提现额度（可用于转换为代付资金）
                BigDecimal withdrawBalance=  fee2yuan(merchantAccountService.getMerchantWithdrawBalance(new Integer(merchantid)));
                //提现余额大于最小金额minAmount时才生成转换订单
                if(minAmount.compareTo(withdrawBalance)>0){
                    continue;
                }

                ManualOrder order = new ManualOrder();
                order.setTarget(TargetTypeEnum.MERCHANT.name());
                order.setBizType(ManualBizTypeEnum.TRANSFER_TO_WITHDRAW.name());
                order.setAmount(withdrawBalance);
                initManualOrder(new Integer(merchantid), order);
                manualOrderService.transferToWithdraw(order);
                count++;
            }
            if(count>0){
                notifyComponent.notifyByAuthority("manual_recharge.audit","您有一条新的资金转换订单待审核！");
            }

            logger.info("[end]资金转换结束...");
        } catch (Throwable e) {
            logger.error("job执行异常.(资金转换)", e);
        }
    }

    private void initManualOrder(Integer merchantId, ManualOrder order) throws ManualOrderException {
        order.setMerchantId(merchantId);
        order.setChannelAccountId(0);
        order.setAmount(yuan2fee(order.getAmount())); //转成分
        order.setMerchantCost(new BigDecimal(0));//转成分
        order.setStatus(OrderStatusEnum.PROCESSING.name());
        order.setAuditStatus(AuditStatusEnum.AUDITING.name());
        order.setCreateTime(new Date());
    }


}
