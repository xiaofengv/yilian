package com.ajl.bfb.upstreamadmin.controller;

import com.ajl.bfb.merchantadmin.common.web.MerchantAdminUserUtils;
import com.ajl.bfb.repo.merchant.model.Merchant;
import com.ajl.bfb.repo.merchant.service.IMerchantService;
import com.hippo.framework.operation.log.LogOperation;
import com.hippo.framework.util.security.BCryptUtils;
import com.hippo.framework.web.ResponseCode;
import com.hippo.framework.web.ResponseResult;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;


@Controller
@RequestMapping("/upstream_admin/setting")
public class UpstreamAdminUserController {

    @Autowired
    private IMerchantService merchantService;

    @RequestMapping("/to_update_pwd")
    public String toUpdatePwd() {
        return "merchant_admin/sys/update_password";
    }

    @RequestMapping("/to_update_secondpwd")
    public String toUpdateSecondPwd() {
        return "merchant_admin/sys/update_second_passwd";
    }

    @RequestMapping("/update_pwd")
    @ResponseBody
    @LogOperation(name = "商户修改密码", module = "商户管理")
    public ResponseResult updatePassword(String oldPwd, String newPwd, HttpServletRequest request) {
        if (StringUtils.isBlank(oldPwd) || StringUtils.isBlank(newPwd)) {
            return new ResponseResult(ResponseCode.FAIL, "请填写旧密码,新密码", "");
        }
        Merchant merchant = MerchantAdminUserUtils.getLoginMerchant(request);
        Merchant oldMerchant = merchantService.findById(merchant.getId());
        boolean checkResult = BCryptUtils.compareBcrypt(oldPwd, oldMerchant.getPassword());
        if (!checkResult) {
            return new ResponseResult(ResponseCode.FAIL, "旧密码有误", "");
        }
        merchantService.updateMerchantPassword(merchant.getId(), newPwd);
        return new ResponseResult(ResponseCode.SUCCESS, "修改成功", "");
    }


    @RequestMapping("/update_secondpwd")
    @ResponseBody
    public ResponseResult updateSecondPassword(String oldPwd, String newPwd, HttpServletRequest request) {
        if (StringUtils.isBlank(oldPwd) || StringUtils.isBlank(newPwd)) {
            return new ResponseResult(ResponseCode.FAIL, "请填写旧密码,新密码", "");
        }
        Merchant merchant = MerchantAdminUserUtils.getLoginMerchant(request);
        Merchant oldMerchant = merchantService.findById(merchant.getId());
        boolean checkResult = BCryptUtils.compareBcrypt(oldPwd, oldMerchant.getSecondPassword());
        if (!checkResult) {
            return new ResponseResult(ResponseCode.FAIL, "旧密码有误", "");
        }
        merchantService.updateSecondPwd(merchant.getId(), newPwd);
        return new ResponseResult(ResponseCode.SUCCESS, "修改成功", "");
    }
}
