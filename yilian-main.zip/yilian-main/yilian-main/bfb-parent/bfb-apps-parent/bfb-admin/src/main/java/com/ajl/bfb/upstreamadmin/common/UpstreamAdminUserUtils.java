package com.ajl.bfb.upstreamadmin.common;

import com.ajl.bfb.merchantadmin.common.web.MerchantAdminSessionKey;
import com.ajl.bfb.repo.merchant.model.Merchant;
import com.ajl.bfb.repo.upstream.entity.UpstreamMerchant;
import com.hippo.framework.auth.admin.model.SysUser;

import javax.servlet.http.HttpServletRequest;


public class UpstreamAdminUserUtils {


    public static void setSessionUser(UpstreamMerchant merchant, HttpServletRequest request) {
        SysUser user = new SysUser();
        user.setUserName(merchant.getMerchantNo());
        user.setId(merchant.getId());
        request.getSession().setAttribute(MerchantAdminSessionKey.LOGIN_USER, user);
        request.getSession().setAttribute(MerchantAdminSessionKey.LOGIN_UPSTREAM, merchant);
    }

    public static UpstreamMerchant getLoginMerchant(HttpServletRequest request) {
        return (UpstreamMerchant) request.getSession().getAttribute(MerchantAdminSessionKey.LOGIN_UPSTREAM);
    }

    public static String getLoginMerchantNo(HttpServletRequest request) {
        return ((UpstreamMerchant) request.getSession().getAttribute(MerchantAdminSessionKey.LOGIN_UPSTREAM)).getMerchantNo();
    }

}
