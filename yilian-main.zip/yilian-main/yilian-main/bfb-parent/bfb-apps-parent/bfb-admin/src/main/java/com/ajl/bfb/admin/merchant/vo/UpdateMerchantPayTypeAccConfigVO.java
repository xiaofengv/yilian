package com.ajl.bfb.admin.merchant.vo;

import java.util.List;


public class UpdateMerchantPayTypeAccConfigVO {

    private Integer merchantId;
    private String payTypeCode;
    private List<Integer> accountIdList;

    public Integer getMerchantId() {
        return merchantId;
    }

    public void setMerchantId(Integer merchantId) {
        this.merchantId = merchantId;
    }

    public String getPayTypeCode() {
        return payTypeCode;
    }

    public void setPayTypeCode(String payTypeCode) {
        this.payTypeCode = payTypeCode;
    }

    public List<Integer> getAccountIdList() {
        return accountIdList;
    }

    public void setAccountIdList(List<Integer> accountIdList) {
        this.accountIdList = accountIdList;
    }
}
