package com.ajl.bfb.admin.channelpaytype.controller;

import com.ajl.bfb.admin.channel.util.ChannelViewUtils;
import com.ajl.bfb.admin.channel.vo.ChannelVO;
import com.ajl.bfb.admin.channelpaytype.vo.ChannelPayTypeVO;
import com.ajl.bfb.core.constants.PaymentTypeEnum;
import com.ajl.bfb.core.constants.RateTypeEnum;
import com.ajl.bfb.core.constants.ReadyStatusEnum;
import com.ajl.bfb.repo.channel.ChannelException;
import com.ajl.bfb.repo.channel.model.Channel;
import com.ajl.bfb.repo.channel.model.ChannelAccount;
import com.ajl.bfb.repo.channel.model.ChannelPayType;
import com.ajl.bfb.repo.channel.model.ChannelQuery;
import com.ajl.bfb.repo.channel.service.IChannelAccPayTypeService;
import com.ajl.bfb.repo.channel.service.IChannelAccountService;
import com.ajl.bfb.repo.channel.service.IChannelPayTypeService;
import com.ajl.bfb.repo.channel.service.IChannelService;
import com.ajl.bfb.repo.payment.model.PayType;
import com.ajl.bfb.repo.payment.service.IPayTypeService;
import com.hippo.framework.auth.admin.OperationAuth;
import com.hippo.framework.web.ResponseCode;
import com.hippo.framework.web.ResponseResult;
import org.apache.commons.lang3.EnumUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;


@Controller
@RequestMapping(value="/admin/channel_pay_type")
public class ChannelPayTypeController {

    @Autowired
    private IChannelPayTypeService channelPayTypeService;
    @Autowired
    private IChannelService channelService;
    @Autowired
    private IPayTypeService payTypeService;
    @Autowired
    private IChannelAccountService channelAccountService;
    @Autowired
    private IChannelAccPayTypeService channelAccPayTypeService;

    @RequestMapping(value="/list")
    @OperationAuth(name = "收款费率管理", authCode = "channel.collectionRateManagement", group = "通道管理")
    public String list(Model model) {

        //查询所有上游渠道
        ChannelQuery channelQuery = new ChannelQuery();
        channelQuery.setStatus("ON");
        List<Channel> channels = channelService.getAllChannelWithPayType(channelQuery);
        List<ChannelVO> channelVOS = ChannelViewUtils.toVO(channels);


        List<PayType> allPayTypes = payTypeService.getAll();
        Map<String, String> payTypeMap = allPayTypes.stream().collect(Collectors.toMap(PayType::getCode, p -> p.getName()));

        Map<String, String> rateTypeMap = Arrays.stream(RateTypeEnum.values()).collect(Collectors.toMap(RateTypeEnum::name, r -> r.getViewDesc()));
        model.addAttribute("channels", channelVOS);
        model.addAttribute("payTypeMap", payTypeMap);
        model.addAttribute("rateTypeMap", rateTypeMap);
        return "/admin/channel_pay_type/list";
    }

    /**
     * 新增payType ,
     * 1.要给每个渠道加上
     * 2.给每个渠道的收款号加上
     * 处理新增加payType
     * @return
     */
    @RequestMapping(value="/sync_pay_type")
    @ResponseBody
    public ResponseResult syncPayType() {
        List<Channel> channels = channelService.getAllChannelWithPayType(new ChannelQuery());
        List<PayType> allPayTypes = payTypeService.getAll();
        int channelPayTypeCount = 0;
        int channelAccPayTypeCount = 0;
        for (Channel channel : channels) {
            Map<String, ChannelPayType> payTypeMap = channel.getChannelPayTypeList().stream()
                    .collect(Collectors.toMap(ChannelPayType::getPayTypeCode, p -> p));
            for (PayType payType : allPayTypes) {
                if (payTypeMap.get(payType.getCode()) == null) {//以前没记录。新增
                    channelPayTypeService.save(channel.getId(), PaymentTypeEnum.valueOf(payType.getCode()));
                    channelPayTypeCount++;
                }
            }
            //处理渠道账号
            List<ChannelAccount> channelAccounts = channelAccountService.findByChannelId(channel.getId());
            for (ChannelAccount account : channelAccounts) {
                int cnt = channelAccPayTypeService.initAccPayType(account.getId());
                channelAccPayTypeCount += cnt;
            }
        }
        return new ResponseResult(ResponseCode.SUCCESS,
                String.format("同步成功.新增渠道支付方式记录%s条,渠道账号支付方法记录%s条", channelPayTypeCount,channelAccPayTypeCount ) , "");
    }

    @RequestMapping(value="/turn_on/{id}")
    @ResponseBody
    public ResponseResult turnOn(@PathVariable("id")int id) {
        try {
            channelPayTypeService.updateStatus(id, ReadyStatusEnum.ON);
        } catch (ChannelException e) {
            return new ResponseResult(ResponseCode.FAIL, "修改失败:" + e.getMessage(), "");
        }
        return new ResponseResult(ResponseCode.SUCCESS, "修改成功", "");
    }

    @RequestMapping(value="/turn_off/{id}")
    @ResponseBody
    public ResponseResult turnOff(@PathVariable("id")int id) {
        try {
            channelPayTypeService.updateStatus(id, ReadyStatusEnum.OFF);
        } catch (ChannelException e) {
            return new ResponseResult(ResponseCode.FAIL, "修改失败:" + e.getMessage(), "");
        }
        return new ResponseResult(ResponseCode.SUCCESS, "修改成功", "");
    }

    @RequestMapping(value="/switch_status/{id}")
    @ResponseBody
    @OperationAuth(name = "通道支付方式开关", authCode = "channel.channelPaymentSwitch", group = "通道管理")
    public ResponseResult switchStatus(@PathVariable("id")int channelPayTypeId,@RequestBody String status) {
        try {
            if(EnumUtils.isValidEnum(ReadyStatusEnum.class,status)){
                channelPayTypeService.updateStatus(channelPayTypeId, ReadyStatusEnum.valueOf(status));
            }else{
                throw new ChannelException("状态不存在!");
            }
        } catch (ChannelException e) {
            return new ResponseResult(ResponseCode.FAIL, "修改失败:" + e.getMessage(), "");
        }
        return new ResponseResult(ResponseCode.SUCCESS, "修改成功", "");
    }

    @RequestMapping(value="/update")
    @ResponseBody
    @OperationAuth(name = "修改通道费率", authCode = "channel.updateChannelRate", group = "通道管理")
    public ResponseResult update( ChannelPayTypeVO type) {
        channelPayTypeService.update(type.getId(), type.getMinAmount(), type.getMaxAmount(), type.getChannelRate(),type.getChannelCode());
        return new ResponseResult(ResponseCode.SUCCESS, "修改成功", "");
    }

}
