package com.ajl.bfb.admin.common.web;

import com.hippo.framework.auth.admin.model.SysUser;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;


public class AdminUserUtils {

    private static final List<HttpSession> ALL_SESSIONS = new CopyOnWriteArrayList<>();

    public static List<HttpSession> getAllSessions() {
        return ALL_SESSIONS;
    }

    public static SysUser getCurrentLoginUser(HttpServletRequest request) {
        return getCurrentLoginUser(request.getSession());
    }

    public  static boolean isAlipayAgent(HttpServletRequest request) {
        Object isAgent = request.getSession().getAttribute("isAgent");
        if (isAgent != null && Boolean.valueOf(isAgent.toString())) {
            return true;
        }
        return false;
    }

    private static SysUser getCurrentLoginUser(HttpSession session) {
        return (SysUser) session.getAttribute(AdminSessionKey.LOGIN_USER);
    }


    public synchronized static void  kickOnlineUser(HttpServletRequest request, SysUser sysUser) {
        String id = request.getSession().getId();

        for (HttpSession session : ALL_SESSIONS) {
            SysUser user = getCurrentLoginUser(session);
            if (user != null && user.getUserName().equals(sysUser.getUserName())) {
                session.invalidate();
            }
        }
        ALL_SESSIONS.add(request.getSession());
    }

    public synchronized static void onSessionDestroy(HttpSession sessiona) {
        String id = sessiona.getId();
        List<HttpSession> sessions = new ArrayList<>(ALL_SESSIONS);
        for (HttpSession session : sessions) {
            if (session.getId().equals(id)) {
                ALL_SESSIONS.remove(session);
            }
        }
    }

}
