package com.ajl.bfb.admin.merchant.controller;

import com.ajl.bfb.repo.merchant.model.Merchant;
import com.ajl.bfb.repo.merchant.model.MerchantAccount;
import com.ajl.bfb.repo.merchant.model.MerchantAccountDetail;
import com.ajl.bfb.repo.merchant.service.IMerchantAccountService;
import com.ajl.bfb.repo.merchant.service.IMerchantService;
import com.hippo.framework.auth.admin.OperationAuth;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;


@Controller
@RequestMapping("/admin/merchant_acc")
public class MerchantAccountController {

    @Autowired
    private IMerchantAccountService merchantAccountService;
    @Autowired
    private IMerchantService merchantService;

    @RequestMapping(value="/detail/{merchantId}")
    @OperationAuth(name = "商户资金详情", authCode = "merchant.queryFund", group = "商户管理")
    public String detail(@PathVariable("merchantId")int merchantId, Model model) {
        MerchantAccountDetail mchAcc = merchantAccountService.getMerchantAccountDetail(merchantId);
        Merchant merchant = merchantService.findById(merchantId);
        model.addAttribute("mchAcc", mchAcc);
        model.addAttribute("merchant", merchant);

        MerchantAccount acc = merchantAccountService.getByMerchantId(merchant.getId());



        long income = acc.getIncomeAmountTotal()+acc.getManualIncomeAmounTotal();
        model.addAttribute("income", income);
        long incomeCost = acc.getPaymentCostTotal()+acc.getManualIncomeCostTotal();
        model.addAttribute("incomeCost", incomeCost);


        long recharge = acc.getRechargeAmountTotal();
        model.addAttribute("recharge", recharge);
        long rechargeCost = acc.getRechargeCostTotal();
        model.addAttribute("rechargeCost", rechargeCost);


        long transfer = acc.getTransferAmountTotal();
        model.addAttribute("transfer", transfer);
        long transferCost = acc.getTransferCostTotal();
        model.addAttribute("transferCost", transferCost);


        long withdraw = acc.getWithdrawAmountTotal()+acc.getManualWithdrawAmountTotal();
        model.addAttribute("withdraw", withdraw);
        long withdrawCost = acc.getManualWithdrawCostTotal()+acc.getWithdrawCostTotal();
        model.addAttribute("withdrawCost", withdrawCost);


        long proxcyPayment = acc.getProxcyPaymentAmountTotal();
        model.addAttribute("proxcyPayment", proxcyPayment);
        long proxcyPaymentCost = acc.getProxcyPaymentCostTotal();
        model.addAttribute("proxcyPaymentCost", proxcyPaymentCost);



        long withdrawBalance =  merchantAccountService.getMerchantWithdrawBalance(merchant.getId());
        model.addAttribute("withdrawBalance", withdrawBalance);

        long proxcyPaymentBalance = merchantAccountService.getMerchantProxcyPaymentBalance(merchant.getId());
        model.addAttribute("proxcyPaymentBalance", proxcyPaymentBalance);

        return "/admin/merchant/merchant_acc_detail";
    }

    @RequestMapping(value="/agent_detail/{merchantId}")
    @OperationAuth(name = "代理商资金详情", authCode = "agent.queryFund", group = "代理商管理")
    public String agentDetail(@PathVariable("merchantId")int merchantId, Model model) {
        detail(merchantId, model);
        return "/admin/agent/agent_acc_detail";
    }
}
