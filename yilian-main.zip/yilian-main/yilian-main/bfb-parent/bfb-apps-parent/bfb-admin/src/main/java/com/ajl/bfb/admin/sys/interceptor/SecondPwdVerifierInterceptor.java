package com.ajl.bfb.admin.sys.interceptor;



import com.ajl.bfb.admin.common.web.AdminUserUtils;
import com.ajl.bfb.itg.config.ItgExceptionHandlerAdvice;
import com.ajl.bfb.admin.sys.exception.SecondPwdVerifierException;
import com.ajl.bfb.repo.merchant.service.IMerchantService;
import com.hippo.framework.auth.admin.model.SysUser;
import com.hippo.framework.util.security.BCryptUtils;
import com.hippo.framework.util.validation.AssertUtils;
import com.hippo.framework.web.util.HttpRequestUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@Component
public class SecondPwdVerifierInterceptor extends HandlerInterceptorAdapter{
    private static final String SECOND_PWD_KEY="_secondPasswordVerifier";

    @Autowired
    IMerchantService merchantService;

    public boolean preHandle(HttpServletRequest request,
                             HttpServletResponse response, Object handler) throws Exception {
        try{
            String secondPwd = request.getParameter(SECOND_PWD_KEY);
            AssertUtils.objectNotNull(secondPwd,"请输入二次密码!");
            SysUser sysUser = AdminUserUtils.getCurrentLoginUser(request);
            Assert.isTrue(BCryptUtils.compareBcrypt(secondPwd, sysUser.getSecondPassword()),"二次密码错误！");
            return true;
        }catch (Exception e){
            request.setAttribute(ItgExceptionHandlerAdvice.EXCEPTION_KEY,new SecondPwdVerifierException("二次密码错误！"));
            if(HttpRequestUtils.isAjaxForSpringMvc(request,handler)){
                request.getRequestDispatcher("/admin/error/ajax-http500").forward(request,response);
            }else{
                request.getRequestDispatcher("/admin/error/http500").forward(request,response);
            }
            return false;
        }
    }

}