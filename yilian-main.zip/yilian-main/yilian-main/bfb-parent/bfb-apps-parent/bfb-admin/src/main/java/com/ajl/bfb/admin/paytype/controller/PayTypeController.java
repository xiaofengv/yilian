package com.ajl.bfb.admin.paytype.controller;

import com.ajl.bfb.admin.paytype.vo.PayTypeVO;
import com.ajl.bfb.admin.paytype.vo.UpdatePayTypeVO;
import com.ajl.bfb.core.constants.PaymentTypeEnum;
import com.ajl.bfb.core.constants.RateTypeEnum;
import com.ajl.bfb.core.util.RateUtils;
import com.ajl.bfb.repo.payment.model.PayType;
import com.ajl.bfb.repo.payment.service.IPayTypeService;
import com.hippo.framework.auth.admin.OperationAuth;
import com.hippo.framework.core.enums.SwitchEnum;
import com.hippo.framework.operation.log.LogOperation;
import com.hippo.framework.util.validation.ValidationUtils;
import com.hippo.framework.web.ResponseCode;
import com.hippo.framework.web.ResponseResult;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;


@Controller
@RequestMapping(value="/admin/global_pay_type")
public class PayTypeController {

    @Autowired
    private IPayTypeService payTypeService;

    @RequestMapping(value="/setting")
    @OperationAuth(name = "系统设置", authCode = "system_setting.to_update", group = "系统设置")
    public String list(Model model) {
        List<PayType> all = payTypeService.getAll();

        List<PayTypeVO> vos = new ArrayList<>();
        for (PayType payType : all) {
            PayTypeVO vo = new PayTypeVO();
            BeanUtils.copyProperties(payType, vo);


            vo.setDefaultRatePercent(RateUtils.rate2percent(vo.getDefaultRate()));
            vo.setDefaultMerchantRatePercent(RateUtils.rate2percent(vo.getMerchantDefaultRate()));
            vos.add(vo);
        }
        Map<String, String> rateTypeMap = Arrays.stream(RateTypeEnum.values()).collect(Collectors.toMap(RateTypeEnum::name, r -> r.getViewDesc()));
        model.addAttribute("rateTypeMap", rateTypeMap);
        model.addAttribute("allPayTypes", vos);
        return "/admin/system_config/pay_type_setting";
    }

    @RequestMapping(value="/update_default_rate")
    @ResponseBody
    @LogOperation(name = "全局默认费率设置",module = "系统参数设置")
    public ResponseResult updateDefaultRate(UpdatePayTypeVO updatePayType) {
        String error = ValidationUtils.validate(updatePayType);
        if (error != null) {
            return new ResponseResult(ResponseCode.FAIL, "修改失败:" + error, null);
        }
        payTypeService.update(PaymentTypeEnum.valueOf(updatePayType.getPayTypeCode()),
                RateUtils.percent2rate(updatePayType.getRate()),RateUtils.percent2rate(updatePayType.getMerchantRate()));
        return new ResponseResult(ResponseCode.SUCCESS, "修改成功", null);
    }

    @RequestMapping(value="/turn_on/{payTypeCode}")
    @ResponseBody
    public ResponseResult turnOn(@PathVariable("payTypeCode")String payTypeCode) {
        payTypeService.updateStatus(PaymentTypeEnum.valueOf(payTypeCode), SwitchEnum.ON);
        return new ResponseResult(ResponseCode.SUCCESS, "修改成功", null);
    }

    @RequestMapping(value="/turn_off/{payTypeCode}")
    @ResponseBody
    public ResponseResult turnOff(@PathVariable("payTypeCode")String payTypeCode) {
        payTypeService.updateStatus(PaymentTypeEnum.valueOf(payTypeCode), SwitchEnum.OFF);
        return new ResponseResult(ResponseCode.SUCCESS, "修改成功", null);
    }
}
