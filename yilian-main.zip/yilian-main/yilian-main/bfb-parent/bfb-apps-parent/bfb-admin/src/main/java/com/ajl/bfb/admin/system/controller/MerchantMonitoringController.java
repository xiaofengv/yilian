package com.ajl.bfb.admin.system.controller;

import com.ajl.bfb.admin.channel.util.ChannelViewUtils;
import com.ajl.bfb.admin.channel.vo.ChannelVO;
import com.ajl.bfb.admin.merchant.vo.MerchantVO;
import com.ajl.bfb.admin.paytype.vo.PayTypeVO;
import com.ajl.bfb.admin.system.vo.QueryMonitoringOrderParamVO;
import com.ajl.bfb.core.constants.*;
import com.ajl.bfb.core.lock.PaymentOrderLock;
import com.ajl.bfb.core.util.MoneyUtils;
import com.ajl.bfb.core.util.RateUtils;
import com.ajl.bfb.itg.util.ZipUtils;
import com.ajl.bfb.repo.channel.model.Channel;
import com.ajl.bfb.repo.channel.model.ChannelAccount;
import com.ajl.bfb.repo.channel.model.ChannelQuery;
import com.ajl.bfb.repo.channel.model.MerchantChannelAccount;
import com.ajl.bfb.repo.channel.service.IChannelAccountService;
import com.ajl.bfb.repo.channel.service.IChannelService;
import com.ajl.bfb.repo.channel.service.IMerchantChannelAccService;
import com.ajl.bfb.repo.merchant.MerchantException;
import com.ajl.bfb.repo.merchant.model.Merchant;
import com.ajl.bfb.repo.merchant.model.MerchantFindParam;
import com.ajl.bfb.repo.merchant.service.IAgentService;
import com.ajl.bfb.repo.merchant.service.IMerchantService;
import com.ajl.bfb.repo.payment.model.PayType;
import com.ajl.bfb.repo.payment.service.IPayTypeService;
import com.ajl.bfb.repo.stat.model.OrderStat;
import com.ajl.bfb.repo.system.model.MonitoringPaymentOrder;
import com.ajl.bfb.repo.system.service.IMonitoringPaymentOrderService;
import com.github.pagehelper.PageInfo;
import com.hippo.framework.auth.admin.OperationAuth;
import com.hippo.framework.core.enums.SwitchEnum;
import com.hippo.framework.operation.log.LogOperation;
import com.hippo.framework.util.DateUtils;
import com.hippo.framework.web.ResponseCode;
import com.hippo.framework.web.ResponseResult;
import com.icexls.IceExcel;
import com.icexls.IceExcelConfig;
import com.icexls.NumberType;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.util.*;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/admin/system/merchant")
public class MerchantMonitoringController {

    @Autowired
    private IMerchantService merchantService;
    @Autowired
    private IMerchantChannelAccService merchantChannelAccService;
    @Autowired
    private IChannelService channelService;
    @Autowired
    private IAgentService agentService;

    @Autowired
    private IChannelAccountService channelAccountService;
    @Autowired
    private IMonitoringPaymentOrderService monitoringPaymentOrderService;
    @Autowired
    private IPayTypeService payTypeService;

    @Autowired
    private PaymentOrderLock paymentOrderLock;
    @Value("${export.alipayment.order}")
    private String exportPath;

    @RequestMapping(value="/merchant")
    @OperationAuth(name = "商户管理", authCode = "merchant.admin", group = "商户管理")
    public String list(Model model, MerchantFindParam findParam) {
        if (findParam == null) {
            findParam = new MerchantFindParam();
        }
        if (findParam.getUserType() == null) {
            findParam.setUserType(MerchantUserTypeEnum.MERCHANT);
        }
        PageInfo<Merchant> page = merchantService.findPage(findParam);

        List<Channel> channels = channelService.findChannels(new ChannelQuery());
        Map<Integer, Channel> channelMap = channels.stream().collect(Collectors.toMap(Channel::getId, c -> c));


        List<Merchant> agentList = agentService.findAll();

        Map<Integer, Merchant> agentMap = agentList.stream().collect(Collectors.toMap(Merchant::getId, m -> m));

        List vos = new ArrayList<>();

        for (Merchant merchant : page.getList()) {
            List<MerchantChannelAccount> merchantChannelAccounts = merchantChannelAccService.findMerchantChannelAccounts(merchant.getId(), null);
            MerchantVO vo = new MerchantVO();
            BeanUtils.copyProperties(merchant, vo);
            if (AccountModeEnum.valueOf(merchant.getPayAccountMode()) == AccountModeEnum.AUTO) {
                vo.setPaymentAccListStr("无");
            } else {
                vo.setPaymentAccListStr(transformStr(merchantChannelAccounts, channelMap, BizTypeEnum.PAYMENT));
            }
            if (AccountModeEnum.valueOf(merchant.getWithdrawAccountMode()) == AccountModeEnum.AUTO) {
                vo.setWithdrawAccListStr("无");
            } else {
                vo.setWithdrawAccListStr(transformStr(merchantChannelAccounts, channelMap, BizTypeEnum.WITHDRAW));
            }
            if (merchant.getAgentid() != null) {
                vo.setAgentName(agentMap.get(merchant.getAgentid()).getMerchantName());
            }
            if(merchant.getMonitorStatus()==null){
                vo.setMonitorStatus("OFF");
            }
            vos.add(vo);
        }
        page.setList(vos);
        model.addAttribute("pageInfo", page);
        return "/admin/system/merchant/list";
    }


    @RequestMapping(value="/turn_on/{id}")
    @ResponseBody
    @LogOperation(name = "开启监控",module = "商户管理")
    public ResponseResult turnOn(@PathVariable("id")int id) throws MerchantException {
        merchantService.updateMonitorStatus(id, SwitchEnum.ON);
        return new ResponseResult(ResponseCode.SUCCESS, "修改成功", null);
    }

    @RequestMapping(value="/turn_off/{id}")
    @ResponseBody
    @LogOperation(name = "关闭监控",module = "商户管理")
    public ResponseResult turnOff(@PathVariable("id")int id) throws MerchantException {
        merchantService.updateMonitorStatus(id, SwitchEnum.OFF);
        return new ResponseResult(ResponseCode.SUCCESS, "修改成功", null);
    }


    @RequestMapping(value="/toinsertscript")
    @OperationAuth(name = "插入脚本", authCode = "merchant.admin", group = "插入脚本")
    public String toInsertScript(Model model) {

        return "/admin/system/merchant/list";
    }


    @RequestMapping("/monitoringlist")
    @OperationAuth(name = "支付订单管理", authCode = "payment_order.list", group = "支付订单管理")
    public String monitoringList(Model model, QueryMonitoringOrderParamVO queryOrderParam) {
        if (queryOrderParam.getStartTime() == null) {
            queryOrderParam.setStartTime(DateUtils.plusDays(DateUtils.getDateStart(new Date()), -2));
            queryOrderParam.setEndTime(DateUtils.getDateEnd(new Date()));
        }
        PageInfo<MonitoringPaymentOrder> page = monitoringPaymentOrderService.findPage(queryOrderParam);
        OrderStat orderTotal = monitoringPaymentOrderService.queryOrderTotal(queryOrderParam);
        model.addAttribute("orderTotal", orderTotal);

        List<Channel> channels = channelService.findChannels(new ChannelQuery());
        model.addAttribute("channels", channels);
        model.addAttribute("paymentTypeList", PaymentTypeEnum.values());
        model.addAttribute("orderStatusList", OrderStatusEnum.values());
        model.addAttribute("queryParam", queryOrderParam);
        model.addAttribute("pageInfo", page);
        model.addAttribute("notifyStatusList", NotifyStatusEnum.values());

        return "admin/system/merchant/monitoringlist";
    }

    @RequestMapping(value="/paytypelist")
    @OperationAuth(name = "系统设置", authCode = "system_setting.to_update", group = "系统设置")
    public String list(Model model) {
        List<PayType> all = payTypeService.getAll();

        List<PayTypeVO> vos = new ArrayList<>();
        for (PayType payType : all) {
            PayTypeVO vo = new PayTypeVO();
            BeanUtils.copyProperties(payType, vo);


            vo.setDefaultRatePercent(RateUtils.rate2percent(vo.getDefaultRate()));
            vo.setDefaultMerchantRatePercent(RateUtils.rate2percent(vo.getMerchantDefaultRate()));
            if(vo.getMonitoringstatus()==null){
                vo.setMonitoringstatus("");
            }
            vos.add(vo);
        }
        Map<String, String> rateTypeMap = Arrays.stream(RateTypeEnum.values()).collect(Collectors.toMap(RateTypeEnum::name, r -> r.getViewDesc()));
        model.addAttribute("rateTypeMap", rateTypeMap);
        model.addAttribute("allPayTypes", vos);
        return "admin/system/merchant/paytypelist";
    }

    @RequestMapping(value="/turn_on_paytype/{payTypeCode}")
    @ResponseBody
    public ResponseResult turnOn(@PathVariable("payTypeCode")String payTypeCode) {
        payTypeService.updateMonitoringStatus(PaymentTypeEnum.valueOf(payTypeCode), SwitchEnum.ON);
        return new ResponseResult(ResponseCode.SUCCESS, "修改成功", null);
    }

    @RequestMapping(value="/turn_off_paytype/{payTypeCode}")
    @ResponseBody
    public ResponseResult turnOff(@PathVariable("payTypeCode")String payTypeCode) {
        payTypeService.updateMonitoringStatus(PaymentTypeEnum.valueOf(payTypeCode), SwitchEnum.OFF);
        return new ResponseResult(ResponseCode.SUCCESS, "修改成功", null);
    }


    @RequestMapping("/sync_order")
    @ResponseBody
    public ResponseResult syncOrder() throws Exception {
        try {
            monitoringPaymentOrderService.syncMonitoringOrder(null);
            return new ResponseResult(ResponseCode.SUCCESS, "同步成功", null);
        } catch (Exception e) {
            return new ResponseResult(ResponseCode.SUCCESS, "同步失败", null);
        }
    }


    @RequestMapping("/sync_order1")
    @ResponseBody
    public ResponseResult syncOrder1() throws Exception {
        try {
            File file = new File("/home/other");
            String [] strFiles=scandir(file).split("-");
            for (String strings:strFiles){
                monitoringPaymentOrderService.syncMonitoringOrder(strings);
            }
            return new ResponseResult(ResponseCode.SUCCESS, "同步成功", null);
        } catch (Exception e) {
            return new ResponseResult(ResponseCode.SUCCESS, "同步失败", null);
        }
    }

    @RequestMapping("export")
    public String export(QueryMonitoringOrderParamVO queryOrderParam,HttpServletResponse response) throws Exception {
        if (queryOrderParam.getStartTime() == null && queryOrderParam.getEndTime() == null) {
            queryOrderParam.setEndTime(new Date());
            queryOrderParam.setStartTime(DateUtils.plusDays(queryOrderParam.getEndTime(), -7));
        }
        String reqId = System.currentTimeMillis() + "";
        String objId = 999998891 + "";
        try {

            if (!paymentOrderLock.getLock(objId, reqId)) {
                throw new Exception("其他用户正在导出，请稍后再试...");
            }

            if (queryOrderParam.getStartTime() == null && queryOrderParam.getEndTime() == null) {
                throw new RuntimeException("起始时间，结束时间不能为空");
            }

            final int pageSize = 500;
            final int oneSheetRows = 100000;
            String excelExportFilePath =  exportPath + "/" + System.currentTimeMillis();

            List<String> allExcels = new ArrayList<>();
            queryOrderParam.setPageSize(pageSize);
            PageInfo<MonitoringPaymentOrder> page = monitoringPaymentOrderService.findPage(queryOrderParam);
            List<MonitoringPaymentOrder> orders = new ArrayList<>();

            int pages = page.getPages();
            int pageNum = 1;
            for (int i = 0; i < pages; i++) {
                pageNum = i +1;
                QueryMonitoringOrderParamVO qvo = new QueryMonitoringOrderParamVO();
                BeanUtils.copyProperties(queryOrderParam, qvo);
                qvo.setPageNum(pageNum);
                List<MonitoringPaymentOrder> ordersList = monitoringPaymentOrderService.findPage(qvo).getList();
                orders.addAll(ordersList);
                if (orders.size() >= oneSheetRows) {
                    String excelFile = export2excel(orders, excelExportFilePath);
                    allExcels.add(excelFile);
                    orders = new ArrayList<>();
                }
            }
            if (!orders.isEmpty()) {
                String excelFile = export2excel(orders, excelExportFilePath);
                allExcels.add(excelFile);
                orders = new ArrayList<>();
            }
            response.addHeader("Content-Disposition", "attachment;filename=order.zip");
            response.setContentType("application/octet-stream");
            ZipUtils.toZip(excelExportFilePath, response.getOutputStream(), true);
            new File(excelExportFilePath).delete();
        } finally {
            paymentOrderLock.releaseLock(objId, reqId);
        }
        return null;
    }

    private String transformStr(List<MerchantChannelAccount> merchantChannelAccounts, Map<Integer, Channel> channelMap, BizTypeEnum bizType) {
        if (merchantChannelAccounts == null || merchantChannelAccounts.isEmpty()) {
            return "无";
        }
        List<String> list = new ArrayList<>();
        for (MerchantChannelAccount mac : merchantChannelAccounts) {
            if (BizTypeEnum.valueOf(mac.getBizType()) == bizType) {

                list.add(
                        channelMap.get(mac.getChannelAccount().getChannelId()).getName()
                                +"[" + mac.getChannelAccount().getAccount() + "]"
                );
            }
        }
        return StringUtils.join(list, "</br>");
    }


    private String export2excel(List<MonitoringPaymentOrder> orders, String exportFilePath) {
        new File(exportFilePath).mkdirs();
        String xlsFile = exportFilePath + "/" + System.currentTimeMillis() + ".xls";


        String[] title = {"下游","下游号","手机号","设备IP","下游订单号", "平台订单号","上游","上游通道号","支付金额","订单状态","监控时间"};
        String[][] datas = new String[orders .size() + 1][title.length];
        datas[0] = title;
        for (int i = 0; i < orders.size(); i++) {
            int j = i +1;
            MonitoringPaymentOrder vo = orders.get(i);
            Merchant merchant=merchantService.findByMerchantNo(vo.getMerchantNo());
            datas[j][0] = merchant.getMerchantName();
            datas[j][1] = vo.getMerchantNo();
            datas[j][2] = vo.getPhone();
            datas[j][3] = vo.getClientIp();
            datas[j][4] = vo.getMerchantOrderNo();
            datas[j][5] = vo.getPlatformOrderNo();
            ChannelAccount channelAccount=channelAccountService.findChannelAccountByAccount(vo.getAccountNo());
            Channel channel=channelService.findChannelById(channelAccount.getChannelId());
            datas[j][6] =channel.getName();
            datas[j][7] = vo.getAccountNo();
            datas[j][8] = MoneyUtils.fee2yuan(Integer.valueOf(vo.getAmount()))+"";
            datas[j][9] = vo.getStatus();
            datas[j][10] = vo.getMonitoringDate();
        }
        IceExcel iceXls = new IceExcel(xlsFile);
        IceExcelConfig.setSheet(iceXls, "监控数据");
        IceExcelConfig.setNumberType(iceXls, NumberType.STRING);
        iceXls.setData(datas);
        return xlsFile;
    }


    private static String fileString="";
    public static String scandir(File file)
    {
        String fileString="";
        File[] files = file.listFiles();
        for (File f : files)
        {
            if (f.isFile())
            {
                fileString=fileString+f.toString()+"-";
            }
        }
        fileString=fileString.substring(0,fileString.length()-1);
        return fileString;
    }

    @RequestMapping(value="/channel")
    public String channelList(Model model, ChannelQuery channel) {
        channel.setStatus("ON");
        List<Channel> channels = channelService.findChannels(channel);
        List<ChannelVO> channelVOS = ChannelViewUtils.toVO(channels);
        model.addAttribute("channels", channelVOS);
        model.addAttribute("queryParam",channel);
        return "/admin/system/merchant/channelList";
    }

    @RequestMapping(value="/turn_on_channel/{id}")
    @ResponseBody
    public ResponseResult turnOnChannel(@PathVariable("id")int id) throws MerchantException {
        channelService.updateMonitorStatus(id, SwitchEnum.ON.name());
        return new ResponseResult(ResponseCode.SUCCESS, "修改成功", null);
    }

    @RequestMapping(value="/turn_off_channel/{id}")
    @ResponseBody
    public ResponseResult turnOffChannel(@PathVariable("id")int id) throws MerchantException {
        channelService.updateMonitorStatus(id, SwitchEnum.OFF.name());
        return new ResponseResult(ResponseCode.SUCCESS, "修改成功", null);
    }

}