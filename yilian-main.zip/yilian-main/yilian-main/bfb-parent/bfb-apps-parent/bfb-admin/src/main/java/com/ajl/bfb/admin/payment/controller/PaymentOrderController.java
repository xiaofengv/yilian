package com.ajl.bfb.admin.payment.controller;

import com.ajl.bfb.admin.channelaccount.util.ChannelAccountViewUtils;
import com.ajl.bfb.admin.channelaccount.vo.ChannelAccountVO;
import com.ajl.bfb.admin.common.web.AdminUserUtils;
import com.ajl.bfb.admin.notice.component.NotifyComponent;
import com.ajl.bfb.admin.payment.vo.PaymentOrderVO;
import com.ajl.bfb.admin.payment.vo.QueryOrderParamVO;
import com.ajl.bfb.common.payment.model.PaymentCallbackResponse;
import com.ajl.bfb.common.payment.model.QueryPaymentOrderResponse;
import com.ajl.bfb.core.constants.*;
import com.ajl.bfb.core.util.MoneyUtils;
import com.ajl.bfb.pay.payment.IPaymentCallbackProxy;
import com.ajl.bfb.pay.payment.IPaymentFacade;
import com.ajl.bfb.pay.payment.IPaymentMerchantNotifyService;
import com.ajl.bfb.pay.payment.PaymentMerchantNotifyException;
import com.ajl.bfb.pay.payment.model.QueryPaymentOrderParam;
import com.ajl.bfb.repo.channel.model.*;
import com.ajl.bfb.repo.channel.service.IChannelAccPayTypeService;
import com.ajl.bfb.repo.channel.service.IChannelAccountService;
import com.ajl.bfb.repo.channel.service.IChannelService;
import com.ajl.bfb.repo.channel.service.IHolidayService;
import com.ajl.bfb.repo.export.service.IExportService;
import com.ajl.bfb.repo.fund.service.IClearCycleMode;
import com.ajl.bfb.repo.fund.service.IClearCycleModeFactory;
import com.ajl.bfb.repo.merchant.model.Merchant;
import com.ajl.bfb.repo.merchant.model.MerchantFindParam;
import com.ajl.bfb.repo.merchant.model.MerchantPayType;
import com.ajl.bfb.repo.merchant.service.IMerchantPayTypeService;
import com.ajl.bfb.repo.merchant.service.IMerchantService;
import com.ajl.bfb.repo.payment.model.PaymentOrder;
import com.ajl.bfb.repo.payment.service.IPayTypeService;
import com.ajl.bfb.repo.payment.service.IPaymentFailOrderService;
import com.ajl.bfb.repo.payment.service.IPaymentOrderService;
import com.ajl.bfb.repo.payment.service.ITempOrderService;
import com.ajl.bfb.repo.stat.model.OrderStat;
import com.github.pagehelper.PageInfo;
import com.hippo.framework.auth.admin.OperationAuth;
import com.hippo.framework.auth.admin.model.SysUser;
import com.hippo.framework.core.enums.OpenStatusEnum;
import com.hippo.framework.operation.log.LogOperation;
import com.hippo.framework.util.DateUtils;
import com.hippo.framework.util.SnowflakeIdWorker;
import com.hippo.framework.web.ResponseCode;
import com.hippo.framework.web.ResponseResult;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Collectors;


@Controller
@RequestMapping("/admin/payment_order")
public class PaymentOrderController {
    private static Logger logger = LogManager.getLogger(PaymentOrderController.class);
    @Autowired
    private IPaymentOrderService paymentOrderService;
    @Autowired
    private IPaymentFailOrderService paymentFailOrderService;
    @Autowired
    private IMerchantService merchantService;
    @Autowired
    private IChannelService channelService;
    @Autowired
    private IChannelAccountService channelAccountService;
    @Autowired
    private IPaymentFacade paymentFacadeService;
    @Autowired
    private IPaymentCallbackProxy paymentNotifyFacade;
    @Autowired
    private IPaymentMerchantNotifyService paymentMerchantNotifyService;
    @Autowired
    private IPaymentCallbackProxy paymentCallbackProxy;
    @Autowired
    private IExportService paymentOrderExportService;
    @Autowired
    private NotifyComponent notifyComponent;
    @Autowired
    private ITempOrderService tempOrderService;
    @Autowired
    private IMerchantPayTypeService merchantPayTypeService;
    @Autowired
    private IChannelAccPayTypeService channelAccPayTypeService;
    @Autowired
    private SnowflakeIdWorker idWorker;
    @Autowired
    private IClearCycleModeFactory clearCycleModeFactory;
    @Autowired
    private IHolidayService holidayService;
    @Autowired
    private IPayTypeService payTypeService;

    enum TimeType {
        paymentTime,
        orderTime;
    }

    @RequestMapping("/list")
    @OperationAuth(name = "查询支付订单", authCode = "payment_order.query", group = "支付订单管理")
    public String list(Model model, QueryOrderParamVO queryOrderParam, String timeType) {
        if (queryOrderParam.getStartTime() == null) {
            queryOrderParam.setStartTime(DateUtils.plusDays(DateUtils.getDateStart2(new Date()), 0));
            queryOrderParam.setEndTime(DateUtils.getDateEnd2(new Date()));
        }
        if (queryOrderParam.getTimeZone() == TimeZoneEnum.MD) {
            queryOrderParam.setStartTime(org.apache.commons.lang3.time.DateUtils.addHours(queryOrderParam.getStartTime(), -12));
            queryOrderParam.setEndTime(org.apache.commons.lang3.time.DateUtils.addHours(queryOrderParam.getEndTime(), -12));
        }
        queryOrderParam.setPageSize(100);

        if (StringUtils.isBlank(timeType)) {
            timeType = TimeType.orderTime.name();
        }
        QueryOrderParamVO queryOrderParamVO=new QueryOrderParamVO();
        queryOrderParamVO.setPageSize(1000);
        queryOrderParamVO.setStartTime(com.hippo.framework.util.DateUtils.pulusMinutes(new Date(), -1));
        queryOrderParamVO.setEndTime(new Date());
        PageInfo<PaymentOrder> page11 = paymentOrderService.findPage(queryOrderParamVO);


        PageInfo<PaymentOrder> page = paymentOrderService.findPage(queryOrderParam);
        OrderStat orderTotal = paymentOrderService.queryOrderTotal(queryOrderParam);
        model.addAttribute("orderTotal", orderTotal);
        List<Channel> channels = channelService.findChannels(new ChannelQuery());
        List paymentOrderVOS = transformVO(page.getList());

        double successOrder = 0;
        for (int i = 0; i < paymentOrderVOS.size(); i++) {
            PaymentOrderVO paymentOrderVO = (PaymentOrderVO) paymentOrderVOS.get(i);
            if (paymentOrderVO.getOrderStatus().equals(OrderStatusEnum.SUCCESS.name())) {
                successOrder++;
            }
        }
        String successOrderNum = "";
        //除数为0，不计算
        if (paymentOrderVOS.size() == 0) {
            successOrderNum = "0";
        } else {
            successOrderNum = MoneyUtils.yuanToFen(successOrder / paymentOrderVOS.size() + "");
        }
        page.setList(paymentOrderVOS);
        model.addAttribute("channels", channels);
        model.addAttribute("onesize", page11.getList().size());
        model.addAttribute("paymentTypeList", PaymentTypeEnum.values());
        model.addAttribute("orderStatusList", OrderStatusEnum.values());
        model.addAttribute("queryParam", queryOrderParam);
        model.addAttribute("timeType", timeType);
        model.addAttribute("pageInfo", page);
        model.addAttribute("successOrderNum", successOrderNum);
        model.addAttribute("notifyStatusList", NotifyStatusEnum.values());

        return "admin/payment_order/list";
    }


    private void initQueryParam(QueryOrderParamVO queryOrderParam, String timeType) {

        if (StringUtils.isBlank(timeType)) {
            timeType = TimeType.orderTime.name();
        }
        if (queryOrderParam.getStartTime() == null) {
            queryOrderParam.setStartTime(DateUtils.plusDays(DateUtils.getDateStart(new Date()), -3));
            queryOrderParam.setEndTime(DateUtils.getDateEnd(new Date()));
        }
        if (queryOrderParam.getTimeZone() == TimeZoneEnum.MD) {
            queryOrderParam.setStartTime(org.apache.commons.lang3.time.DateUtils.addHours(queryOrderParam.getStartTime(), -12));
            queryOrderParam.setEndTime(org.apache.commons.lang3.time.DateUtils.addHours(queryOrderParam.getEndTime(), -12));
        }

        if (TimeType.valueOf(timeType) == TimeType.paymentTime) {
            queryOrderParam.setStartCallbackTime(queryOrderParam.getStartTime());
            queryOrderParam.setEndCallbackTime(queryOrderParam.getEndTime());
        }
    }


    @RequestMapping("/export")
    @OperationAuth(name = "导出支付订单", authCode = "payment_order.export", group = "支付订单管理")
    public void export1(QueryOrderParamVO queryOrderParam, String timeType, HttpServletResponse response) throws Exception {
        logger.info("支付报表导出开始...");
        initQueryParam(queryOrderParam, timeType);
        PageInfo<PaymentOrder> page = paymentOrderService.findPage(queryOrderParam);
        queryOrderParam.setTotal(page.getTotal());
        long start = System.currentTimeMillis();
        paymentOrderExportService.export(response, queryOrderParam);
        logger.info("支付报表导出结束...共耗时:" + (System.currentTimeMillis() - start) / 1000 + "s");
    }


    @RequestMapping("/fail_detail/{orderId}")
    public String failOrderDetail(@PathVariable("orderId") long orderId, Model model) {
        PaymentOrder order = paymentFailOrderService.findById(orderId);
        List paymentOrderVOS = transformVO(Arrays.asList(order));
        model.addAttribute("order", paymentOrderVOS.get(0));
        return "admin/payment_order/detail";
    }

    @RequestMapping("/detail/{orderId}")
    @OperationAuth(name = "订单详情", authCode = "payment_order.orderDetails", group = "支付订单管理")
    public String orderDetail(@PathVariable("orderId") long orderId, Model model) {
        PaymentOrder order = paymentOrderService.findById(orderId);
        List paymentOrderVOS = transformVO(Arrays.asList(order));
        model.addAttribute("order", paymentOrderVOS.get(0));
        return "admin/payment_order/detail";
    }

    @RequestMapping("/fail_list")
    @OperationAuth(name = "支付订单管理", authCode = "payment_order.list", group = "支付订单管理")
    public String failList(Model model, QueryOrderParamVO queryOrderParam) {

        if (queryOrderParam.getStartTime() == null) {
            queryOrderParam.setStartTime(DateUtils.getDateStart(new Date()));
            queryOrderParam.setEndTime(DateUtils.getDateEnd(new Date()));
        }

        PageInfo<PaymentOrder> page = paymentFailOrderService.findPage(queryOrderParam);

        List<Channel> channels = channelService.findChannels(new ChannelQuery());

        List paymentOrderVOS = transformVO(page.getList());
        page.setList(paymentOrderVOS);

        model.addAttribute("channels", channels);
        model.addAttribute("paymentTypeList", PaymentTypeEnum.values());
        model.addAttribute("orderStatusList", OrderStatusEnum.values());
        model.addAttribute("queryParam", queryOrderParam);
        model.addAttribute("pageInfo", page);
        return "admin/payment_order/fail_list";
    }


    @RequestMapping("/sync_order_status/{orderId}")
    @ResponseBody
    @OperationAuth(name = "同步上游状态", authCode = "payment_order.synchronizedUpstreamState", group = "支付订单管理")
    public ResponseResult syncOrderStatus(@PathVariable("orderId") long orderId) throws Exception {
        PaymentOrder order = paymentOrderService.findById(orderId);
        QueryPaymentOrderParam param = new QueryPaymentOrderParam();
        param.setMerchantNo(order.getMerchantNo());
        param.setMerchantOrderNo(order.getMerchantOrderNo());
        QueryPaymentOrderResponse rsp = paymentFacadeService.query(param);
        PaymentCallbackResponse r = transform(rsp, order.getPlatformOrderNo());
        try {
            paymentNotifyFacade.doCallback(r, true);
            return new ResponseResult(ResponseCode.SUCCESS, String.format("同步成功,订单状态:%s.", rsp.getOrderStatus().getDesc()), null);
        } catch (PaymentMerchantNotifyException e) {
            logger.error("通知下游商户失败", e);
            return new ResponseResult(ResponseCode.SUCCESS, String.format("同步成功,订单状态:%s,通知下游失败.", rsp.getOrderStatus().getDesc()), null);
        }
    }


    @RequestMapping("/update_order_status/{orderId}")
    @ResponseBody
    @OperationAuth(name = "订单状态修改", authCode = "payment_order.update_order_status", group = "支付订单管理")
    @LogOperation(name = "订单状态修改", module = "订单管理")
    public ResponseResult updateOrderStatus(HttpServletRequest request, @PathVariable("orderId") long orderId, String status) throws Exception {
        PaymentOrder order = paymentOrderService.findById(orderId);
        if (!order.getOrderStatus().equals(OrderStatusEnum.PROCESSING.name())) {
            return new ResponseResult(ResponseCode.FAIL, "非处理中订单，不能修改状态！", null);
        }
        PaymentCallbackResponse rsp = new PaymentCallbackResponse();
        rsp.setOrderStatus(OrderStatusEnum.valueOf(status));
        rsp.setPlateformOrderNo(order.getPlatformOrderNo());
        rsp.setOrderDesc("手工修改订单状态为：" + rsp.getOrderStatus().getDesc());
        rsp.setResponseContent("");
        rsp.setTotalFee(order.getAmount());
        try {
            paymentCallbackProxy.doCallback(rsp, true);
            SysUser sysUser = AdminUserUtils.getCurrentLoginUser(request);
            String msg = "账号：【" + sysUser.getUserName() + "】手动更新收款订单：" + order.getPlatformOrderNo() + "状态为成功";
            notifyComponent.notifyByAuthority("user_operation_log.list", msg);
            return new ResponseResult(ResponseCode.SUCCESS, String.format("更新成功,订单状态:%s,通知下游成功.", rsp.getOrderStatus().getDesc()), null);
        } catch (PaymentMerchantNotifyException e) {
            logger.error("通知下游商户失败", e);
            return new ResponseResult(ResponseCode.FAIL, "订单状态更新失败！", null);
        }
    }


    @RequestMapping("/notify_merchant/{platformOrderNo}")
    @ResponseBody
    @OperationAuth(name = "回调下游", authCode = "payment_order.callbackDownstream", group = "支付订单管理")
    public ResponseResult notifyMerchant(@PathVariable("platformOrderNo") String platformOrderNo) {
        try {
            paymentMerchantNotifyService.notify(platformOrderNo);
            return new ResponseResult(ResponseCode.FAIL, "通知成功", null);
        } catch (PaymentMerchantNotifyException e) {
            logger.error("通知失败", e);
            return new ResponseResult(ResponseCode.FAIL, e.getMessage(), null);
        }
    }

    private PaymentCallbackResponse transform(QueryPaymentOrderResponse rsp, String plateformOrderNo) {
        return paymentNotifyFacade.transform(rsp, plateformOrderNo);
    }

    public List<PaymentOrderVO> transformVO(List<PaymentOrder> list) {
        if (list.isEmpty()) {
            return Collections.EMPTY_LIST;
        }

        List<Integer> merchantIds = list.stream().map(PaymentOrder::getMerchantId).distinct().collect(Collectors.toList());
        List<Merchant> mchs = merchantService.findByIds(merchantIds);
        Map<Integer, Merchant> merchantMap = mchs.stream().collect(Collectors.toMap(Merchant::getId, m -> m));


        List<Integer> channelAccIds = list.stream().map(PaymentOrder::getChannelAccountId).distinct().collect(Collectors.toList());
        List<ChannelAccount> channelAccounts = channelAccountService.findByIds(channelAccIds);
        Map<Integer, ChannelAccount> accMap = channelAccounts.stream().collect(Collectors.toMap(ChannelAccount::getId, acc -> acc));


        List<Integer> agentIdList = list.stream().map(PaymentOrder::getAgentid).distinct().collect(Collectors.toList());
        List<Merchant> agentList = merchantService.findByIds(agentIdList);
        Map<Integer, Merchant> agentMap = agentList.stream().collect(Collectors.toMap(Merchant::getId, m -> m));

        List<PaymentOrderVO> voList = new ArrayList<>();
        for (PaymentOrder order : list) {
            PaymentOrderVO vo = new PaymentOrderVO();
            BeanUtils.copyProperties(order, vo);
            vo.setMerchantName(merchantMap.get(order.getMerchantId()).getMerchantName());
            vo.setChannelAccName(accMap.get(order.getChannelAccountId()).getName());
            if (order.getAgentid() != null) {
                vo.setAgentName(agentMap.get(order.getAgentid()).getMerchantName());
            } else {
                vo.setAgentName("");
            }
            voList.add(vo);
        }
        return voList;
    }

    @RequestMapping("/questionList")
    @OperationAuth(name = "查询问题订单", authCode = "payment_order.questionList", group = "支付订单管理")
    public String questionOrder(Model model, QueryOrderParamVO queryOrderParam, String timeType) {
        if (queryOrderParam.getStartTime() == null) {
            queryOrderParam.setStartTime(DateUtils.plusDays(DateUtils.getDateStart2(new Date()), 0));
            queryOrderParam.setEndTime(DateUtils.getDateEnd2(new Date()));
        }
        if (queryOrderParam.getTimeZone() == TimeZoneEnum.MD) {
            queryOrderParam.setStartTime(org.apache.commons.lang3.time.DateUtils.addHours(queryOrderParam.getStartTime(), -12));
            queryOrderParam.setEndTime(org.apache.commons.lang3.time.DateUtils.addHours(queryOrderParam.getEndTime(), -12));
        }
        queryOrderParam.setPageSize(100);
        if (StringUtils.isBlank(timeType)) {
            timeType = TimeType.orderTime.name();
        }
        queryOrderParam.setIsQuestionOrder("Y");
        PageInfo<PaymentOrder> page = paymentOrderService.findPage(queryOrderParam);
        OrderStat orderTotal = paymentOrderService.queryOrderTotal(queryOrderParam);
        model.addAttribute("orderTotal", orderTotal);

        List<Channel> channels = channelService.findChannels(new ChannelQuery());
        List paymentOrderVOS = transformVO(page.getList());

        double successOrder = 0;
        for (int i = 0; i < paymentOrderVOS.size(); i++) {
            PaymentOrderVO paymentOrderVO = (PaymentOrderVO) paymentOrderVOS.get(i);
            if (paymentOrderVO.getOrderStatus().equals(OrderStatusEnum.SUCCESS.name())) {
                successOrder++;
            }
        }

        String successOrderNum = MoneyUtils.yuanToFen(successOrder / paymentOrderVOS.size() + "");
        page.setList(paymentOrderVOS);
        model.addAttribute("channels", channels);
        model.addAttribute("paymentTypeList", PaymentTypeEnum.values());
        model.addAttribute("orderStatusList", OrderStatusEnum.values());
        model.addAttribute("queryParam", queryOrderParam);
        model.addAttribute("timeType", timeType);
        model.addAttribute("pageInfo", page);
        model.addAttribute("successOrderNum", successOrderNum);
        model.addAttribute("notifyStatusList", NotifyStatusEnum.values());

        return "admin/payment_order/question_list";
    }

    @RequestMapping("/updateAmount/{orderNo}")
    @ResponseBody
    @OperationAuth(name = "修改订单金额", authCode = "payment_order.updateAmount", group = "支付订单管理")
    @LogOperation(name = "修改订单金额", module = "订单管理")
    public ResponseResult updateAmount(HttpServletRequest request, @PathVariable("orderNo") String orderNo, String updateAmount) throws Exception {
        PaymentOrder order = paymentOrderService.findByPlatformOrderNo(orderNo);
        if (order == null){
            return new ResponseResult(ResponseCode.FAIL, "订单不存在", null);
        }
        if (!order.getOrderStatus().equals(OrderStatusEnum.PROCESSING.name())) {
            return new ResponseResult(ResponseCode.FAIL, "非处理中订单，不能修改状态！", null);
        }
        Integer amount = order.getAmount();
        Integer newAmount = MoneyUtils.yuan2fee(new BigDecimal(updateAmount)).intValue();
        if (amount.equals(newAmount)) {
            return new ResponseResult(ResponseCode.FAIL, "修改前后金额一致", null);
        }
        order.setOrderAmount(amount);
        order.setAmount(newAmount);
        order.setIsQuestionOrder("Y");
        order.setOrderStatus(OrderStatusEnum.SUCCESS.name());
        order.setOrderStatusDesc("手动修改订单金额");
        //查询下游费率
        MerchantPayType merchantPayType = merchantPayTypeService.getMerchantPayType(order.getMerchantId(), PaymentTypeEnum.valueOf(order.getPayTypeCode()));
        //渠道支付类型
        ChannelAccPayType channelAccPayType = channelAccPayTypeService.findByPaymentType(order.getChannelAccountId(), PaymentTypeEnum.valueOf(order.getPayTypeCode()));
        Merchant merchant = merchantService.findById(order.getMerchantId());
        Channel channel = channelService.findChannelById(order.getChannelId());
        calCost(merchant,channel,order,merchantPayType,channelAccPayType);
        paymentOrderService.manualUpdateOrderAmount(order);
        //入账
        tempOrderService.insertTempChargeOrder(order.getId());
        return new ResponseResult(ResponseCode.SUCCESS, String.format("修改金额成功"),null);
    }

    /**
     * 计算成本
     * @param merchant 商户
     * @param channel 渠道
     * @param paymentOrder 订单
     * @param merchantPayType 商户支付类型
     * @param channelAccPayType 渠道账户收款类型
     */
    private void calCost(Merchant merchant,Channel channel,PaymentOrder paymentOrder,MerchantPayType merchantPayType, ChannelAccPayType channelAccPayType) {
        int merchantRate = merchantPayType.getRate().intValue();
        int merchantDefaultRate = payTypeService.findByCode(PaymentTypeEnum.valueOf(merchantPayType.getPayTypeCode())).getMerchantDefaultRate();
        if (merchantRate <= 0 && merchantDefaultRate <= 0) {
            throw new IllegalArgumentException("商户的费率不能为0:" + merchantPayType.getPayTypeCode());
        }
        if (merchantRate <=0){
            merchantRate = merchantDefaultRate;
        }
        if (channelAccPayType.getRate().intValue() <=0) {
            throw new IllegalArgumentException(String.format("渠道收款号费率不能为0.收款号:%s,支付方式:%s",paymentOrder.getChannelAccount(),paymentOrder.getPayTypeCode()));
        }
        //代理商利润
        int agentCost = 0;
        if (merchant.getAgentid() != null) {
            paymentOrder.setAgentRate(merchantPayType.getAgentRate());
            agentCost = MoneyUtils.calCost(paymentOrder.getAmount(), merchantPayType.getAgentRate());
        }
        //渠道介绍人费用
        int channelIntroducerCost = 0;
        if (channel.getIntroducerId() != null){
            paymentOrder.setChannelIntroducerRate(channelAccPayType.getIntroducerRate());
            channelIntroducerCost = MoneyUtils.calCost(paymentOrder.getAmount(), channelAccPayType.getIntroducerRate());
        }
        //计算商户成本
        int merchantCost = MoneyUtils.calCost(paymentOrder.getAmount(), merchantRate);
        //计算渠道成本
        int channelCost = MoneyUtils.calCost(paymentOrder.getAmount(), channelAccPayType.getRate());
        //计算平台收入
        int platformIncome = merchantCost - channelCost - agentCost - channelIntroducerCost;
        paymentOrder.setPlatformCost(channelCost);
        paymentOrder.setMerchantCost(merchantCost);
        paymentOrder.setPlatformIncome(platformIncome);
        paymentOrder.setAgentCost(agentCost);
        paymentOrder.setChannelIntroducerCost(channelIntroducerCost);
    }

    @RequestMapping(value = "/to_supplementOrder")
    @OperationAuth(name = "补单", authCode = "payment_order.supplementOrder", group = "支付订单管理")
    public String toSupplementOrder(Model model){
        MerchantFindParam merchantFindParam = new MerchantFindParam();
        merchantFindParam.setUserType(MerchantUserTypeEnum.MERCHANT);
        List<Merchant> merchantList = merchantService.findAllMerchant(merchantFindParam);
        model.addAttribute("merchants",merchantList);
        model.addAttribute("payTypeList", PaymentTypeEnum.values());
        List<ChannelAccount> channelAccounts = channelAccountService.findAllChannelAccounts(null);
        List<ChannelAccountVO> channelAccountVOS = toAccountVO(channelAccounts);
        Map<String,List<ChannelAccountVO>> channelVOMap = channelAccountVOS.stream().collect(Collectors.groupingBy(channelAccountVO->channelAccountVO.getChannelName()));
        model.addAttribute("channelVOMap",channelVOMap);
        return "/admin/payment_order/supplementOrder";
    }
    private List<ChannelAccountVO> toAccountVO(List<ChannelAccount> accounts) {

        ChannelQuery channelQuery=new ChannelQuery();
        List<Channel> channels = channelService.findChannels(channelQuery);
        Map<Integer,String> channelMap = channels.stream().collect(Collectors.toMap(Channel::getId,Channel::getName));
        List<ChannelAccountVO> channelAccountVOS = ChannelAccountViewUtils.toVO(accounts);
        for (ChannelAccountVO acc : channelAccountVOS) {
            acc.setChannelName(channelMap.get(acc.getChannelId()));
        }
        return channelAccountVOS;
    }
    @RequestMapping(value = "/supplementOrder")
    @OperationAuth(name = "补单", authCode = "payment_order.supplementOrder", group = "支付订单管理")
    public String supplementOrder(Model model,PaymentOrder order){
        String platformOrderNo = idWorker.nextId() + "";
        order.setPlatformOrderNo(platformOrderNo);
        order.setChannelOrderNo("C"+platformOrderNo);
        order.setMerchantOrderNo("M"+platformOrderNo);
        order.setAmount(MoneyUtils.yuan2fee(order.getAmount()).intValue());
        order.setOrderAmount(0);
        order.setPayUrl("N/A");
        Merchant merchant = merchantService.findById(order.getMerchantId());
        order.setMerchantNo(merchant.getMerchantNo());
        order.setMerchantId(merchant.getId());
        order.setAgentid(merchant.getAgentid());
        ChannelAccount channelAccount = channelAccountService.findById(order.getChannelAccountId());
        Channel channel = channelService.findChannelById(channelAccount.getChannelId());
        order.setChannelId(channel.getId());
        order.setChannelIntroducerId(channel.getIntroducerId());
        order.setChannelAccount(channelAccount.getAccount());
        order.setChannelAccountId(channelAccount.getId());
        order.setChannelCode(channel.getCode());
        order.setChannelTypeCode(PaymentTypeEnum.valueOf(order.getPayTypeCode()).getChannelType());
        order.setOrderStatus(OrderStatusEnum.SUCCESS.name());
        order.setOrderStatusDesc("补单成功");
        order.setOrderTime(new Date());
        order.setCallbackTime(new Date());
        order.setCallbackUrl("N/A");
        order.setClientIp("202.124.47.217");
        order.setNotifyStatus(NotifyStatusEnum.WAIT.name());
        order.setNotifyTimes(0);
        order.setSettleStatus(OpenStatusEnum.N.name());
        order.setClearCycle(channelAccount.getClearCycle());
        order.setChargeStatus(OpenStatusEnum.N.name());
        order.setChannelAckStatus(OpenStatusEnum.N.name());
        order.setLinkid(UUID.randomUUID().toString().replace("-","").toLowerCase());
        order.setIsQuestionOrder("Y");
        //查询下游费率
        MerchantPayType merchantPayType = merchantPayTypeService.getMerchantPayType(order.getMerchantId(), PaymentTypeEnum.valueOf(order.getPayTypeCode()));
        order.setMerchantRate(merchantPayType.getRate());
        //渠道支付类型
        ChannelAccPayType channelAccPayType = channelAccPayTypeService.findByPaymentType(order.getChannelAccountId(), PaymentTypeEnum.valueOf(order.getPayTypeCode()));
        order.setChannelAccRate(channelAccPayType.getRate());
        calCost(merchant,channel,order,merchantPayType,channelAccPayType);
        calPreClearTime(order,channelAccount);
        paymentOrderService.insert(order);
        //入账
        tempOrderService.insertTempChargeOrder(order.getId());
        return list(model,new QueryOrderParamVO(),null);
    }
    private void calPreClearTime(PaymentOrder order,ChannelAccount channelAccount) {
        //商户上面的清账周期没用了。只管上游渠道账号,如果D0满了。自动转T1
        ClearCycleEnum clearCycle = ClearCycleEnum.valueOf(channelAccount.getClearCycle());
        //获得此 账号d0跑了多少。(如果是d0),满了转t1,再根据渠道的t1清算时间等信息，计算出订单的预清算时间
        IClearCycleMode clearCycleMode = clearCycleModeFactory.getClearCycleMode(clearCycle);

        //解析清算 时间 10:10这个格式，分解出小时，分钟
        String clearTime = channelAccount.getPreClearTime();
        String[] arr = clearTime.split(":");
        int hour = Integer.valueOf(arr[0]);//小时
        int minute = Integer.valueOf(arr[1]);//分钟

        //获得节假日 30天内的
        List<Holiday> holidayList = holidayService.findByStartTime(order.getOrderTime(), 30);
        List<Date> holidays = holidayList.stream() .map(Holiday::getHolidayDate).collect(Collectors.toList());
        order.setPreClearTime(clearCycleMode.getPreClearTime(order.getOrderTime(), hour, minute, holidays));
    }

}
