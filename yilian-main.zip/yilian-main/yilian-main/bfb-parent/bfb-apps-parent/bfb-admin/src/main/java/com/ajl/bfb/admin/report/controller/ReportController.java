package com.ajl.bfb.admin.report.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import javax.sql.DataSource;


@Controller
@RequestMapping(value = "/reports")
public class ReportController {

    private static final String REPORT_NAME = "reportName";
    private static final String FILE_FORMAT = "format";
    private static final String DATASOURCE = "datasource";

    private static final String queryStr = "你的sql语句";

    @Autowired
    private DataSource dbSource;


    @GetMapping("/{reportName}")
    public ModelAndView getReportByParam(final ModelMap modelMap,
                                         @PathVariable(REPORT_NAME) final String reportName,
                                         @RequestParam(FILE_FORMAT) final String format) {
        modelMap.put(DATASOURCE, dbSource);
        modelMap.put(FILE_FORMAT, format);
        ModelAndView modelAndView = new ModelAndView(reportName, modelMap);
        return modelAndView;
    }


    @GetMapping("/report/{reportName}")
    public ModelAndView getReport(final ModelMap modelMap,
                                         @PathVariable(REPORT_NAME) final String reportName) {
        modelMap.put(DATASOURCE, dbSource);

        ModelAndView modelAndView = new ModelAndView(reportName, modelMap);
        return modelAndView;
    }


    @GetMapping("/query/{reportName}")
    public ModelAndView getReportByParamAndQuery(final ModelMap modelMap,
                                                 @PathVariable(REPORT_NAME) final String reportName,
                                                 @RequestParam(FILE_FORMAT) final String format, ModelAndView modelAndView) {
        try {

        } catch ( Exception e) {
            e.printStackTrace();
        }
        return modelAndView;
    }
}