package com.ajl.bfb.itg.util;

import com.ajl.bfb.itg.ItgBaseVO;
import com.hippo.framework.util.security.MD5Utils;
import org.apache.commons.codec.binary.Base64;


public class ItgSignUtils {

    private static final String PWD = "gAefyHG2h2GOfUTU";

    public static String base64(String content) {
        try {
            return Base64.encodeBase64String( (content).getBytes() );
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException(e);
        }
    }

    public static String sign(String content)  {

        return MD5Utils.MD5Encode(content + PWD).toUpperCase();
    }

    public static boolean checkSign(ItgBaseVO vo)  {
        if (1 == 1) {
            return true;
        }


        String sign = sign(vo.getNonceStr());
        return vo.getSign().equalsIgnoreCase(sign);
    }
}
