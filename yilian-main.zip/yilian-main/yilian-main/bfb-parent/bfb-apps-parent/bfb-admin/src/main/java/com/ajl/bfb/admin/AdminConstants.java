package com.ajl.bfb.admin;


public final class AdminConstants {

    public static final String LOGIN_URI = "/admin/sys/to-login";

    public static final String NO_PERMISSION_URI = "/admin/common/nopermission";

    public static final String ADMIN_USER = "admin";
}
