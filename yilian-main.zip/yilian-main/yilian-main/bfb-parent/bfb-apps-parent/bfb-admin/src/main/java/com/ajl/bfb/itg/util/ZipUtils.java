package com.ajl.bfb.itg.util;



import org.apache.commons.lang3.time.StopWatch;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.List;
import java.util.logging.Logger;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;


public class ZipUtils {

    private static  final Logger logger = Logger.getLogger(ZipUtils.class.getName());

    private static final int  BUFFER_SIZE = 2 * 1024;


    public static void toZip(String srcDir, OutputStream out, boolean KeepDirStructure)

            throws RuntimeException{

        StopWatch watch = new StopWatch();
        watch.start();
        ZipOutputStream zos = null ;
        try {

            zos = new ZipOutputStream(out);

            File sourceFile = new File(srcDir);

            compress(sourceFile,zos,sourceFile.getName(),KeepDirStructure);

            watch.stop();
            logger.info("压缩完成，耗时：" + watch.getTime() +" ms");

        } catch (Exception e) {

            throw new RuntimeException("zip error from ZipUtils",e);

        }finally{
            if(zos != null){
                try {
                    zos.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }

            }

        }



    }





    public static void toZip(List<File> srcFiles , OutputStream out)throws RuntimeException {

        StopWatch watch = new StopWatch();
        watch.start();

        ZipOutputStream zos = null ;

        try {

            zos = new ZipOutputStream(out);

            for (File srcFile : srcFiles) {

                byte[] buf = new byte[BUFFER_SIZE];

                zos.putNextEntry(new ZipEntry(srcFile.getName()));

                int len;

                FileInputStream in = new FileInputStream(srcFile);

                while ((len = in.read(buf)) != -1){

                    zos.write(buf, 0, len);

                }

                zos.closeEntry();

                in.close();

            }

            watch.stop();

            logger.info("压缩完成，耗时：" + watch.getTime() +" ms");
        } catch (Exception e) {

            throw new RuntimeException("zip error from ZipUtils",e);

        }finally{

            if(zos != null){

                try {

                    zos.close();

                } catch (IOException e) {

                    e.printStackTrace();

                }

            }

        }

    }







    private static void compress(File sourceFile, ZipOutputStream zos, String name,

                                 boolean KeepDirStructure) throws Exception{

        byte[] buf = new byte[BUFFER_SIZE];

        if(sourceFile.isFile()){



            zos.putNextEntry(new ZipEntry(name));



            int len;

            FileInputStream in = new FileInputStream(sourceFile);

            while ((len = in.read(buf)) != -1){

                zos.write(buf, 0, len);

            }



            zos.closeEntry();

            in.close();

        } else {

            File[] listFiles = sourceFile.listFiles();

            if(listFiles == null || listFiles.length == 0){



                if(KeepDirStructure){



                    zos.putNextEntry(new ZipEntry(name + "/"));



                    zos.closeEntry();

                }



            }else {

                for (File file : listFiles) {



                    if (KeepDirStructure) {





                        compress(file, zos, name + "/" + file.getName(),KeepDirStructure);

                    } else {

                        compress(file, zos, file.getName(),KeepDirStructure);

                    }



                }

            }

        }

    }
}