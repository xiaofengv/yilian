package com.ajl.bfb.admin.channelpaytype.util;

import com.ajl.bfb.admin.channelpaytype.vo.ChannelPayTypeVO;
import com.ajl.bfb.core.util.MoneyUtils;
import com.ajl.bfb.core.util.RateUtils;
import com.ajl.bfb.repo.channel.model.ChannelPayType;
import org.springframework.beans.BeanUtils;

import java.util.ArrayList;
import java.util.List;


public class ChannelPayTypeViewUtils {

    public static ChannelPayTypeVO toVO(ChannelPayType payType) {
        ChannelPayTypeVO vo = new ChannelPayTypeVO();
        BeanUtils.copyProperties(payType, vo);
        vo.setChannelRatePercent(RateUtils.rate2percent(payType.getChannelRate()));
        vo.setMinAmountYuan(MoneyUtils.fee2yuan(payType.getMinAmount()));
        vo.setMaxAmountYuan(MoneyUtils.fee2yuan(payType.getMaxAmount()));
        return vo;
    }

    public static List<ChannelPayTypeVO> toVO(List<ChannelPayType> payType) {
        List<ChannelPayTypeVO> vos = new ArrayList<>();
        for (ChannelPayType type : payType) {
            vos.add(toVO(type));
        }
        return vos;
    }
}
