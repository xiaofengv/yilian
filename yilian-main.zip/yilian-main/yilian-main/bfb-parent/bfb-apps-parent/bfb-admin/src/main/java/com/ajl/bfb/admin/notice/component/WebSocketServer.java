package com.ajl.bfb.admin.notice.component;



import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import javax.websocket.*;
import javax.websocket.server.PathParam;
import javax.websocket.server.ServerEndpoint;
import java.io.IOException;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
@ServerEndpoint("/admin/websocket/{userName}")
@Component
public class WebSocketServer {
    private static Logger logger = LogManager.getLogger(WebSocketServer.class);


    private static int onlineCount = 0;


    private static ConcurrentHashMap<String,WebSocketServer> webSocketMap = new ConcurrentHashMap<>();

    private static ConcurrentHashMap<String,Set<String>> userAuthMap = new ConcurrentHashMap<>();


    private Session session;


    	@OnOpen
    	public void onOpen(@PathParam("userName") String userName, Session session) {
            this.session = session;
            webSocketMap.put(userName,this);
            addOnlineCount();
            logger.info("有新连接加入！当前在线人数为" + getOnlineCount());
    	}


    @OnClose
    public void onClose(@PathParam("userName") String userName) {
        webSocketMap.remove(userName);
        subOnlineCount();
        logger.info("有一连接关闭！当前在线人数为" + getOnlineCount());
    }


    @OnMessage
    public void onMessage(@PathParam("userName") String userName,String message, Session session) {
        logger.info("来自客户端的消息:" + message);
        try {
            webSocketMap.get(userName).sendMessage(message);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    @OnError
    public void onError(Session session, Throwable error) {
        logger.error("发生错误");
        error.printStackTrace();
    }


    public void sendMessage(String message) throws IOException {
        this.session.getBasicRemote().sendText(message);

        try {
            Thread.sleep(4000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }



    public static void sendInfo(String message) throws IOException {
        logger.info(message);
        for (WebSocketServer item : webSocketMap.values()) {
            try {
                item.sendMessage(message);
            } catch (IOException e) {
                continue;
            }
        }
    }

    private static synchronized int getOnlineCount() {
        return onlineCount;
    }

    private static synchronized void addOnlineCount() {
        WebSocketServer.onlineCount++;
    }

    private static synchronized void subOnlineCount() {
        WebSocketServer.onlineCount--;
    }

    public static ConcurrentHashMap<String, WebSocketServer> getWebSocketMap() {
        return webSocketMap;
    }


    public static void postRealTimeNotice(Set<String>userNameSet,String msg) throws IOException {

        ConcurrentHashMap<String, WebSocketServer> userMap = getWebSocketMap();
        logger.info("发送在线消息:"+msg);
        logger.info("通知用户名单:"+userNameSet.toString());
        for (Map.Entry<String, WebSocketServer> webSocketServerEntry : userMap.entrySet()) {
            logger.info("当前在线用户:"+webSocketServerEntry.getKey());
            if(userNameSet.contains(webSocketServerEntry.getKey())){
                webSocketServerEntry.getValue().sendMessage(msg);
            }
        }
    }

}
