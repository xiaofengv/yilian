package com.ajl.bfb.upstreamadmin.controller;

import com.ajl.bfb.admin.notice.component.NotifyComponent;
import com.ajl.bfb.core.constants.*;
import com.ajl.bfb.core.util.MoneyUtils;
import com.ajl.bfb.merchantadmin.common.web.MerchantAdminUserUtils;
import com.ajl.bfb.repo.manualorder.ManualOrderException;
import com.ajl.bfb.repo.manualorder.model.ManualOrder;
import com.ajl.bfb.repo.manualorder.service.ManualOrderService;
import com.ajl.bfb.repo.merchant.FundException;
import com.ajl.bfb.repo.merchant.model.Merchant;
import com.ajl.bfb.repo.merchant.model.MerchantAccount;
import com.ajl.bfb.repo.merchant.model.MerchantAccountDetail;
import com.ajl.bfb.repo.merchant.service.IMerchantAccountService;
import com.ajl.bfb.repo.upstream.entity.UpstreamMerchant;
import com.ajl.bfb.upstreamadmin.common.UpstreamAdminUserUtils;
import com.hippo.framework.dictionary.service.IDictionaryService;
import com.hippo.framework.util.validation.ValidationUtils;
import com.hippo.framework.web.ResponseCode;
import com.hippo.framework.web.ResponseResult;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.Date;

import static com.ajl.bfb.core.util.MoneyUtils.fee2yuan;
import static com.ajl.bfb.core.util.MoneyUtils.yuan2fee;


@Controller
@RequestMapping(value="/upstream_admin/merchant_acc")
public class UpstreamAccController {

    @Autowired
    private ManualOrderService manualOrderService;
    @Autowired
    private NotifyComponent notifyComponent;


    @RequestMapping(value="/detail")
    public String detail(HttpServletRequest request,Model model) {
        UpstreamMerchant merchant = UpstreamAdminUserUtils.getLoginMerchant(request);
        model.addAttribute("userType",merchant.getUserType());
        MerchantAccountDetail mchAcc = new MerchantAccountDetail();
        model.addAttribute("mchAcc", mchAcc);
        model.addAttribute("merchant", merchant);
        MerchantAccount acc = new MerchantAccount();

        long income = 0l;
        model.addAttribute("income", income);
        long incomeCost = 0l;
        model.addAttribute("incomeCost", incomeCost);


        long recharge = 0l;
        model.addAttribute("recharge", recharge);
        long rechargeCost = 0l;
        model.addAttribute("rechargeCost", rechargeCost);


        long transfer = 0l;
        model.addAttribute("transfer", transfer);
        long transferCost = 0l;
        model.addAttribute("transferCost", transferCost);


        long withdraw = 0l;
        model.addAttribute("withdraw", withdraw);
        long withdrawCost = 0l;
        model.addAttribute("withdrawCost", withdrawCost);


        long proxcyPayment = 0l;
        model.addAttribute("proxcyPayment", proxcyPayment);
        long proxcyPaymentCost = 0l;
        model.addAttribute("proxcyPaymentCost", proxcyPaymentCost);

        long withdrawBalance = 0;
        model.addAttribute("withdrawBalance", withdrawBalance);

        long proxcyPaymentBalance = 0;
        model.addAttribute("proxcyPaymentBalance", proxcyPaymentBalance);

        return "/upstream_admin/account/merchant_acc_detail";
    }


    @RequestMapping(value="/transfer_to_withdraw")
    public String transferToWithdraw(HttpServletRequest request,Model model) {
        Merchant merchant = MerchantAdminUserUtils.getLoginMerchant(request);

        int costrate = manualOrderService.getMerchantCostRate(merchant.getId(),PaymentTypeEnum.TRANSFER_TO_WITHDRAW);
        model.addAttribute("costrate", MoneyUtils.fee2yuan(costrate));

        MerchantAccountDetail mchAcc = new MerchantAccountDetail();
        model.addAttribute("mchAcc", mchAcc);
        model.addAttribute("merchant", merchant);

        long withdrawBalance = 0l;
        model.addAttribute("withdrawBalance", withdrawBalance);
        return "/upstream_admin/account/transfer_to_withdraw";
    }

    @RequestMapping("/do_transfer_to_withdraw")
    @ResponseBody
    public ResponseResult doTransferToWithdraw(HttpServletRequest request, ManualOrder order, Model model) throws IOException, ManualOrderException, FundException {
        Merchant merchant = MerchantAdminUserUtils.getLoginMerchant(request);

        order.setTarget(TargetTypeEnum.MERCHANT.name());
        order.setBizType(ManualBizTypeEnum.TRANSFER_TO_WITHDRAW.name());
        String error = ValidationUtils.validate(order);
        if(StringUtils.isNotEmpty(error)){
            return new ResponseResult(ResponseCode.FAIL, "创建失败！"+error, null);
        }
        if(order.getAmount().intValue()<0){
            return new ResponseResult(ResponseCode.FAIL, "转换资金要大于0！"+error, null);
        }


        BigDecimal withdrawBalance= fee2yuan(0);
        model.addAttribute("withdrawBalance", withdrawBalance);
        Assert.isTrue(order.getAmount().intValue()<=withdrawBalance.intValue(), String.format("转换资金%s不能大于可提现余额%s",order.getAmount().intValue(),withdrawBalance));

        initManualOrder(request, order);
        manualOrderService.transferToWithdraw(order);


        notifyComponent.notifyByAuthority("manual_recharge.audit","您有一条新的资金转换订单待审核！");
        return new ResponseResult(ResponseCode.SUCCESS, "转换订单创建成功！", null);
    }

    private void initManualOrder(HttpServletRequest request, ManualOrder order) throws ManualOrderException {
        Merchant merchant = MerchantAdminUserUtils.getLoginMerchant(request);
        order.setMerchantId(merchant.getId());
        order.setChannelAccountId(0);
        order.setAmount(yuan2fee(order.getAmount()));
        int merchantCost = manualOrderService.checkMerchantTransferMoney(merchant.getId(),order.getAmount().intValue(), PaymentTypeEnum.TRANSFER_TO_WITHDRAW);
        order.setMerchantCost(new BigDecimal(merchantCost));
        order.setStatus(OrderStatusEnum.PROCESSING.name());
        order.setAuditStatus(AuditStatusEnum.AUDITING.name());
        order.setCreateTime(new Date());
    }



}
