/**
 * 读取cookie key是currentMenuCode, 然后找到 带有currentMenuCode属性的li,把他的样式加上active,
 * 以让他显示成激活状态菜单, 再把父级加上open class 让他展开
 */
$(function(){
    var currentMenuCodeInCookie =  $.cookie('currentMenuCode');
    console.log('currentMenuCodeInCookie::' + currentMenuCodeInCookie);
    if (currentMenuCodeInCookie == null || currentMenuCodeInCookie == '') {
        console.log('cannot found currentMenuCode in cookie');
    }else{
        $("li[currentMenuCode]").each(function(){
            if(currentMenuCodeInCookie == $(this).attr('currentMenuCode')) {
                //增加激活样式
                $(this).addClass('active');

                try {
                    //父节点增加open样式
                    $(this).parent().parent().addClass('open');
                    //父节点增加open样式
                    // $(this).parent().parent().parent().parent().addClass('open');
                    if ($(this).attr("accqu") == '1') {
                        $('#alipay_guma').addClass('open');
                        $('#alipay_account').addClass('open');
                    }
                } catch (e){
                }

            }
        });
    }

});