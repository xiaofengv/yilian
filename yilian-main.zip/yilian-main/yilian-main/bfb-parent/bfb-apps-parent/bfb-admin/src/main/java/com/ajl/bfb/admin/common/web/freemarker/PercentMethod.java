package com.ajl.bfb.admin.common.web.freemarker;

import com.ajl.bfb.core.util.RateUtils;
import freemarker.template.TemplateMethodModelEx;
import freemarker.template.TemplateModelException;

import java.util.List;


public class PercentMethod implements TemplateMethodModelEx {

    @Override
    public Object exec(List arguments) throws TemplateModelException {
        if (arguments == null || arguments.isEmpty() || arguments.get(0) == null) {
            return "";
        }
        int rate = Integer.valueOf(arguments.get(0).toString());
        return RateUtils.rate2percent(rate);
    }
}
