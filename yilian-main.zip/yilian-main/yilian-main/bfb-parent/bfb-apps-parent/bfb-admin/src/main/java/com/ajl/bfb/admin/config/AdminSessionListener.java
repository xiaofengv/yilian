package com.ajl.bfb.admin.config;

import com.ajl.bfb.admin.common.web.AdminUserUtils;

import javax.servlet.annotation.WebListener;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;


@WebListener
public class AdminSessionListener implements HttpSessionListener {


    public synchronized void sessionCreated(HttpSessionEvent arg0) {
    }
    @Override
    public synchronized void sessionDestroyed(HttpSessionEvent arg0) {
        AdminUserUtils.onSessionDestroy(arg0.getSession());
    }

}
