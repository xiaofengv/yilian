package com.ajl.bfb.admin.manualorder.vo;


import com.ajl.bfb.core.constants.AuditStatusEnum;
import com.ajl.bfb.repo.payment.model.TransferPaymentOrder;

import java.math.BigDecimal;


public class TransferPaymentOrderVO extends TransferPaymentOrder {

    private String merchantName;

    private String aliAcc;

    private String aliAccName;


    public String getMerchantName() {
        return merchantName;
    }

    public void setMerchantName(String merchantName) {
        this.merchantName = merchantName;
    }

    public String getAuditStatusStr() {
        return AuditStatusEnum.valueOf(getAuditStatus()).getDesc();
    }

    public String getOrderStatusStr() {
        return TransferPaymentOrder.OrderStatusEnum.valueOf(getOrderStatus()).getDesc();
    }

    private BigDecimal amountYuan;

    private BigDecimal platformCostYuan;

    private BigDecimal transferCostYuan;

    private BigDecimal rechargeCostYuan;


    public BigDecimal getAmountYuan() {
        return amountYuan;
    }

    public void setAmountYuan(BigDecimal amountYuan) {
        this.amountYuan = amountYuan;
    }

    public BigDecimal getPlatformCostYuan() {
        return platformCostYuan;
    }

    public void setPlatformCostYuan(BigDecimal platformCostYuan) {
        this.platformCostYuan = platformCostYuan;
    }

    public BigDecimal getTransferCostYuan() {
        return transferCostYuan;
    }

    public void setTransferCostYuan(BigDecimal transferCostYuan) {
        this.transferCostYuan = transferCostYuan;
    }

    public BigDecimal getRechargeCostYuan() {
        return rechargeCostYuan;
    }

    public void setRechargeCostYuan(BigDecimal rechargeCostYuan) {
        this.rechargeCostYuan = rechargeCostYuan;
    }

    public String getImgFileName(){
        String imgUrl = getConfirmImgUrl();
        return imgUrl.substring(imgUrl.lastIndexOf("/")+1,imgUrl.length());
    }

    public String getAliAcc() {
        return aliAcc;
    }

    public void setAliAcc(String aliAcc) {
        this.aliAcc = aliAcc;
    }

    public String getAliAccName() {
        return aliAccName;
    }

    public void setAliAccName(String aliAccName) {
        this.aliAccName = aliAccName;
    }
}
