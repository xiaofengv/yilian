package com.ajl.bfb.merchantadmin.payment.vo;

import com.ajl.bfb.core.util.IgnoreSign;
import org.hibernate.validator.constraints.NotBlank;

import java.io.Serializable;


public class BaseRequestVO implements Serializable {

    public static final String ORDER_TIME_FORMAT = "yyyyMMddHHmmss";


    @NotBlank(message = "商户号不能为空")
    private String merchantNo;

    @NotBlank(message = "随机字符串不能为空")
    private String nonceStr;


    @IgnoreSign
    private String sign;

    public String getMerchantNo() {
        return merchantNo;
    }

    public void setMerchantNo(String mchId) {
        this.merchantNo = mchId;
    }

    public String getNonceStr() {
        return nonceStr;
    }

    public void setNonceStr(String nonceStr) {
        this.nonceStr = nonceStr;
    }

    public String getSign() {
        return sign;
    }

    public void setSign(String sign) {
        this.sign = sign;
    }
}
