var OfflineWithdrawOrder = {};

    /**
     * @param status
     * @param orderId
     */
    OfflineWithdrawOrder.modifyOrderStatus = function (status,orderId) {
        if (!hippo.validateForm("offlineWithdrawForm")) {
            return;
        }
        var showmsg="";
        if("SUCCESS"==status){
            showmsg="确定通过吗？";
        }else if ("FAIL"==status) {
            showmsg="确定取消吗？";
        }
        var remark = $("#remark").val().trim();
        layer.confirm(
            showmsg,
            {icon: 0, title:'提示'},
            function(index, layero){
                layer.close(index);
                var actionUrl = getWebPath() + "/admin/offline_withdraw/modify_order_status";
                $.ajax({
                    type : "POST", //提交方式
                    url : actionUrl,//路径
                    data : {
                        "withdrawId":orderId,
                        "orderStatus":status,
                        "remark":remark
                    },
                    success : function(result) {//返回数据根据结果进行相应的处理
                        hippo.msg(result.message);
                        if(result.statusCode=="SUCCESS"){
                            setTimeout((function() {
                                window.location.href =getWebPath() + "/admin/offline_withdraw/list";
                            }), 2000);
                        }
                    }
                });
            }
        );
    }

OfflineWithdrawOrder.closeModifyOrderStatusWindow = function () {
    $('.close',window.parent.document).trigger("click");
}

