var IP = {};

$(function () {
    $(".limitMoney").each(function (index, el) {
        hippo.limitMoney(el.id);
    });
});
IP.delIP = function(id){
    var url =  getWebPath() + "/admin/ip/delete/" + id;
    layer.confirm(
        "确定要删除吗?",
        {icon: 0, title:'提示'},
        function(index, layero){
            layer.close(index);
            window.location.href = url;
        }
    );
}
//添加黑白名单
IP.add = function (ip,flag) {
    var url =  getWebPath() + "/admin/ip/addBlacklist";
    var data = {
        "ip":ip,
        "isBlacklist":"Y",
        "isWhitelist":"N"
    }
    if (flag == 1){
        url =  getWebPath() + "/admin/ip/addWhitelist";
        data = {
            "ip":ip,
            "isBlacklist":"N",
            "isWhitelist":"Y"
        }
    }
    $.ajax({
        type : "POST", //提交方式
        url : url,//路径
        data : data,
        success : function(result) {//返回数据根据结果进行相应的处理
            hippo.msg(result.message);
        }
    });
}
IP.synchronizedAddress = function(){
    var id = $('input[type=checkbox]:checked').data("id");
    var actionUrl = getWebPath() + "/admin/ip/synchronizedAddress/" + id;
    $.ajax({
        type : "POST", //提交方式
        url : actionUrl,//路径
        data : {},
        success : function(result) {//返回数据根据结果进行相应的处理
            hippo.msg(result.message);
        }
    });
}
$(function(){
    $('input[type=checkbox]').each(function(){
        $(this).click(function(){
            if($(this).prop('checked')){
                //当前选中，其他取消选中
                $('input[type=checkbox]').prop("checked",false);
                $(this).prop("checked",true);
                var country = $(this).data("country");
                if(country==''){
                    $("#synchronizedAddress").removeClass("disabled");
                }else{
                    $("#synchronizedAddress").addClass("disabled");
                }

            }else{
                $("#synchronizedAddress").addClass("disabled");
            }
        });
    });
});