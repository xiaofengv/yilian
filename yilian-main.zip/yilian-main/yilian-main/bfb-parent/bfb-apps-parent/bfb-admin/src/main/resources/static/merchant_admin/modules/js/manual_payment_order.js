var ManualPaymentOrder = {};

$(function () {
  hippo.limitInteger('amount');
});


ManualPaymentOrder.checkForm = function() {
    return hippo.validateForm('addManualPaymentOrderForm');
}

ManualPaymentOrder.close = function(){
    $('.close',window.parent.document).trigger("click");
}
ManualPaymentOrder.createForm = function () {
    alert("开始提交1");
    if (!ManualPaymentOrder.checkForm()) {
        return;
    }
    alert($("#addManualPaymentOrderForm").innerHTML);
    $("#addManualPaymentOrderForm").submit(function () {
        alert("开始提交");
        $('.close',window.parent.document).trigger("click");
        window.parent.location.href =  window.parent.document.getElementById('searchForm').action;
    });
}


//手工订单新增或更新保存
ManualPaymentOrder.create = function(){
    if (!ManualPaymentOrder.checkForm()) {
        return;
    }

    $("#addManualPaymentOrderForm").ajaxSubmit(function(response) {
        if(response.statusCode=="SUCCESS"){
            $('#errorMsgDiv').hide();
            new $.zui.Messager(response.message, {
                type: 'success' // 定义颜色主题
            }).show();

            window.parent.location.href =  window.parent.document.getElementById('searchForm').action;
        }else{
            hippo.warning(response.message);
        }
    });
}