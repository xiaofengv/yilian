package com.ajl.bfb.admin.channel.vo;

import com.ajl.bfb.admin.channelpaytype.vo.ChannelPayTypeVO;
import com.ajl.bfb.core.util.MoneyUtils;
import com.ajl.bfb.repo.channel.model.Channel;
import lombok.Data;

import java.util.List;

@Data
public class ChannelVO extends Channel {

    private Long incomeTotalMaxYuan;

    private Long dayMaxAmountYuan;

    private Integer cardMaxYuan;



    private List<ChannelPayTypeVO> channelPayTypeVOS;

    public List<ChannelPayTypeVO> getChannelPayTypeVOS() {
        return channelPayTypeVOS;
    }

    public void setChannelPayTypeVOS(List<ChannelPayTypeVO> channelPayTypeVOS) {
        this.channelPayTypeVOS = channelPayTypeVOS;
    }



    public Long getIncomeTotalMaxYuan() {
        return incomeTotalMaxYuan;
    }

    public void setIncomeTotalMaxYuan(Long incomeTotalMaxYuan) {
        this.incomeTotalMaxYuan = incomeTotalMaxYuan;
        setIncomeTotalMax(MoneyUtils.yuan2fee(incomeTotalMaxYuan).longValue());
    }

    public Long getDayMaxAmountYuan() {
        return dayMaxAmountYuan;
    }

    public void setDayMaxAmountYuan(Long dayMaxAmountYuan) {
        this.dayMaxAmountYuan = dayMaxAmountYuan;
        setDayMaxAmount(MoneyUtils.yuan2fee(dayMaxAmountYuan).longValue());
    }

    public Integer getCardMaxYuan() {
        return cardMaxYuan;
    }

    public void setCardMaxYuan(Integer cardMaxYuan) {
        this.cardMaxYuan = cardMaxYuan;
        setCardMax(MoneyUtils.yuan2fee(cardMaxYuan).intValue());
    }

}
