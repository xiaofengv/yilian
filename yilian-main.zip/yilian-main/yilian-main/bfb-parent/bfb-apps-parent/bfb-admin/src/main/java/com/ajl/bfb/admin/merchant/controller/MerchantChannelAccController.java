package com.ajl.bfb.admin.merchant.controller;

import com.ajl.bfb.admin.merchant.vo.UpdateMerchantAccConfigVO;
import com.ajl.bfb.core.constants.BizTypeEnum;
import com.ajl.bfb.core.constants.ReadyStatusEnum;
import com.ajl.bfb.repo.channel.model.Channel;
import com.ajl.bfb.repo.channel.model.ChannelAccount;
import com.ajl.bfb.repo.channel.model.ChannelQuery;
import com.ajl.bfb.repo.channel.model.MerchantChannelAccount;
import com.ajl.bfb.repo.channel.service.IChannelAccountService;
import com.ajl.bfb.repo.channel.service.IChannelService;
import com.ajl.bfb.repo.channel.service.IMerchantChannelAccService;
import com.hippo.framework.auth.admin.OperationAuth;
import com.hippo.framework.web.ResponseCode;
import com.hippo.framework.web.ResponseResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;


@Controller
@RequestMapping("/admin/merchant_channel_acc")
public class MerchantChannelAccController {

    @Autowired
    private IChannelService channelService;
    @Autowired
    private IMerchantChannelAccService merchantChannelAccService;
    @Autowired
    private IChannelAccountService channelAccountService;


    @RequestMapping("/config_payment")
    @OperationAuth(name = "商户管理", authCode = "merchant.admin", group = "商户管理")
    public String configPayment(Model model, int merchantId) {
        return config(model, merchantId, BizTypeEnum.PAYMENT);
    }

    @RequestMapping("/config_withdraw")
    @OperationAuth(name = "商户管理", authCode = "merchant.admin", group = "商户管理")
    public String configWithdraw(Model model, int merchantId) {
        return config(model, merchantId, BizTypeEnum.WITHDRAW);
    }

    public String config(Model model, int merchantId, BizTypeEnum bizType) {

        List<Channel> allChannels = channelService.findChannels(new ChannelQuery());

        List<Channel> channels = new ArrayList<>();
        for (Channel channel : allChannels) {
            List<ChannelAccount> accounts = channelAccountService.findByChannelId(channel.getId());

            List<ChannelAccount> openedAccs = accounts.stream().filter(acc -> (ReadyStatusEnum.valueOf(acc.getStatus()) != ReadyStatusEnum.OFF)).collect(Collectors.toList());
            channel.setChannelAccountList(openedAccs);
            if (!openedAccs.isEmpty()) {
                channels.add(channel);
            }
        }
        List<MerchantChannelAccount> merchantChannelAccounts = merchantChannelAccService.findMerchantChannelAccounts(merchantId, bizType);
        Map<Integer, MerchantChannelAccount> accountMap = merchantChannelAccounts.stream().collect(Collectors.toMap(MerchantChannelAccount::getChannelAccId, acc -> acc));

        model.addAttribute("bizType", bizType);
        model.addAttribute("merchantId", merchantId);
        model.addAttribute("channelList", channels);
        model.addAttribute("merchantAccountMap", accountMap);
        return "/admin/merchant_channel_acc/config";
    }


    @RequestMapping("/update_cfg")
    @ResponseBody
    public ResponseResult updateCfg(Model model,UpdateMerchantAccConfigVO merchantAccConfig) {
        if (merchantAccConfig.getAccountIdList() == null) {
            merchantAccConfig.setAccountIdList(new ArrayList<>());
        }
        merchantChannelAccService.updateMerchantChannelAcc(merchantAccConfig.getMerchantId(), merchantAccConfig.getAccountIdList(),
                BizTypeEnum.valueOf(merchantAccConfig.getBizType()));
        return new ResponseResult(ResponseCode.SUCCESS, "修改成功", "");
    }

}
