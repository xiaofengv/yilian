package com.ajl.bfb.upstreamadmin.controller;

import com.ajl.bfb.merchantadmin.common.web.MerchantAdminSessionKey;
import com.ajl.bfb.repo.upstream.entity.UpstreamMerchant;
import com.ajl.bfb.repo.upstream.service.IUpstreamMerchantService;
import com.ajl.bfb.upstreamadmin.common.UpstreamAdminUserUtils;
import com.hippo.framework.core.enums.SwitchEnum;
import com.hippo.framework.util.security.BCryptUtils;
import com.hippo.framework.util.validation.ValidationUtils;
import com.hippo.framework.web.ResponseCode;
import com.hippo.framework.web.ResponseResult;
import com.hippo.framework.web.vo.LoginUserVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Objects;

@Controller
@RequestMapping("/upstream_admin/sys")
public class UpstreamAdminLoginController {
    @Autowired
    private IUpstreamMerchantService merchantService;

    @Autowired
    private Environment env;

    @RequestMapping("/login")
    @ResponseBody
    public ResponseResult login(Model model, LoginUserVO userVO, HttpServletRequest request, HttpServletResponse response) {
        String validateResult = ValidationUtils.validate(userVO, LoginUserVO.class);
        if (validateResult != null) {
            return new ResponseResult(ResponseCode.FAIL, validateResult, null);
        }

        UpstreamMerchant merchant = merchantService.selectByMerchantNo(userVO.getUserName());

        String profile = env.getProperty("spring.profiles.active");
        /*if (!profile.equals("dev")) {
            if(merchant == null||!GoogleAuthenticator.authcode(userVO.getVerifyCode(),merchant.getVerificationCodeSecretKey())){
                return new ResponseResult(ResponseCode.FAIL, "验证码有误", null);
            }
        }*/

        if (merchant == null || !merchant.getStatus().equals(SwitchEnum.ON.name())
                || !BCryptUtils.compareBcrypt(userVO.getPassword(), merchant.getPassword())
        ) {
            return new ResponseResult(ResponseCode.FAIL, "用户名或密码错误", null);
        }

        if (!checkLoginIP(request, merchant)) {
            return new ResponseResult(ResponseCode.FAIL, "登录IP地址没有加入白名单！", null);
        }

        String withdraw = null;
        String batchWithdraw = null;

        /*List<MerchantPayType> merchantPayTypes = merchantPayTypeService.getMerchantPayTypes(merchant.getId());
        for (MerchantPayType p : merchantPayTypes) {
            if (SwitchEnum.valueOf(p.getStatus()) == SwitchEnum.ON) {
                if (PaymentTypeEnum.valueOf(p.getPayTypeCode()) == PaymentTypeEnum.WITHDRAW) {
                    withdraw = "true";
                }
                if (PaymentTypeEnum.valueOf(p.getPayTypeCode()) == PaymentTypeEnum.BATCH_WITHDRAW) {
                    batchWithdraw = "true";
                }
            }
        }*/
        request.getSession().setAttribute("withdrawAuth", withdraw);
        request.getSession().setAttribute("batchWithdrawAuth", batchWithdraw);
        UpstreamAdminUserUtils.setSessionUser(merchant, request);

        return new ResponseResult(ResponseCode.SUCCESS, "登录成功", null);
    }

    private boolean checkLoginIP(HttpServletRequest request, UpstreamMerchant merchant) {
        return true;
    }

    private void setVerifyCodeForDev(LoginUserVO userVO, HttpServletRequest request) {
        String profile = env.getProperty("spring.profiles.active");
        if (profile.equals("dev")) {
            userVO.setVerifyCode(Objects.toString(request.getSession().getAttribute(MerchantAdminSessionKey.LOGIN_VERIFY_CODE), ""));
        }
    }

    @RequestMapping("/home")
    public String home(HttpServletRequest request, Model model) {
        UpstreamMerchant merchant = UpstreamAdminUserUtils.getLoginMerchant(request);
        model.addAttribute("merchant", merchant);
        return "/upstream_admin/sys/home";
    }

    @RequestMapping("/logout")
    public String logout(Model model, HttpServletRequest request) {
        request.getSession().removeAttribute(MerchantAdminSessionKey.LOGIN_USER);
        request.getSession().invalidate();
        return "redirect:/upstream_admin/sys/to-login";
    }

    @RequestMapping("/to-login")
    public String toLogin(Model model, LoginUserVO userVO, HttpServletRequest request) {
        return "/upstream_admin/sys/user_login";
    }

}
