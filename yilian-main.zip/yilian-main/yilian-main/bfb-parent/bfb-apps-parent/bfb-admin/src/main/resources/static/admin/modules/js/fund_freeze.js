var fund_freeze = {};

fund_freeze.checkForm = function() {
    return hippo.validateForm('manualFundFreezeForm');
}



fund_freeze.close = function(){
    $('.close',window.parent.document).trigger("click");
}

//手工订单新增或更新保存
fund_freeze.save = function(){
    if (!fund_freeze.checkForm()) {
        return;
    }

    $("#manualFundFreezeForm").ajaxSubmit(function(response) {
        if(response.statusCode=="SUCCESS"){
            $('#errorMsgDiv').hide();
            new $.zui.Messager(response.message, {
                type: 'success' // 定义颜色主题
            }).show();

            window.parent.location.href =  window.parent.document.getElementById('searchForm').action;
        }else{
            hippo.warning(response.message);
        }
    });
}


fund_freeze.unfreeze = function(status){
    var showmsg="确定要解冻资金吗？";
    layer.confirm(
        showmsg,
        {icon: 0, title:'提示'},
        function(index, layero){
            layer.close(index);
            if (!hippo.validateForm('manualFundFreezeForm')) {
                return;
            }

            $("#manualFundFreezeForm").ajaxSubmit(function(response) {
                if(response.statusCode=="SUCCESS"){
                    $('#errorMsgDiv').hide();
                    new $.zui.Messager(response.message, {
                        type: 'success' // 定义颜色主题
                    }).show();

                    window.parent.location.href =  window.parent.document.getElementById('searchForm').action;
                }else{
                    hippo.warning(response.message);
                }
            });
        }
    );
}


$(function () {
    hippo.limitMoney("amountYuan");
});








