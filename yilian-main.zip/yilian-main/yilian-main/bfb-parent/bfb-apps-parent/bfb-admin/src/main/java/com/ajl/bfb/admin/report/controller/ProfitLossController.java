package com.ajl.bfb.admin.report.controller;

import com.ajl.bfb.admin.common.web.AdminUserUtils;
import com.ajl.bfb.core.util.MoneyUtils;
import com.ajl.bfb.repo.platfom.model.ProfitLoss;
import com.ajl.bfb.repo.platfom.service.IProfitLostService;
import com.hippo.framework.auth.admin.OperationAuth;
import com.hippo.framework.auth.admin.model.SysUser;
import com.hippo.framework.web.ResponseCode;
import com.hippo.framework.web.ResponseResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import java.util.Date;
import java.util.List;


@Controller
@RequestMapping(value = "/admin/profit_loss")
public class ProfitLossController {

    @Autowired
    IProfitLostService profitLostService;

    @RequestMapping("/list")
    @OperationAuth(name = "盈亏报表", authCode = "platform.profitLossReport", group = "平台报表")
    public String platmentProfitReport(ProfitLoss profitLoss,Model model){
        List<ProfitLoss> profitLossList =  profitLostService.selectByExample(profitLoss);
        model.addAttribute("profitLossList", profitLossList);
        return "/admin/profit_loss/list";
    }


    @RequestMapping("/to_add")
    @OperationAuth(name = "添加盈亏记录", authCode = "platform.addProfitLoss", group = "平台报表")
    public String toAdd(){
        return "/admin/profit_loss/add_profit_loss";
    }

    @RequestMapping("/add")
    @ResponseBody
    @OperationAuth(name = "添加盈亏记录", authCode = "platform.addProfitLoss", group = "平台报表")
    public ResponseResult addProfitLoss(HttpServletRequest request,ProfitLoss profitLoss){
        SysUser sysUser = AdminUserUtils.getCurrentLoginUser(request);
        profitLoss.setAmount(MoneyUtils.yuan2fee(profitLoss.getAmountYuan()).intValue());
        profitLoss.setCreateTime(new Date());
        profitLoss.setCreateBy(sysUser.getId());
        profitLostService.insert(profitLoss);
        return new ResponseResult(ResponseCode.SUCCESS, "创建成功！", null);
    }
}
