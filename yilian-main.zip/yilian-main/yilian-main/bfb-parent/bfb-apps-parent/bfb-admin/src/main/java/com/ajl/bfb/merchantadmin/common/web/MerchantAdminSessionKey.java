package com.ajl.bfb.merchantadmin.common.web;


public final class MerchantAdminSessionKey {

    public static final String LOGIN_VERIFY_CODE = "merchant_admin_login_verify_code";

    public static final String LOGIN_USER = "merchant_admin_login_user";

    public static final String LOGIN_MERCHANT = "admin_login_merchant";

    public static final String LOGIN_UPSTREAM = "admin_login_upstream";

}
