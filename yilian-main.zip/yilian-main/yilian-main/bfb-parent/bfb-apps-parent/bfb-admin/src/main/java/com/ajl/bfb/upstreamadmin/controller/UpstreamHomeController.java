package com.ajl.bfb.upstreamadmin.controller;

import com.ajl.bfb.repo.upstream.entity.UpstreamMerchant;
import com.ajl.bfb.upstreamadmin.common.UpstreamAdminUserUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;


@Controller
@RequestMapping("/upstream_admin/common")
public class UpstreamHomeController {

    @RequestMapping("/parent_home")
    public String parent_home(Model model, HttpServletRequest request) {
        UpstreamMerchant merchant = UpstreamAdminUserUtils.getLoginMerchant(request);
        model.addAttribute("userName",merchant.getMerchantNo());
        return "/upstream_admin/sys/parent_home";
    }

    @RequestMapping("/home")
    public String home(Model model, HttpServletRequest request) {
        UpstreamMerchant merchant = UpstreamAdminUserUtils.getLoginMerchant(request);
        model.addAttribute("userType",merchant.getUserType());
        return "/upstream_admin/sys/home";
    }

    @RequestMapping("/nopermission")
    public String noPermission() {
        return "/upstream_admin/sys/nopermission";
    }

}
