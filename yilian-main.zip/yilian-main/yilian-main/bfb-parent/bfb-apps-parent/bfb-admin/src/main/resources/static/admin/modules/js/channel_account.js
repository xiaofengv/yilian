var channel_account = {};



//通道新增或更新保存
channel_account.save = function(){
    if (!channel_account.checkForm()) {
        return;
    }

    $("#channelAccountForm").ajaxSubmit(function(response) {
        if(response.statusCode=="SUCCESS"){
            $('#errorMsgDiv').hide();
            if(response.data!=null){
                $('#channelAccountId').val(response.data);
            }
            new $.zui.Messager(response.message, {
                type: 'success' // 定义颜色主题
            }).show();

            window.parent.location.href =  window.parent.document.getElementById('searchForm').action;
        }else{
            hippo.warning(response.message);
        }
    });
}

channel_account.delete = function (channelId,accountId) {
    layer.confirm(
        "确定要删除吗?",
        {icon: 0, title:'提示'},
        function(index, layero){
            layer.close(index);
            window.location.href = getWebPath() + "/admin/channel_account/delete/"+channelId+"/"+ accountId;
        }
    );
}

channel_account.reloadList = function() {
    // alert($('#searchForm').attr('action'));
    window.location.href =  window.document.getElementById('searchForm').action;
    // var obj=window.parent.document.getElementById('searchForm').value;
    // alert(obj)
}


channel_account.updateStatus = function (status) {
    var selectedIds = [];
    $(".checkAll:checked").each(function () {
        selectedIds.push($(this).val());
    })
    var param = {accounts:selectedIds,status:status};
    $.ajax({
        type:"post",
        url:getWebPath()+"/admin/channel_account/update_status",
        data : JSON.stringify(param),
        contentType:"application/json",
        success:function (response) {
            new $.zui.Messager(response.message, {
                type: 'success' // 定义颜色主题
            }).show();
            channel_account.reloadList();
        }

    })
}

channel_account.updateLowArea = function(isLowArea){
    var selectedIds = [];
    $(".checkAll:checked").each(function () {
        selectedIds.push($(this).val());
    })
    if (selectedIds.length ==0) {
        hippo.msg("请选择操作的账号");
        return;
    }
    var param = {accounts:selectedIds,isLowArea:isLowArea};
    $.ajax({
        type:'post',
        url:getWebPath()+"/admin/channel_account/update_low_area",
        data:JSON.stringify(param),
        contentType:"application/json",
        success:function (response) {
            new $.zui.Messager(response.message, {
                type: 'success' // 定义颜色主题
            }).show();
            channel_account.reloadList();
        }
    })
}


channel_account.close = function(){
        $('.close',window.parent.document).trigger("click");
}

channel_account.checkForm = function() {
    return hippo.validateForm('channelAccountForm');
}

$(function () {
    $(".channel-amount").each(function (index, el) {
        hippo.limitInteger(el.id);
    });
   /* $('.close',window.parent.document).click(function(){
        if(!confirm('您确定要关闭本页吗？')){
            return false;
        }
    });*/
});








