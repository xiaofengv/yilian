var manual_payment_order = {};


$(function () {
    $(".limitMoney").each(function (index, el) {
        hippo.limitMoney(el.id);
    });

});

manual_payment_order.checkForm = function() {
    return hippo.validateForm('addManualOrderForm');
}



manual_payment_order.close = function(){
    $('.close',window.parent.document).trigger("click");
}


manual_payment_order.process = function(status){
    $("input[name='rechargeStatus']").val(status);
    var showmsg="";
    if("RECHARGE"==status){
        //如果完成充值，需要上传票据
        if(!hippo.validateElement("file")){
            return;
        }
        showmsg="您确定已经充值成功了吗?";
    }else{
        showmsg="您确定要取消充值吗?";
    }

    layer.confirm(
        showmsg,
        {icon: 0, title:'提示'},
        function(index, layero){
            layer.close(index);
            if (!hippo.validateForm('auditManualOrderForm')) {
                return;
            }

            $("#auditManualOrderForm").ajaxSubmit(function(response) {
                if(response.statusCode=="SUCCESS"){
                    $('#errorMsgDiv').hide();
                    new $.zui.Messager(response.message, {
                        type: 'success' // 定义颜色主题
                    }).show();

                    window.parent.location.href =  window.parent.document.getElementById('searchForm').action;
                }else{
                    hippo.warning(response.message);
                }
            });
        }
    );
}