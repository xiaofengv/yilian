package com.ajl.bfb.admin.sys.interceptor;

import com.ajl.bfb.admin.common.web.AdminUserUtils;
import com.hippo.framework.auth.admin.model.SysUser;
import com.hippo.framework.operation.log.web.AbstractOperationLogInterceptor;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@Component
public class AdminOperationLogInterceptor extends AbstractOperationLogInterceptor {

    @Override
    protected String getOperator(HttpServletRequest request, HttpServletResponse response, Object handler) {
        SysUser sysUser = AdminUserUtils.getCurrentLoginUser(request);
        return sysUser==null?request.getParameter("userName"):sysUser.getUserName();
    }

    @Override
    protected String getLogType() {
        return "平台管理操作日志";
    }
}
