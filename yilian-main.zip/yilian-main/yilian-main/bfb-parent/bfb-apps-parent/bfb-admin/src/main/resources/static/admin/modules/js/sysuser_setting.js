var sysuser_setting = {};


//通道新增或更新保存
sysuser_setting.save = function () {
    if (!hippo.validateForm("addForm")) {
        return;
    }

    $("#addForm").ajaxSubmit(function (response) {
        if (response.statusCode == "SUCCESS") {
            hippo.msg(response.message);
            window.setTimeout(function () {
                window.top.location.href=getWebPath()+"/admin/sys/logout";
            }, 500);
        } else {
            hippo.msg(response.message);
        }
    });
}

//二次密码新增或更新保存
sysuser_setting.update_secondpwd = function () {
    if (!hippo.validateForm("addForm")) {
        return;
    }

    $("#addForm").ajaxSubmit(function (response) {
        if (response.statusCode == "SUCCESS") {
            hippo.msg(response.message);
            window.setTimeout(function () {
                window.top.location.href=getWebPath()+"/admin/sys/logout";
            }, 500);
        } else {
            hippo.msg(response.message);
        }
    });
}

sysuser_setting.initMerchantAccount = function () {
    $.ajax({
        type : "POST", //提交方式
        url : getWebPath()+"/admin/sys_user_setting/init_account",//路径
        success : function(result) {//返回数据根据结果进行相应的处理
            hippo.msg(result.message);
        }
    });

}

sysuser_setting.close = function () {
    $('.close', window.parent.document).trigger("click");
}








