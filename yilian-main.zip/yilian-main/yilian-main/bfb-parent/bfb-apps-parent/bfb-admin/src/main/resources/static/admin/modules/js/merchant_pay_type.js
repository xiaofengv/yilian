var merchant_pay_type = {};

$(function () {
    $(".channel_rate_cls").each(function (index, el) {
        hippo.limitMoney(el.id);
    });

});

merchant_pay_type.updateRate = function (channelPayTypeId) {
    var rate = $('#merchant_pay_type_rate_' + channelPayTypeId).val();
    var agentRate = $('#merchant_pay_type_agent_rate_' + channelPayTypeId).val();
    var minAmount = $('#merchant_pay_type_minamount_' + channelPayTypeId).val();
    var maxAmount = $('#merchant_pay_type_maxamount_' + channelPayTypeId).val();
    $.ajax({
        type : "POST", //提交方式
        url : getWebPath() + "/admin/merchant_pay_type/update_rate",//路径
        data : {
                id:channelPayTypeId,
                rate:rate,
                agentRate:agentRate,
                minAmount:minAmount,
                maxAmount:maxAmount
        },
        success : function(result) {//返回数据根据结果进行相应的处理
            hippo.msg(result.message);
        }
    });
}

merchant_pay_type.saveChannel = function(merchantId,payTypeCode){
    var selectedIds = [];
    if($(".checkbox :checked").length==0){
        hippo.toast("最少选择一个渠道!");
        return;
    }
    $(".checkbox :checked").each(function () {
        selectedIds.push($(this).val());
    })
    $.ajax({
        type:'post',
        url:getWebPath()+"/admin/merchant_channel/save/"+merchantId+"/"+payTypeCode,
        data:JSON.stringify(selectedIds),
        contentType:"application/json",
        success:function (response) {
            if(response.statusCode=="SUCCESS"){
                $('#errorMsgDiv').hide();
                new $.zui.Messager(response.message, {
                    type: 'success' // 定义颜色主题
                }).show();
                window.parent.location.reload();
            }else{
                $('#errorMsgDiv').show();
                $('#errorMsg').html(response.message);
            }

        }
    })
}


merchant_pay_type.close = function(){
    window.parent.location.reload();
}

/**
 * 设置页面，切换通道状态
 * @param id
 */
merchant_pay_type.switchStatus = function (el, id) {
    var isChecked = $(el).prop('checked');
    var switchActionUrl = getWebPath() + '/admin/merchant_pay_type/turn_off/' + id;

    $("#switch_" + id).html("关");
    if (isChecked) {
        switchActionUrl = getWebPath() + '/admin/merchant_pay_type/turn_on/' + id;
        $("#switch_" + id).html("开");
    }

    $.ajax({
        type : "POST", //提交方式
        url : switchActionUrl,//路径
        data : {},
        success : function(result) {//返回数据根据结果进行相应的处理
            if (result.statusCode == 'SUCCESS') {
                new $.zui.Messager(result.message, {
                    type: 'success' // 定义颜色主题
                }).show();
            } else {
                hippo.msg(result.message);
            }
        }
    });
}