package com.ajl.bfb.upstreamadmin.withdraw.vo;

import com.ajl.bfb.repo.withdraw.model.ManualWithdrawOrder;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class ManualWithdrawOrderVO extends ManualWithdrawOrder {

    private String payeeBankCodeStr;

    private BigDecimal amountYuan;

    private String channelAccountId;

    private String secondPassword;
}
