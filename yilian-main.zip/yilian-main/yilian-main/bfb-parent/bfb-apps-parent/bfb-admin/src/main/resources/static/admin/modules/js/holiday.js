var holiday = {};

holiday.delete = function (id) {
    layer.confirm(
        "确定要删除吗?",
        {icon: 0, title:'提示'},
        function(index, layero){
            layer.close(index);
            window.location.href = getWebPath() + "/admin/holiday/delete/" + id ;
        }
    );
}

holiday.close = function(){
    $('.close',window.parent.document).trigger("click");
}

//通道新增或更新保存
holiday.save = function(){
    if (!hippo.validateForm("addForm")) {
        return;
    }

    $("#addForm").ajaxSubmit(function(response) {
        if(response.statusCode=="SUCCESS"){
            new $.zui.Messager(response.message, {
                type: 'success' // 定义颜色主题
            }).show();
            window.parent.location.href =  window.parent.document.getElementById('searchForm').action;
        }else{
            hippo.msg(response.message);
        }
    });
}