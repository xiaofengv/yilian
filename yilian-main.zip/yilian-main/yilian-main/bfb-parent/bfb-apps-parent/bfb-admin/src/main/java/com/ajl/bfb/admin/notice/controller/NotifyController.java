package com.ajl.bfb.admin.notice.controller;

import com.ajl.bfb.admin.common.web.AdminSessionKey;
import com.ajl.bfb.admin.common.web.AdminUserUtils;
import com.ajl.bfb.admin.notice.component.WebSocketServer;
import com.ajl.bfb.core.constants.AuditStatusEnum;
import com.ajl.bfb.repo.manualorder.model.ManualOrder;
import com.ajl.bfb.repo.manualorder.model.ManualOrderQueryParam;
import com.ajl.bfb.repo.manualorder.service.IManualOrderService;
import com.ajl.bfb.repo.payment.model.TransferPaymentOrder;
import com.ajl.bfb.repo.payment.model.TransferPaymentOrderQueryParam;
import com.ajl.bfb.repo.payment.service.ITransferPaymentOrderService;
import com.ajl.bfb.repo.withdraw.model.WithdrawOrder;
import com.ajl.bfb.repo.withdraw.model.WithdrawOrderQueryParam;
import com.ajl.bfb.repo.withdraw.service.ITransferWithdrawOrderService;
import com.ajl.bfb.repo.withdraw.service.IWithdrawOrderService;
import com.github.pagehelper.PageInfo;
import com.hippo.framework.auth.admin.model.Authority;
import com.hippo.framework.auth.admin.model.SysUser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.Collections;
import java.util.Map;
import java.util.Set;


@Controller
@RequestMapping("/admin/notify")
public class NotifyController {
    @Autowired
    WebSocketServer webSocketServer;
    @Autowired
    IWithdrawOrderService withdrawOrderService;
    @Autowired
    IManualOrderService manualOrderService;
    @Autowired
    private ITransferPaymentOrderService transferPaymentOrderService;
    @Autowired
    private ITransferWithdrawOrderService transferWithdrawOrderService;


    @RequestMapping("/login_notice")

    void postMsg(HttpServletRequest request) throws IOException {

        SysUser sysUser = AdminUserUtils.getCurrentLoginUser(request);
        webSocketServer.getWebSocketMap().get(sysUser.getUserName()).sendMessage("您好,欢迎回来！");

        Map<String, Authority> authorityMap = getUserResourcesMap(request);
        Set<String> quthoritySet = authorityMap.keySet();

        if(quthoritySet.contains("withdraw_order.audit_withdraw_order")){

            notifyWithdrawAudit(sysUser);

            notifyTransferWithdrawAudit(sysUser);
        }
        if(quthoritySet.contains("manual_order.audit")){

            notifyManualOrderAudit(sysUser);
        }
        if(quthoritySet.contains("transfer_payment.confirmPayment")){

            notifyTransferPaymentAudit(sysUser);
        }

    }

    private void notifyTransferPaymentAudit(SysUser sysUser) throws IOException {
        TransferPaymentOrderQueryParam queryOrderParam = new TransferPaymentOrderQueryParam();
        queryOrderParam.setAuditStatus(AuditStatusEnum.AUDITING);
        PageInfo<TransferPaymentOrder> pageInfo = transferPaymentOrderService.findPage(queryOrderParam);
        long orderCount = pageInfo.getTotal();
        if(orderCount>0){
            webSocketServer.getWebSocketMap().get(sysUser.getUserName()).sendMessage(String.format("您有%s笔待确认的中转充值订单！",orderCount));
        }
    }

    private void notifyTransferWithdrawAudit(SysUser sysUser) throws IOException {
        WithdrawOrderQueryParam withdrawOrderQueryParam = new WithdrawOrderQueryParam();
        withdrawOrderQueryParam.setAuditStatus(AuditStatusEnum.AUDITING);
        PageInfo<WithdrawOrder> pageInfo = transferWithdrawOrderService.findTransferWithdrawList(withdrawOrderQueryParam);
        long orderCount = pageInfo.getTotal();
        if(orderCount>0) {
            webSocketServer.getWebSocketMap().get(sysUser.getUserName()).sendMessage(String.format("您有%s笔待审核的中转下发订单！", orderCount));
        }
    }

    private void notifyManualOrderAudit(SysUser sysUser) throws IOException {
        ManualOrderQueryParam param = new ManualOrderQueryParam();
        param.setAuditStatus(AuditStatusEnum.AUDITING.name());
        PageInfo<ManualOrder> pageInfo =  manualOrderService.getManualOrderList(param);
        long orderCount = pageInfo.getTotal();
        if(orderCount>0) {
            webSocketServer.getWebSocketMap().get(sysUser.getUserName()).sendMessage(String.format("您有%s笔待处理的手工订单！", orderCount));
        }

    }

    private void notifyWithdrawAudit(SysUser sysUser) throws IOException {

        WithdrawOrderQueryParam withdrawOrderQueryParam = new WithdrawOrderQueryParam();
        withdrawOrderQueryParam.setAuditStatus(AuditStatusEnum.AUDITING);
        PageInfo<WithdrawOrder> pageInfo = withdrawOrderService.findList(withdrawOrderQueryParam);
        long orderCount = pageInfo.getTotal();
        if(orderCount>0) {
            webSocketServer.getWebSocketMap().get(sysUser.getUserName()).sendMessage(String.format("您有%s笔待审核的代付订单！", orderCount));
        }
    }



    protected Map<String, Authority> getUserResourcesMap(HttpServletRequest request) {
        Map<String, Authority> authorityMap = (Map<String, Authority>) request.getSession().getAttribute(AdminSessionKey.USER_AUTHORITY);
        if (authorityMap == null) {
            return Collections.EMPTY_MAP;
        }
        return authorityMap;
    }
}
