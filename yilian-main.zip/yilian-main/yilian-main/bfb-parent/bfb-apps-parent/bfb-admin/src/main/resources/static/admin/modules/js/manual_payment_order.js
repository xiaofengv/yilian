var manual_payment_order = {};


$(function () {
    $(".limitMoney").each(function (index, el) {
        hippo.limitMoney(el.id);
    });

    $("#channelAccount").selectpicker('val', '');
});

manual_payment_order.checkForm = function() {
    return hippo.validateForm('addManualOrderForm');
}



manual_payment_order.close = function(){
    $('.close',window.parent.document).trigger("click");
}

manual_payment_order.selectChannelAcc = function(el){
    var transferBankCardOwner = $(el).find("option:selected").data('transferbankcardowner');
    var transferBankCard = $(el).find("option:selected").data('transferbankcard');
    $("#transferBankCardOwner").val(transferBankCardOwner);
    $("#transferBankCard").val(transferBankCard);
}

manual_payment_order.audit = function(status){
    $("input[name='auditStatus']").val(status);
    var showmsg="";
    if("SUCCESS"==status){
        //如果审核通过，必须输入银行卡号
        if(!hippo.validateElement("transferBankCard")){
            return;
        }
        showmsg="确定受理该订单?";
    }else{
        showmsg="确定要驳回该订单?";
    }

    layer.confirm(
        showmsg,
        {icon: 0, title:'提示'},
        function(index, layero){
            layer.close(index);
            if (!hippo.validateForm('auditManualOrderForm')) {
                return;
            }

            $("#auditManualOrderForm").ajaxSubmit(function(response) {
                if(response.statusCode=="SUCCESS"){
                    $('#errorMsgDiv').hide();
                    new $.zui.Messager(response.message, {
                        type: 'success' // 定义颜色主题
                    }).show();

                    window.parent.location.href =  window.parent.document.getElementById('searchForm').action;
                }else{
                    hippo.warning(response.message);
                }
            });
        }
    );
}

//充值确认
manual_payment_order.confirm = function(status){
    if (!hippo.validateForm('confirmManualOrderForm')) {
        return;
    }
        $("input[name='status']").val(status);
        var showmsg="";
        if("SUCCESS"==status){
            showmsg="确定充值已到账吗?";
        }else{
            showmsg="确定充值未到账吗?";
        }

        layer.confirm(
            showmsg,
            {icon: 0, title:'提示'},
            function(index, layero){
                layer.close(index);
                $("#confirmManualOrderForm").ajaxSubmit(function(response) {
                    if(response.statusCode=="SUCCESS"){
                        $('#errorMsgDiv').hide();
                        new $.zui.Messager(response.message, {
                            type: 'success' // 定义颜色主题
                        }).show();

                        window.parent.location.href =  window.parent.document.getElementById('searchForm').action;
                    }else{
                        hippo.warning(response.message);
                    }
                });
            }
        );
    }