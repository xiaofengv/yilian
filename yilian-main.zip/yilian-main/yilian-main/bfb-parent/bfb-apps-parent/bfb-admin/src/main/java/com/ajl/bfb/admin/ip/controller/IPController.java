package com.ajl.bfb.admin.ip.controller;

import com.ajl.bfb.admin.common.web.AdminUserUtils;
import com.ajl.bfb.repo.ip.model.IPObject;
import com.ajl.bfb.repo.ip.model.IPVO;
import com.ajl.bfb.repo.ip.model.IpOrderStatistics;
import com.ajl.bfb.repo.ip.model.QueryIPParam;
import com.ajl.bfb.repo.ip.service.IIPService;
import com.github.pagehelper.PageInfo;
import com.google.gson.Gson;
import com.hippo.framework.auth.admin.OperationAuth;
import com.hippo.framework.auth.admin.model.SysUser;
import com.hippo.framework.operation.log.LogOperation;
import com.hippo.framework.util.AddressUtils;
import com.hippo.framework.util.DateUtils;
import com.hippo.framework.util.JsonUtils;
import com.hippo.framework.web.ResponseCode;
import com.hippo.framework.web.ResponseResult;
import net.sf.json.JSONArray;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import java.io.UnsupportedEncodingException;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Controller
@RequestMapping(value = "/admin/ip")
public class IPController {
    private static final Logger logger = LogManager.getLogger(IPController.class);
    @Autowired
    private IIPService iipService;

    @RequestMapping(value = "/list")
    @OperationAuth(name = "查询ip黑白名单", authCode = "ip.list", group = "黑白名单管理")
    @LogOperation(name = "查询ip黑白名单", module = "黑白名单管理")
    public String list(Model model, QueryIPParam queryIPParam) {
        queryIPParam.setPageSize(20);

        if (queryIPParam.getStartTime() == null) {
            queryIPParam.setStartTime(DateUtils.plusDays(DateUtils.getDateStart2(new Date()), 0));
            queryIPParam.setEndTime(DateUtils.getDateEnd2(new Date()));
        }
        PageInfo<IPVO> pageInfo = iipService.findList(queryIPParam);
        model.addAttribute("pageInfo", pageInfo);
        model.addAttribute("queryParam",queryIPParam);

        QueryIPParam todayBlackListQuery = new QueryIPParam();
        todayBlackListQuery.setStartTime(DateUtils.plusDays(DateUtils.getDateStart2(new Date()), 0));
        todayBlackListQuery.setEndTime(DateUtils.getDateEnd2(new Date()));
        todayBlackListQuery.setIsBlacklist("Y");
        todayBlackListQuery.setPageSize(1000);
        PageInfo<IPVO> todayBlackListPage = iipService.findList(todayBlackListQuery);
        int todayBlackListNum = todayBlackListPage.getList().size();
        model.addAttribute("todayBlackListNum",todayBlackListNum);
        return "admin/ip/list";
    }

    @RequestMapping(value = "/to_add")
    @OperationAuth(name = "添加ip黑白名单", authCode = "ip.add", group = "黑白名单管理")
    @LogOperation(name = "添加ip黑白名单", module = "黑白名单管理")
    public String toAdd(Model model){
        return "/admin/ip/add";
    }
    @RequestMapping(value = "/add")
    @OperationAuth(name = "添加ip黑白名单", authCode = "ip.add", group = "黑白名单管理")
    @LogOperation(name = "添加ip黑白名单", module = "黑白名单管理")
    public String add(Model model, IPVO ipvo, HttpServletRequest request){
        String ip = ipvo.getIp();
        if (checkIp(ip)){
            model.addAttribute("warning", "ip:" + ip + "已存在");
            QueryIPParam queryIPParam = new QueryIPParam();
            queryIPParam.setPageSize(100);
            PageInfo<IPVO> pageInfo = iipService.findList(queryIPParam);
            model.addAttribute("pageInfo", pageInfo);
            model.addAttribute("queryParam",queryIPParam);
            return "admin/ip/list";
        }
        SysUser sysUser = AdminUserUtils.getCurrentLoginUser(request);
        String userName = sysUser.getUserName();
        ipvo.setCreateBy(userName);
        ipvo.setUpdateBy(userName);
        if (ipvo.getIsTempBlacklist().equals("Y")){
            ipvo.setBlacklistInterceptNum(1);
        }
        setCountryAndCity(ipvo);
        iipService.insert(ipvo);
        return list(model,new QueryIPParam());
    }

    @RequestMapping(value = "/addBlacklist")
    @ResponseBody
    @OperationAuth(name = "添加ip黑白名单", authCode = "ip.add", group = "黑白名单管理")
    @LogOperation(name = "添加ip黑名单", module = "黑白名单管理")
    public ResponseResult addBlacklist(Model model, IPVO ipvo, HttpServletRequest request){
        String ip = ipvo.getIp();
        SysUser sysUser = AdminUserUtils.getCurrentLoginUser(request);
        String userName = sysUser.getUserName();
        IPVO tempIpvo = iipService.selectByIp(ip);
        if (tempIpvo != null){
            //已存在，则修改
            tempIpvo.setIsBlacklist("Y");
            tempIpvo.setIsTempBlacklist("Y");
            tempIpvo.setIsWhitelist("N");
            tempIpvo.setIsTempWhitelist("N");
            tempIpvo.setDeleteFlag("N");
            tempIpvo.setUpdateBy(userName);
            setCountryAndCity(tempIpvo);
            iipService.updateByPrimaryKey(tempIpvo);
            return new ResponseResult(ResponseCode.SUCCESS, "添加成功","");
        }
        ipvo.setCreateBy(userName);
        ipvo.setUpdateBy(userName);
        ipvo.setIsTempBlacklist("Y");
        ipvo.setIsTempWhitelist("N");
        ipvo.setBlacklistInterceptNum(1);
        setCountryAndCity(ipvo);
        iipService.insert(ipvo);
        return new ResponseResult(ResponseCode.SUCCESS, "添加成功","");
    }
    @RequestMapping(value = "/addWhitelist")
    @ResponseBody
    @OperationAuth(name = "添加ip黑白名单", authCode = "ip.add", group = "黑白名单管理")
    @LogOperation(name = "添加ip白名单", module = "黑白名单管理")
    public ResponseResult addWhitelist(Model model, IPVO ipvo, HttpServletRequest request){
        String ip = ipvo.getIp();
        SysUser sysUser = AdminUserUtils.getCurrentLoginUser(request);
        String userName = sysUser.getUserName();

        IPVO tempIpvo = iipService.selectByIp(ip);
        if (tempIpvo != null){
            //已存在，则修改
            tempIpvo.setIsBlacklist("N");
            tempIpvo.setIsTempBlacklist("N");
            tempIpvo.setIsWhitelist("Y");
            tempIpvo.setIsTempWhitelist("Y");
            tempIpvo.setDeleteFlag("N");
            tempIpvo.setUpdateBy(userName);
            setCountryAndCity(tempIpvo);
            iipService.updateByPrimaryKey(tempIpvo);
            return new ResponseResult(ResponseCode.SUCCESS, "添加成功","");
        }
        ipvo.setUpdateBy(userName);
        ipvo.setCreateBy(userName);
        ipvo.setIsTempBlacklist("N");
        ipvo.setIsTempWhitelist("Y");
        ipvo.setBlacklistInterceptNum(0);
        setCountryAndCity(ipvo);
        iipService.insert(ipvo);
        return new ResponseResult(ResponseCode.SUCCESS, "添加成功","");
    }

    private void setCountryAndCity(IPVO ipvo) {
        IPVO temp = getAddresses(ipvo.getIp());
        ipvo.setCountry(temp.getCountry());
        ipvo.setRegion(temp.getRegion());
        ipvo.setCity(temp.getCity());
        ipvo.setIsp(temp.getIsp());
    }


    @RequestMapping(value = "/synchronizedAddress/{id}")
    @ResponseBody
    @OperationAuth(name = "同步城市信息", authCode = "ip.synchronizedAddress", group = "黑白名单管理")
    @LogOperation(name = "同步城市信息", module = "黑白名单管理")
    public ResponseResult synchronizedAddress(Model model, @PathVariable("id") int id, HttpServletRequest request){
        IPVO ipvo = iipService.selectByPrimaryKey(id);
        IPVO temp = getAddresses(ipvo.getIp());
        String country = temp.getCountry();
        if (StringUtils.isEmpty(country)){
            return new ResponseResult(ResponseCode.FAIL, "同步城市信息失败","");
        }
        ipvo.setCountry(country);
        ipvo.setRegion(temp.getRegion());
        ipvo.setCity(temp.getCity());
        ipvo.setIsp(temp.getIsp());
        iipService.updateByPrimaryKey(ipvo);
        return new ResponseResult(ResponseCode.SUCCESS, "同步城市信息成功","");
    }

    private IPVO jiexiIpAddress(String ipInfo){
        IPVO ipAddress = new IPVO();
        Map m = JsonUtils.json2map(ipInfo);
        String ret = m.get("ret").toString();
        if (ret.equals("ok")){
            String ip = m.get("ip").toString();
            String data = m.get("data").toString();
            JSONArray jsonArr = JSONArray.fromObject(data);//转换成JSONArray 格式
            List<String> addresss = JSONArray.toList(jsonArr);
            ipAddress.setCountry(addresss.get(0));
            ipAddress.setIp(ip);
            ipAddress.setRegion(addresss.get(1));
            ipAddress.setCity(addresss.get(2));
            ipAddress.setIsp(addresss.get(3));
        }else{
            return null;
        }
        return ipAddress;
    }
    private IPVO getAddresses(String ip) {
        String ipResult = AddressUtils.getAddressFromIp138(ip);
        IPVO ipvo = null;
        if(StringUtils.isNotEmpty(ipResult)){
            ipvo = jiexiIpAddress(ipResult);
        }
        if (ipvo != null){
            return ipvo;
        }
        String content = "ip=" + ip;
        String returnStr = null;
        //先从TB获取，若获取失败，则从360获取
        try {
            returnStr = AddressUtils.getAddressesFromTB(content);
            if (StringUtils.isNotEmpty(returnStr)){
                IPObject ipVo = new Gson().fromJson(returnStr, IPObject.class);
                if (ipVo != null && ipVo.getCode().equals("0")){
                    return ipVo.getData();
                }
            }
        } catch (UnsupportedEncodingException e) {
            logger.info("从TB获取IP对应的城市异常");
        }
        return new IPVO();
    }

    private boolean checkIp(String ip){
        if (StringUtils.isEmpty(ip)){
            throw new RuntimeException("IP不能为空");
        }
        IPVO ipvo = iipService.selectByIp(ip);
        if (ipvo != null){
            return true;
        }
        return false;
    }
    @RequestMapping(value = "/delete/{id}")
    @OperationAuth(name = "删除ip黑白名单", authCode = "ip.delete", group = "黑白名单管理")
    @LogOperation(name = "删除ip黑白名单", module = "黑白名单管理")
    public String delete(Model model, @PathVariable("id") int id){
        iipService.deleteByPrimaryKey(id);
        return list(model,new QueryIPParam());
    }

    @RequestMapping(value = "/to_update/{id}")
    @OperationAuth(name = "修改ip黑白名单", authCode = "ip.update", group = "黑白名单管理")
    @LogOperation(name = "修改ip黑白名单", module = "黑白名单管理")
    public String toUpdate(Model model, @PathVariable("id") int id) {
        IPVO ipvo = iipService.selectByPrimaryKey(id);
        model.addAttribute("ipVO", ipvo);
        return "admin/ip/update";
    }

    @RequestMapping(value = "/update")
    @OperationAuth(name = "修改ip黑白名单", authCode = "ip.update", group = "黑白名单管理")
    @LogOperation(name = "修改ip黑白名单", module = "黑白名单管理")
    public String update(IPVO ipvo, Model model, HttpServletRequest request) {
        SysUser sysUser = AdminUserUtils.getCurrentLoginUser(request);
        String userName = sysUser.getUserName();
        ipvo.setUpdateBy(userName);
        iipService.updateByPrimaryKey(ipvo);
        return list(model,new QueryIPParam());
    }

    @RequestMapping(value = "/ipOrderSuccessRate")
    @OperationAuth(name = "IP订单成功率", authCode = "ip.successRate", group = "黑白名单管理")
    @LogOperation(name = "查询IP订单成功率", module = "黑白名单管理")
    public String successRate(Model model, IpOrderStatistics queryParam){
        if (queryParam.getStartTime() == null) {
            queryParam.setStartTime(DateUtils.plusDays(DateUtils.getDateStart2(new Date()), 0));
            queryParam.setEndTime(DateUtils.getDateEnd2(new Date()));
        }
        if (queryParam.getSkipNum() == null){
            queryParam.setSkipNum(0);
        }
        if (queryParam.getSuccessNum() == null){
            queryParam.setSuccessNum(99999);
        }
        if (queryParam.getProcessingNum() == null){
            queryParam.setProcessingNum(0);
        }
        queryParam.setPageSize(100);
        PageInfo<IpOrderStatistics> page = iipService.selectSuccessRateByIp(queryParam);
        model.addAttribute("pageInfo",page);
        model.addAttribute("queryParam",queryParam);

        QueryIPParam queryIPParam  = new QueryIPParam();
        //查询黑名单集合
        queryIPParam.setIsBlacklist("Y");
        queryIPParam.setDeleteFlag("N");
        List<IPVO> blackList = iipService.findBlackORWhiteList(queryIPParam);
        Map<String, IPVO> blackMap = blackList.stream().collect(Collectors.toMap(IPVO::getIp, m -> m));
        model.addAttribute("blackMap",blackMap);

        //查询白名单集合
        queryIPParam.setIsBlacklist("N");
        queryIPParam.setIsWhitelist("Y");
        queryIPParam.setDeleteFlag("N");
        List<IPVO> whiteList = iipService.findBlackORWhiteList(queryIPParam);
        Map<String, IPVO> whiteMap = whiteList.stream().collect(Collectors.toMap(IPVO::getIp, m -> m));
        model.addAttribute("whiteMap",whiteMap);
        return "admin/ip/ip_order_scuccess_rate";
    }
    @RequestMapping(value = "/detailsAnalysis/{id}")
    @OperationAuth(name = "IP分析", authCode = "ip.successRate", group = "黑白名单管理")
    @LogOperation(name = "查询IP分析", module = "黑白名单管理")
    public String detailsAnalysis(Model model, @PathVariable("id") int id){
        IPVO ipvo = iipService.selectByPrimaryKey(id);
        model.addAttribute("ipvo",ipvo);
        IpOrderStatistics queryParam = new IpOrderStatistics();
        queryParam.setIp(ipvo.getIp());
        //当天统计数据
        queryParam.setStartTime(DateUtils.plusDays(DateUtils.getDateStart2(new Date()), 0));
        queryParam.setEndTime(DateUtils.getDateEnd2(new Date()));
        queryParam.setSkipNum(0);
        PageInfo<IpOrderStatistics> page = iipService.selectSuccessRateByIp(queryParam);
        IpOrderStatistics today = page.getList().get(0);
        model.addAttribute("day",today);
        //本周统计数据
        queryParam.setStartTime(DateUtils.getFirstDayOfWeek());
        page = iipService.selectSuccessRateByIp(queryParam);
        IpOrderStatistics thisWeek = page.getList().get(0);
        model.addAttribute("week",thisWeek);
        //本月统计数据
        queryParam.setStartTime(DateUtils.getFirstDayOfMonth());
        page = iipService.selectSuccessRateByIp(queryParam);
        IpOrderStatistics month = page.getList().get(0);
        model.addAttribute("month",month);
        //三十天统计数据
        queryParam.setStartTime(DateUtils.getAppointDay(30,true));
        page = iipService.selectSuccessRateByIp(queryParam);
        IpOrderStatistics thirty = page.getList().get(0);
        model.addAttribute("thirty",thirty);
        //六十天统计数据
        queryParam.setStartTime(DateUtils.getAppointDay(60,true));
        page = iipService.selectSuccessRateByIp(queryParam);
        IpOrderStatistics sixty = page.getList().get(0);
        model.addAttribute("sixty",sixty);
        return "admin/ip/detailsAnalysis";
    }
}
