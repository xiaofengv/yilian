package com.ajl.bfb.admin.manualorder.controller;

import com.ajl.bfb.admin.common.web.AdminUserUtils;
import com.ajl.bfb.admin.notice.component.NotifyComponent;
import com.ajl.bfb.core.constants.AuditStatusEnum;
import com.ajl.bfb.core.constants.ManualBizTypeEnum;
import com.ajl.bfb.core.constants.ManualOrderTarge;
import com.ajl.bfb.core.constants.OrderStatusEnum;
import com.ajl.bfb.core.lock.MerchantLock;
import com.ajl.bfb.core.util.MoneyUtils;
import com.ajl.bfb.repo.channel.model.Channel;
import com.ajl.bfb.repo.channel.model.ChannelAccount;
import com.ajl.bfb.repo.channel.service.IChannelAccountService;
import com.ajl.bfb.repo.channel.service.IChannelService;
import com.ajl.bfb.repo.channelstat.model.ChannelAccountInstance;
import com.ajl.bfb.repo.channelstat.service.IChannelAccountInstanceService;
import com.ajl.bfb.repo.export.service.TransferFundOrderExportService;
import com.ajl.bfb.repo.manualorder.ManualOrderException;
import com.ajl.bfb.repo.manualorder.model.ManualOrder;
import com.ajl.bfb.repo.manualorder.model.ManualOrderQueryParam;
import com.ajl.bfb.repo.manualorder.service.IManualOrderService;
import com.ajl.bfb.repo.merchant.FundException;
import com.ajl.bfb.repo.merchant.model.Merchant;
import com.ajl.bfb.repo.merchant.service.IMerchantService;
import com.ajl.bfb.repo.stat.model.OrderStat;
import com.github.pagehelper.PageInfo;
import com.hippo.framework.auth.admin.OperationAuth;
import com.hippo.framework.auth.admin.model.SysUser;
import com.hippo.framework.operation.log.LogOperation;
import com.hippo.framework.util.validation.AssertUtils;
import com.hippo.framework.util.validation.ValidationUtils;
import com.hippo.framework.web.ResponseCode;
import com.hippo.framework.web.ResponseResult;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Collectors;

import static com.ajl.bfb.core.util.MoneyUtils.yuan2fee;


@Controller
@RequestMapping("/admin/manual_order")
public class ManualOrderController {
    private static Logger logger = LogManager.getLogger(ManualOrderController.class);

    @Autowired
    IManualOrderService manualOrderService;
    @Autowired
    IMerchantService merchantService;
    @Autowired
    IChannelAccountService channelAccountService;
    @Autowired
    IChannelAccountInstanceService channelAccountInstanceService;
    @Autowired
    IChannelService channelService;
    @Autowired
    private MerchantLock merchantLock;
    @Autowired
    private NotifyComponent notifyComponent;
    @Autowired
    TransferFundOrderExportService transferFundOrderExportService;


    @RequestMapping("/list")
    @OperationAuth(name = "订单查看", authCode = "manual_order.list", group = "手工订单")
    public String getManualOrderList(ManualOrderQueryParam param,Model model){
        PageInfo<ManualOrder> pageInfo =  manualOrderService.getManualOrderList(param);
        List<ManualOrder> orders = pageInfo.getList();

        OrderStat orderStat = manualOrderService.queryManualOrderTotal(param);
        model.addAttribute("orderStat", orderStat);

        List<Integer> merchantIds = orders.stream().map(order->order.getMerchantId()).distinct().collect(Collectors.toList());
        List<Merchant> merchants = merchantService.findByIds(merchantIds);
        Map<Integer,String> merchantMap = merchants.stream().collect(Collectors.toMap(Merchant::getId, t -> t.getMerchantNo()));
        model.addAttribute("merchantMap", merchantMap);

        List<Integer> channelAccountids = orders.stream().map(order->order.getChannelAccountId()).distinct().collect(Collectors.toList());
        List<ChannelAccount> channelAccounts = channelAccountService.findByIds(channelAccountids);
        Map<Integer,String> channelAccountMap = channelAccounts.stream().collect(Collectors.toMap(ChannelAccount::getId,t -> t.getAccount()));
        model.addAttribute("channelAccountMap", channelAccountMap);

        model.addAttribute("bizTypeList", ManualBizTypeEnum.values());
        Map<String,String> bizTypeMap = Arrays.stream(ManualBizTypeEnum.values()).collect(Collectors.toMap(ManualBizTypeEnum::name, r -> r.getDesc()));
        model.addAttribute("bizTypeMap", bizTypeMap);

        model.addAttribute("targeList", ManualOrderTarge.values());
        Map<String,String> targetMap = Arrays.stream(ManualOrderTarge.values()).collect(Collectors.toMap(ManualOrderTarge::name, r -> r.getDesc()));
        model.addAttribute("targetMap", targetMap);

        model.addAttribute("orderStatusList", OrderStatusEnum.values());
        Map<String,String> orderStatusMap = Arrays.stream(OrderStatusEnum.values()).collect(Collectors.toMap(OrderStatusEnum::name, r -> r.getDesc()));
        model.addAttribute("orderStatusMap", orderStatusMap);

        model.addAttribute("auditStatusList", AuditStatusEnum.values());
        Map<String,String> auditStatusMap = Arrays.stream(AuditStatusEnum.values()).collect(Collectors.toMap(AuditStatusEnum::name, r -> r.getDesc()));
        model.addAttribute("auditStatusMap", auditStatusMap);

        model.addAttribute("pageInfo",pageInfo);
        model.addAttribute("queryParam",param);
        return "/admin/manual_order/list";
    }


    @RequestMapping("/transfer_withdraw_list")
    @OperationAuth(name = "订单查看", authCode = "manual_order.list", group = "手工订单")
    public String getManualTransferOrderList(ManualOrderQueryParam param,Model model){
        param.setBizType(ManualBizTypeEnum.TRANSFER_TO_WITHDRAW.name());
        PageInfo<ManualOrder> pageInfo =  manualOrderService.getManualOrderList(param);
        List<ManualOrder> orders = pageInfo.getList();

        OrderStat orderStat = manualOrderService.queryManualOrderTotal(param);
        model.addAttribute("orderStat", orderStat);

        List<Integer> merchantIds = orders.stream().map(order->order.getMerchantId()).distinct().collect(Collectors.toList());
        List<Merchant> merchants = merchantService.findByIds(merchantIds);
        Map<Integer,Merchant> merchantMap = merchants.stream().collect(Collectors.toMap(Merchant::getId, t -> t));
        model.addAttribute("merchantMap", merchantMap);

        List<Integer> channelAccountids = orders.stream().map(order->order.getChannelAccountId()).distinct().collect(Collectors.toList());
        List<ChannelAccount> channelAccounts = channelAccountService.findByIds(channelAccountids);
        Map<Integer,String> channelAccountMap = channelAccounts.stream().collect(Collectors.toMap(ChannelAccount::getId,t -> t.getAccount()));
        model.addAttribute("channelAccountMap", channelAccountMap);

        model.addAttribute("bizTypeList", ManualBizTypeEnum.values());
        Map<String,String> bizTypeMap = Arrays.stream(ManualBizTypeEnum.values()).collect(Collectors.toMap(ManualBizTypeEnum::name, r -> r.getDesc()));
        model.addAttribute("bizTypeMap", bizTypeMap);

        model.addAttribute("targeList", ManualOrderTarge.values());
        Map<String,String> targetMap = Arrays.stream(ManualOrderTarge.values()).collect(Collectors.toMap(ManualOrderTarge::name, r -> r.getDesc()));
        model.addAttribute("targetMap", targetMap);

        model.addAttribute("orderStatusList", OrderStatusEnum.values());
        Map<String,String> orderStatusMap = Arrays.stream(OrderStatusEnum.values()).collect(Collectors.toMap(OrderStatusEnum::name, r -> r.getDesc()));
        model.addAttribute("orderStatusMap", orderStatusMap);

        model.addAttribute("auditStatusList", AuditStatusEnum.values());
        Map<String,String> auditStatusMap = Arrays.stream(AuditStatusEnum.values()).collect(Collectors.toMap(AuditStatusEnum::name, r -> r.getDesc()));
        model.addAttribute("auditStatusMap", auditStatusMap);

        model.addAttribute("pageInfo",pageInfo);
        model.addAttribute("queryParam",param);
        return "/admin/manual_order/transfer_withdraw_list";
    }

    @RequestMapping("/exportTransferFundOrder")
    @OperationAuth(name = "资金转换订单导出", authCode = "manual_order.transfer_withdraw_export", group = "手工订单")
    public void export(Model model, ManualOrderQueryParam param, HttpServletResponse response) throws Exception {
        logger.info("资金中转报表导出开始...");
        param.setBizType(ManualBizTypeEnum.TRANSFER_TO_WITHDRAW.name());
        PageInfo<ManualOrder> pageInfo =  manualOrderService.getManualOrderList(param);

        param.setTotal(pageInfo.getTotal());
        long start = System.currentTimeMillis();
        transferFundOrderExportService.export(response,param);
        logger.info("资金中转报表导出结束...共耗时:" + (System.currentTimeMillis() - start)/1000 + "s");
    }

    @RequestMapping("/add_merchant_order")
    @OperationAuth(name = "创建手工订单", authCode = "manual_order.create", group = "手工订单")
    public String addMerchantManualOrder(ManualOrderQueryParam param,Model model){
        model.addAttribute("bizTypeList", ManualBizTypeEnum.values());
        model.addAttribute("targeList", ManualOrderTarge.values());
        model.addAttribute("orderStatusList", OrderStatusEnum.values());
        model.addAttribute("auditStatusList", AuditStatusEnum.values());
        model.addAttribute("queryParam",param);
        return "/admin/manual_order/add_merchant_order";
    }

    @RequestMapping("/add_channelAcc_order")
    @OperationAuth(name = "创建手工订单", authCode = "manual_order.create", group = "手工订单")
    public String addChannelAccManualOrder(ManualOrderQueryParam param,Model model){
        model.addAttribute("bizTypeList", ManualBizTypeEnum.values());
        model.addAttribute("orderStatusList", OrderStatusEnum.values());
        model.addAttribute("auditStatusList", AuditStatusEnum.values());
        List<ChannelAccount> channelAccounts = channelAccountService.findChannelAccounts(null);
        model.addAttribute("channelAccounts",channelAccounts);
        List<Merchant> merchants = merchantService.findMerchant(null);
        model.addAttribute("merchants",merchants);
        List<Channel> channels = channelService.findChannels(null);
        Map channelMap = channels.stream().distinct().collect(Collectors.toMap(Channel::getId,Channel::getName));
        model.addAttribute("channelMap",channelMap);
        model.addAttribute("queryParam",param);
        return "/admin/manual_order/add_channelacc_order";
    }

    @RequestMapping("/create")
    @ResponseBody
    @OperationAuth(name = "创建手工订单", authCode = "manual_order.create", group = "手工订单")
    @LogOperation(name = "添加订单",module = "手工订单管理")
    public ResponseResult createManualOrder(HttpServletRequest request, ManualOrder order, Model model) throws IOException {
        String error = ValidationUtils.validate(order);
        if(StringUtils.isNotEmpty(error)){
            return new ResponseResult(ResponseCode.FAIL, "创建失败！"+error, null);
        }
        try {
            initManualOrder(request, order);
        } catch (ManualOrderException e) {
            return new ResponseResult(ResponseCode.FAIL, String.format("创建失败:%s",e.getMessage()), null);
        }

        manualOrderService.createManualOrder(order);

        notifyComponent.notifyByAuthority("manual_order.audit","您有一条新的手工订单待审核");
        return new ResponseResult(ResponseCode.SUCCESS, "创建成功！", null);
    }

    private void initManualOrder(HttpServletRequest request, ManualOrder order) throws ManualOrderException {
        if(ManualOrderTarge.MERCHANT.name().equals(order.getTarget())){
            Merchant merchant = merchantService.findByMerchantNo(order.getAccount());
            if(Objects.isNull(merchant)){
                throw new ManualOrderException(String.format("商户号：%s 不存在！",order.getAccount()));
            }
            order.setMerchantId(merchant.getId());
            order.setChannelAccountId(0);
        }else{
            ChannelAccount channelAccount = channelAccountService.findById(order.getChannelAccountId());
            if(Objects.isNull(channelAccount)){
                throw new ManualOrderException(String.format("收款号：%s 不存在！",order.getAccount()));
            }
            order.setChannelAccountId(channelAccount.getId());
            order.setMerchantId(0);
        }
        order.setAmount(yuan2fee(order.getAmount()));
        order.setStatus(OrderStatusEnum.PROCESSING.name());
        order.setAuditStatus(AuditStatusEnum.AUDITING.name());
        SysUser sysUser = AdminUserUtils.getCurrentLoginUser(request);
        order.setProcessSysUserId(sysUser.getId());
        order.setCreateTime(new Date());
    }

    @RequestMapping("/to_audit/{id}")
    @OperationAuth(name = "订单审核", authCode = "manual_order.audit", group = "手工订单")
    public String toAuditManualOrder(@PathVariable("id") Integer id, Model model){
        Map<String,String> bizTypeMap = Arrays.stream(ManualBizTypeEnum.values()).collect(Collectors.toMap(ManualBizTypeEnum::name, r -> r.getDesc()));
        model.addAttribute("bizTypeMap", bizTypeMap);
        Map<String,String> targetMap = Arrays.stream(ManualOrderTarge.values()).collect(Collectors.toMap(ManualOrderTarge::name, r -> r.getDesc()));
        model.addAttribute("targetMap", targetMap);
        ManualOrder manualOrder = manualOrderService.selectByPrimaryKey(id);
        model.addAttribute("manualOrder",manualOrder);
        setAccount(manualOrder);
        return "/admin/manual_order/audit";
    }

    private void setAccount(ManualOrder manualOrder) {
        if(manualOrder.getMerchantId()!=0){
            Merchant merchant = merchantService.findById(manualOrder.getMerchantId());
            manualOrder.setAccount(merchant.getMerchantNo());
        }else {
            ChannelAccount channelAccount = channelAccountService.findById(manualOrder.getChannelAccountId());
            manualOrder.setAccount(channelAccount.getAccount());
        }
    }

    @RequestMapping("/audit")
    @ResponseBody
    @OperationAuth(name = "订单审核", authCode = "manual_order.audit", group = "手工订单")
    @LogOperation(name = "审核订单",module = "手工订单管理")
    public ResponseResult auditManualOrder(Integer id, String status, BigDecimal merchantCost, String auditRemark, HttpServletRequest request){
        SysUser sysUser = AdminUserUtils.getCurrentLoginUser(request);
        ManualOrder manualOrder = manualOrderService.selectByPrimaryKey(id);
        if(AuditStatusEnum.AUDITING != AuditStatusEnum.valueOf(manualOrder.getAuditStatus())){
            return new ResponseResult(ResponseCode.FAIL, String.format("该订单已经审核!"), null);
        }
        try {
            if(ManualBizTypeEnum.TRANSFER_TO_WITHDRAW.name().equals(manualOrder.getBizType())){
                manualOrderService.auditTransferToWithdrawManualOrder(id,merchantCost,status,auditRemark,sysUser.getId());
            }else{
                manualOrderService.auditManualOrder(id,status,auditRemark,sysUser.getId());
            }

        } catch (ManualOrderException e) {
            return new ResponseResult(ResponseCode.FAIL, String.format("审核失败：%s",e.getMessage()), null);
        } catch (FundException e) {
            return new ResponseResult(ResponseCode.FAIL, String.format("审核失败：%s",e.getMessage()), null);
        }
        return new ResponseResult(ResponseCode.SUCCESS, AuditStatusEnum.SUCCESS.name().equals(status)?"审核成功！":"驳回成功！", null);
    }


    @RequestMapping("/to_process/{id}")
    @OperationAuth(name = "订单处理", authCode = "manual_order.process", group = "手工订单")
    public String toProcessManualOrder(@PathVariable("id") Integer id, Model model){
        Map<String,String> bizTypeMap = Arrays.stream(ManualBizTypeEnum.values()).collect(Collectors.toMap(ManualBizTypeEnum::name, r -> r.getDesc()));
        model.addAttribute("bizTypeMap", bizTypeMap);
        Map<String,String> targetMap = Arrays.stream(ManualOrderTarge.values()).collect(Collectors.toMap(ManualOrderTarge::name, r -> r.getDesc()));
        model.addAttribute("targetMap", targetMap);
        ManualOrder manualOrder = manualOrderService.selectByPrimaryKey(id);
        model.addAttribute("manualOrder",manualOrder);
        setAccount(manualOrder);
        return "/admin/manual_order/process";
    }

    @RequestMapping("/process")
    @ResponseBody
    @OperationAuth(name = "订单处理", authCode = "manual_order.process", group = "手工订单")
    @LogOperation(name = "处理订单",module = "手工订单管理")
    public ResponseResult processManualOrder(HttpServletRequest request,Integer id,String status,String processRemark){
        ManualOrder manualOrder = manualOrderService.selectByPrimaryKey(id);
        if(OrderStatusEnum.PROCESSING!= OrderStatusEnum.valueOf(manualOrder.getStatus())){
            return new ResponseResult(ResponseCode.FAIL, String.format("该订单已经处理完成!"), null);
        }
        SysUser sysUser = AdminUserUtils.getCurrentLoginUser(request);
        final String requestId = System.currentTimeMillis() + "";
        int merchantId = manualOrder.getMerchantId()!=0?manualOrder.getMerchantId():manualOrder.getChannelAccountId();
        try {

            boolean lock = merchantLock.getLock(merchantId, requestId);
            if (!lock) {
                throw new ManualOrderException("获取账户资金锁失败.请重试");
            }
            manualOrderService.processManualOrder(id,status,processRemark,sysUser.getId());
        } catch (ManualOrderException e) {
            return new ResponseResult(ResponseCode.FAIL, String.format("操作失败：%s",e.getMessage()), null);
        } finally {

        merchantLock.releaseLock(merchantId, requestId);
        }
        return new ResponseResult(ResponseCode.SUCCESS, "操作成功！", null);
    }


    @RequestMapping("/toAddSupplierProfitSettlementOrder")
    public String toAddSupplierProfitSettlementOrder(Model model,HttpServletRequest request) throws IOException {
        SysUser sysUser = AdminUserUtils.getCurrentLoginUser(request);
        ChannelAccount channelAccount = channelAccountService.findByUserId(sysUser.getId());
        AssertUtils.objectNotNull(channelAccount,"找不到当前合作商的合作通道！");
        ChannelAccountInstance channelAccountInstance = channelAccountInstanceService.getByAccount(channelAccount.getId());
        Long totalProfit = channelAccountInstance.getPaymentCostTotal()==null?0:channelAccountInstance.getPaymentCostTotal();
        Long drawedSupplierProfitTotal = channelAccountInstance.getDrawedSupplierProfitTotal()==null?0:channelAccountInstance.getDrawedSupplierProfitTotal();
        Long balance = totalProfit-drawedSupplierProfitTotal;

        model.addAttribute("totalProfit", totalProfit);
        model.addAttribute("drawedSupplierProfitTotal", drawedSupplierProfitTotal);
        model.addAttribute("balance", balance);

        Merchant merchant = merchantService.findByUserId(sysUser.getId());
        model.addAttribute("merchant", merchant);

        return "/admin/manual_order/add_supplier_profit_settlement_order";
    }


    @RequestMapping("/addSupplierProfitSettlementOrder")
    @ResponseBody
    public ResponseResult addSupplierProfitSettlementOrder(HttpServletRequest request, ManualOrder order, Model model) throws IOException {

        String error = ValidationUtils.validate(order);
        if(StringUtils.isNotEmpty(error)){
            return new ResponseResult(ResponseCode.FAIL, "创建失败！"+error, null);
        }

        SysUser sysUser = AdminUserUtils.getCurrentLoginUser(request);
        ChannelAccount channelAccount = channelAccountService.findByUserId(sysUser.getId());
        AssertUtils.objectNotNull(channelAccount,"找不到当前合作商的合作通道！");
        ChannelAccountInstance channelAccountInstance = channelAccountInstanceService.getByAccount(channelAccount.getId());
        Long totalProfit = channelAccountInstance.getPaymentCostTotal()==null?0:channelAccountInstance.getPaymentCostTotal();
        Long drawedSupplierProfitTotal = channelAccountInstance.getDrawedSupplierProfitTotal()==null?0:channelAccountInstance.getDrawedSupplierProfitTotal();
        Long balance = totalProfit-drawedSupplierProfitTotal;

        model.addAttribute("totalProfit", totalProfit);
        model.addAttribute("drawedSupplierProfitTotal", drawedSupplierProfitTotal);
        model.addAttribute("balance", balance);

        Assert.isTrue(MoneyUtils.yuan2fee(order.getAmount()).intValue()<balance*100,"本次结算金额超出未结算余额！");

        try {
            initManualOrder(request, order);
            order.setChannelAccountId(channelAccount.getId());
        } catch (ManualOrderException e) {
            return new ResponseResult(ResponseCode.FAIL, String.format("创建失败:%s",e.getMessage()), null);
        }

        manualOrderService.createManualOrder(order);


        notifyComponent.notifyByAuthority("manual_order.audit","您有一条新的手工订单待审核");

        return new ResponseResult(ResponseCode.SUCCESS, "创建成功！", null);
    }

}
