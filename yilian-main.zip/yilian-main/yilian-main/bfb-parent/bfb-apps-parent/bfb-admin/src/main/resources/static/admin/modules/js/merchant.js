var merchant = {};

merchant.delMerchant = function (merchantId) {
    layer.confirm(
        "确定要删除吗?",
        {icon: 0, title:'提示'},
        function(index, layero){
            layer.close(index);
            window.location.href = getWebPath() + "/admin/merchant/delete/" + merchantId ;
        }
    );
}
merchant.otddelMerchant = function (merchantId) {
    layer.confirm(
        "确定要删除吗?",
        {icon: 0, title:'提示'},
        function(index, layero){
            layer.close(index);
            window.location.href = getWebPath() + "/admin/otc_merchant/delete/" + merchantId ;
        }
    );
}

/**
 * 设置页面，切换通道状态
 * @param id
 */
merchant.switchStatus = function (el, id) {
    var isChecked = $(el).prop('checked');
    var switchActionUrl = getWebPath() + '/admin/merchant/turn_off/' + id;

    $("#switch_" + id).html("关");
    if (isChecked) {
        switchActionUrl = getWebPath() + '/admin/merchant/turn_on/' + id;
        $("#switch_" + id).html("开");
    }

    $.ajax({
        type : "POST", //提交方式
        url : switchActionUrl,//路径
        data : {},
        success : function(result) {//返回数据根据结果进行相应的处理
            new $.zui.Messager(result.message, {
                type: 'success' // 定义颜色主题
            }).show();
        }
    });
}
/**
 * 设置页面，切换通道状态
 * @param id
 */
merchant.otcSwitchStatus = function (el, id) {
    var isChecked = $(el).prop('checked');
    var switchActionUrl = getWebPath() + '/admin/otc_merchant/turn_off/' + id;

    $("#switch_" + id).html("关");
    if (isChecked) {
        switchActionUrl = getWebPath() + '/admin/otc_merchant/turn_on/' + id;
        $("#switch_" + id).html("开");
    }

    $.ajax({
        type : "POST", //提交方式
        url : switchActionUrl,//路径
        data : {},
        success : function(result) {//返回数据根据结果进行相应的处理
            new $.zui.Messager(result.message, {
                type: 'success' // 定义颜色主题
            }).show();
        }
    });
}

var monitor={};

monitor.switchStatus = function (el, id) {
    var isChecked = $(el).prop('checked');
    var switchActionUrl = getWebPath() + '/admin/system/merchant/turn_off/' + id;

    $("#switch_" + id).html("关");
    if (isChecked) {
        switchActionUrl = getWebPath() + '/admin/system/merchant/turn_on/' + id;
        $("#switch_" + id).html("开");
    }

    $.ajax({
        type : "POST", //提交方式
        url : switchActionUrl,//路径
        data : {},
        success : function(result) {//返回数据根据结果进行相应的处理
            new $.zui.Messager(result.message, {
                type: 'success' // 定义颜色主题
            }).show();
        }
    });
}
