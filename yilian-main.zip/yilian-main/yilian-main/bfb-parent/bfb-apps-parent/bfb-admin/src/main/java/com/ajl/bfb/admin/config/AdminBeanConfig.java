package com.ajl.bfb.admin.config;

import com.hippo.framework.util.SnowflakeIdWorker;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;


@Configuration
public class AdminBeanConfig {

    @Bean
    public SnowflakeIdWorker getSnowflakeIdWorker() {
        SnowflakeIdWorker idWorker = new SnowflakeIdWorker(0, 0);
        return idWorker;
    }

}
