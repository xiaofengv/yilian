package com.ajl.bfb.admin.config;

import com.ajl.bfb.admin.common.web.AdminSessionKey;
import com.ajl.bfb.admin.sys.servlet.BarCode2DServlet;
import com.hippo.framework.web.servlet.AuthImageServlet;
import com.hippo.framework.web.servlet.ParameterFilter;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;


/**
 * Created by admin on 2018-02-15 0015.
 */
@Configuration
public class ServletConfig {

    @Bean("loginVerifyCodeImgServlet")
    public ServletRegistrationBean loginVerifyCodeImgRegistration() {
        ServletRegistrationBean registration = new ServletRegistrationBean(new AuthImageServlet());
        registration.addUrlMappings("/admin-login-verifycode");
        registration.addInitParameter("height", "30");
        registration.addInitParameter("width", "80");
        registration.addInitParameter("key", AdminSessionKey.LOGIN_VERIFY_CODE);
        registration.setName("loginVerifyCodeImgServlet");
        return registration;
    }


    @Bean("qrCodeImgServlet")
    public ServletRegistrationBean loginQrVerifyCodeImgRegistration() {
        ServletRegistrationBean registration = new ServletRegistrationBean(new BarCode2DServlet());
        registration.addUrlMappings("/qr_code_image");
        registration.setName("qrCodeImgServlet");
        return registration;
    }


    @Bean
    public FilterRegistrationBean indexFilterRegistration() {
        FilterRegistrationBean registration = new FilterRegistrationBean(new ParameterFilter());
        registration.addUrlPatterns("/*");
        registration.setOrder(0);
        return registration;
    }

}
