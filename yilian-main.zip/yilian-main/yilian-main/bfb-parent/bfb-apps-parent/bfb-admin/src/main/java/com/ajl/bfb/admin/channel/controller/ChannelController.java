package com.ajl.bfb.admin.channel.controller;

import com.ajl.bfb.admin.channel.util.ChannelViewUtils;
import com.ajl.bfb.admin.channel.vo.ChannelVO;
import com.ajl.bfb.core.constants.BankCodeEnum;
import com.ajl.bfb.repo.channel.model.Channel;
import com.ajl.bfb.repo.channel.model.ChannelQuery;
import com.ajl.bfb.repo.channel.service.IChannelService;
import com.ajl.bfb.repo.merchant.model.Merchant;
import com.ajl.bfb.repo.merchant.service.IAgentService;
import com.google.gson.JsonParseException;
import com.google.gson.JsonParser;
import com.hippo.framework.auth.admin.OperationAuth;
import com.hippo.framework.core.enums.SwitchEnum;
import com.hippo.framework.operation.log.LogOperation;
import com.hippo.framework.web.ResponseCode;
import com.hippo.framework.web.ResponseResult;
import org.apache.commons.lang3.EnumUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;


@Controller
@RequestMapping(value = "/admin/channel")
public class ChannelController {
    @Autowired
    private IChannelService channelService;
    @Autowired
    private IAgentService agentService;

    @RequestMapping(value = "/list")
    @OperationAuth(name = "查询通道", authCode = "channel.query", group = "通道管理")
    public String toChannelList(Model model, ChannelQuery channel) {
        List<Channel> channels = channelService.findChannels(channel);
        List<ChannelVO> channelVOS = ChannelViewUtils.toVO(channels);
        model.addAttribute("channels", channelVOS);
        model.addAttribute("queryParam",channel);
        List<Merchant> introducerList = agentService.findAll();
        Map<Integer,Merchant> introducerMap = introducerList.stream().collect(Collectors.toMap(Merchant::getId,m -> m));
        model.addAttribute("introducerMap", introducerMap);
        return "admin/channel/list";
    }


    @RequestMapping(value = "/get_channels")
    @ResponseBody
    public List<Channel> getChannels(ChannelQuery channel) {
        List<Channel> channels = channelService.findChannels(channel);
        return channels;
    }

    @RequestMapping(value = "/turn_on/{id}")
    @ResponseBody
    @OperationAuth(name = "通道开关", authCode = "channel.onOrOff", group = "通道管理")
    @LogOperation(name = "开启通道",module = "通道管理")
    public ResponseResult turnOn(@PathVariable("id") int id) {
        channelService.updateStatus(id, SwitchEnum.ON);
        return new ResponseResult(ResponseCode.SUCCESS, "修改成功", null);
    }

    @RequestMapping(value = "/turn_off/{id}")
    @ResponseBody
    @OperationAuth(name = "通道开关", authCode = "channel.onOrOff", group = "通道管理")
    @LogOperation(name = "关闭通道",module = "通道管理")
    public ResponseResult turnOff(@PathVariable("id") int id) {
        channelService.updateStatus(id, SwitchEnum.OFF);
        return new ResponseResult(ResponseCode.SUCCESS, "修改成功", null);
    }

    @RequestMapping(value = "/to_add")
    @OperationAuth(name = "添加通道", authCode = "channel.add", group = "通道管理")
    public String toAddChannel(Model model) {
        //上游介绍人
        List<Merchant> introducerList = agentService.findAll();
        model.addAttribute("introducerList", introducerList);
        List<BankCodeEnum> banks = EnumUtils.getEnumList(BankCodeEnum.class);
        model.addAttribute("banks", banks);
        return "admin/channel/add";
    }

    @RequestMapping(value = "/to_update/{id}")
    @OperationAuth(name = "修改通道", authCode = "channel.update", group = "通道管理")
    public String toUpdateChannel(Model model, @PathVariable("id") int id) {
        //上游介绍人
        List<Merchant> introducerList = agentService.findAll();
        model.addAttribute("introducerList", introducerList);
        List<BankCodeEnum> banks = EnumUtils.getEnumList(BankCodeEnum.class);
        model.addAttribute("banks", banks);
        Channel channel = channelService.findChannelById(id);
        ChannelVO channelVO = ChannelViewUtils.toVO(channel);
        model.addAttribute("channel", channelVO);
        return "admin/channel/update";
    }

    @RequestMapping(value = "/add_channel")
    @ResponseBody
    @OperationAuth(name = "添加通道", authCode = "channel.add", group = "通道管理")
    @LogOperation(name = "添加通道",module = "通道管理")
    public ResponseResult addChannel(ChannelVO channel, Model model) {
        Integer channelId = null;
        String other = channel.getOther();
        if (!isJson(other)){
            return new ResponseResult(ResponseCode.FAIL, "其他信息格式错误!", channelId);
        }
        channel.setOther(trimComma(other));
        if (Objects.isNull(channel.getId())) {
            channelId = channelService.insert(channel);
        } else {
            channel.setUpdateTime(new Date());
            channelService.update(channel);
        }
        return new ResponseResult(ResponseCode.SUCCESS, "保存成功!", channelId);
    }



    @RequestMapping(value = "/update_channel")
    @ResponseBody
    @OperationAuth(name = "修改通道", authCode = "channel.update", group = "通道管理")
    public ResponseResult updateChannel(ChannelVO channel, Model model) {
        String other = channel.getOther();
        if (!isJson(other)){
            return new ResponseResult(ResponseCode.FAIL, "其他信息格式错误!", null);
        }
        channel.setOther(trimComma(other));
        channel.setUpdateTime(new Date());
        channelService.update(channel);
        return new ResponseResult(ResponseCode.SUCCESS, "保存成功!", null);
    }

    @RequestMapping(value = "/delete/{id}")
    @OperationAuth(name = "删除通道", authCode = "channel.delete", group = "通道管理")
    @LogOperation(name = "删除通道",module = "通道管理")
    public String deleteChannel(@PathVariable("id") int id, Model model) {
        channelService.delete(id);
        return toChannelList(model, new ChannelQuery());
    }


    private String trimComma(String json) {
        if(StringUtils.isNotEmpty(json)){
            String beforComma = String.valueOf(json.charAt(1));
            StringBuffer sb = new StringBuffer(json);
            if (",".equals(beforComma)){
                sb = sb.deleteCharAt(1);
            }
            String afterComma = String.valueOf(json.charAt(json.length()-3));
            if (",".equals(afterComma)){
                sb = sb.deleteCharAt(sb.length()-3);
            }
            return sb.toString();
        }else{
            return "";
        }
    }
    private  boolean isJson(String json) {
        if (StringUtils.isBlank(json)) {
            return true;
        }
        try {
            new JsonParser().parse(json);
            return true;
        } catch (JsonParseException e) {
            return false;
        }
    }

}
