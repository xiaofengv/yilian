package com.ajl.bfb.admin.channelaccount.controller;

import com.ajl.bfb.admin.channel.util.ChannelViewUtils;
import com.ajl.bfb.admin.channelaccount.util.ChannelAccountViewUtils;
import com.ajl.bfb.admin.channelaccount.vo.ChannelAccPayTypeVO;
import com.ajl.bfb.admin.channelaccount.vo.ChannelAccountVO;
import com.ajl.bfb.admin.channelpaytype.util.ChannelPayTypeViewUtils;
import com.ajl.bfb.admin.channelpaytype.vo.ChannelPayTypeVO;
import com.ajl.bfb.core.constants.ClearCycleEnum;
import com.ajl.bfb.core.constants.PaymentTypeEnum;
import com.ajl.bfb.core.constants.ReadyStatusEnum;
import com.ajl.bfb.core.constants.WithdrawCostModeEnum;
import com.ajl.bfb.core.util.MoneyUtils;
import com.ajl.bfb.core.util.RateUtils;
import com.ajl.bfb.repo.channel.model.*;
import com.ajl.bfb.repo.channel.service.IChannelAccPayTypeService;
import com.ajl.bfb.repo.channel.service.IChannelAccountService;
import com.ajl.bfb.repo.channel.service.IChannelPayTypeService;
import com.ajl.bfb.repo.channel.service.IChannelService;
import com.ajl.bfb.repo.channelstat.service.IChannelAccountInstanceService;
import com.ajl.bfb.repo.fund.service.IFinanceFacadeService;
import com.hippo.framework.auth.admin.OperationAuth;
import com.hippo.framework.core.enums.OpenStatusEnum;
import com.hippo.framework.core.enums.SwitchEnum;
import com.hippo.framework.operation.log.LogOperation;
import com.hippo.framework.web.ResponseCode;
import com.hippo.framework.web.ResponseResult;
import org.apache.commons.lang3.EnumUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Collectors;


@Controller
@RequestMapping(value = "/admin/channel_account")
public class ChannelAccountController {
    @Autowired
    private IChannelAccountService channelAccountService;
    @Autowired
    private IChannelService channelService;
    @Autowired
    private IChannelPayTypeService channelPayTypeService;
    @Autowired
    private IChannelAccPayTypeService channelAccPayTypeService;
    @Autowired
    private IChannelAccountInstanceService channelAccountInstanceService;
    @Autowired
    private IFinanceFacadeService financeFacadeService;

    @RequestMapping(value = "/list/{channelId}")
    @OperationAuth(name = "通道号管理", authCode = "channel.channelNumberManagement", group = "通道管理")
    public String toList(@PathVariable("channelId")int channelId, Model model,ChannelAccount channelAccount){
        List<ChannelAccount> accounts = channelAccountService.findChannelAccounts(channelAccount);
        List<ChannelAccountVO> accountsVO = ChannelAccountViewUtils.toVO(accounts);
        List<ReadyStatusEnum> status = EnumUtils.getEnumList(ReadyStatusEnum.class);
        Map<String,ReadyStatusEnum> statusMap = EnumUtils.getEnumMap(ReadyStatusEnum.class);
        model.addAttribute("status",status);
        model.addAttribute("statusMap",statusMap);
        Channel channel = channelService.findChannelById(channelId);
        model.addAttribute("channelId",channelId);
        model.addAttribute("channel",channel);
        model.addAttribute("accounts",accountsVO);
        return "admin/channel_account/list";
    }

    @RequestMapping(value = "/rate_setting/{accountId}")
    public String toRateSetting(@PathVariable("accountId")int accountId, Model model) {
        //把渠道的支付方式信息捞出来，
        ChannelAccount acc = channelAccountService.findById(accountId);
        List<ChannelPayType> channelPayTypes = channelPayTypeService.findByChannelId(acc.getChannelId());
        Map<String, ChannelPayType> channelPayTypeMap = channelPayTypes.stream().collect(Collectors.toMap(ChannelPayType::getPayTypeCode, t -> t));

        List<ChannelAccPayType> accPayTypes = channelAccPayTypeService.findByAccountAndStatus(accountId,SwitchEnum.ON.name());
        //只显示渠道上是开启状态的
        List<ChannelAccPayTypeVO> vos = new ArrayList<>();
        for (ChannelAccPayType accPayType : accPayTypes) {
            ChannelPayType channelPayType = channelPayTypeMap.get(accPayType.getPayTypeCode());
            if (channelPayType.getStatus().equals(SwitchEnum.ON.name())) {
                ChannelAccPayTypeVO vo = new ChannelAccPayTypeVO();
                BeanUtils.copyProperties(accPayType, vo);
                vo.setRatePercent(RateUtils.rate2percent(accPayType.getRate()));
                vo.setChannelPayTypeRatePercent(RateUtils.rate2percent(channelPayType.getChannelRate()));
                vo.setMinAmount(accPayType.getMinAmount());
                vo.setMaxAmount(accPayType.getMaxAmount());
                vos.add(vo);
            }
        }
        model.addAttribute("accPayTypes", vos);
        return "/admin/channel/acc_pay_type_setting";
    }

    @RequestMapping(value = "/update_rate/{accPayTypeId}")
    @ResponseBody
    @LogOperation(name = "通道费率设置",module = "通道管理")
    @OperationAuth(name = "通道费率设置", authCode = "channel.update_rate", group = "通道管理")
    public ResponseResult updateRate(@PathVariable("accPayTypeId")int accPayTypeId, BigDecimal rate,BigDecimal rateByTime,BigDecimal introducerRate) {
        if (rate == null) {
            return new ResponseResult(ResponseCode.FAIL, "请填写费率", null);
        }
        channelAccPayTypeService.updateRate(accPayTypeId, RateUtils.percent2rate(rate), MoneyUtils.yuan2fee(rateByTime).intValue(),RateUtils.percent2rate(introducerRate));

        return new ResponseResult(ResponseCode.SUCCESS, "修改成功", null);
    }

    @RequestMapping(value = "/update_quota/{accPayTypeId}")
    @ResponseBody
    @LogOperation(name = "通道限额设置",module = "通道管理")
    @OperationAuth(name = "通道限额设置", authCode = "channel.update_quota", group = "通道管理")
    public ResponseResult updateQuota(@PathVariable("accPayTypeId")int accPayTypeId, BigDecimal minAmount, BigDecimal maxAmount,String isWholeHundred,String fixedAmount) {
        if (isWholeHundred.equals("Y") || isWholeHundred.equals("X")){
            if (minAmount == null) {
                return new ResponseResult(ResponseCode.FAIL, "请填写最小限额", null);
            }
            if (maxAmount == null) {
                return new ResponseResult(ResponseCode.FAIL, "请填写最大限额", null);
            }
            //页面是元，要转成万分比； 最大，最小限额转成分
            channelAccPayTypeService.updateQuota(accPayTypeId,MoneyUtils.yuan2fee(minAmount).intValue(),MoneyUtils.yuan2fee(maxAmount).intValue(),isWholeHundred);
        }else{
            channelAccPayTypeService.updateFixedAmount(accPayTypeId,fixedAmount);
        }

        return new ResponseResult(ResponseCode.SUCCESS, "修改成功", null);
    }


    @RequestMapping(value = "/list_lowarea")
    @OperationAuth(name = "低额区收款号查询", authCode = "channel.LowFrontalAreaQuery", group = "通道管理")
    public String toList(Model model,ChannelAccount channelAccount){
        //查询低额收款号
        channelAccount.setIsLowArea(OpenStatusEnum.Y.name());
        List<ChannelAccount> accounts = channelAccountService.findChannelAccounts(channelAccount);
        List<ChannelAccountVO> channelAccountVOS = toAccountVO(accounts, false);
        model.addAttribute("accounts",channelAccountVOS);
        model.addAttribute("status",EnumUtils.getEnumList(ReadyStatusEnum.class));
        return "admin/channel_account/list_lowarea";
    }

    /**
     * 获取所有可用代付渠道和所有代付渠道
     * @param accounts
     * @param withBalance
     * @return
     */
    public List<ChannelAccountVO> toAccountVO(List<ChannelAccount> accounts, boolean withBalance) {
        List<Channel> channels = channelService.findChannels(new ChannelQuery());
        Map<Integer,String> channelMap = channels.stream().collect(Collectors.toMap(Channel::getId,Channel::getName));
        List<ChannelAccountVO> channelAccountVOS = ChannelAccountViewUtils.toVO(accounts);
        for (ChannelAccountVO acc : channelAccountVOS) {
            acc.setChannelName(channelMap.get(acc.getChannelId()));
            if (withBalance) {
                long channelAccCashBalance = financeFacadeService.getChannelAccCashBalance(acc.getId());
                ChannelAccPayType accPayType = channelAccPayTypeService.findByPaymentType(acc.getId(), PaymentTypeEnum.WITHDRAW);
                acc.setCashBalance(channelAccCashBalance);
                acc.setWithdrawRate(accPayType.getRateByTime());
            }
        }
        return channelAccountVOS;
    }

    @RequestMapping(value = "/to_add/{id}")
    @OperationAuth(name = "添加收款号", authCode = "channel_account.add_channel_account", group = "通道管理")
    public String toAdd(@PathVariable("id")int channelId, Model model){
        model.addAttribute("channelId",channelId);
        Channel channel = channelService.findChannelById(channelId);
        model.addAttribute("channel",ChannelViewUtils.toVO(channel));
        List<ChannelPayType> paymentTypes = channelPayTypeService.findByChannelId(channelId);
        //分组一下
        List<ChannelPayTypeVO> channelPayTypeVOS = ChannelPayTypeViewUtils.toVO(paymentTypes);
        Map<String, List<ChannelPayTypeVO>> channelTypeGroup = channelPayTypeVOS.stream().collect(Collectors.groupingBy(ChannelPayTypeVO::getChannelType));

        Map<String,PaymentTypeEnum> paymentMap =  EnumUtils.getEnumMap(PaymentTypeEnum.class);
        model.addAttribute("channelTypeGroup",channelTypeGroup);
        model.addAttribute("paymentMap",paymentMap);
        model.addAttribute("clearCycleList", ClearCycleEnum.values());
        model.addAttribute("withdrawCostModeList", WithdrawCostModeEnum.values());
        return "admin/channel_account/add";
    }

    @RequestMapping(value = "/to_update/{channelId}/{accountId}")
    public String toUpdate(@PathVariable("channelId")int channelId,@PathVariable("accountId")int accountId, Model model){
        model.addAttribute("channelId",channelId);
        Channel channel = channelService.findChannelById(channelId);
        model.addAttribute("channel",ChannelViewUtils.toVO(channel));
        ChannelAccount channelAccount = channelAccountService.findById(accountId);
        ChannelAccountVO channelAccountVO = ChannelAccountViewUtils.toVO(channelAccount);
        List<ChannelPayType> paymentTypes = channelPayTypeService.findByChannelId(channelId);
        Map<String,PaymentTypeEnum> paymentMap =  EnumUtils.getEnumList(PaymentTypeEnum.class).stream().collect(Collectors.toMap(PaymentTypeEnum::name,paymentTypeEnum -> paymentTypeEnum));
        model.addAttribute("clearCycleList", ClearCycleEnum.values());
        model.addAttribute("rateModes",OpenStatusEnum.values());
        model.addAttribute("paymentTypes",paymentTypes);
        model.addAttribute("paymentMap",paymentMap);
        model.addAttribute("channelAccount",channelAccountVO);
        model.addAttribute("withdrawCostModeList",WithdrawCostModeEnum.values());
        return "admin/channel_account/update";
    }


    @RequestMapping(value = "/update/{accountId}")
    @ResponseBody
    @OperationAuth(name = "修改收款号", authCode = "channel_account.update", group = "通道管理")
    public ResponseResult updateChannelAccount(Model model, ChannelAccountVO channelAccount){
        if (channelAccount.getPayments() == null || channelAccount.getPayments().isEmpty()) {
            return new ResponseResult(ResponseCode.FAIL, "请选择支持的支付方式", null);
        }


        channelAccountService.update(channelAccount);
        return new ResponseResult(ResponseCode.SUCCESS, "保存成功!", null);
    }

    @RequestMapping(value = "/update_status")
    @ResponseBody
    @OperationAuth(name = "收款号开关", authCode = "channel_account.update_status", group = "通道管理")
    public ResponseResult updateStatus(@RequestBody ChannelAccountRequstParam requstParam){
        if(!EnumUtils.isValidEnum(ReadyStatusEnum.class,requstParam.getStatus().toUpperCase())){
            throw new RuntimeException("状态不存在!");
        }
        for (int accountId: requstParam.getAccounts()) {
            channelAccountService.updateStatus(accountId, ReadyStatusEnum.valueOf(requstParam.getStatus()));
        }
        return new ResponseResult(ResponseCode.SUCCESS, "状态设置成功!", null);

    }

    @RequestMapping("update_low_area")
    @ResponseBody
    @OperationAuth(name = "低额区管理", authCode = "channel_account.update_low_area", group = "通道管理")
    public ResponseResult updateLowArea(@RequestBody ChannelAccountRequstParam requstParam){
        channelAccountService.updateLowArea(requstParam.getAccounts(), OpenStatusEnum.valueOf(requstParam.getIsLowArea()));
        return new ResponseResult(ResponseCode.SUCCESS, "设置成功!", null);
    }

    @RequestMapping(value = "/add/{channelId}")
    @ResponseBody
    @OperationAuth(name = "添加收款号", authCode = "channel_account.add_channel_account", group = "通道管理")
    public ResponseResult addChannelAccount(@PathVariable("channelId")int channelId, Model model,
                                            ChannelAccountVO channelAccount){
        if (channelAccount.getPayments() == null || channelAccount.getPayments().isEmpty()) {
            return new ResponseResult(ResponseCode.FAIL, "请选择支持的支付方式", null);
        }
        Channel channel = channelService.findChannelById(channelAccount.getChannelId());
        if(Channel.ChannelType.WITHDRAW.equals(channel.getType())){
            channelAccount.setIncomeTotalMax(0L);
            channelAccount.setDayMaxCount(0);
            channelAccount.setDayMaxAmount(0L);
        }
        channelAccountService.insert(channelAccount);
        return new ResponseResult(ResponseCode.SUCCESS, "保存成功!", null);
    }

    @RequestMapping("/delete/{channelId}/{id}")
    @OperationAuth(name = "删除收款号", authCode = "channel_account.delete", group = "通道管理")
    public String deleteById(@PathVariable("channelId")int channelId,@PathVariable("id")int id){
        channelAccountService.delete(id);
        return "forward:/admin/channel_account/list/"+channelId;
    }

    @RequestMapping("/balance/{accId}")
    @OperationAuth(name = "收款号资金详情", authCode = "channel_account.balance", group = "通道管理")
    public String balance(@PathVariable("accId")int accId, Model model){
        ChannelAccountDetail accDetail = channelAccountInstanceService.getMerchantAccountDetail(accId);
        ChannelAccount channelAcc = channelAccountService.findById(accId);
        model.addAttribute("accDetail", accDetail);
        model.addAttribute("channelAcc", channelAcc);
        return "/admin/channel_account/channel_acc_detail";
    }

}
