var PaymentOrder = {};

$(function () {
  hippo.limitInteger('amount');
});

PaymentOrder.syncOrderStatus = function (orderId) {
    var actionUrl = getWebPath() + "/merchant_admin/payment_order/sync_order_status/" + orderId;
    $.ajax({
        type : "POST", //提交方式
        url : actionUrl,//路径
        data : {},
        success : function(result) {//返回数据根据结果进行相应的处理
            hippo.msg(result.message);
        }
    });
}

PaymentOrder.export = function () {
    $('#searchForm').attr("action",getWebPath() + "/merchant_admin/payment_order/export");
    $('#searchForm').submit();
}

PaymentOrder.search = function () {
    $('#searchForm').attr("action",getWebPath() + "/merchant_admin/payment_order/list");
    $('#searchForm').submit();
}

PaymentOrder.notifyMerchant = function (platformOrderNo) {
    var actionUrl = getWebPath() + "/merchant_admin/payment_order/notify_merchant/" + platformOrderNo;
    $.ajax({
        type : "POST", //提交方式
        url : actionUrl,//路径
        data : {},
        success : function(result) {//返回数据根据结果进行相应的处理
            hippo.msg(result.message);
        }
    });
}