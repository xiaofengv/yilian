package com.ajl.bfb.admin.report.controller;

import com.ajl.bfb.core.constants.MerchantUserTypeEnum;
import com.ajl.bfb.repo.channel.service.IChannelAccountService;
import com.ajl.bfb.repo.merchant.model.Merchant;
import com.ajl.bfb.repo.merchant.model.MerchantAccountDetail;
import com.ajl.bfb.repo.merchant.model.MerchantFindParam;
import com.ajl.bfb.repo.merchant.service.IMerchantAccountService;
import com.ajl.bfb.repo.merchant.service.IMerchantService;
import com.ajl.bfb.repo.stat.model.QueryMerchantAccountParam;
import org.apache.http.HttpRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;


@Controller
@RequestMapping("/admin/report")
public class IntroducerReportController {
    @Autowired
    private IMerchantService merchantService;

    @Autowired
    private IMerchantAccountService merchantAccountService;

    @Autowired
    IChannelAccountService channelAccountService;


    @RequestMapping("/introducer_user_balance")
//    @OperationAuth(name = "用户余额报表", authCode = "platform.userBalanceReport", group = "平台报表")
    public String platmentUserBalance(QueryMerchantAccountParam queryParam, Model model, HttpRequest request){
        MerchantFindParam findParam = new MerchantFindParam();
        findParam.setUserType(MerchantUserTypeEnum.AGENT);
        List<Merchant> merchants = merchantService.findAllMerchant(findParam);
        Map<Integer,Merchant> merchantMap = merchants.stream().collect(Collectors.toMap(Merchant::getId,t->t));
        List<MerchantAccountDetail> merchantAccountDetails = new ArrayList<>();
        for (Merchant merchant : merchants) {
            MerchantAccountDetail merchantAccountDetail = merchantAccountService.getMerchantAccountDetail(merchant.getId());
            merchantAccountDetails.add(merchantAccountDetail);
        }

        model.addAttribute("merchantAccountDetails",merchantAccountDetails);
        model.addAttribute("merchantMap",merchantMap);
        return "/admin/report/introducer/introducerBalanceReport";
    }

}
