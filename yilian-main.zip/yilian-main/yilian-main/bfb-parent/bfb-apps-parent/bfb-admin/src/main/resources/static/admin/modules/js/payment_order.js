var PaymentOrder = {};

var MonitoringPaymentOrder={};

$(function () {
    hippo.limitInteger('amount');
});

PaymentOrder.syncOrderStatus = function () {
    var orderId = $('input[type=checkbox]:checked').data("id");
    var actionUrl = getWebPath() + "/admin/payment_order/sync_order_status/" + orderId;
    $.ajax({
        type : "POST", //提交方式
        url : actionUrl,//路径
        data : {},
        success : function(result) {//返回数据根据结果进行相应的处理
            hippo.msg(result.message);
        }
    });
}

PaymentOrder.export = function () {
    $('#searchForm').attr("action",getWebPath() + "/admin/payment_order/export");
    $('#searchForm').submit();
}

PaymentOrder.search = function (obj) {
    if (obj == 1){
        console.log("shrinkSearchForm查询")
        $('#shrinkSearchForm').attr("action",getWebPath() + "/admin/payment_order/list");
        $('#shrinkSearchForm').submit();
    }else {
        console.log("searchForm查询")
        $('#searchForm').attr("action",getWebPath() + "/admin/payment_order/list");
        $('#searchForm').submit();
    }
}
PaymentOrder.questionOrderSearch = function (obj) {
    if (obj == 1){
        console.log("shrinkSearchForm查询")
        $('#shrinkSearchForm').attr("action",getWebPath() + "/admin/payment_order/questionList");
        $('#shrinkSearchForm').submit();
    }else {
        console.log("searchForm查询")
        $('#searchForm').attr("action",getWebPath() + "/admin/payment_order/questionList");
        $('#searchForm').submit();
    }
}
PaymentOrder.open = function (obj){
    console.log(obj);
    if (obj == 1){
        console.log("searchForm展开")
        $('#searchForm').show();
        $('#shrinkSearchForm').hide();
    }else{
        console.log("shrinkSearchForm展开")
        $('#shrinkSearchForm').show();
        $('#searchForm').hide()
    }

}

PaymentOrder.updateOrderStatus = function (orderId,status) {
    var showmsg="";
    if("SUCCESS"==status){
        showmsg="确定修改订单为成功状态？";
    }else{
        showmsg="确定修改订单为失败状态？";
    }
    layer.confirm(
        showmsg,
        {icon: 0, title:'提示'},
        function(index, layero){
            layer.close(index);
            var actionUrl = getWebPath() + "/admin/payment_order/update_order_status/" + orderId;
            $.ajax({
                type : "POST", //提交方式
                url : actionUrl,//路径
                data : {"status":status},
                success : function(result) {//返回数据根据结果进行相应的处理
                    hippo.msg(result.message);
                    if(result.statusCode=="SUCCESS"){
                        setTimeout((function() {
                            $("#searchForm").submit();
                        }), 2000);
                    }

                }
            });
        }
    );
}

PaymentOrder.notifyMerchant = function () {
    var platformOrderNo = $('input[type=checkbox]:checked').data("orderno");
    var actionUrl = getWebPath() + "/admin/payment_order/notify_merchant/" + platformOrderNo;
    $.ajax({
        type : "POST", //提交方式
        url : actionUrl,//路径
        data : {},
        success : function(result) {//返回数据根据结果进行相应的处理
            hippo.msg(result.message);
        }
    });
}
PaymentOrder.updateAmount = function () {
    var platformOrderNo = $('input[type=checkbox]:checked').data("orderno");
    console.log(platformOrderNo);
    layer.prompt({
        formType: 0,
        value: 0,
        title: '请输入收款金额'
    }, function(value, index, elem){
        layer.close(index);
        var actionUrl = getWebPath() + "/admin/payment_order/updateAmount/" + platformOrderNo+"?updateAmount="+value;
        $.ajax({
            type : "POST", //提交方式
            url : actionUrl,//路径
            data : {"status":status},
            success : function(result) {//返回数据根据结果进行相应的处理
                hippo.msg(result.message);
                if(result.statusCode=="SUCCESS"){
                    setTimeout((function() {
                        $("#searchForm").submit();
                    }), 1000);
                }
            }
        });
    });
}



MonitoringPaymentOrder.search = function (obj) {
    $('#searchForm').attr("action",getWebPath() + "/admin/system/merchant/monitoringlist");
    $('#searchForm').submit();
}


MonitoringPaymentOrder.syncOrder = function () {
    var actionUrl = getWebPath() + "/admin/system/merchant/sync_order";
    $.ajax({
        type : "POST", //提交方式
        url : actionUrl,//路径
        data : {},
        success : function(result) {//返回数据根据结果进行相应的处理
            hippo.msg(result.message);
        }
    });
}

MonitoringPaymentOrder.export = function () {
    $('#searchForm').attr("action",getWebPath() + "/admin/system/merchant/export");
    $('#searchForm').submit();
}


$(function(){
    $('input[type=checkbox]').each(function(){
        $(this).click(function(){
            if($(this).prop('checked')){
                //当前选中，其他取消选中
                $('input[type=checkbox]').prop("checked",false);
                $(this).prop("checked",true);

                var orderStatus = $(this).data("orderstatus");
                var orderId = $(this).data("id");

                if(orderStatus=='PROCESSING'){
                    $("#syncOrderStatus").removeClass("disabled");
                    $("#updateAmount").removeClass("disabled");
                    $("#notifyMerchant").addClass("disabled");
                }else{
                    $("#syncOrderStatus").addClass("disabled");
                    $("#notifyMerchant").removeClass("disabled");
                    $("#updateAmount").addClass("disabled");
                }
            }else{
                $("#syncOrderStatus").addClass("disabled");
                $("#notifyMerchant").addClass("disabled");
                $("#updateAmount").addClass("disabled");
            }
        });
    });
});
