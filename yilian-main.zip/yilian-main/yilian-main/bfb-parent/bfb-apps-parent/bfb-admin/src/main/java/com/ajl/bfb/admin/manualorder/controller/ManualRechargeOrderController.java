package com.ajl.bfb.admin.manualorder.controller;

import com.ajl.bfb.admin.channelaccount.controller.ChannelAccountController;
import com.ajl.bfb.admin.channelaccount.vo.ChannelAccountVO;
import com.ajl.bfb.admin.common.web.AdminUserUtils;
import com.ajl.bfb.admin.notice.component.NotifyComponent;
import com.ajl.bfb.core.constants.AuditStatusEnum;
import com.ajl.bfb.core.constants.ManualBizTypeEnum;
import com.ajl.bfb.core.constants.ManualOrderTarge;
import com.ajl.bfb.core.constants.OrderStatusEnum;
import com.ajl.bfb.core.lock.MerchantLock;
import com.ajl.bfb.repo.channel.model.Channel;
import com.ajl.bfb.repo.channel.model.ChannelAccount;
import com.ajl.bfb.repo.channel.service.IChannelAccountService;
import com.ajl.bfb.repo.channel.service.IChannelService;
import com.ajl.bfb.repo.export.service.IExportService;
import com.ajl.bfb.repo.manualorder.ManualOrderException;
import com.ajl.bfb.repo.manualorder.model.ManualOrder;
import com.ajl.bfb.repo.manualorder.model.ManualOrderQueryParam;
import com.ajl.bfb.repo.manualorder.service.IManualOrderService;
import com.ajl.bfb.repo.merchant.model.Merchant;
import com.ajl.bfb.repo.merchant.service.IMerchantService;
import com.ajl.bfb.repo.stat.model.OrderStat;
import com.github.pagehelper.PageInfo;
import com.hippo.framework.auth.admin.OperationAuth;
import com.hippo.framework.auth.admin.model.SysUser;
import com.hippo.framework.operation.log.LogOperation;
import com.hippo.framework.web.ResponseCode;
import com.hippo.framework.web.ResponseResult;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;


@Controller
@RequestMapping("/admin/manual_payment_order")
public class ManualRechargeOrderController {
    private static final Logger logger = LogManager.getLogger(ManualRechargeOrderController.class);
    @Autowired
    IManualOrderService manualOrderService;
    @Autowired
    IMerchantService merchantService;
    @Autowired
    IChannelAccountService channelAccountService;
    @Autowired
    private MerchantLock merchantLock;
    @Autowired
    private NotifyComponent notifyComponent;
    @Autowired
    IChannelService channelService;
    @Autowired
    private ChannelAccountController channelAccountController;
    @Autowired
    private IExportService manualRechargeOrderExportService;


    @RequestMapping("/list")
    @OperationAuth(name = "订单查看", authCode = "manual_recharge.list", group = "下游会员手工充值订单")
    public String manualRechargeOrderList(ManualOrderQueryParam param, Model model){

        PageInfo<ManualOrder> pageInfo =  manualOrderService.getManualRechargeOrderList(param);
        List<ManualOrder> orders = pageInfo.getList();
        List<Integer> merchantIds = orders.stream().map(order->order.getMerchantId()).distinct().collect(Collectors.toList());
        List<Merchant> merchants = merchantService.findByIds(merchantIds);
        Map<Integer,Merchant> merchantMap = merchants.stream().collect(Collectors.toMap(Merchant::getId, t -> t));
        model.addAttribute("merchantMap", merchantMap);

        OrderStat orderStat = manualOrderService.queryRechargeOrderTotal(param);
        model.addAttribute("orderStat", orderStat);

        param.setTransferStatus("Y");
        OrderStat orderTransferStat = manualOrderService.queryRechargeOrderTotal(param);
        model.addAttribute("orderTransferStat", orderTransferStat);

        List<Integer> channelAccountids = orders.stream().map(order->order.getChannelAccountId()).distinct().collect(Collectors.toList());
        List<ChannelAccount> channelAccounts = channelAccountService.findByIds(channelAccountids);
        Map<Integer,String> channelAccountMap = channelAccounts.stream().collect(Collectors.toMap(ChannelAccount::getId,t -> t.getAccount()));
        model.addAttribute("channelAccountMap", channelAccountMap);

        model.addAttribute("bizTypeList", ManualBizTypeEnum.values());
        Map<String,String> bizTypeMap = Arrays.stream(ManualBizTypeEnum.values()).collect(Collectors.toMap(ManualBizTypeEnum::name, r -> r.getDesc()));
        model.addAttribute("bizTypeMap", bizTypeMap);

        model.addAttribute("targeList", ManualOrderTarge.values());
        Map<String,String> targetMap = Arrays.stream(ManualOrderTarge.values()).collect(Collectors.toMap(ManualOrderTarge::name, r -> r.getDesc()));
        model.addAttribute("targetMap", targetMap);

        model.addAttribute("orderStatusList", OrderStatusEnum.values());
        Map<String,String> orderStatusMap = Arrays.stream(OrderStatusEnum.values()).collect(Collectors.toMap(OrderStatusEnum::name, r -> r.getDesc()));
        model.addAttribute("orderStatusMap", orderStatusMap);

        model.addAttribute("auditStatusList", AuditStatusEnum.values());
        Map<String,String> auditStatusMap = Arrays.stream(AuditStatusEnum.values()).collect(Collectors.toMap(AuditStatusEnum::name, r -> r.getDesc1()));
        model.addAttribute("auditStatusMap", auditStatusMap);

        model.addAttribute("pageInfo",pageInfo);
        model.addAttribute("queryParam",param);
        return "/admin/manual_payment_order/list";
    }


    @RequestMapping(value="/export")
    @OperationAuth(name = "导出会员充值订单", authCode = "manual_recharge.export", group = "下游会员手工充值订单")
    public void export(Model model, ManualOrderQueryParam param, HttpServletResponse response) throws Exception {
        logger.info("手工充值报表导出开始...");
        PageInfo<ManualOrder> page =  manualOrderService.getManualRechargeOrderList(param);
        param.setTotal(page.getTotal());
        long start = System.currentTimeMillis();
        manualRechargeOrderExportService.export(response,param);
        logger.info("手工充值报表导出结束...共耗时:" + (System.currentTimeMillis() - start)/1000 + "s");
    }


    @RequestMapping("/to_audit/{id}")
    @OperationAuth(name = "订单审核", authCode = "manual_recharge.audit", group = "下游会员手工充值订单")
    public String toAuditManualOrder(@PathVariable("id") Integer id, Model model){
        ManualOrder manualOrder = manualOrderService.selectByPrimaryKey(id);
        model.addAttribute("manualOrder",manualOrder);

        List<Channel> channels = channelService.findChannels(null);
        Set<Integer> channelIds = channels.stream().distinct().filter(channel->channel.getType().equals(Channel.ChannelType.WITHDRAW)).map(Channel::getId).collect(Collectors.toSet());

        List<ChannelAccount> channelAccounts = channelAccountService.findChannelAccounts(null).stream().filter(acc->channelIds.contains(acc.getChannelId())).collect(Collectors.toList());

        List<ChannelAccountVO> channelAccountVOS = channelAccountController.toAccountVO(channelAccounts, true);
        Map<String,List<ChannelAccountVO>> channelVOMap = channelAccountVOS.stream().collect(Collectors.groupingBy(channelAccountVO->channelAccountVO.getChannelName()));

        model.addAttribute("channelVOMap",channelVOMap);

        return "/admin/manual_payment_order/audit";
    }


    @RequestMapping("/audit")
    @ResponseBody
    @OperationAuth(name = "订单审核", authCode = "manual_recharge.audit", group = "下游会员手工充值订单")
    @LogOperation(name = "订单审核",module = "会员充值订单")
    public ResponseResult auditManualOrder(ManualOrder order,HttpServletRequest request){
        SysUser sysUser = AdminUserUtils.getCurrentLoginUser(request);
        order.setAuditSysUserId(sysUser.getId());
        ManualOrder manualOrder = manualOrderService.selectByPrimaryKey(order.getId());
        Merchant merchant = merchantService.findById(manualOrder.getMerchantId());
        if(AuditStatusEnum.AUDITING != AuditStatusEnum.valueOf(manualOrder.getAuditStatus())){
            return new ResponseResult(ResponseCode.FAIL, String.format("该订单已经受理!"), null);
        }
        try {
            manualOrderService.auditManualPaymentOrder(order);


            notifyComponent.notifyByUserName(merchant.getMerchantNo(),"您的充值订单已受理！");

        } catch (Exception e) {
            return new ResponseResult(ResponseCode.FAIL, String.format("审核失败：%s",e.getMessage()), null);
        }
        return new ResponseResult(ResponseCode.SUCCESS, AuditStatusEnum.SUCCESS.name().equals(order.getAuditStatus())?"受理成功！":"驳回成功！", null);
    }


    @RequestMapping("/to_confirm/{id}")
    @OperationAuth(name = "收款确认", authCode = "manual_recharge.confirm", group = "下游会员手工充值订单")
    public String toConfirmManualOrder(@PathVariable("id") Integer id, Model model){
        ManualOrder manualOrder = manualOrderService.selectByPrimaryKey(id);
        model.addAttribute("manualOrder",manualOrder);
        return "/admin/manual_payment_order/confirm";
    }


    @RequestMapping("/confirm")
    @ResponseBody
    @OperationAuth(name = "收款确认", authCode = "manual_recharge.confirm", group = "下游会员手工充值订单")
    @LogOperation(name = "收款确认",module = "会员充值订单")
    public ResponseResult confirmManualOrder(HttpServletRequest request,Integer id,String status,String processRemark){
        ManualOrder manualOrder = manualOrderService.selectByPrimaryKey(id);
        SysUser sysUser = AdminUserUtils.getCurrentLoginUser(request);
        Assert.isTrue(manualOrder.getAuditSysUserId().equals(sysUser.getId()),"当前用户没有权限确认收款！");
        final String requestId = System.currentTimeMillis() + "";
        int merchantId = manualOrder.getMerchantId();
        try {

            boolean lock = merchantLock.getLock(merchantId, requestId);
            if (!lock) {
                throw new ManualOrderException("获取账户资金锁失败.请重试");
            }
            manualOrderService.confirmManualRechargeOrder(id,status,processRemark,sysUser.getId());

            Merchant merchant = merchantService.findById(manualOrder.getMerchantId());
            notifyComponent.notifyByUserName(merchant.getMerchantNo(),"您的充值已确认到账！");
        } catch (Exception e) {
            return new ResponseResult(ResponseCode.FAIL, String.format("操作失败：%s",e.getMessage()), null);
        } finally {

            merchantLock.releaseLock(merchantId, requestId);
        }
        return new ResponseResult(ResponseCode.SUCCESS, "操作成功！", null);
    }

}
