package com.ajl.bfb.admin.upstream.controller;

import com.ajl.bfb.admin.merchant.vo.MerchantVO;
import com.ajl.bfb.core.constants.*;
import com.ajl.bfb.core.util.MoneyUtils;
import com.ajl.bfb.repo.channel.model.Channel;
import com.ajl.bfb.repo.channel.model.ChannelQuery;
import com.ajl.bfb.repo.channel.model.MerchantChannelAccount;
import com.ajl.bfb.repo.channel.service.IChannelService;
import com.ajl.bfb.repo.channel.service.IMerchantChannelAccService;
import com.ajl.bfb.repo.merchant.MerchantException;
import com.ajl.bfb.repo.merchant.model.Merchant;
import com.ajl.bfb.repo.merchant.model.MerchantInfo;
import com.ajl.bfb.repo.merchant.service.IAgentService;
import com.ajl.bfb.repo.upstream.entity.UpstreamFindParam;
import com.ajl.bfb.repo.upstream.entity.UpstreamMerchant;
import com.ajl.bfb.repo.upstream.service.IUpstreamMerchantService;
import com.github.pagehelper.PageInfo;
import com.hippo.framework.auth.admin.OperationAuth;
import com.hippo.framework.core.enums.SwitchEnum;
import com.hippo.framework.operation.log.LogOperation;
import com.hippo.framework.util.validation.AssertUtils;
import com.hippo.framework.web.ResponseCode;
import com.hippo.framework.web.ResponseResult;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * 码商管理
 */
@Controller
@RequestMapping(value = "/admin/upstream")
public class UpstreamController {

    private static final String LIST_URI = "redirect:/admin/upstream/list";

    @Autowired
    private IUpstreamMerchantService upstreamMerchantService;
    @Autowired
    private IMerchantChannelAccService merchantChannelAccService;
    @Autowired
    private IChannelService channelService;
    @Autowired
    private IAgentService agentService;

    @RequestMapping(value = "/list")
    @OperationAuth(name = "商户查询", authCode = "merchant.query", group = "商户管理")
    public String list(Model model, UpstreamFindParam findParam) {
        if (findParam == null) {
            findParam = new UpstreamFindParam();
        }
        if (findParam.getUserType() == null) {
            findParam.setUserType(MerchantUserTypeEnum.MERCHANT);
        }
        PageInfo<UpstreamMerchant> page = upstreamMerchantService.findPage(findParam);

        List<Channel> channels = channelService.findChannels(new ChannelQuery());
        Map<Integer, Channel> channelMap = channels.stream().collect(Collectors.toMap(Channel::getId, c -> c));


        List<Merchant> agentList = agentService.findAll();

        Map<Integer, Merchant> agentMap = agentList.stream().collect(Collectors.toMap(Merchant::getId, m -> m));

        List vos = new ArrayList<>();

        for (UpstreamMerchant merchant : page.getList()) {
            List<MerchantChannelAccount> merchantChannelAccounts = merchantChannelAccService.findMerchantChannelAccounts(merchant.getId(), null);
            MerchantVO vo = new MerchantVO();
            BeanUtils.copyProperties(merchant, vo);
            if (AccountModeEnum.valueOf(merchant.getPayAccountMode()) == AccountModeEnum.AUTO) {
                vo.setPaymentAccListStr("无");
            } else {
                vo.setPaymentAccListStr(transformStr(merchantChannelAccounts, channelMap, BizTypeEnum.PAYMENT));
            }
            if (AccountModeEnum.valueOf(merchant.getWithdrawAccountMode()) == AccountModeEnum.AUTO) {
                vo.setWithdrawAccListStr("无");
            } else {
                vo.setWithdrawAccListStr(transformStr(merchantChannelAccounts, channelMap, BizTypeEnum.WITHDRAW));
            }
            if (merchant.getAgentid() != null && agentMap.get(merchant.getAgentid()) != null) {
                vo.setAgentName(agentMap.get(merchant.getAgentid()).getMerchantName());
            }
            vos.add(vo);
        }
        page.setList(vos);
        model.addAttribute("pageInfo", page);
        return "/admin/upstream/list";
    }

    private String transformStr(List<MerchantChannelAccount> merchantChannelAccounts, Map<Integer, Channel> channelMap, BizTypeEnum bizType) {
        if (merchantChannelAccounts == null || merchantChannelAccounts.isEmpty()) {
            return "无";
        }
        List<String> list = new ArrayList<>();
        for (MerchantChannelAccount mac : merchantChannelAccounts) {
            if (BizTypeEnum.valueOf(mac.getBizType()) == bizType) {
                list.add(channelMap.get(mac.getChannelAccount().getChannelId()).getName() + "[" + mac.getChannelAccount().getAccount() + "]");
            }
        }
        return StringUtils.join(list, "</br>");
    }

    @RequestMapping(value = "/to_add")
    @OperationAuth(name = "添加商户", authCode = "merchant.add", group = "商户管理")
    public String toAdd(Model model) {
        model.addAttribute("accountModeList", AccountModeEnum.values());
        model.addAttribute("withdrawModeList", WithdrawModeEnum.values());
        model.addAttribute("clearCycleList", ClearCycleEnum.values());
        return "/admin/upstream/add";
    }

    @RequestMapping(value = "/add")
    @OperationAuth(name = "添加商户", authCode = "merchant.add", group = "商户管理")
    @LogOperation(name = "添加商户", module = "商户管理")
    public String add(UpstreamMerchant merchantInfo) {
        merchantInfo.setUserType(MerchantUserTypeEnum.MERCHANT.name());
        upstreamMerchantService.insertSelective(merchantInfo);
        return LIST_URI;
    }

    @RequestMapping(value = "/to_update/{id}")
    @OperationAuth(name = "修改商户", authCode = "merchant.update", group = "商户管理")
    public String toUpdate(@PathVariable("id") int id, Model model) {
        UpstreamMerchant m = upstreamMerchantService.selectByPrimaryKey(id);
        List<Merchant> agentList = agentService.findAll();
        model.addAttribute("agentList", agentList);
        model.addAttribute("accountModeList", AccountModeEnum.values());
        model.addAttribute("withdrawModeList", WithdrawModeEnum.values());
        model.addAttribute("merchant", m);
        model.addAttribute("clearCycleList", ClearCycleEnum.values());
        return "/admin/upstream/update";
    }

    @RequestMapping(value = "/update/{id}")
    @OperationAuth(name = "修改商户", authCode = "merchant.update", group = "商户管理")
    @LogOperation(name = "修改商户", module = "商户管理")
    public String update(@PathVariable("id") int id, UpstreamMerchant merchantInfo) {
        if (merchantInfo.getCautionMoney() != null) {
            merchantInfo.setCautionMoney(MoneyUtils.yuan2fee(merchantInfo.getCautionMoney()).intValue());
        }
        merchantInfo.setId(id);
        upstreamMerchantService.updateByPrimaryKeySelective(merchantInfo);
        return LIST_URI;
    }

    @RequestMapping(value = "/to_update_password/{id}")
    public String toUpdatePassword(@PathVariable("id") int id, Model model) {
        UpstreamMerchant merchant = upstreamMerchantService.selectByPrimaryKey(id);
        model.addAttribute("merchant", merchant);
        return "/admin/upstream/update_password";
    }

    @RequestMapping(value = "/update_password/{id}")
    @OperationAuth(name = "修改密码", authCode = "merchant.updatePassWord", group = "商户管理")
    @LogOperation(name = "修改密码", module = "商户管理")
    public String updatePassword(@PathVariable("id") int id, @RequestParam("newPassword") String newPassword) {
        upstreamMerchantService.updateMerchantPassword(id, newPassword);
        UpstreamMerchant mch = upstreamMerchantService.selectByPrimaryKey(id);
        if (MerchantUserTypeEnum.valueOf(mch.getUserType()) == MerchantUserTypeEnum.AGENT) {
            return "redirect:/admin/agent/list";
        } else {
            return LIST_URI;
        }
    }

    @RequestMapping(value = "/update_second_password/{id}")
    @OperationAuth(name = "修改密码", authCode = "merchant.updatePassWord", group = "商户管理")
    @LogOperation(name = "修改二次密码", module = "商户管理")
    public String updateSecondPassword(@PathVariable("id") int id, @RequestParam("newPassword") String newPassword) {
        upstreamMerchantService.updateSecondPwd(id, newPassword);
        UpstreamMerchant mch = upstreamMerchantService.selectByPrimaryKey(id);
        if (MerchantUserTypeEnum.valueOf(mch.getUserType()) == MerchantUserTypeEnum.AGENT) {
            return "redirect:/admin/agent/list";
        } else {
            return LIST_URI;
        }
    }

    @RequestMapping(value = "/delete/{id}")
    @OperationAuth(name = "删除商户", authCode = "merchant.delete", group = "商户管理")
    @LogOperation(name = "删除", module = "商户管理")
    public String delete(@PathVariable("id") int id) {
        upstreamMerchantService.deleteByPrimaryKey(id);
        return LIST_URI;
    }

    @RequestMapping(value = "/turn_on/{id}")
    @ResponseBody
    @OperationAuth(name = "启用停用", authCode = "merchant.startOrStop", group = "商户管理")
    @LogOperation(name = "开启", module = "商户管理")
    public ResponseResult turnOn(@PathVariable("id") int id) throws MerchantException {
        UpstreamMerchant upstreamMerchant = UpstreamMerchant.builder().id(id).status(SwitchEnum.ON.name()).build();
        upstreamMerchantService.updateByPrimaryKeySelective(upstreamMerchant);
        return new ResponseResult(ResponseCode.SUCCESS, "修改成功", null);
    }

    @RequestMapping(value = "/turn_off/{id}")
    @ResponseBody
    @OperationAuth(name = "启用停用", authCode = "merchant.startOrStop", group = "商户管理")
    @LogOperation(name = "关闭", module = "商户管理")
    public ResponseResult turnOff(@PathVariable("id") int id) throws MerchantException {
        UpstreamMerchant upstreamMerchant = UpstreamMerchant.builder().id(id).status(SwitchEnum.OFF.name()).build();
        upstreamMerchantService.updateByPrimaryKeySelective(upstreamMerchant);
        return new ResponseResult(ResponseCode.SUCCESS, "修改成功", null);
    }


    @RequestMapping(value = "/generate_secret_key/{id}")
    @OperationAuth(name = "刷新动态码", authCode = "merchant.refreshDynamicCode", group = "商户管理")
    @LogOperation(name = "刷新动态码", module = "商户管理")
    @ResponseBody
    public ResponseResult generateSecretKey(@PathVariable("id") int id) throws MerchantException {
/*
        String secretKey = GoogleAuthenticator.generateSecretKey();
        upstreamMerchantService.updateVerificationCodeDecretKey(id, secretKey);
        UpstreamMerchant merchant = upstreamMerchantService.selectByPrimaryKey(id);
        String qrBarcodeURL = GoogleAuthenticator.getQRBarcodeURL(merchant.getMerchantNo(), secretKey);*/

        return new ResponseResult(ResponseCode.SUCCESS, "修改成功", null);
    }


    @RequestMapping("/to_config_white_list/{id}")
    @OperationAuth(name = "白名单设置", authCode = "merchant.settingWhiteList", group = "商户管理")
    public String toConfigWhiteList(@PathVariable("id") int id, Model model) {
        UpstreamMerchant m = upstreamMerchantService.selectByPrimaryKey(id);
        model.addAttribute("merchant", m);
        return "/admin/upstream/config_white_list";
    }

    @RequestMapping("/config_white_list/{id}")
    @OperationAuth(name = "白名单设置", authCode = "merchant.settingWhiteList", group = "商户管理")
    @LogOperation(name = "白名单设置", module = "商户管理")
    public String configWhiteList(@PathVariable("id") int id, MerchantInfo merchantInfo) {
        UpstreamMerchant upstreamMerchant = UpstreamMerchant.builder().id(id).loginIp(merchantInfo.getLoginIP()).apiCallIp(merchantInfo.getApiCallIP())
                .manualWithdrawIp(merchantInfo.getManualWithdrawIP()).bankCardWhiteList(merchantInfo.getBankCardWhiteList()).updateTime(new Date()).build();
        upstreamMerchantService.updateByPrimaryKeySelective(upstreamMerchant);
        return LIST_URI;
    }

    @RequestMapping("/add_bankcard_whiltelist")
    @ResponseBody
    @OperationAuth(name = "白名单设置", authCode = "merchant.settingWhiteList", group = "商户管理")
    @LogOperation(name = "代付银行卡白名单设置", module = "商户管理")
    public ResponseResult addBankCardWhiteList(String merchantNo, String bankCard) {
        AssertUtils.stringNotBlank(merchantNo, "商户号不能为空!");
        AssertUtils.stringNotBlank(bankCard, "银行卡号不能为空!");

        /*UpstreamMerchant merchant = upstreamMerchantService.findByMerchantNo(merchantNo);
        String bankCardWhiteList = StringUtils.defaultString(merchant.getBankCardWhiteList());
        if (bankCardWhiteList.indexOf(StringUtils.defaultString(bankCard)) > 0) {
            return new ResponseResult(ResponseCode.SUCCESS, "已经在白名单！", null);
        }
        MerchantInfo merchantInfo = new MerchantInfo();
        merchantInfo.setLoginIP(merchant.getLoginIP());
        merchantInfo.setApiCallIP(merchant.getApiCallIP());
        String bankCardStr = bankCard + "," + merchant.getBankCardWhiteList();
        //现在白名单长度
        if (bankCardStr.length() >= 5000) {
            merchantInfo.setBankCardWhiteList(bankCardStr.substring(0, 5000));
        } else {
            merchantInfo.setBankCardWhiteList(bankCardStr);
        }
        merchantInfo.setManualWithdrawIP(merchant.getManualWithdrawIP());
        upstreamMerchantService.updateWhiteList(merchant.getId(), merchantInfo);*/
        return new ResponseResult(ResponseCode.SUCCESS, "添加成功", null);
    }


    @RequestMapping("/add_requestip_whiltelist")
    @ResponseBody
    @OperationAuth(name = "白名单设置", authCode = "merchant.settingWhiteList", group = "商户管理")
    @LogOperation(name = "请求IP地址白名单设置", module = "商户管理")
    public ResponseResult addRequestipWhiltelist(String merchantNo, String requestIP) {
        /*AssertUtils.stringNotBlank(merchantNo, "商户号不能为空!");
        AssertUtils.stringNotBlank(requestIP, "IP地址不能为空!");
        Merchant merchant = upstreamMerchantService.findByMerchantNo(merchantNo);
        MerchantInfo merchantInfo = new MerchantInfo();
        merchantInfo.setLoginIP(merchant.getLoginIP());
        merchantInfo.setApiCallIP(merchant.getApiCallIP());
        merchantInfo.setBankCardWhiteList(merchant.getBankCardWhiteList());
        merchantInfo.setManualWithdrawIP(requestIP + "," + merchant.getManualWithdrawIP());
        upstreamMerchantService.updateWhiteList(merchant.getId(), merchantInfo);*/
        return new ResponseResult(ResponseCode.SUCCESS, "添加成功", null);
    }


}
