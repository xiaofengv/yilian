package com.ajl.bfb.admin.channelprovider.controller;

import com.github.pagehelper.PageInfo;
import com.hippo.framework.auth.admin.model.SysUser;
import com.hippo.framework.auth.admin.queryparam.SysUserQueryParam;
import com.hippo.framework.auth.admin.service.ISysUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;


@Controller
@RequestMapping(value="/admin/channel_provider")
public class ChannelProviderController {

    @Autowired
    private ISysUserService sysUserService;

    @RequestMapping(value="/to_add")
    public String toAdd() {
        return "/admin/channel_provider/add";
    }

    @RequestMapping(value="/save")
    public String add() {
        return "/admin/channel_provider/add";
    }

    @RequestMapping(value="/list")
    public String list(Model model, SysUserQueryParam param) {
        param.setPageSize(2);
        PageInfo<SysUser> page = sysUserService.findPage(param);
        model.addAttribute("pageInfo", page);
        return "/admin/channel_provider/list";
    }



}
