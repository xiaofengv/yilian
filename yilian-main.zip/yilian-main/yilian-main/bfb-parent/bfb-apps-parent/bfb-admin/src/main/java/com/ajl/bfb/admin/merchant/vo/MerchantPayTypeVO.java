package com.ajl.bfb.admin.merchant.vo;

import com.ajl.bfb.core.constants.PaymentTypeEnum;
import com.ajl.bfb.core.constants.RateTypeEnum;
import com.ajl.bfb.core.util.MoneyUtils;
import com.ajl.bfb.core.util.RateUtils;
import com.ajl.bfb.repo.merchant.model.MerchantPayType;

import java.math.BigDecimal;


public class MerchantPayTypeVO extends MerchantPayType {

    private BigDecimal globalDefaultRatePercent;


    public String getPayTypeDesc() {
        return PaymentTypeEnum.valueOf(getPayTypeCode()).getDesc();
    }


    public String getRateTypeDesc() {
        return RateTypeEnum.valueOf(getRateType()).getViewDesc();
    }

    public BigDecimal getAgentRatePercent() {
        return RateUtils.rate2percent(getAgentRate());
    }

    public BigDecimal getRatePercent() {
        return RateUtils.rate2percent(getRate());
    }


    public BigDecimal getMinAmountYuan() {
        return MoneyUtils.fee2yuan(getMinAmount());
    }

    public BigDecimal getMaxAmountYuan() {
        return MoneyUtils.fee2yuan(getMaxAmount());
    }


    public BigDecimal getGlobalDefaultRatePercent() {
        return globalDefaultRatePercent;
    }

    public void setGlobalDefaultRatePercent(BigDecimal globalDefaultRatePercent) {
        this.globalDefaultRatePercent = globalDefaultRatePercent;
    }


}
