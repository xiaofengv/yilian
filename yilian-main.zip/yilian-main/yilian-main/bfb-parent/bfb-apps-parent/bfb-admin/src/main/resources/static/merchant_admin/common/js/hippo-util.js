var hippo = {};

String.prototype.trim=function()
{
    return this.replace(/(^\s*)|(\s*$)/g, '');
}

String.prototype.isEmpty=function() {
    return this.trim() == "";
}

hippo.toast = function (msg) {
    layer.msg(msg, {
        time: 5000 //20s后自动关闭
    });
}

/**
 * 选择全部, 总控制的checkbox id必须是controlCheckAll, 被控制的checkbox 必须带有样式 checkAll
 */
hippo.controlCheckAll = function() {
    if ($("#controlCheckAll").prop('checked')) {
        $(".checkAll").prop('checked', true)
    } else {
        $(".checkAll").removeAttr("checked");
    }
}

/**
 * 回到上一页并刷新
 */
hippo.goback = function () {
    // window.history.go(-1);
    // window.location.reload();
    if (document.referrer != null && document.referrer != '') {
        window.location.href=document.referrer;
    } else {
        window.history.go(-1);
    }
}

/**
 * 只能输入整数
 * @param id
 */
hippo.limitInteger = function(id) {
    //限制键盘只能按数字键、小键盘数字键、退格键
    $("#" + id).keydown(function (e) {
        var code = parseInt(e.keyCode);
        if (code >= 96 && code <= 105 || code >= 48 && code <= 57 || code == 8) {
            return true;
        } else {
            return false;
        }
    });

//文本框输入事件,任何非正整数的输入都重置为空
    $("#" + id).bind("input propertychange", function () {
        if (isNaN(parseFloat($(this).val())) || parseFloat($(this).val()) <= 0) $(this).val("");
    })
}

/**
 * 只能输入2位小数的数字
 * @param obj
 */
hippo.limitFloat = function(id){
    $("#" + id).keyup(function (e) {
        this.value = this.value.replace(/[^\d.]/g,""); //清除"数字"和"."以外的字符
        this.value = this.value.replace(/^\./g,""); //验证第一个字符是数字
        this.value = this.value.replace(/\.{2,}/g,"."); //只保留第一个, 清除多余的
        this.value = this.value.replace(".","$#$").replace(/\./g,"").replace("$#$",".");
        this.value = this.value.replace(/^(\-)*(\d+)\.(\d\d).*$/,'$1$2.$3'); //只能输入两个小数
    });
//文本框输入事件,任何非正整数的输入都重置为1
    $("#" + id).bind("input propertychange", function () {
        if (isNaN(parseFloat($(this).val())) || parseFloat($(this).val()) <= 0) $(this).val("");
    })
}

hippo.validateForm = function (formId) {
    var targetForm = $("#" + formId);
    /* 校验 hippo_required的input */
    // c=$.merge(a,b);
    //所有input框
    var inputEls = targetForm.find('input[hippo_required]');
    var selectEls = targetForm.find('select[hippo_required]');
    var textareaEls = targetForm.find('textarea[hippo_required]');

    var allInputElements = $.merge(inputEls,selectEls);
    allInputElements = $.merge(allInputElements,textareaEls);
    for (var i = 0, len = allInputElements.length; i < len; i++) {
        if ($(allInputElements[i]).val().isEmpty()) {
            // new $.zui.Messager($(inputArray[i]).attr('hippo_error_msg'), {
            //     type: 'warning' // 定义颜色主题
            // }).show();

            layer.tips($(allInputElements[i]).attr('hippo_error_msg'), $(allInputElements[i]), {
                tips: [2, '#0FA6D8'], //设置tips方向和颜色 类型：Number/Array，默认：2 tips层的私有参数。支持上右下左四个方向，通过1-4进行方向设定。如tips: 3则表示在元素的下面出现。有时你还可能会定义一些颜色，可以设定tips: [1, '#c00']
                tipsMore: true, //是否允许多个tips 类型：Boolean，默认：false 允许多个意味着不会销毁之前的tips层。通过tipsMore: true开启
                time:3000  //2秒后销毁，还有其他的基础参数可以设置。。。。这里就不添加了
             });

            $(allInputElements[i]).focus();
            return false;
        }
    }
    return true;
}


/**
 *  msg:提示的内容
 * adsorptiveElement 吸附元素选择器,如#id, 或者直接的对象也可以,没有则为空
 */
hippo.tips = function (adsorptiveElement,msg) {
    layer.tips(msg, adsorptiveElement, {
        tips: [3, '#0FA6D8'], //设置tips方向和颜色 类型：Number/Array，默认：2 tips层的私有参数。支持上右下左四个方向，通过1-4进行方向设定。如tips: 3则表示在元素的下面出现。有时你还可能会定义一些颜色，可以设定tips: [1, '#c00']
        tipsMore: true, //是否允许多个tips 类型：Boolean，默认：false 允许多个意味着不会销毁之前的tips层。通过tipsMore: true开启
        time:3000  //2秒后销毁，还有其他的基础参数可以设置。。。。这里就不添加了
    });
}

hippo.msg = function (msg) {
    layer.msg(msg);
}


hippo.warning = function(msg) {
    layer.alert(msg, {title:'警告',icon: 5})
}


/*
spring boot 默认ajax 报错 报文
{
    "timestamp":1518749390849,
    "status":404,
    "error":"Not Found",
    "message":"No message available",
    "path":"/manager/sys/login"
}*/

/**
 * 1.如果有个叫loading的div 就显示遮罩效果, 依赖showloading.js
 * 2.如果服务器端报异常， 在这里拦截，直接提示，包括应用本身没处理到的，返回了spring boot 默认的异常
 */
var hippoLayerLoadingIndex = -1;
$.ajaxSetup({
    cache:false,
    timeout: 30000,//10s
    beforeSend: function () {
        //ajax请求之前
        //如果有个叫loading的div 就显示遮罩效果, 依赖showloading.js
        // if(document.getElementById('loading')) {
        //     $('#loading').showLoading();
        // }
        try {
            hippoLayerLoadingIndex = layer.load();
        } catch (e) {}
    },
    ajaxComplete:function () {
    },
    complete: function (jqXHR, textStatus, errorMsg) {//ajax请求完成，不管成功失败,
        //关闭loading效果
        try {
            layer.close(hippoLayerLoadingIndex);
        } catch (e) {}
        showSystemError(jqXHR, textStatus, errorMsg);
    }, error: function (jqXHR, textStatus, errorMsg) {//ajax请求失败
        // jqXHR 是经过jQuery封装的XMLHttpRequest对象
        // textStatus 可能为null、 'timeout'、 'error'、 'abort'和'parsererror'等
        // errorMsg 是错误信息字符串(响应状态的文本描述部分，例如'Not Found'或'Internal Server Error')
        console.log("hippo pay ajax error");
        // showSystemError(jqXHR, textStatus, errorMsg);
    },ajaxError:function () {
        console.log("hippo pay ajaxError error");
        hippo.warning('请求异常(ajaxError)，请联系管理员');
    }
});

function showSystemError(jqXHR, textStatus, errorMsg) {
    try {
        var stCode = JSON.parse(jqXHR.responseText).statusCode;
        // console.log("stCode:" + stCode);
        if((typeof jqXHR.responseText == "string")
            && (stCode == "UNKNOWN_EXCEPTION"
            || stCode == "UNAUTHORIZED"
            || stCode == "NO_PERMISSION")) {
            hippo.warning(JSON.parse(jqXHR.responseText).message);
            return false;
        }
        /*else if (typeof jqXHR.responseText == "string"
         && JSON.parse(jqXHR.responseText).status != null){//应用系统没处理，spring boot 默认的响应
         var rsp = JSON.parse(jqXHR.responseText);
         new $.zui.Messager(rsp.status + ":" + rsp.error + ":" + rsp.message, {
         time:10000,
         type: 'danger' // 定义颜色主题
         }).show();
         return false;
         }*/
    } catch (e) {}
}

/**
 * 根据选中的记录，跳转url
 * @param url
 */
hippo.jumpUrlBySelect = function (url) {
    var id = hippo.getSelectRecord();
    if (id != -1) {
        window.location.href=url + id;
    }
}

/**
 * 获得列表中选中的那条记录的值
 * @returns {number}
 */
hippo.getSelectRecord = function () {
    var list = $('input[type=checkbox][class=checkAll]:checked');
    if (list.length != 1) {
        hippo.toast("请选中1条记录");
        return -1;
    }
    return list[0].value;
}


