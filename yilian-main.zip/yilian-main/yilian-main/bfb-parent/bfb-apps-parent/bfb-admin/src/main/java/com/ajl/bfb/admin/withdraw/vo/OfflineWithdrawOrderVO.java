package com.ajl.bfb.admin.withdraw.vo;

import com.ajl.bfb.core.constants.OrderStatusEnum;
import com.ajl.bfb.repo.withdraw.model.OfflineWithdrawOrder;
import com.ajl.bfb.repo.withdraw.model.WithdrawOrder;


public class OfflineWithdrawOrderVO extends WithdrawOrder {

    private String merchantName;

    private OfflineWithdrawOrder offlineWithdrawOrder;

    public String getMerchantName() {
        return merchantName;
    }

    public void setMerchantName(String merchantName) {
        this.merchantName = merchantName;
    }


    public String getOrderStatusStr() {
        return OrderStatusEnum.valueOf(offlineWithdrawOrder.getStatus()).getDesc();
    }

    public OfflineWithdrawOrder getOfflineWithdrawOrder() {
        return offlineWithdrawOrder;
    }

    public void setOfflineWithdrawOrder(OfflineWithdrawOrder offlineWithdrawOrder) {
        this.offlineWithdrawOrder = offlineWithdrawOrder;
    }
}
