package com.ajl.bfb.admin.withdraw.controller;

import com.ajl.bfb.admin.common.web.AdminUserUtils;
import com.ajl.bfb.admin.withdraw.vo.OfflineWithdrawOrderVO;
import com.ajl.bfb.core.constants.AuditStatusEnum;
import com.ajl.bfb.core.constants.OrderStatusEnum;
import com.ajl.bfb.core.constants.WithdrawTypeEnum;
import com.ajl.bfb.repo.merchant.FundException;
import com.ajl.bfb.repo.merchant.model.Merchant;
import com.ajl.bfb.repo.merchant.service.IMerchantService;
import com.ajl.bfb.repo.withdraw.model.OfflineWithdrawOrder;
import com.ajl.bfb.repo.withdraw.model.WithdrawOrder;
import com.ajl.bfb.repo.withdraw.model.WithdrawOrderQueryParam;
import com.ajl.bfb.repo.withdraw.service.IOfflineWithdrawOrderService;
import com.ajl.bfb.repo.withdraw.service.IWithdrawOrderService;
import com.github.pagehelper.PageInfo;
import com.hippo.framework.auth.admin.OperationAuth;
import com.hippo.framework.auth.admin.model.SysUser;
import com.hippo.framework.util.validation.AssertUtils;
import com.hippo.framework.web.ResponseCode;
import com.hippo.framework.web.ResponseResult;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;


@Controller
@RequestMapping(value="/admin/offline_withdraw")
public class OfflineWithdrawController{

    private static final Logger logger = LogManager.getLogger(OfflineWithdrawController.class);
    @Autowired
    IOfflineWithdrawOrderService offLineWithdrawOrderService;

    @Autowired
    private IMerchantService merchantService;

    @Autowired
    private IWithdrawOrderService withdrawOrderService;

    @RequestMapping(value="/list")
    @OperationAuth(name = "查看线下代付订单", authCode = "offline_withdraw.query", group = "线下代付订单管理")
    public String list(Model model, WithdrawOrderQueryParam param) {
        if (param == null) {
            param = new WithdrawOrderQueryParam();
        }
        PageInfo<WithdrawOrder> page = offLineWithdrawOrderService.findList(param);
        List<WithdrawOrder> list = page.getList();
        page.setList(toVO(list));
        model.addAttribute("pageInfo", page);
        model.addAttribute("queryParam", param);
        model.addAttribute("withdrawTypeList", WithdrawTypeEnum.values());
        model.addAttribute("orderStatusList", OrderStatusEnum.values());
        model.addAttribute("auditStatusList", AuditStatusEnum.values());
        return "admin/withdraw/offline_list";
    }


    @RequestMapping(value="/order_detail/{orderId}")
    public String orderDetail(@PathVariable("orderId") int orderId, Model model) {
        WithdrawOrder order = withdrawOrderService.findById(orderId);
        OfflineWithdrawOrderVO withdrawOrderVO = toVO(order);
        model.addAttribute("order",withdrawOrderVO);
        return "admin/withdraw/offline_order_detail";
    }

    private List toVO(List<WithdrawOrder> list) {
        List<Integer> mchIds = list.stream() .map(WithdrawOrder::getMerchantId).distinct().collect(Collectors.toList());
        List<Merchant> merchantList = merchantService.findByIds(mchIds);
        Map<Integer, Merchant> merchantMap = merchantList.stream().collect(Collectors.toMap(Merchant::getId, m -> m));
        List volist = new ArrayList();
        for (WithdrawOrder order : list) {
            OfflineWithdrawOrderVO vo = new OfflineWithdrawOrderVO();
            BeanUtils.copyProperties(order, vo);
            vo.setMerchantName(merchantMap.get(order.getMerchantId()).getMerchantName());
            vo.setOfflineWithdrawOrder(offLineWithdrawOrderService.findByWithdrawId(order.getId()));
            volist.add(vo);
        }
        return volist;
    }

    private OfflineWithdrawOrderVO toVO(WithdrawOrder order) {
        List<OfflineWithdrawOrderVO> list = toVO(Arrays.asList(order));
        return list.get(0);
    }


    @RequestMapping(value="/modify_order_status")
    @ResponseBody
    @OperationAuth(name = "修改线下代付订单状态", authCode = "offline_withdraw.modify_order_status", group = "线下代付订单管理")
    public ResponseResult modifyOrderStatus(HttpServletRequest request, int withdrawId, String orderStatus, String remark) throws FundException {
        logger.info("直接修改代付订单状态id:%s, remark:%s, status:%s", withdrawId, remark, orderStatus);
        AssertUtils.stringNotBlank(remark, "备注不能为空");
        AssertUtils.stringNotBlank(orderStatus, "状态不能为空");
        OrderStatusEnum orderSt = OrderStatusEnum.valueOf(orderStatus);
        if (orderSt != OrderStatusEnum.SUCCESS && orderSt != OrderStatusEnum.FAIL) {
            throw new RuntimeException("非法的status参数:" + orderStatus);
        }
        OfflineWithdrawOrder offlineWithdrawOrder = offLineWithdrawOrderService.findByWithdrawId(withdrawId);
        AssertUtils.objectNotNull(offlineWithdrawOrder, "订单不存在");
        SysUser sysUser = AdminUserUtils.getCurrentLoginUser(request);
        offLineWithdrawOrderService.updateStatus(sysUser.getId(),sysUser.getUserName(),orderSt,remark,withdrawId);
        return new ResponseResult(ResponseCode.SUCCESS, "状态修改成功", "");
    }
}
