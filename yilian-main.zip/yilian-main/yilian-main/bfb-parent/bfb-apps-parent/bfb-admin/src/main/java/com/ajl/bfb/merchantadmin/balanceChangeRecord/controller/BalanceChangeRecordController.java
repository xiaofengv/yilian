package com.ajl.bfb.merchantadmin.balanceChangeRecord.controller;

import com.ajl.bfb.core.constants.BalanceChangeTypeEnum;
import com.ajl.bfb.merchantadmin.common.web.MerchantAdminUserUtils;
import com.ajl.bfb.repo.merchant.model.Merchant;
import com.ajl.bfb.repo.merchant.model.MerchantBalanceChange;
import com.ajl.bfb.repo.merchant.model.MerchantBalanceChangeParam;
import com.ajl.bfb.repo.merchant.service.IMerchantBalanceChangeService;
import com.github.pagehelper.PageInfo;
import com.hippo.framework.util.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import java.util.Date;

@Controller
@RequestMapping(value="/merchant_admin/balance_change_record")
public class BalanceChangeRecordController {
    @Autowired
    private IMerchantBalanceChangeService merchantBalanceChangeService;
    @RequestMapping(value="/list")
    public String list(HttpServletRequest request, Model model, MerchantBalanceChangeParam queryParam) {
        Merchant merchant = MerchantAdminUserUtils.getLoginMerchant(request);
        queryParam.setMerchantId(merchant.getId());
        if (queryParam.getStartTime() == null) {
            queryParam.setStartTime(DateUtils.plusDays(DateUtils.getDateStart2(new Date()), 0));
            queryParam.setEndTime(DateUtils.getDateEnd2(new Date()));
        }
        queryParam.setPageSize(20);
        PageInfo<MerchantBalanceChange> page = merchantBalanceChangeService.findList(queryParam);
        model.addAttribute("pageInfo", page);
        model.addAttribute("queryParam", queryParam);
        model.addAttribute("changeType", BalanceChangeTypeEnum.values());
        return "/merchant_admin/balance_change_record/list";
    }
}
