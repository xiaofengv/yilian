package com.ajl.bfb.admin.channelaccount.util;

import com.ajl.bfb.admin.channelaccount.vo.ChannelAccountVO;
import com.ajl.bfb.core.util.MoneyUtils;
import com.ajl.bfb.repo.channel.model.ChannelAccount;
import org.springframework.beans.BeanUtils;

import java.util.ArrayList;
import java.util.List;


public class ChannelAccountViewUtils {

    public static List<ChannelAccountVO> toVO(List<ChannelAccount> accounts) {
        List<ChannelAccountVO> vos = new ArrayList<>();
        for (ChannelAccount account : accounts) {
            if(account!=null) {
                vos.add(toVO(account));
            }
        }
        return vos;
    }

    public static ChannelAccountVO toVO(ChannelAccount acc) {
        ChannelAccountVO vo = new ChannelAccountVO();
        BeanUtils.copyProperties(acc, vo);
        vo.setDayMaxAmountYuan(MoneyUtils.fee2yuan(vo.getDayMaxAmount()).longValue());
        vo.setIncomeTotalMaxYuan(MoneyUtils.fee2yuan(vo.getIncomeTotalMax()).longValue());
        return vo;
    }
}
