package com.ajl.bfb.admin.payment.vo;

import com.ajl.bfb.core.constants.ChannelCodeEnum;
import com.ajl.bfb.core.constants.NotifyStatusEnum;
import com.ajl.bfb.core.constants.OrderStatusEnum;
import com.ajl.bfb.core.constants.PaymentTypeEnum;
import com.ajl.bfb.core.util.MoneyUtils;
import com.ajl.bfb.repo.payment.model.PaymentOrder;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.math.BigDecimal;


public class PaymentOrderVO extends PaymentOrder {
    private static final Logger logger = LogManager.getLogger(PaymentOrderVO.class);
    private String merchantName;

    private String channelAccName;

    private String agentName;

    public String getChannelAccName() {
        return channelAccName;
    }

    public String getNotifyStatusStr() {
        return NotifyStatusEnum.valueOf(getNotifyStatus()).getDesc();
    }

    public BigDecimal getMerchantCostYuan() {
        return MoneyUtils.fee2yuan(getMerchantCost());
    }

    public BigDecimal getPlatformCostYuan() {
        return MoneyUtils.fee2yuan(getPlatformCost());
    }

    public BigDecimal getPlatformIncomeYuan() {
        return MoneyUtils.fee2yuan(getPlatformIncome());
    }


    public String getPaymentTypeStr() {
        return PaymentTypeEnum.valueOf(getPayTypeCode()).getDesc();
    }


    public String getChannelName() {
        try {
            return ChannelCodeEnum.valueOf(getChannelCode()).getDesc();
        }catch (RuntimeException e){
            logger.info("上游转换异常"+ e.getMessage());
            return "N/A";
        }
    }

    public void setChannelAccName(String channelAccName) {
        this.channelAccName = channelAccName;
    }


    public String getAmountYuan() {
        return MoneyUtils.fee2yuan(getAmount()).toString();
    }

    public String getOrderAmountYuan() {
        return MoneyUtils.fee2yuan(getOrderAmount()).toString();
    }


    public String getOrderStatusStr() {
        return OrderStatusEnum.valueOf(getOrderStatus()).getDesc();
    }

    public String getMerchantName() {
        return merchantName;
    }

    public void setMerchantName(String merchantName) {
        this.merchantName = merchantName;
    }

    public String getAgentName() {
        return agentName;
    }

    public void setAgentName(String agentName) {
        this.agentName = agentName;
    }
}
