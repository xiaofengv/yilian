package com.ajl.bfb.upstreamadmin.withdraw.controller;

import com.ajl.bfb.admin.channelaccount.util.ChannelAccountViewUtils;
import com.ajl.bfb.admin.channelaccount.vo.ChannelAccountVO;
import com.ajl.bfb.admin.notice.component.NotifyComponent;
import com.ajl.bfb.admin.withdraw.controller.WithdrawController;
import com.ajl.bfb.admin.withdraw.vo.WithdrawOrderVO;
import com.ajl.bfb.common.withdraw.model.CreateWithdrawOrderRequest;
import com.ajl.bfb.core.constants.*;
import com.ajl.bfb.core.lock.MerchantLock;
import com.ajl.bfb.core.util.MoneyUtils;
import com.ajl.bfb.pay.withdraw.IWithdrawFacade;
import com.ajl.bfb.pay.withdraw.QueryBankByAccount;
import com.ajl.bfb.repo.channel.model.Channel;
import com.ajl.bfb.repo.channel.model.ChannelAccount;
import com.ajl.bfb.repo.channel.model.ChannelQuery;
import com.ajl.bfb.repo.channel.service.IChannelAccountService;
import com.ajl.bfb.repo.channel.service.IChannelService;
import com.ajl.bfb.repo.export.service.IExportService;
import com.ajl.bfb.repo.merchant.FundException;
import com.ajl.bfb.repo.merchant.model.Merchant;
import com.ajl.bfb.repo.merchant.service.IMerchantService;
import com.ajl.bfb.repo.meta.model.Area;
import com.ajl.bfb.repo.meta.service.IRegionDataService;
import com.ajl.bfb.repo.stat.model.OrderStat;
import com.ajl.bfb.repo.upstream.entity.UpstreamMerchant;
import com.ajl.bfb.repo.upstream.service.IUpstreamMerchantService;
import com.ajl.bfb.repo.withdraw.WithdrawException;
import com.ajl.bfb.repo.withdraw.component.ExcelImportCfg;
import com.ajl.bfb.repo.withdraw.model.BatchWithdrawOrder;
import com.ajl.bfb.repo.withdraw.model.MerchantBankCard;
import com.ajl.bfb.repo.withdraw.model.WithdrawOrder;
import com.ajl.bfb.repo.withdraw.model.WithdrawOrderQueryParam;
import com.ajl.bfb.repo.withdraw.service.IBatchWithdrawOrderImportService;
import com.ajl.bfb.repo.withdraw.service.IMerchantBankCardService;
import com.ajl.bfb.repo.withdraw.service.IWithdrawOrderService;
import com.ajl.bfb.upstreamadmin.common.UpstreamAdminUserUtils;
import com.ajl.bfb.upstreamadmin.withdraw.vo.ManualWithdrawOrderVO;
import com.ajl.bfb.upstreamadmin.withdraw.vo.MerchantBankCardVO;
import com.github.pagehelper.PageInfo;
import com.hippo.framework.auth.admin.OperationAuth;
import com.hippo.framework.util.CollectionUtils;
import com.hippo.framework.util.DownloadUtils;
import com.hippo.framework.util.net.HttpUtils;
import com.hippo.framework.util.security.BCryptUtils;
import com.hippo.framework.util.validation.ValidationUtils;
import com.hippo.framework.web.ResponseCode;
import com.hippo.framework.web.ResponseResult;
import com.hippo.framework.web.util.HttpRequestUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Collectors;


@Controller
@RequestMapping(value="/upstream_admin/withdraw")
public class UpstreamWithdrawOrderController {

    private static final Logger logger = LogManager.getLogger(UpstreamWithdrawOrderController.class);
    @Autowired
    private IWithdrawOrderService withdrawOrderService;
    @Autowired
    private IUpstreamMerchantService merchantService;
    @Autowired
    private IWithdrawFacade withdrawFacade;
    @Autowired
    private WithdrawController withdrawController;
    @Autowired
    private IRegionDataService regionDataService;
    @Autowired
    private ExcelImportCfg excelImportCfg;
    @Autowired
    private NotifyComponent notifyComponent;
    @Autowired
    private IExportService merchantWithdrawOrderExportService;
    @Autowired
    private IExportService merchantBatchWithdrawOrderExportService;
    @Autowired
    private IBatchWithdrawOrderImportService batchWithdrawOrderImportService;
    @Autowired
    private MerchantLock merchantLock;
    @Autowired
    private IMerchantBankCardService merchantBankCardService;
    @Autowired
    private QueryBankByAccount queryBankByAccount;
    @Autowired
    private IMerchantService imerchantService;
    @Autowired
    private IChannelService channelService;
    @Autowired
    private IChannelAccountService channelAccountService;


    @RequestMapping(value="/list")
    public String list(Model model, WithdrawOrderQueryParam param, HttpServletRequest request) {
        param.setMerchantId(UpstreamAdminUserUtils.getLoginMerchant(request).getId());
        withdrawController.manualWithdrawList(model, param);
        UpstreamMerchant merchant = UpstreamAdminUserUtils.getLoginMerchant(request);
        model.addAttribute("userType",merchant.getUserType());
        return "upstream_admin/withdraw_order/list";
    }


    @RequestMapping(value="/batch_list")
    public String batchOrderList(Model model, WithdrawOrderQueryParam param, HttpServletRequest request) {
        UpstreamMerchant merchant = UpstreamAdminUserUtils.getLoginMerchant(request);
//        model.addAttribute("userType",merchant.getUserType());

//        withdrawController.batchWithdrawList(model, param);
        if (param == null) {
            param = new WithdrawOrderQueryParam();
        }
//        param.setMerchantNo(merchant.getMerchantNo());
        PageInfo<WithdrawOrder> page = withdrawOrderService.findBatchWithdrawList(param);
        OrderStat orderTotal = withdrawOrderService.queryBatchOrderTotal(param);
        model.addAttribute("orderTotal", orderTotal);
        List<WithdrawOrder> list = page.getList();
        page.setList(toVO(list));

        model.addAttribute("withdrawTypeList", WithdrawTypeEnum.values());
        model.addAttribute("pageInfo", page);
        model.addAttribute("queryParam", param);
        model.addAttribute("orderStatusList", OrderStatusEnum.values());
        model.addAttribute("auditStatusList", AuditStatusEnum.values());


        List<ChannelAccount> channelAccounts = channelAccountService.findAllChannelAccounts(null);

        List<ChannelAccountVO> channelAccountVOS = toAccountVO(channelAccounts);
        Map<String,List<ChannelAccountVO>> channelVOMap = channelAccountVOS.stream().collect(Collectors.groupingBy(channelAccountVO->channelAccountVO.getChannelName()));
        model.addAttribute("channelVOMap",channelVOMap);

        return "upstream_admin/withdraw_order/batch_withdraw_list";
    }
    @RequestMapping(value="/batch_import_list")
    public String batchImportOrderList(Model model, WithdrawOrderQueryParam param, HttpServletRequest request) {
        Integer merchantId = UpstreamAdminUserUtils.getLoginMerchant(request).getId();
        List<BatchWithdrawOrder> orders = batchWithdrawOrderImportService.findList(merchantId);
        model.addAttribute("orders",orders);

        Map<String, Long> statusAmountMap = orders.stream()
                .collect(Collectors.groupingBy(BatchWithdrawOrder::getStatus,
                        Collectors.summingLong(BatchWithdrawOrder::getAmount)));


        Map<String, Long> statusCountMap = orders.stream()
                .collect(Collectors.groupingBy(BatchWithdrawOrder::getStatus,
                        Collectors.counting()));

        Map<String, Long> nameCountMap = orders.stream()
                .collect(Collectors.groupingBy(BatchWithdrawOrder::getPayeeName,
                        Collectors.counting())).entrySet().stream().filter(entry->entry.getValue()>1).collect(Collectors.toMap(entry->entry.getKey(),entry->entry.getValue()));


        model.addAttribute("statusAmountMap",statusAmountMap);
        model.addAttribute("statusCountMap",statusCountMap);
        model.addAttribute("nameCountMap",nameCountMap);

        Map<String,String> statusMap =  (Arrays.stream(BatchWithdrawOrder.StatusEnum.values())).collect(Collectors.toMap(BatchWithdrawOrder.StatusEnum::name,BatchWithdrawOrder.StatusEnum::getDesc));
        model.addAttribute("statusMap",statusMap);



        return "upstream_admin/withdraw_order/batch_import_withdraw_list";
    }


    @RequestMapping(value="/export")
    public void export(Model model, WithdrawOrderQueryParam param, HttpServletResponse response,HttpServletRequest request) throws Exception {
        logger.info("提现报表导出开始...");
        if (param == null) {
            param = new WithdrawOrderQueryParam();
        }
        param.setMerchantId(UpstreamAdminUserUtils.getLoginMerchant(request).getId());


        PageInfo<WithdrawOrder> page = withdrawOrderService.findManualWithdrawList(param);

        param.setTotal(page.getTotal());

        merchantWithdrawOrderExportService.export(response,param);
        logger.info("提现报表导出结束...");
    }

    @RequestMapping(value="/export_batch_withdraw")
    @OperationAuth(name = "导出代付订单", authCode = "batch_withdraw.export", group = "代付订单管理")
    public void exportBatchWithdraw(Model model, WithdrawOrderQueryParam param, HttpServletResponse response,HttpServletRequest request) throws Exception {
        logger.info("代付报表导出开始...");
        if (param == null) {
            param = new WithdrawOrderQueryParam();
        }
        param.setMerchantId(UpstreamAdminUserUtils.getLoginMerchant(request).getId());
        PageInfo<WithdrawOrder> page = withdrawOrderService.findBatchWithdrawList(param);
        param.setTotal(page.getTotal());
        long start = System.currentTimeMillis();
        merchantBatchWithdrawOrderExportService.export(response,param);
        logger.info("支付报表导出结束...共耗时:" + (System.currentTimeMillis() - start)/1000 + "s");
    }

    @ResponseBody
    @RequestMapping(value="/cancel_order/{id}")
    public ResponseResult cancelOrder(@PathVariable("id")int id,String remark, HttpServletRequest request) throws FundException {
        int merchantId = UpstreamAdminUserUtils.getLoginMerchant(request).getId();
        withdrawOrderService.cancelOrder(id, remark);
        return new ResponseResult(ResponseCode.SUCCESS, "取消成功", null);
    }

    @RequestMapping(value="/add_order")
    @ResponseBody
    public ResponseResult addOrder(ManualWithdrawOrderVO order, int cardid, Model model, HttpServletRequest request) throws IOException {
        UpstreamMerchant merchant = UpstreamAdminUserUtils.getLoginMerchant(request);
        int merchantId = merchant.getId();
        logger.info("商户提现创建订单：商户ID【{}】",merchantId);
        MerchantBankCard card = merchantBankCardService.findById(cardid);
        if (card.getMerchantId().intValue() != merchantId) {
            throw new RuntimeException("非法破坏系统。资金将于3分钟后全部冻结。");
        }
        if(!BCryptUtils.compareBcrypt(order.getSecondPassword(), merchant.getSecondPassword())){
            return new ResponseResult(ResponseCode.FAIL, "支付密码错误","");
        }
        order.setPayeeBankCodeStr(card.getPayeeBankCode());
        order.setBankDetailName(card.getBankDetailName());
        order.setCity(card.getCity());
        order.setPayeeBankAccount(card.getPayeeBankAccount());
        order.setPayeeIdCardNo(card.getPayeeIdCardNo());
        order.setPayeeName(card.getPayeeName());
        order.setPayeePhone(card.getPayeePhone());
        order.setProvince(card.getProvince());
        order.setUnionBankCode(card.getUnionBankCode());
        try {


            String requestIP = getRequestIP(request);
            order.setRequestIP(requestIP);
            order.setMerchantId(merchantId);
            order.setBankAccType(BankAccTypeEnum.PRIVATE);
            order.setAmount(MoneyUtils.yuan2fee(order.getAmountYuan()).intValue());
            order.setPayeeBankCode(BankCodeEnum.valueOfCode(order.getPayeeBankCodeStr()));
            order.setMerchantOrderNo(System.currentTimeMillis()+"");
            order.setCreateOrderTime(new Date());


            if (StringUtils.isNotBlank(order.getProvince())) {
                Area area = regionDataService.getByCode(Integer.valueOf(order.getProvince().trim()));
                order.setProvince(area.getName());
            }
            if (StringUtils.isNotBlank(order.getCity())) {
                Area area = regionDataService.getByCode(Integer.valueOf(order.getCity().trim()));
                order.setCity(area.getName());
            }
            String error = ValidationUtils.validate(order);
            if (error != null) {
                throw new WithdrawException(error);
            }
            order.setWithdrawType(WithdrawTypeEnum.MANUAL);
            withdrawFacade.createManualOrder(order);


            notifyComponent.notifyByAuthority("withdraw_order.audit_withdraw_order","您有一条新的代付订单待审核");

            return new ResponseResult(ResponseCode.SUCCESS, "添加成功","");
        } catch (FundException|WithdrawException e) {
            logger.error("", e);
            return new ResponseResult(ResponseCode.FAIL, "添加失败:" + e.getMessage(),"");
        }
    }

    private String getRequestIP(HttpServletRequest request) {
        String requestIP ="";
        try {
            requestIP = HttpRequestUtils.getIpAddr(request);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return requestIP;
    }

    @RequestMapping(value="/download_template")
    public void downloadTemplate(HttpServletResponse response) {
        File templateFile = new File(excelImportCfg.getTemplatePath());
        DownloadUtils.downloadByFile(response,templateFile,"withdraw_template.xlsx");
    }



    @RequestMapping(value="/batch_import_order")
    public String batchImportOrder( HttpServletRequest request,@RequestParam(value = "_secondPasswordVerifier") String secondPassword,MultipartFile file,HttpServletResponse response) throws Exception {
        UpstreamMerchant merchant = UpstreamAdminUserUtils.getLoginMerchant(request);
        UpstreamMerchant oldMerchant = merchantService.selectByPrimaryKey(merchant.getId());
        boolean checkResult = BCryptUtils.compareBcrypt(secondPassword, oldMerchant.getSecondPassword());
        if (!checkResult) {
            throw new WithdrawException( "旧密码有误");
        }
        int batchWithdrawKey = 8888;
        Integer merchantId = merchant.getId()+batchWithdrawKey;
        final String requestId = System.currentTimeMillis() + "";
        try {

            boolean lock = merchantLock.getLock(merchantId, requestId);
            if (!lock) {
                throw new WithdrawException("导入订单获取锁失败.请重试");
            }
            InputStream inputStream = file.getInputStream();
            List<Map<String,String>> orders =  withdrawOrderService.importOrder(inputStream);
            int beginRowNum = 3;
            Map<String,String> bankMap = Arrays.stream(BankCodeEnum.values()).collect(Collectors.toMap(BankCodeEnum::getBankName,BankCodeEnum::getCode));

            int rowNum = 0;
            for (Map<String, String> importOrder : orders) {
                importOrder.put("payeeBankName",importOrder.get("payeeBankCodeStr"));
                Map<String ,String> queryMap = queryBankByAccount.queryBankMapByBankAccount(importOrder.get("payeeBankAccount").trim());
                if (!"true".equals(queryMap.get("validated"))){
                    throw new WithdrawException(String.format("%s行银行卡号%s校验失败！"+bankMap.get("ret_msg"),beginRowNum+rowNum,importOrder.get("payeeBankAccount")));
                }

                try{
                    BankCodeEnum bankCodeEnum = BankCodeEnum.valueOfQueryCode(queryMap.get("bank"));
                    importOrder.put("payeeBankCode",bankCodeEnum.getCode());
                }catch (IllegalArgumentException e){
                    throw new WithdrawException(String.format("%s行银行类型%s暂不支持！",beginRowNum+rowNum,queryMap.get("bank_name")));
                }

                try{
                    new BigDecimal(importOrder.get("amountYuan"));
                }catch (Exception e){
                    throw new WithdrawException(String.format("%s行金额(%s)转换错误！",beginRowNum+rowNum,importOrder.get("amountYuan")));
                }
                importOrder.put("amount",MoneyUtils.yuan2fee(new BigDecimal(importOrder.get("amountYuan"))).toString());
                CreateWithdrawOrderRequest order = createOrderReq(importOrder,bankMap, request);
                String error = ValidationUtils.validate(order);
                if (error != null) {
                    throw new WithdrawException(String.format("%s行数据校验错误！"+error,beginRowNum+rowNum));
                }
                rowNum++;
            }

            Integer batchNum = new Integer(DateFormatUtils.format(new Date(),"MMddHHmmss"));


            Integer currentMaxBatchNum = batchWithdrawOrderImportService.findMaxBatchNum(merchant.getId());


            batchWithdrawOrderImportService.batchInsertByMap(orders,merchant.getId(),batchNum);


            if(currentMaxBatchNum!=null){
                batchWithdrawOrderImportService.deleteByMerchantId(merchant.getId(),currentMaxBatchNum);
            }

            return "redirect:/upstream_admin/withdraw/batch_import_list";
        }catch (DuplicateKeyException e){
            logger.error("批付订单重复", e);
            throw new Exception("批付订单重复！");
        }
        finally {

            merchantLock.releaseLock(merchantId, requestId);
        }
    }

    @RequestMapping(value="/batch_withdraw")
    @ResponseBody
    public  ResponseResult batchWithdraw( HttpServletRequest request,@RequestParam(value = "orderIds[]") Integer[] orderIds) throws WithdrawException {

        logger.info(">>>>>>>>>>批付开始...");
        if(!CollectionUtils.isNotEmpty(Arrays.asList(orderIds))){
            return new ResponseResult(ResponseCode.FAIL, "请选择批付订单!","");
        }
        UpstreamMerchant merchant = UpstreamAdminUserUtils.getLoginMerchant(request);
        Integer merchantId = merchant.getId();
        final String requestId = System.currentTimeMillis() + "";

        int i = 0;
        try {

            boolean lock = merchantLock.getLock(merchantId,requestId);
            if (!lock) {
                return new ResponseResult(ResponseCode.FAIL, "当前服务器代付排队人数较多，请稍后再试！","");
            }

            List<BatchWithdrawOrder> orders = batchWithdrawOrderImportService.findListByIds(orderIds,merchantId);
            if(!CollectionUtils.isNotEmpty(orders)){
                return new ResponseResult(ResponseCode.FAIL, "没有待受理订单！","");
            }

            Map<String,String> bankMap = Arrays.stream(BankCodeEnum.values()).collect(Collectors.toMap(BankCodeEnum::getBankName,BankCodeEnum::getCode));


            for (BatchWithdrawOrder batchWithdrawOrder : orders) {
                i++;

                batchWithdrawOrder.setStatus(BatchWithdrawOrder.StatusEnum.SUCCESS.name());
                batchWithdrawOrder.setErrorDesc("");
                int updateCount = batchWithdrawOrderImportService.updateOrderSuccess(batchWithdrawOrder);
                if(updateCount<=0){
                    continue;
                }

                CreateWithdrawOrderRequest order = createBatchWithdrawOrderReq(batchWithdrawOrder,bankMap, request);
                try {
                    withdrawFacade.createBatchWithdrawOrder(order, PaymentTypeEnum.BATCH_WITHDRAW);
                    batchWithdrawOrder.setStatus(BatchWithdrawOrder.StatusEnum.SUCCESS.name());
                } catch (Exception e) {
                    if("获取账户资金锁失败.请重试".equals(e.getMessage())){
                        batchWithdrawOrder.setStatus(BatchWithdrawOrder.StatusEnum.PROCESSING.name());
                    }else{
                        batchWithdrawOrder.setStatus(BatchWithdrawOrder.StatusEnum.FAIL.name());
                    }
                    batchWithdrawOrder.setErrorDesc(e.getMessage());
                    e.printStackTrace();
                    logger.info(">>>>>>>>>>批付失败:",e);
                }

                batchWithdrawOrderImportService.updateOrder(batchWithdrawOrder);
            }
        } finally {

            merchantLock.releaseLock(merchantId, requestId);
        }
        logger.info(">>>>>>>>>>批付结束，共"+i+"条记录");
        return new ResponseResult(ResponseCode.SUCCESS, "批付完成,请查看批付订单!","");
    }



    @RequestMapping(value="/delete_imported_order/{id}")
    @ResponseBody
    public ResponseResult deleteImportedOrder( HttpServletRequest request,@PathVariable("id") Integer id) throws WithdrawException {
        batchWithdrawOrderImportService.deleteById(id);
        return new ResponseResult(ResponseCode.SUCCESS, "删除成功!","");
    }


    @RequestMapping(value="/delete_all_imported_order")
    @ResponseBody
    public ResponseResult deleteAllImportedOrder( HttpServletRequest request) throws WithdrawException {
        UpstreamMerchant merchant = UpstreamAdminUserUtils.getLoginMerchant(request);
        Integer currentMaxBatchNum = batchWithdrawOrderImportService.findMaxBatchNum(merchant.getId());
        batchWithdrawOrderImportService.deleteByMerchantId(merchant.getId(),currentMaxBatchNum);
        return new ResponseResult(ResponseCode.SUCCESS, "删除成功!","");
    }

    private void validateImportData(List<Map<String, String>> orders,int beginRowNum) throws WithdrawException {

        StringBuffer sb = new StringBuffer();
        for(int i=0;i<orders.size();i++){
            Map<String,String> order = orders.get(i);
            String payeeName = order.get("payeeName");
            String payeeBankAccount = order.get("payeeBankAccount");
            String payeeBankCodeStr = order.get("payeeBankCodeStr");
            String amountYuan = order.get("amountYuan");
            if(StringUtils.isBlank(payeeName)){
                sb.append(String.format("第%s行收款人姓名不能为空！",i+beginRowNum)).append("<br>");
            }
            if(StringUtils.isBlank(payeeBankAccount)){
                sb.append(String.format("第%s行收款银行账号不能为空！",i+beginRowNum)).append("<br>");
            }
            if(StringUtils.isBlank(payeeBankCodeStr)){
                sb.append(String.format("第%s行银行类型不能为空！",i+beginRowNum)).append("<br>");
            }
            if(StringUtils.isBlank(amountYuan)){
                sb.append(String.format("第%s行代付金额不能为空！",i+beginRowNum)).append("<br>");
            }



        }
        if(sb.toString().length()>1){
            throw new WithdrawException("导入数据校验错误,请检查确认导入数据：<br>"+sb.toString());
        }
    }

    private CreateWithdrawOrderRequest  createBatchWithdrawOrderReq( BatchWithdrawOrder batchWithdrawOrder,Map<String,String> bankMap, HttpServletRequest request) {
        UpstreamMerchant merchant = UpstreamAdminUserUtils.getLoginMerchant(request);

        CreateWithdrawOrderRequest withdrawOrder = new CreateWithdrawOrderRequest();
        withdrawOrder.setAmount(batchWithdrawOrder.getAmount());
        withdrawOrder.setOrderTime(new Date());
        withdrawOrder.setClientIp(HttpUtils.getRemoteAddr(request));
        withdrawOrder.setMerchantOrderNo(System.currentTimeMillis()+"");
        withdrawOrder.setMerchantNo(merchant.getMerchantNo());

        withdrawOrder.setBankAccType(BankAccTypeEnum.PRIVATE);
        withdrawOrder.setPayeeName(batchWithdrawOrder.getPayeeName());
        withdrawOrder.setPayeeBankCode(batchWithdrawOrder.getPayeeBankCode()==null?BankCodeEnum.valueOfCode(bankMap.get(batchWithdrawOrder.getPayeeBankName())):BankCodeEnum.valueOfCode(batchWithdrawOrder.getPayeeBankCode()));
        withdrawOrder.setPayeeBankAccount(batchWithdrawOrder.getPayeeBankAccount());
        withdrawOrder.setPayeeIdCardNo(batchWithdrawOrder.getPayeeIdCardNo());
        withdrawOrder.setPayeePhone(batchWithdrawOrder.getPayeePhone());

        withdrawOrder.setProvince(batchWithdrawOrder.getProvince());
        withdrawOrder.setCity(batchWithdrawOrder.getCity());
        withdrawOrder.setBankDetailName(batchWithdrawOrder.getBankDetailName());
        withdrawOrder.setNotifyUrl("http://www.baidu.com");
        withdrawOrder.setOrderRemark("");
        if (StringUtils.isBlank(batchWithdrawOrder.getUnionBankCode())) {
            withdrawOrder.setUnionBankCode(withdrawOrder.getPayeeBankCode().getUnionCode());
        } else {
            withdrawOrder.setUnionBankCode(batchWithdrawOrder.getUnionBankCode());
        }
        withdrawOrder.setExtendParams(new HashMap<>());
        return withdrawOrder;
    }

    private CreateWithdrawOrderRequest createOrderReq( Map<String, String> importOrder,Map<String,String> bankMap, HttpServletRequest request) {
        UpstreamMerchant merchant = UpstreamAdminUserUtils.getLoginMerchant(request);

        CreateWithdrawOrderRequest withdrawOrder = new CreateWithdrawOrderRequest();
        withdrawOrder.setAmount(MoneyUtils.yuan2fee(new BigDecimal(importOrder.get("amountYuan"))).intValue());
        withdrawOrder.setOrderTime(new Date());
        withdrawOrder.setClientIp(HttpUtils.getRemoteAddr(request));
        withdrawOrder.setMerchantOrderNo(System.currentTimeMillis()+"");
        withdrawOrder.setMerchantNo(merchant.getMerchantNo());

        withdrawOrder.setBankAccType(BankAccTypeEnum.PRIVATE);
        withdrawOrder.setPayeeName(importOrder.get("payeeName"));
        withdrawOrder.setPayeeBankCode(BankCodeEnum.valueOfCode(bankMap.get(importOrder.get("payeeBankCodeStr"))));
        withdrawOrder.setPayeeBankAccount(importOrder.get("payeeBankAccount"));
        withdrawOrder.setPayeeIdCardNo(importOrder.get("payeeIdCardNo"));
        withdrawOrder.setPayeePhone(importOrder.get("payeePhone"));

        withdrawOrder.setProvince(importOrder.get("province"));
        withdrawOrder.setCity(importOrder.get("city"));
        withdrawOrder.setBankDetailName(importOrder.get("bankDetailName"));

        withdrawOrder.setNotifyUrl("http://www.baidu.com");
        withdrawOrder.setOrderRemark(importOrder.get("orderRemark"));
        if (StringUtils.isBlank(importOrder.get("unionBankCode"))) {
            withdrawOrder.setUnionBankCode(withdrawOrder.getPayeeBankCode().getUnionCode());
        } else {
            withdrawOrder.setUnionBankCode(importOrder.get("unionBankCode"));
        }
        withdrawOrder.setExtendParams(new HashMap<>());
        return withdrawOrder;
    }

    private ManualWithdrawOrderVO getManualWithdrawOrderVO(HttpServletRequest request, Map<String, String> importOrder, Map<String,String> bankMap) {
        ManualWithdrawOrderVO order = new ManualWithdrawOrderVO();
        int merchantId = UpstreamAdminUserUtils.getLoginMerchant(request).getId();
        order.setMerchantId(merchantId);
        order.setBankAccType(BankAccTypeEnum.PRIVATE);
        order.setPayeeBankCode(BankCodeEnum.valueOfCode(bankMap.get(importOrder.get("payeeBankCodeStr"))));
        order.setMerchantOrderNo(System.currentTimeMillis()+"");
        order.setCreateOrderTime(new Date());
        order.setPayeeName(importOrder.get("payeeName"));
        order.setPayeeBankAccount(importOrder.get("payeeBankAccount"));
        order.setAmount(MoneyUtils.yuan2fee(Integer.parseInt(importOrder.get("amountYuan"))).intValue());
        order.setPayeeIdCardNo(importOrder.get("payeeIdCardNo"));
        order.setPayeePhone(importOrder.get("payeePhone"));
        order.setUnionBankCode(importOrder.get("unionBankCode"));
        order.setProvince(importOrder.get("province"));
        order.setCity(importOrder.get("city"));
        order.setBankDetailName(importOrder.get("bankDetailName"));
        order.setOrderRemark(importOrder.get("orderRemark"));
        return order;
    }

    @RequestMapping(value="/to_import_order")
    public String toImportOrder(Model model) {
        return "upstream_admin/withdraw_order/import";
    }



    @RequestMapping(value="/to_add_order")
    public String toAddOrder(Model model, HttpServletRequest request, @RequestParam(name = "copyOrderId", required = false) Integer copyOrderId) {
        BankAccTypeEnum[] bankAccTypeEnums = BankAccTypeEnum.values();
        model.addAttribute("bankCodeEnums", BankCodeEnum.values());
        model.addAttribute("bankAccTypeEnums", bankAccTypeEnums);
        List<MerchantBankCard> cardlist = merchantBankCardService.findByMerchantid(UpstreamAdminUserUtils.getLoginMerchant(request).getId());
        List<MerchantBankCardVO> cardvos = UpstreamBankCardController.toVO(cardlist);
        model.addAttribute("cardlist", cardvos);
        if (copyOrderId != null) {
            WithdrawOrder oldOrder = withdrawOrderService.findById(copyOrderId);
            model.addAttribute("oldOrder", oldOrder);
        } else {
            model.addAttribute("oldOrder", new WithdrawOrder());
        }
        return "upstream_admin/withdraw_order/add_new";
    }

    @RequestMapping(value="/order_detail/{orderId}")
    public String orderDetail(@PathVariable("orderId") int orderId,Model model, HttpServletRequest request) {
//        WithdrawOrder order = withdrawOrderService.findById(orderId);
//        if (order.getMerchantId() != UpstreamAdminUserUtils.getLoginMerchant(request).getId().intValue()) {
//            throw new RuntimeException("警告,蓄意破坏系统，将导致当前登录账户资金冻结");
//        }
//        withdrawController.orderDetail(orderId, model);

        WithdrawOrder order = withdrawOrderService.findById(orderId);
        WithdrawOrderVO withdrawOrderVO = toVO(order);
        model.addAttribute("order",withdrawOrderVO);
        return "upstream_admin/withdraw_order/order_detail";
    }

    private List toVO(List<WithdrawOrder> list) {
        List<Integer> mchIds = list.stream() .map(WithdrawOrder::getMerchantId).distinct().collect(Collectors.toList());
        List<Merchant> merchantList = imerchantService.findByIds(mchIds);
        Map<Integer, Merchant> merchantMap = merchantList.stream().collect(Collectors.toMap(Merchant::getId, m -> m));
        Map<Integer,String> channelMap = channelService.findChannels(null).stream().collect(Collectors.toMap(Channel::getId,Channel::getName));
        Map<Integer, ChannelAccount> channelAccounts = channelAccountService.findAllChannelAccounts(null).stream().collect(Collectors.toMap(ChannelAccount::getId, r->r));

        List volist = new ArrayList();
        for (WithdrawOrder order : list) {
            WithdrawOrderVO vo = new WithdrawOrderVO();
            BeanUtils.copyProperties(order, vo);
            vo.setMerchantName(merchantMap.get(order.getMerchantId()).getMerchantName());

            String manualWithdrawIP = StringUtils.defaultString(merchantMap.get(order.getMerchantId()).getManualWithdrawIP());
            if(manualWithdrawIP.indexOf(StringUtils.defaultString(order.getRequestIP()))<0){
                vo.setValidRequestIP(false);
            }else{
                vo.setValidRequestIP(true);
            }


            String bankCardWhiteList = StringUtils.defaultString(merchantMap.get(order.getMerchantId()).getBankCardWhiteList());
            if(bankCardWhiteList.indexOf(StringUtils.defaultString(order.getPayeeBankAccount()))<0){
                vo.setValidPayeeBankAccount(false);
            }else{
                vo.setValidPayeeBankAccount(true);
            }

            vo.setChannelName(channelMap.get(order.getChannelId()));
            ChannelAccount channelAccount = channelAccounts.get(order.getChannelAccountId());
            vo.setChannelAcc(channelAccount==null?null:channelAccount.getAccount());
            vo.setChannelAccName(channelAccount==null?null:channelAccount.getName());

            volist.add(vo);
        }
        return volist;
    }
    private List<ChannelAccountVO> toAccountVO(List<ChannelAccount> accounts) {
        List<Channel> channels = channelService.findChannels(new ChannelQuery());
        Map<Integer,String> channelMap = channels.stream().collect(Collectors.toMap(Channel::getId,Channel::getName));
        List<ChannelAccountVO> channelAccountVOS = ChannelAccountViewUtils.toVO(accounts);
        for (ChannelAccountVO acc : channelAccountVOS) {
            acc.setChannelName(channelMap.get(acc.getChannelId()));
        }
        return channelAccountVOS;
    }
    private WithdrawOrderVO toVO(WithdrawOrder order) {
        List<WithdrawOrderVO> list = toVO(Arrays.asList(order));
        return list.get(0);
    }

}