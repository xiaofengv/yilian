package com.ajl.bfb.admin.common.web;


public final class AdminSessionKey {

    public static final String LOGIN_VERIFY_CODE = "admin_login_verify_code";

    public static final String LOGIN_USER = "admin_login_user";

    public static final String USER_AUTHORITY = "admin_user_authority";

    public static final String USER_MENU = "admin_user_menus";
}
