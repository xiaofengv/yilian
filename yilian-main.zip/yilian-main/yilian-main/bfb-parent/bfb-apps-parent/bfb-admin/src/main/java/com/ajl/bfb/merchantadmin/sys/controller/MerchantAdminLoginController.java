package com.ajl.bfb.merchantadmin.sys.controller;

import com.ajl.bfb.core.constants.PaymentTypeEnum;
import com.ajl.bfb.merchantadmin.common.web.MerchantAdminSessionKey;
import com.ajl.bfb.merchantadmin.common.web.MerchantAdminUserUtils;
import com.ajl.bfb.repo.merchant.model.Merchant;
import com.ajl.bfb.repo.merchant.model.MerchantPayType;
import com.ajl.bfb.repo.merchant.service.IMerchantPayTypeService;
import com.ajl.bfb.repo.merchant.service.IMerchantService;
import com.hippo.framework.core.enums.SwitchEnum;
import com.hippo.framework.util.security.BCryptUtils;
import com.hippo.framework.util.security.GoogleAuthenticator;
import com.hippo.framework.util.validation.ValidationUtils;
import com.hippo.framework.web.ResponseCode;
import com.hippo.framework.web.ResponseResult;
import com.hippo.framework.web.vo.LoginUserVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Objects;



@Controller
@RequestMapping("/merchant_admin/sys")
public class MerchantAdminLoginController {
    @Autowired
    private IMerchantService merchantService;
    @Autowired
    private IMerchantPayTypeService merchantPayTypeService;

    @Autowired
    private Environment env;

    @RequestMapping("/login")
    @ResponseBody
    public ResponseResult login(Model model, LoginUserVO userVO, HttpServletRequest request, HttpServletResponse response) {



        String validateResult = ValidationUtils.validate(userVO, LoginUserVO.class);
        if (validateResult != null) {
            return new ResponseResult(ResponseCode.FAIL, validateResult, null);
        }






        Merchant merchant = merchantService.findByMerchantNo(userVO.getUserName());

        String profile = env.getProperty("spring.profiles.active");
        /*if (!profile.equals("dev")) {
            if(merchant == null||!GoogleAuthenticator.authcode(userVO.getVerifyCode(),merchant.getVerificationCodeSecretKey())){
                return new ResponseResult(ResponseCode.FAIL, "验证码有误", null);
            }
        }*/

        if (merchant == null
                || !merchant.getStatus().equals(SwitchEnum.ON.name())
                || !BCryptUtils.compareBcrypt(userVO.getPassword(), merchant.getPassword())
                ) {
            return new ResponseResult(ResponseCode.FAIL, "用户名或密码错误", null);
        }

        if (!checkLoginIP(request, merchant)) {
            return new ResponseResult(ResponseCode.FAIL, "登录IP地址没有加入白名单！", null);
        }

        String withdraw = null;
        String batchWithdraw = null;

        List<MerchantPayType> merchantPayTypes = merchantPayTypeService.getMerchantPayTypes(merchant.getId());
        for (MerchantPayType p : merchantPayTypes) {
            if (SwitchEnum.valueOf(p.getStatus()) == SwitchEnum.ON) {
                if (PaymentTypeEnum.valueOf(p.getPayTypeCode()) == PaymentTypeEnum.WITHDRAW) {
                    withdraw = "true";
                }
                if (PaymentTypeEnum.valueOf(p.getPayTypeCode()) == PaymentTypeEnum.BATCH_WITHDRAW) {
                    batchWithdraw = "true";
                }
            }
        }
        request.getSession().setAttribute("withdrawAuth", withdraw);
        request.getSession().setAttribute("batchWithdrawAuth", batchWithdraw);
        MerchantAdminUserUtils.setSessionUser(merchant, request);

        return new ResponseResult(ResponseCode.SUCCESS, "登录成功", null);
    }

    private boolean checkLoginIP(HttpServletRequest request, Merchant merchant) {

        return true;
    }


    private void setVerifyCodeForDev(LoginUserVO userVO, HttpServletRequest request) {
        String profile = env.getProperty("spring.profiles.active");
        if (profile.equals("dev")) {
            userVO.setVerifyCode(Objects.toString(request.getSession().getAttribute(MerchantAdminSessionKey.LOGIN_VERIFY_CODE), ""));
        }
    }

    @RequestMapping("/home")
    public String home(HttpServletRequest request,Model model) {
        Merchant merchant = MerchantAdminUserUtils.getLoginMerchant(request);
        model.addAttribute("merchant",merchant);
        return "/merchant_admin/sys/home";
    }

    @RequestMapping("/logout")
    public String logout(Model model, HttpServletRequest request) {
        request.getSession().removeAttribute(MerchantAdminSessionKey.LOGIN_USER);
        request.getSession().invalidate();
        return "redirect:/merchant_admin/sys/to-login";
    }

    @RequestMapping("/to-login")
    public String toLogin(Model model, LoginUserVO userVO, HttpServletRequest request) {
        return "/merchant_admin/sys/user_login";
    }

}
