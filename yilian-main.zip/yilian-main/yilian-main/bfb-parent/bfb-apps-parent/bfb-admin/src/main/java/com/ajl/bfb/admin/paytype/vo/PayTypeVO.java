package com.ajl.bfb.admin.paytype.vo;

import com.ajl.bfb.core.constants.RateTypeEnum;
import com.ajl.bfb.core.util.RateUtils;
import com.ajl.bfb.repo.payment.model.PayType;
import com.hippo.framework.core.enums.SwitchEnum;

import java.math.BigDecimal;


public class PayTypeVO extends PayType {

    private BigDecimal defaultRatePercent;

    private BigDecimal defaultMerchantRatePercent;

    private BigDecimal minAmountYuan;

    private BigDecimal maxAmountYuan;

    public String getStatusStr() {
        return SwitchEnum.valueOf(getStatus()).getDesc();
    }

    public String getRateTypeStr() {
        return RateTypeEnum.valueOf(getRateType()).getViewDesc();
    }

    public BigDecimal getDefaultRatePercent() {
        return defaultRatePercent;
    }

    public void setDefaultRatePercent(BigDecimal defaultRatePercent) {
        this.defaultRatePercent = defaultRatePercent;
        setDefaultRate(RateUtils.percent2rate(defaultRatePercent));
    }

    public void setDefaultMerchantRatePercent(BigDecimal defaultMerchantRatePercent) {
        this.defaultMerchantRatePercent = defaultMerchantRatePercent;
        setMerchantDefaultRate(RateUtils.percent2rate(defaultMerchantRatePercent));
    }

    public BigDecimal getMinAmountYuan() {
        return minAmountYuan;
    }

    public void setMinAmountYuan(BigDecimal minAmountYuan) {
        this.minAmountYuan = minAmountYuan;
    }

    public BigDecimal getMaxAmountYuan() {
        return maxAmountYuan;
    }

    public void setMaxAmountYuan(BigDecimal maxAmountYuan) {
        this.maxAmountYuan = maxAmountYuan;
    }

    public BigDecimal getDefaultMerchantRatePercent() {
        return defaultMerchantRatePercent;
    }


}
