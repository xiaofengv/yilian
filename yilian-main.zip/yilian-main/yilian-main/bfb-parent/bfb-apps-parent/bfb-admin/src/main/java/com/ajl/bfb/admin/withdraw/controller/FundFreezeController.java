package com.ajl.bfb.admin.withdraw.controller;

import com.ajl.bfb.admin.common.web.AdminUserUtils;
import com.ajl.bfb.core.constants.TargetTypeEnum;
import com.ajl.bfb.repo.channel.model.ChannelAccount;
import com.ajl.bfb.repo.channel.service.IChannelAccountService;
import com.ajl.bfb.repo.fund.service.IFinanceFacadeService;
import com.ajl.bfb.repo.merchant.FundException;
import com.ajl.bfb.repo.merchant.model.FundFreeze;
import com.ajl.bfb.repo.merchant.model.FundFreezeFindParam;
import com.ajl.bfb.repo.merchant.model.Merchant;
import com.ajl.bfb.repo.merchant.service.IFundFreezeService;
import com.ajl.bfb.repo.merchant.service.IMerchantService;
import com.github.pagehelper.PageInfo;
import com.hippo.framework.auth.admin.OperationAuth;
import com.hippo.framework.auth.admin.model.SysUser;
import com.hippo.framework.auth.admin.service.ISysUserService;
import com.hippo.framework.operation.log.LogOperation;
import com.hippo.framework.util.validation.AssertUtils;
import com.hippo.framework.util.validation.ValidationUtils;
import com.hippo.framework.web.ResponseCode;
import com.hippo.framework.web.ResponseResult;
import org.apache.commons.lang3.EnumUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import static com.ajl.bfb.core.util.MoneyUtils.yuan2fee;
import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;


@Controller
@RequestMapping("/admin/fundFreeze")
public class FundFreezeController {
    @Autowired
    IFundFreezeService fundFreezeService;
    @Autowired
    IMerchantService merchantService;
    @Autowired
    IChannelAccountService channelAccountService;
    @Autowired
    ISysUserService sysUserService;
    @Autowired
    IFinanceFacadeService financeFacadeService;

    @RequestMapping("/list")
    @OperationAuth(name = "查询资金冻结", authCode = "fundFreeze.query", group = "资金冻结管理")
    public String fundFreezeList(FundFreezeFindParam param,Model model){
        PageInfo<FundFreeze> pageInfo = fundFreezeService.findFundFreezeList(param);
        List<FundFreeze> fundFreezes = pageInfo.getList();
        List<Integer> merchantIds = fundFreezes.stream().map(fundFreeze->fundFreeze.getMerchantId()).distinct().collect(Collectors.toList());
        List<Merchant> merchants = merchantService.findByIds(merchantIds);
        Map<Integer,String> merchantMap = merchants.stream().collect(Collectors.toMap(Merchant::getId, t -> t.getMerchantNo()));
        model.addAttribute("merchantMap", merchantMap);
        Map<Integer, String> userNameMap = getUserNameMap(fundFreezes);
        model.addAttribute("userNameMap", userNameMap);
        List<Integer> channelAccountids = fundFreezes.stream().map(fundFreeze->fundFreeze.getChannelAccId()).distinct().collect(Collectors.toList());
        List<ChannelAccount> channelAccounts = channelAccountService.findByIds(channelAccountids);
        Map<Integer,String> channelAccountMap = channelAccounts.stream().collect(Collectors.toMap(ChannelAccount::getId,t -> t.getAccount()));
        model.addAttribute("channelAccountMap", channelAccountMap);

        model.addAttribute("bizTypeList", FundFreeze.BizTypeEnum.values());
        Map<String,String> bizTypeMap = Arrays.stream(FundFreeze.BizTypeEnum.values()).collect(Collectors.toMap(FundFreeze.BizTypeEnum::name, r -> r.getDesc()));
        model.addAttribute("bizTypeMap", bizTypeMap);

        model.addAttribute("targeList", TargetTypeEnum.values());
        Map<String,String> targetMap = Arrays.stream(TargetTypeEnum.values()).collect(Collectors.toMap(TargetTypeEnum::name, r -> r.getDesc()));
        model.addAttribute("targetMap", targetMap);

        model.addAttribute("statusList", FundFreeze.StatusEnum.values());
        Map<String,String> statusMap = Arrays.stream(FundFreeze.StatusEnum.values()).collect(Collectors.toMap(FundFreeze.StatusEnum::name, r -> r.getDesc()));
        model.addAttribute("statusMap", statusMap);

        model.addAttribute("pageInfo",pageInfo);
        model.addAttribute("queryParam",param);
        return "/admin/fund_freeze/list";
    }


    private Map<Integer, String> getUserNameMap(List<FundFreeze> fundFreezes) {
        List<Integer> operaters = new ArrayList<>();
        List<Integer> freezers = fundFreezes.stream().map(fundFreeze->fundFreeze.getFreezer()).distinct().collect(Collectors.toList());
        List<Integer> unfreezers = fundFreezes.stream().map(fundFreeze->fundFreeze.getUnfreezer()).distinct().collect(Collectors.toList());
        operaters.addAll(freezers);
        operaters.addAll(unfreezers);
        List<SysUser> users = sysUserService.findAll();
        return users.stream().filter(SysUser->operaters.contains(SysUser.getId())).collect(Collectors.toMap(SysUser::getId,t->t.getUserName()));
    }

    @RequestMapping("/to_add")
    @OperationAuth(name = "手工冻结商户资金", authCode = "fundFreeze.add", group = "资金冻结管理")
    public String addFundFreeze(FundFreezeFindParam param,Model model){
        return "/admin/fund_freeze/add";
    }

    @RequestMapping("/create_merchant_fundfreeze")
    @ResponseBody
    @OperationAuth(name = "手工冻结商户资金", authCode = "fundFreeze.add", group = "资金冻结管理")
    @LogOperation(name = "冻结资金",module = "资金冻结管理")
    public ResponseResult createManualMerchantFundFreeze(HttpServletRequest request, FundFreeze fundFreeze, Model model) throws FundException {
        Merchant merchant = merchantService.findByMerchantNo(fundFreeze.getMerchantAccount());
        AssertUtils.objectNotNull(merchant,String.format("商户号:%s不存在！",fundFreeze.getMerchantAccount()));
        String error = ValidationUtils.validate(fundFreeze);
        if(StringUtils.isNotEmpty(error)){
            return new ResponseResult(ResponseCode.FAIL, "创建失败！"+error, null);
        }
        if(!EnumUtils.isValidEnum(FundFreeze.BizTypeEnum.class,fundFreeze.getBusinessType())){
            return new ResponseResult(ResponseCode.FAIL, "业务类型不存在！", null);
        }
        SysUser sysUser = AdminUserUtils.getCurrentLoginUser(request);
        financeFacadeService.onManualFreezeMerchantFund(merchant.getId(),yuan2fee(fundFreeze.getAmountYuan()).intValue(),sysUser.getId(),fundFreeze.getRemark());
        return new ResponseResult(ResponseCode.SUCCESS, "冻结成功！", null);
    }

    @RequestMapping("/to_unfreeze/{freezeId}")
    @OperationAuth(name = "解冻资金", authCode = "fundFreeze.unfreezingFunds", group = "资金冻结管理")
    public String toUnfreeze(@PathVariable("freezeId") Integer freezeId, Model model){
        FundFreeze fundFreeze = fundFreezeService.findById(freezeId);
        Merchant merchant = merchantService.findById(fundFreeze.getMerchantId());
        fundFreeze.setMerchantAccount(merchant.getMerchantNo());
        model.addAttribute("fundFreeze",fundFreeze);
        return "/admin/fund_freeze/unfreeze_fund";
    }


    @RequestMapping("/unfreeze_merchant_fund")
    @ResponseBody
    @OperationAuth(name = "解冻资金", authCode = "fundFreeze.unfreezingFunds", group = "资金冻结管理")
    @LogOperation(name = "解冻资金",module = "资金冻结管理")
    public ResponseResult unFreezeMerchantFund(HttpServletRequest request, FundFreeze fundFreeze, Model model) throws FundException {
        SysUser sysUser = AdminUserUtils.getCurrentLoginUser(request);
        financeFacadeService.onManualUnFreezeMerchantFund(fundFreeze.getId(),fundFreeze.getRemark(),sysUser.getId());
        return new ResponseResult(ResponseCode.SUCCESS, "解冻成功！", null);
    }
}
