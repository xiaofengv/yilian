package com.ajl.bfb.admin.common.web;

import com.hippo.framework.web.util.HttpRequestUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.NoHandlerFoundException;

import javax.servlet.http.HttpServletRequest;


@ControllerAdvice(basePackages = "com.ajl.bfb.admin")
public class ManagerExceptionHandlerAdvice {

    public static final String EXCEPTION_KEY = "exception";
    private static Logger logger = LogManager.getLogger(com.ajl.bfb.itg.config.ItgExceptionHandlerAdvice.class);

    @ExceptionHandler(value=Throwable.class)
    public ModelAndView exception(Throwable exception,HttpServletRequest request,HandlerMethod method){
        logger.error("异常请求uri:" + request.getRequestURI());
        logger.error("bfb pay程序异常", exception);

        request.setAttribute("error",extractErrorMsg(exception));
        ModelAndView mav = new ModelAndView();
        mav.addObject(EXCEPTION_KEY, exception);

        if(HttpRequestUtils.isAjaxForSpringMvc(request,method)) {
            mav.setViewName("forward:/admin/error/ajax-http500");
        } else {
            mav.setViewName("forward:/admin/error/http500");
        }
        return mav;
    }

    private String extractErrorMsg(Throwable exception) {
        if (StringUtils.isNotBlank(exception.getMessage())) {
            return exception.getMessage();
        }
        return  "golbal未知的程序错误";
    }

    @ExceptionHandler(value = NoHandlerFoundException.class)
    public ModelAndView defaultErrorHandler(HttpServletRequest request, Exception e) throws Exception {
        logger.error("request uri:" + request.getRequestURI());
        logger.error("bfb pay程序异常", e);

        request.setAttribute("error", ExceptionUtils.getStackTrace(e));
        ModelAndView mav = new ModelAndView();
        mav.addObject("exception", e);
        mav.addObject("url", request.getRequestURL());
        mav.setViewName("forward:/admin/error/http404");
        return mav;
    }
}
