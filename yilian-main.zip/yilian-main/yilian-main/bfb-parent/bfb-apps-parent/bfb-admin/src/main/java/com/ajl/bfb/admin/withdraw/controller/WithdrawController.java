package com.ajl.bfb.admin.withdraw.controller;

import com.ajl.bfb.admin.channelaccount.controller.ChannelAccountController;
import com.ajl.bfb.admin.channelaccount.util.ChannelAccountViewUtils;
import com.ajl.bfb.admin.channelaccount.vo.ChannelAccountVO;
import com.ajl.bfb.admin.withdraw.vo.WithdrawOrderVO;
import com.ajl.bfb.common.exception.QueryOrderException;
import com.ajl.bfb.common.withdraw.model.CreateManualWithdrawOrderRequest;
import com.ajl.bfb.common.withdraw.model.QueryWithdrawOrderResponse;
import com.ajl.bfb.common.withdraw.model.WithdrawCallbackResponse;
import com.ajl.bfb.core.constants.*;
import com.ajl.bfb.pay.withdraw.IWithdrawCallbackProxy;
import com.ajl.bfb.pay.withdraw.IWithdrawFacade;
import com.ajl.bfb.pay.withdraw.WithdrawMerchantNotifyException;
import com.ajl.bfb.pay.withdraw.model.CreateWithdrawOrderResult;
import com.ajl.bfb.pay.withdraw.model.QueryWithdrawOrderParam;
import com.ajl.bfb.repo.channel.model.Channel;
import com.ajl.bfb.repo.channel.model.ChannelAccount;
import com.ajl.bfb.repo.channel.model.ChannelQuery;
import com.ajl.bfb.repo.channel.service.IChannelAccountService;
import com.ajl.bfb.repo.channel.service.IChannelService;
import com.ajl.bfb.repo.channel.service.IGlobalSettingService;
import com.ajl.bfb.repo.export.service.IExportService;
import com.ajl.bfb.repo.merchant.FundException;
import com.ajl.bfb.repo.merchant.model.Merchant;
import com.ajl.bfb.repo.merchant.service.IMerchantPayTypeAccountService;
import com.ajl.bfb.repo.merchant.service.IMerchantService;
import com.ajl.bfb.repo.stat.model.OrderStat;
import com.ajl.bfb.repo.withdraw.WithdrawException;
import com.ajl.bfb.repo.withdraw.model.WithdrawOrder;
import com.ajl.bfb.repo.withdraw.model.WithdrawOrderQueryParam;
import com.ajl.bfb.repo.withdraw.service.IWithdrawOrderService;
import com.github.pagehelper.PageInfo;
import com.hippo.framework.auth.admin.OperationAuth;
import com.hippo.framework.core.enums.OpenStatusEnum;
import com.hippo.framework.operation.log.LogOperation;
import com.hippo.framework.util.validation.AssertUtils;
import com.hippo.framework.web.ResponseCode;
import com.hippo.framework.web.ResponseResult;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletResponse;
import java.util.*;
import java.util.stream.Collectors;


@Controller
@RequestMapping(value="/admin/withdraw")
public class WithdrawController {

    private static final Logger logger = LogManager.getLogger(WithdrawController.class);
    @Autowired
    private IWithdrawOrderService withdrawOrderService;
    @Autowired
    private IMerchantService merchantService;
    @Autowired
    private IWithdrawFacade withdrawFacade;
    @Autowired
    private IChannelAccountService channelAccountService;
    @Autowired
    private ChannelAccountController channelAccountController;
    @Autowired
    private IWithdrawCallbackProxy withdrawCallbackProxy;
    @Autowired
    private IExportService withdrawOrderExportService;
    @Autowired
    private IExportService batchWithdrawOrderExportService;

    @Autowired
    private IGlobalSettingService globalSettingService;
    @Autowired
    private IMerchantPayTypeAccountService merchantPayTypeAccountService;
    @Autowired
    private IChannelService channelService;


    @RequestMapping(value="/list")
    @OperationAuth(name = "代付订单管理", authCode = "withdraw_order.list", group = "代付订单管理")
    public String list(Model model,WithdrawOrderQueryParam param) {
        if (param == null) {
            param = new WithdrawOrderQueryParam();
        }

        PageInfo<WithdrawOrder> page = withdrawOrderService.findList(param);
        OrderStat orderTotal = withdrawOrderService.queryOrderTotal(param);
        model.addAttribute("orderTotal", orderTotal);
        List<WithdrawOrder> list = page.getList();
        page.setList(toVO(list));

        model.addAttribute("withdrawTypeList", WithdrawTypeEnum.values());
        model.addAttribute("pageInfo", page);
        model.addAttribute("queryParam", param);
        model.addAttribute("orderStatusList", OrderStatusEnum.values());
        model.addAttribute("auditStatusList", AuditStatusEnum.values());
        return "admin/withdraw/list";
    }

    @RequestMapping(value="/manual_withdraw_list")
    @OperationAuth(name = "查询提现订单", authCode = "withdraw_order.query", group = "代付订单管理")
    public String manualWithdrawList(Model model,WithdrawOrderQueryParam param) {
        if (param == null) {
            param = new WithdrawOrderQueryParam();
        }
        param.setPageSize(20);
        PageInfo<WithdrawOrder> page = withdrawOrderService.findManualWithdrawList(param);
        OrderStat orderTotal = withdrawOrderService.queryManualOrderTotal(param);
        model.addAttribute("orderTotal", orderTotal);
        List<WithdrawOrder> list = page.getList();
        page.setList(toVO(list));

        model.addAttribute("withdrawTypeList", WithdrawTypeEnum.values());
        model.addAttribute("pageInfo", page);
        model.addAttribute("queryParam", param);
        model.addAttribute("orderStatusList", OrderStatusEnum.values());
        model.addAttribute("auditStatusList", AuditStatusEnum.values());


        List<ChannelAccount> channelAccounts = channelAccountService.findAllChannelAccounts(null);

        List<ChannelAccountVO> channelAccountVOS = toAccountVO(channelAccounts);
        Map<String,List<ChannelAccountVO>> channelVOMap = channelAccountVOS.stream().collect(Collectors.groupingBy(channelAccountVO->channelAccountVO.getChannelName()));
        model.addAttribute("channelVOMap",channelVOMap);

        return "admin/withdraw/list";
    }

    @RequestMapping(value="/batch_withdraw_list")
    @OperationAuth(name = "代付订单管理", authCode = "batch_withdraw.list", group = "代付订单管理")
    public String batchWithdrawList(Model model,WithdrawOrderQueryParam param) {
        if (param == null) {
            param = new WithdrawOrderQueryParam();
        }

        PageInfo<WithdrawOrder> page = withdrawOrderService.findBatchWithdrawList(param);
        OrderStat orderTotal = withdrawOrderService.queryBatchOrderTotal(param);
        model.addAttribute("orderTotal", orderTotal);
        List<WithdrawOrder> list = page.getList();
        page.setList(toVO(list));

        model.addAttribute("withdrawTypeList", WithdrawTypeEnum.values());
        model.addAttribute("pageInfo", page);
        model.addAttribute("queryParam", param);
        model.addAttribute("orderStatusList", OrderStatusEnum.values());
        model.addAttribute("auditStatusList", AuditStatusEnum.values());


        List<ChannelAccount> channelAccounts = channelAccountService.findAllChannelAccounts(null);

        List<ChannelAccountVO> channelAccountVOS = toAccountVO(channelAccounts);
        Map<String,List<ChannelAccountVO>> channelVOMap = channelAccountVOS.stream().collect(Collectors.groupingBy(channelAccountVO->channelAccountVO.getChannelName()));
        model.addAttribute("channelVOMap",channelVOMap);


        return "admin/withdraw/batch_withdraw_list";
    }


    private List<ChannelAccountVO> toAccountVO(List<ChannelAccount> accounts) {
        List<Channel> channels = channelService.findChannels(new ChannelQuery());
        Map<Integer,String> channelMap = channels.stream().collect(Collectors.toMap(Channel::getId,Channel::getName));
        List<ChannelAccountVO> channelAccountVOS = ChannelAccountViewUtils.toVO(accounts);
        for (ChannelAccountVO acc : channelAccountVOS) {
            acc.setChannelName(channelMap.get(acc.getChannelId()));
        }
        return channelAccountVOS;
    }

    @RequestMapping(value="/export")
    @OperationAuth(name = "导出提现订单", authCode = "withdraw_order.export", group = "代付订单管理")
    public void export(Model model, WithdrawOrderQueryParam param, HttpServletResponse response) throws Exception {
        logger.info("提现报表导出开始...");
        if (param == null) {
            param = new WithdrawOrderQueryParam();
        }

        PageInfo<WithdrawOrder> page = withdrawOrderService.findManualWithdrawList(param);
        param.setTotal(page.getTotal());
        long start = System.currentTimeMillis();
        withdrawOrderExportService.export(response,param);
        logger.info("提现报表导出结束...共耗时:" + (System.currentTimeMillis() - start)/1000 + "s");
    }

    @RequestMapping(value="/export_batch_withdraw")
    public void exportBatchWithdraw(Model model, WithdrawOrderQueryParam param, HttpServletResponse response) throws Exception {
        logger.info("代付报表导出开始...");
        if (param == null) {
            param = new WithdrawOrderQueryParam();
        }

        PageInfo<WithdrawOrder> page = withdrawOrderService.findBatchWithdrawList(param);
        param.setTotal(page.getTotal());
        long start = System.currentTimeMillis();
        batchWithdrawOrderExportService.export(response,param);
        logger.info("支付报表导出结束...共耗时:" + (System.currentTimeMillis() - start)/1000 + "s");
    }


    @RequestMapping(value="/order_detail/{orderId}")
    @OperationAuth(name = "审核提现订单", authCode = "withdraw_order.review", group = "代付订单管理")
    public String orderDetail(@PathVariable("orderId") int orderId,Model model) {
        WithdrawOrder order = withdrawOrderService.findById(orderId);
        WithdrawOrderVO withdrawOrderVO = toVO(order);
        model.addAttribute("order",withdrawOrderVO);
        return "admin/withdraw/order_detail";
    }

    @RequestMapping(value="/sync_order_status")
    @ResponseBody
    public ResponseResult syncOrderStatus(int withdrawId) {
        WithdrawOrder order = withdrawOrderService.findById(withdrawId);
        QueryWithdrawOrderParam param = new QueryWithdrawOrderParam();
        param.setMerchantOrderNo(order.getMerchantOrderNo());
        param.setMerchantNo(order.getMerchantNo());
        try {
            QueryWithdrawOrderResponse rsp = withdrawFacade.queryWithdrawOrder(param);

            if (rsp.getResultCode() == ResultCodeEnum.FAIL) {
                return new ResponseResult(ResponseCode.FAIL, rsp.getResultMsg(), "");
            } else if (rsp.getResultCode() == ResultCodeEnum.SUCCESS) {
                String msg = "同步结果:订单状态:" + rsp.getResultMsg();
                return new ResponseResult(ResponseCode.SUCCESS, msg, "");
            } else {
                throw new RuntimeException("非法的业务状态:" + rsp.getResultCode().getDesc());
            }
        } catch (QueryOrderException|FundException e) {
            logger.error("同步代付订单异常", e);
            return new ResponseResult(ResponseCode.FAIL, "同步代付订单异常:" + e.getMessage(), "");
        } catch (WithdrawMerchantNotifyException e) {
            logger.error("下游通知异常", e);
            return new ResponseResult(ResponseCode.FAIL, "下游通知异常:" + e.getMessage(), "");
        }
    }

    @RequestMapping(value="/audit_withdraw_order")
    @ResponseBody
    @OperationAuth(name = "代付订单审核", authCode = "withdraw_order.audit_withdraw_order", group = "代付订单管理")
    @LogOperation(name = "代付订单审核",module = "代付订单")
    public ResponseResult auditWithdrawOrder(Model model, int withdrawId, String auditStatus, String auditRemark) throws FundException {
        if (withdrawId ==0 || StringUtils.isBlank(auditStatus) || StringUtils.isBlank(auditStatus)) {
            return new ResponseResult(ResponseCode.FAIL,"参数非法", "");
        }

        WithdrawOrder order = withdrawOrderService.findById(withdrawId);
        Merchant merchant = merchantService.findByMerchantNo(order.getMerchantNo());

        String manualWithdrawIP = StringUtils.defaultString(merchant.getManualWithdrawIP());
        if(manualWithdrawIP.indexOf(StringUtils.defaultString(order.getRequestIP()))<0){
            return new ResponseResult(ResponseCode.FAIL, "请求IP地址没有加入白名单", "");
        }


        String bankCardWhiteList = StringUtils.defaultString(merchant.getBankCardWhiteList());
        if(bankCardWhiteList.indexOf(StringUtils.defaultString(order.getPayeeBankAccount()))<0){
            return new ResponseResult(ResponseCode.FAIL, "银行卡号没有加入白名单", "");
        }


        Date currentTime = new Date();
        int withdrawMaxCount = globalSettingService.getWithdrawMaxCount();
        int orderCount = withdrawOrderService.queryOrderCountByBankCardNo(order.getPayeeBankAccount(),DateUtils.addDays(currentTime,-1),currentTime);
        if(orderCount>withdrawMaxCount){
            return new ResponseResult(ResponseCode.FAIL, "该卡24小时内代付笔数超过限制", "");
        }

        AuditStatusEnum auditSt = AuditStatusEnum.valueOf(auditStatus);
        if (auditSt == AuditStatusEnum.SUCCESS) {
            withdrawOrderService.auditOrderSuccess(withdrawId,auditRemark);
        } else if (auditSt == AuditStatusEnum.FAIL) {
            withdrawOrderService.auditOrderFail(withdrawId,auditRemark);
        } else {
            throw new RuntimeException("输入了非法的订单审核状态");
        }
        return new ResponseResult(ResponseCode.SUCCESS, "审核成功", "");
    }

    @RequestMapping(value="/to_do_withdarw/{withdrawId}")
    public String toDoWithdraw(Model model,@PathVariable("withdrawId") int withdrawId) {

        WithdrawOrder order = withdrawOrderService.findById(withdrawId);
        WithdrawOrderVO withdrawOrderVO = toVO(order);
        List<ChannelAccount> availableAccs = channelAccountService.findAvailableAccsByBank(BankCodeEnum.valueOfCode(order.getPayeeBankCode()));
        List<ChannelAccountVO> channelAccountVOS = channelAccountController.toAccountVO(availableAccs, true);


        List<ChannelAccount> specifyAccountList = merchantPayTypeAccountService.findMerchantPayTypeAccounts(order.getMerchantId(), PaymentTypeEnum.WITHDRAW);
        List<ChannelAccountVO> specifyAccountListVOS = channelAccountController.toAccountVO(specifyAccountList, true);

        model.addAttribute("specifyAccountList", specifyAccountListVOS);
        model.addAttribute("channelAccountList", channelAccountVOS);
        model.addAttribute("order", withdrawOrderVO);
        return "/admin/withdraw/dowithdraw";
    }

    @RequestMapping(value="/do_withdarw")
    @ResponseBody
    @OperationAuth(name = "提交代付", authCode = "withdraw_order.do_withdarw", group = "代付订单管理")
    @LogOperation(name = "代付提交",module = "代付订单")
    public ResponseResult doWithdraw(int withdrawId, int channelAccountId) throws WithdrawException {
        Assert.isTrue(withdrawId>0);
        Assert.isTrue(channelAccountId>0);
        CreateManualWithdrawOrderRequest req = new CreateManualWithdrawOrderRequest();
        req.setWithdrawId(withdrawId);
        req.setChannelAccountId(channelAccountId);
        CreateWithdrawOrderResult withdrawOrderResult = withdrawFacade.doManualOrder(req,WithdrawTypeEnum.MANUAL);
        if (withdrawOrderResult.getResultCode() != WithdrawResultCodeEnum.FAIL) {
            return new ResponseResult(ResponseCode.SUCCESS, "代付申请已提交上游成功", "");
        } else {
            return new ResponseResult(ResponseCode.SUCCESS, withdrawOrderResult.getResultDesc(), "");
        }
    }


    @RequestMapping(value="/do_offline_withdarw")
    @ResponseBody
    @OperationAuth(name = "提交代付", authCode = "withdraw_order.do_withdarw", group = "代付订单管理")
    @LogOperation(name = "代付提交",module = "代付订单")
    public ResponseResult doOfflineWithdarw(int withdrawId, int channelAccountId) throws WithdrawException {
        Assert.isTrue(withdrawId>0);
        Assert.isTrue(channelAccountId>0);
        CreateManualWithdrawOrderRequest req = new CreateManualWithdrawOrderRequest();
        req.setWithdrawId(withdrawId);
        req.setChannelAccountId(channelAccountId);
        CreateWithdrawOrderResult withdrawOrderResult = withdrawFacade.doManualOrder(req,WithdrawTypeEnum.MANUAL_OFFLINE_TRANSFER);
        if (withdrawOrderResult.getResultCode() != WithdrawResultCodeEnum.FAIL) {
            return new ResponseResult(ResponseCode.SUCCESS, "代付申请已提交上游成功", "");
        } else {
            return new ResponseResult(ResponseCode.SUCCESS, withdrawOrderResult.getResultDesc(), "");
        }
    }


    @RequestMapping(value="/cannel_withdraw_order")
    @ResponseBody
    @OperationAuth(name = "取消代付", authCode = "withdraw_order.cannel_withdraw_order", group = "代付订单管理")
    @LogOperation(name = "取消代付",module = "代付订单")
    public ResponseResult cannelWithdraw(int withdrawId, @RequestParam("orderResultDesc")String orderResultDesc) throws WithdrawException, FundException {
        withdrawFacade.cannelWithdraw(withdrawId, orderResultDesc);
        return new ResponseResult(ResponseCode.SUCCESS, "取消成功", "");
    }

    @RequestMapping(value="/to_modify_order_status")
    public String toModifyOrderStatus(int withdrawId, Model model) {
        model.addAttribute("orderStatusList", new OrderStatusEnum[]{OrderStatusEnum.SUCCESS, OrderStatusEnum.FAIL});
        model.addAttribute("withdrawId", withdrawId);
        return "/admin/withdraw/modify_withdraw_order";
    }

    @RequestMapping(value="/modify_order_status")
    @ResponseBody
    @OperationAuth(name = "代付订单状态修改", authCode = "withdraw_order.modify_order_status", group = "代付订单管理")
    @LogOperation(name = "代付订单状态修改",module = "代付订单")
    public ResponseResult modifyOrderStatus(int withdrawId, String orderResultDesc,String orderStatus) throws FundException, WithdrawMerchantNotifyException {
        logger.info("直接修改代付订单状态id:%s, remark:%s, status:%s", withdrawId, orderResultDesc, orderResultDesc);
        AssertUtils.stringNotBlank(orderResultDesc, "备注不能为空");
        AssertUtils.stringNotBlank(orderStatus, "状态不能为空");
        OrderStatusEnum orderSt = OrderStatusEnum.valueOf(orderStatus);
        if (orderSt != OrderStatusEnum.SUCCESS && orderSt != OrderStatusEnum.FAIL) {
            throw new RuntimeException("非法的status参数:" + orderStatus);
        }
        WithdrawOrder order = withdrawOrderService.findById(withdrawId);

        if (OrderStatusEnum.valueOf(order.getOrderStatus()) == OrderStatusEnum.PROCESSING &&
                OpenStatusEnum.valueOf(order.getRequestChannelFlag()) == OpenStatusEnum.Y) {
            WithdrawCallbackResponse rsp = new WithdrawCallbackResponse();
            rsp.setOrderDesc(orderResultDesc);
            rsp.setOrderStatus(orderSt);
            rsp.setPlateformOrderNo(order.getPlatformOrderNo());
            rsp.setTotalFee(order.getAmount());
            rsp.setResponseContent("N/A手动改单");
            withdrawCallbackProxy.doCallback(rsp, true);
            return new ResponseResult(ResponseCode.SUCCESS, "修改成功", "");
        } else {
            return new ResponseResult(ResponseCode.FAIL, "此订单状态下不能改单", "");
        }
    }

    private List toVO(List<WithdrawOrder> list) {
        List<Integer> mchIds = list.stream() .map(WithdrawOrder::getMerchantId).distinct().collect(Collectors.toList());
        List<Merchant> merchantList = merchantService.findByIds(mchIds);
        Map<Integer, Merchant> merchantMap = merchantList.stream().collect(Collectors.toMap(Merchant::getId, m -> m));
        Map<Integer,String> channelMap = channelService.findChannels(null).stream().collect(Collectors.toMap(Channel::getId,Channel::getName));
        Map<Integer,ChannelAccount> channelAccounts = channelAccountService.findAllChannelAccounts(null).stream().collect(Collectors.toMap(ChannelAccount::getId,r->r));

        List volist = new ArrayList();
        for (WithdrawOrder order : list) {
            WithdrawOrderVO vo = new WithdrawOrderVO();
            BeanUtils.copyProperties(order, vo);
            vo.setMerchantName(merchantMap.get(order.getMerchantId()).getMerchantName());

            String manualWithdrawIP = StringUtils.defaultString(merchantMap.get(order.getMerchantId()).getManualWithdrawIP());
            if(manualWithdrawIP.indexOf(StringUtils.defaultString(order.getRequestIP()))<0){
                vo.setValidRequestIP(false);
            }else{
                vo.setValidRequestIP(true);
            }


            String bankCardWhiteList = StringUtils.defaultString(merchantMap.get(order.getMerchantId()).getBankCardWhiteList());
            if(bankCardWhiteList.indexOf(StringUtils.defaultString(order.getPayeeBankAccount()))<0){
                vo.setValidPayeeBankAccount(false);
            }else{
                vo.setValidPayeeBankAccount(true);
            }

            vo.setChannelName(channelMap.get(order.getChannelId()));
            ChannelAccount channelAccount = channelAccounts.get(order.getChannelAccountId());
            vo.setChannelAcc(channelAccount==null?null:channelAccount.getAccount());
            vo.setChannelAccName(channelAccount==null?null:channelAccount.getName());

            volist.add(vo);
        }
        return volist;
    }

    private WithdrawOrderVO toVO(WithdrawOrder order) {
        List<WithdrawOrderVO> list = toVO(Arrays.asList(order));
        return list.get(0);
    }

}
