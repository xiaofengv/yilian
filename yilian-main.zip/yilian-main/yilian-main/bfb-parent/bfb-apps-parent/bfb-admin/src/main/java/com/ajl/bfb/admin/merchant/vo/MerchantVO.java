package com.ajl.bfb.admin.merchant.vo;

import com.ajl.bfb.core.constants.AccountModeEnum;
import com.ajl.bfb.core.constants.WithdrawModeEnum;
import com.ajl.bfb.repo.merchant.model.Merchant;
import com.hippo.framework.util.security.GoogleAuthenticator;


public class MerchantVO extends Merchant {

    private String agentName;

    public String getAgentName() {
        return agentName;
    }

    public void setAgentName(String agentName) {
        this.agentName = agentName;
    }


    private String paymentAccListStr;

    private String withdrawAccListStr;

    public String getWithdrawModeStr() {
        if (getWithdrwMode() == null) {
            return "";
        }
        return WithdrawModeEnum.valueOf(getWithdrwMode()).getDesc();
    }

    public String getChannelModeStr() {
        return AccountModeEnum.valueOf(getChannelMode()).getDesc();
    }

    public String getPayAccountModeStr() {
        return AccountModeEnum.valueOf(getPayAccountMode()).getDesc();
    }

    public String getWithdrawAccountModeStr() {
        return AccountModeEnum.valueOf(getWithdrawAccountMode()).getDesc();
    }

    public String getPaymentAccListStr() {
        return paymentAccListStr;
    }

    public void setPaymentAccListStr(String paymentAccListStr) {
        this.paymentAccListStr = paymentAccListStr;
    }

    public String getWithdrawAccListStr() {
        return withdrawAccListStr;
    }

    public void setWithdrawAccListStr(String withdrawAccListStr) {
        this.withdrawAccListStr = withdrawAccListStr;
    }

    public String getQrUrl(){
        return "qr_code_image?content="+GoogleAuthenticator.getQRCodeURL(this.getMerchantNo(),this.getVerificationCodeSecretKey());

    }
}
