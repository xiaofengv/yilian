package com.ajl.bfb.admin.manualorder.controller;

import com.ajl.bfb.admin.channelaccount.controller.ChannelAccountController;
import com.ajl.bfb.admin.channelaccount.vo.ChannelAccountVO;
import com.ajl.bfb.admin.common.web.AdminUserUtils;
import com.ajl.bfb.admin.manualorder.vo.TransferWithdrawOrderVO;
import com.ajl.bfb.admin.withdraw.vo.WithdrawOrderVO;
import com.ajl.bfb.core.constants.*;
import com.ajl.bfb.core.util.MoneyUtils;
import com.ajl.bfb.merchantadmin.withdraw.vo.ManualWithdrawOrderVO;
import com.ajl.bfb.pay.withdraw.IWithdrawFacade;
import com.ajl.bfb.repo.channel.model.Channel;
import com.ajl.bfb.repo.channel.model.ChannelAccount;
import com.ajl.bfb.repo.channel.service.IChannelAccountService;
import com.ajl.bfb.repo.channel.service.IChannelService;
import com.ajl.bfb.repo.export.service.TransferWithdrawOrderExportService;
import com.ajl.bfb.repo.merchant.FundException;
import com.ajl.bfb.repo.merchant.model.Merchant;
import com.ajl.bfb.repo.merchant.service.IMerchantService;
import com.ajl.bfb.repo.meta.model.Area;
import com.ajl.bfb.repo.meta.service.IRegionDataService;
import com.ajl.bfb.repo.payment.model.TransferPaymentOrder;
import com.ajl.bfb.repo.payment.service.ITransferPaymentOrderService;
import com.ajl.bfb.repo.stat.model.OrderStat;
import com.ajl.bfb.repo.withdraw.TransferException;
import com.ajl.bfb.repo.withdraw.WithdrawException;
import com.ajl.bfb.repo.withdraw.model.TransferWithdrawOrder;
import com.ajl.bfb.repo.withdraw.model.WithdrawOrder;
import com.ajl.bfb.repo.withdraw.model.WithdrawOrderQueryParam;
import com.ajl.bfb.repo.withdraw.service.ITransferWithdrawOrderService;
import com.github.pagehelper.PageInfo;
import com.hippo.framework.auth.admin.OperationAuth;
import com.hippo.framework.auth.admin.model.SysUser;
import com.hippo.framework.operation.log.LogOperation;
import com.hippo.framework.util.validation.AssertUtils;
import com.hippo.framework.util.validation.ValidationUtils;
import com.hippo.framework.web.ResponseCode;
import com.hippo.framework.web.ResponseResult;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.*;
import java.util.stream.Collectors;


@Controller
@RequestMapping("/admin/transfer_withdraw")
public class TransferWithdrawOrderController {
    private static final Logger logger = LogManager.getLogger(TransferWithdrawOrderController.class);

    @Autowired
    IRegionDataService regionDataService;
    @Autowired
    IChannelAccountService channelAccountService;
    @Autowired
    IChannelService channelService;
    @Autowired
    ChannelAccountController channelAccountController;
    @Autowired
    TransferWithdrawOrderExportService transferWithdrawOrderExportService;
    @Autowired
    IMerchantService merchantService;
    @Autowired
    IWithdrawFacade withdrawFacade;
    @Autowired
    ITransferPaymentOrderService transferPaymentOrderService;
    @Autowired
    ITransferWithdrawOrderService transferWithdrawOrderService;

    @RequestMapping("/list")
    @OperationAuth(name = "订单查看", authCode = "transfer_withdraw.list", group = "中转订单")
    public String list(Model model, WithdrawOrderQueryParam param){
        if (param == null) {
            param = new WithdrawOrderQueryParam();
        }
        param.setSubclass(WithdrawSubclassEnum.TRANSFER_DOWN.name());
        PageInfo<WithdrawOrder> page = transferWithdrawOrderService.findTransferWithdrawList(param);
        List<WithdrawOrder> list = page.getList();
        page.setList(toVO(list));
        model.addAttribute("pageInfo", page);
        OrderStat orderTotal = transferWithdrawOrderService.queryOrderTotal(param);
        model.addAttribute("orderTotal", orderTotal);
        model.addAttribute("withdrawTypeList", WithdrawTypeEnum.values());
        model.addAttribute("queryParam", param);
        model.addAttribute("orderStatusList", OrderStatusEnum.values());
        model.addAttribute("auditStatusList", AuditStatusEnum.values());
        return "/admin/transfer_withdraw_order/list";
    }


    @RequestMapping("/export")
    @OperationAuth(name = "导出订单", authCode = "transfer_withdraw.export", group = "中转订单")
    public void export(Model model, WithdrawOrderQueryParam queryOrderParam,HttpServletResponse response) throws Exception {
        logger.info("中转下发报表导出开始...");
        if (queryOrderParam == null) {
            queryOrderParam = new WithdrawOrderQueryParam();
        }
        queryOrderParam.setSubclass(WithdrawSubclassEnum.TRANSFER_DOWN.name());
        PageInfo<WithdrawOrder> page = transferWithdrawOrderService.findTransferWithdrawList(queryOrderParam);
        queryOrderParam.setTotal(page.getTotal());
        long start = System.currentTimeMillis();
        transferWithdrawOrderExportService.export(response,queryOrderParam);
        logger.info("中转下发报表导出结束...共耗时:" + (System.currentTimeMillis() - start)/1000 + "s");
    }




    @RequestMapping(value="/to_add_offline_order")
    public String toAddOfflineOrder(Model model){
        BankAccTypeEnum[] bankAccTypeEnums = BankAccTypeEnum.values();
        model.addAttribute("bankCodeEnums", BankCodeEnum.values());
        model.addAttribute("bankAccTypeEnums", bankAccTypeEnums);





        List<Channel> channels = channelService.findChannels(null);
        Set<Integer> channelIds = channels.stream().distinct().filter(channel->channel.getType().equals(Channel.ChannelType.PAYMENT)).map(Channel::getId).collect(Collectors.toSet());

        List<ChannelAccount> channelAccounts = channelAccountService.findChannelAccounts(null).stream().filter(acc->channelIds.contains(acc.getChannelId())).collect(Collectors.toList());

        List<ChannelAccountVO> channelAccountVOS = channelAccountController.toAccountVO(channelAccounts, true);
        Map<String,List<ChannelAccountVO>> channelVOMap = channelAccountVOS.stream().collect(Collectors.groupingBy(channelAccountVO->channelAccountVO.getChannelName()));

        model.addAttribute("channelVOMap",channelVOMap);

        return "/admin/transfer_withdraw_order/add_offline";
    }



    @RequestMapping(value="/add_offline_order")
    @ResponseBody
    @OperationAuth(name = "下发中转", authCode = "transfer_withdraw.transfer", group = "中转订单")
    @LogOperation(name = "线下中转下发",module = "中转订单")
    public ResponseResult addOnlineOrder(TransferWithdrawOrderVO order, Model model, HttpServletRequest request) {
        try {
            SysUser sysUser = AdminUserUtils.getCurrentLoginUser(request);
            Integer currentUserId = sysUser.getId();
            Merchant merchant = merchantService.findByUserId(currentUserId);
            AssertUtils.objectNotNull(merchant,"账户没有初始化！");
            order.setMerchantId(merchant.getId());
            order.setMerchantNo(merchant.getMerchantNo());
            AssertUtils.objectNotNull(currentUserId,"获取用户信息失败");
            ChannelAccount channelAccount = channelAccountService.findById(order.getChannelAccountId());
            order.setChannelId(channelAccount.getChannelId());
            order.setChannelAccountNo(channelAccount.getAccount());
            order.setChannelAccountId(channelAccount.getId());
            order.setMiddleman(currentUserId);
            order.setCreateUserid(currentUserId);
            order.setBankAccType(BankAccTypeEnum.PRIVATE);
            order.setAmount(MoneyUtils.yuan2fee(order.getAmountYuan()).intValue());
            order.setPlatformCost(MoneyUtils.yuan2fee(order.getPlatformCostYuan()).intValue());
            order.setPayeeBankCode(BankCodeEnum.valueOfCode(order.getPayeeBankCodeStr()));
            order.setCreateTime(new Date());
            order.setUpdateTime(new Date());
            order.setTransferType(TransferWithdrawOrder.TransferTypeEnum.FROM_OFFLINE.name());



            if (StringUtils.isNotBlank(order.getProvince())) {
                Area area = regionDataService.getByCode(Integer.valueOf(order.getProvince().trim()));
                order.setProvince(area.getName());
            }
            if (StringUtils.isNotBlank(order.getCity())) {
                Area area = regionDataService.getByCode(Integer.valueOf(order.getCity().trim()));
                order.setCity(area.getName());
            }
            String error = ValidationUtils.validate(order);
            if (error != null) {
                throw new TransferException(error);
            }
            withdrawFacade.createTransferWithdrawOrder(order);
            return new ResponseResult(ResponseCode.SUCCESS, "添加成功","");
        } catch (FundException |TransferException e) {
            logger.error("", e);
            return new ResponseResult(ResponseCode.FAIL, "添加失败:" + e.getMessage(),"");
        }
    }



    @RequestMapping("/to_add_online_order")
    @OperationAuth(name = "下发中转", authCode = "transfer_withdraw.transfer", group = "中转订单")
    public String toAddOnlineOrder(Model model) {
        BankAccTypeEnum[] bankAccTypeEnums = BankAccTypeEnum.values();
        model.addAttribute("bankCodeEnums", BankCodeEnum.values());
        model.addAttribute("bankAccTypeEnums", bankAccTypeEnums);
        return "/admin/transfer_withdraw_order/add_online";
    }



    @RequestMapping(value="/add_online_order")
    @ResponseBody
    @OperationAuth(name = "下发中转", authCode = "transfer_withdraw.transfer", group = "中转订单")
    @LogOperation(name = "线上中转下发",module = "中转订单")
    public ResponseResult addOfflineOrder(ManualWithdrawOrderVO order, Model model, HttpServletRequest request) {
        try {
            SysUser sysUser = AdminUserUtils.getCurrentLoginUser(request);
            Integer currentUserId = sysUser.getId();
            Merchant merchant = merchantService.findByUserId(currentUserId);
            AssertUtils.objectNotNull(merchant,"账户没有初始化！");
            order.setMerchantId(merchant.getId());
            order.setBankAccType(BankAccTypeEnum.PRIVATE);
            order.setAmount(MoneyUtils.yuan2fee(order.getAmountYuan()).intValue());
            order.setPayeeBankCode(BankCodeEnum.valueOfCode(order.getPayeeBankCodeStr()));
            order.setMerchantOrderNo(System.currentTimeMillis()+"");
            order.setCreateOrderTime(new Date());


            if (StringUtils.isNotBlank(order.getProvince())) {
                Area area = regionDataService.getByCode(Integer.valueOf(order.getProvince().trim()));
                order.setProvince(area.getName());
            }
            if (StringUtils.isNotBlank(order.getCity())) {
                Area area = regionDataService.getByCode(Integer.valueOf(order.getCity().trim()));
                order.setCity(area.getName());
            }
            String error = ValidationUtils.validate(order);
            if (error != null) {
                throw new WithdrawException(error);
            }
            order.setSubclass(WithdrawSubclassEnum.TRANSFER_DOWN.name());
            order.setWithdrawType(WithdrawTypeEnum.MANUAL_ONLINE_TRANSFER);
            withdrawFacade.createManualOrder(order);
            return new ResponseResult(ResponseCode.SUCCESS, "添加成功","");
        } catch (FundException|WithdrawException e) {
            logger.error("", e);
            return new ResponseResult(ResponseCode.FAIL, "添加失败:" + e.getMessage(),"");
        }
    }

    private List toVO(List<WithdrawOrder> list) {
        List<Integer> mchIds = list.stream() .map(WithdrawOrder::getMerchantId).distinct().collect(Collectors.toList());
        List<Merchant> merchantList = merchantService.findByIds(mchIds);
        Map<Integer, Merchant> merchantMap = merchantList.stream().collect(Collectors.toMap(Merchant::getId, m -> m));
        List<Channel> channels = channelService.findChannels(null);
        Map<Integer,String>channelMap = channels.stream().collect(Collectors.toMap(Channel::getId,Channel::getName));

        List<ChannelAccount> channelAccounts = channelAccountService.findAllChannelAccounts(null);
        Map<Integer,String> channelAccMap = channelAccounts.stream().collect(Collectors.toMap(ChannelAccount::getId,ChannelAccount::getName));
        List volist = new ArrayList();
        for (WithdrawOrder order : list) {
            WithdrawOrderVO vo = new WithdrawOrderVO();
            BeanUtils.copyProperties(order, vo);
            vo.setMerchantName(merchantMap.get(order.getMerchantId()).getMerchantName());
            vo.setChannelName(channelMap.get(order.getChannelId()));
            vo.setChannelAccName(channelAccMap.get(order.getChannelAccountId()));

            if(order.getTransferPaymentOrderId()!=null){
                TransferPaymentOrder transferPaymentOrder = transferPaymentOrderService.findById(order.getTransferPaymentOrderId());
                vo.setTransferPaymentStatus(TransferPaymentStatusEnum.valueOf(transferPaymentOrder.getAuditStatus()));
            }else {
                vo.setTransferPaymentStatus(TransferPaymentStatusEnum.WAIT_RECHAREGE);
            }
            volist.add(vo);
        }
        return volist;
    }

}
