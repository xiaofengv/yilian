package com.ajl.bfb.admin.holiday.controller;

import com.ajl.bfb.repo.channel.model.Holiday;
import com.ajl.bfb.repo.channel.model.HolidayQuery;
import com.ajl.bfb.repo.channel.service.IHolidayService;
import com.github.pagehelper.PageInfo;
import com.hippo.framework.auth.admin.OperationAuth;
import com.hippo.framework.util.DateUtils;
import com.hippo.framework.web.ResponseCode;
import com.hippo.framework.web.ResponseResult;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.Date;


@Controller
@RequestMapping("/admin/holiday")
public class HolidayController {

    @Autowired
    private IHolidayService holidayService;

    @RequestMapping("/list")
    @OperationAuth(name = "系统设置", authCode = "system_setting.to_update", group = "系统设置")
    public String list(Model model, HolidayQuery query, Integer year) {
        query.setPageSize(150);

        if (year != null) {
            query.setStartTime(DateUtils.parse2Date(year + "-01-01"));
            query.setEndTime(new DateTime(query.getStartTime()).dayOfYear().withMaximumValue().toDate());
        }
        PageInfo<Holiday> page = holidayService.findPage(query);
        model.addAttribute("pageInfo", page);
        return "admin/holiday/list";
    }

    @RequestMapping("/to_add")
    public String toAdd() {
        return "admin/holiday/add";
    }

    @RequestMapping("/add")
    @ResponseBody
    public ResponseResult add(String date) {
        Date d = null;
        try {
            d = DateUtils.parse2Date(date);
        } catch (Exception e) {
            return new ResponseResult(ResponseCode.FAIL, "日期格式有误(正确格式:如20180101)", "");
        }
        Holiday holiday = holidayService.findByDate(d);
        if (holiday != null) {
            return new ResponseResult(ResponseCode.FAIL, "日期已经存在", "");
        }
        holidayService.save(d);
        return new ResponseResult(ResponseCode.SUCCESS, "添加成功", "");
    }

    @RequestMapping("/delete/{id}")
    public String delete(@PathVariable("id")int id, Model model) {
        holidayService.deleteById(id);
        return list(model, new HolidayQuery(), null);
    }


}
