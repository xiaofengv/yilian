package com.ajl.bfb.merchantadmin;


public final class MerchantAdminConstants {

    public static final String LOGIN_URI = "/merchant_admin/sys/to-login";

    public static final String NO_PERMISSION_URI = "/merchant_admin/common/nopermission";
}
