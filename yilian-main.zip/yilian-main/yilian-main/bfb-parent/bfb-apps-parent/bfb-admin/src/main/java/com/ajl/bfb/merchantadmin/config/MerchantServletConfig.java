package com.ajl.bfb.merchantadmin.config;

import com.ajl.bfb.merchantadmin.common.web.MerchantAdminSessionKey;
import com.hippo.framework.web.servlet.AuthImageServlet;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;


@Configuration
public class MerchantServletConfig {


    @Bean("merchantLoginVerifyCodeImgServlet")
    public ServletRegistrationBean loginVerifyCodeImgRegistration() {
        ServletRegistrationBean registration = new ServletRegistrationBean(new AuthImageServlet());
        registration.addUrlMappings("/merchant-admin-login-verifycode");
        registration.addInitParameter("height", "30");
        registration.addInitParameter("width", "80");
        registration.addInitParameter("key", MerchantAdminSessionKey.LOGIN_VERIFY_CODE);
        registration.setName("merchantLoginVerifyCodeImgServlet");
        return registration;
    }





}
