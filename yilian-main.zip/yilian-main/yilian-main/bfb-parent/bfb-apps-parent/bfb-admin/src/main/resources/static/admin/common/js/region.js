function ProviceBind() {
    //清空下拉数据
    $("#province").html("");
    var str = "<option>===请选择===</option>";
    $.ajax({
        type: "POST",
        url: getWebPath() + "/merchant_admin/region/provinces",
        data: {},
        dataType: "JSON",
        async: false,
        success: function (data) {
            //从服务器获取数据进行绑定
            $.each(data.data, function (i, item) {
                str += "<option code='" + item.code + "' value=" + item.name + ">" + item.name + "</option>";
            })
            //将数据添加到省份这个下拉框里面
            $("#province").append(str);
        },
        error: function () { alert("Error"); }
    });
}

function CityBind() {
    var provice = $("#province").attr("value");
    var code = $("#province").attr("code");
    //判断省份这个下拉框选中的值是否为空
    if (provice == "") {
        return;
    }
    $("#city").html("");
    var str = "<option>===请选择===</option>";
    $.ajax({
        type: "POST",
        url: getWebPath() + "/merchant_admin/citys/" + code,
        data: {},
        dataType: "JSON",
        async: false,
        success: function (data) {
            //从服务器获取数据进行绑定
            $.each(data.data, function (i, item) {
                str += "<option code='" + item.code + "' value=" + item.name + ">" + item.name + "</option>";
            })
            //将数据添加到省份这个下拉框里面
            $("#city").append(str);
        },
        error: function () { alert("Error"); }
    });


}
function VillageBind() {


    var provice = $("#City").attr("value");
    //判断市这个下拉框选中的值是否为空
    if (provice == "") {
        return;
    }
    $("#Village").html("");
    var str = "<option>==请选择===</option>";
    //将市的ID拿到数据库进行查询，查询出他的下级进行绑定
    $.ajax({
        type: "POST",
        url: "/Home/GetAddress",
        data: { "parentiD": provice, "MyColums": "Village" },
        dataType: "JSON",
        async: false,
        success: function (data) {
            //从服务器获取数据进行绑定
            $.each(data.data, function (i, item) {
                str += "<option code='" + item.code + "' value=" + item.name + ">" + item.name + "</option>";
            })
            //将数据添加到省份这个下拉框里面
            $("#Village").append(str);
        },
        error: function () { alert("Error"); }
    });
    //$.post("/Home/GetAddress", { parentiD: provice, MyColums: "Village" }, function (data) {
    //    $.each(data.Data, function (i, item) {
    //        str += "<option value=" + item.Id + ">" + item.MyTexts + "</option>";
    //    })
    //    $("#Village").append(str);
    //})
}

