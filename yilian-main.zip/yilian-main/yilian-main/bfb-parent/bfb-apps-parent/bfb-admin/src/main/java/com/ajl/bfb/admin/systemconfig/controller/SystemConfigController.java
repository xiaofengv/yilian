package com.ajl.bfb.admin.systemconfig.controller;

import com.ajl.bfb.core.util.MoneyUtils;
import com.ajl.bfb.core.util.RateUtils;
import com.ajl.bfb.repo.channel.service.GlobalSettingService;
import com.ajl.bfb.repo.channel.service.IGlobalSettingService;
import com.hippo.framework.auth.admin.OperationAuth;
import com.hippo.framework.core.enums.OpenStatusEnum;
import com.hippo.framework.dictionary.model.Dictionary;
import com.hippo.framework.dictionary.service.IDictionaryService;
import com.hippo.framework.operation.log.LogOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import java.math.BigDecimal;


@RequestMapping("/admin/system_config")
@Controller
public class SystemConfigController {

    @Autowired
    IGlobalSettingService globalSettingService;
    @Autowired
    IDictionaryService dictionaryService;

    @RequestMapping("to_update")
    @OperationAuth(name = "系统设置", authCode = "system_setting.to_update", group = "系统设置")
    public String toUpdate(Model model){

        int lowAreaAmount = MoneyUtils.fee2yuan(globalSettingService.getLowAreaAmount()).intValue();

        int lowWarnAmount = MoneyUtils.fee2yuan(globalSettingService.getAccountLowWarnAmount()).intValue();
        int apiWithdrawMaxAmount = MoneyUtils.fee2yuan(globalSettingService.getApiWithdrawMaxAmount()).intValue();
        OpenStatusEnum allowApiWithdraw = globalSettingService.getAllowApiWithdraw();
        OpenStatusEnum allowApiPayment = globalSettingService.getAllowApiPayment();
        int withdrawMaxCount = globalSettingService.getWithdrawMaxCount();
        int rechargeCost = globalSettingService.getRechargeCost();
        int numberofBlackListByDay = globalSettingService.getNumberofBlacklistByDay();
        int numberofBlackListByForever = globalSettingService.getNumberofBlacklistByForever();
        String blackListSwitch = globalSettingService.getBlackListSwitch();
        String collectAlipayUserIdSwitch = globalSettingService.getCollectAlipayUserIdSwitch();
        String alipayAppId = globalSettingService.getAlipayAppId();
        String informationText = globalSettingService.getInformationText();

        model.addAttribute("lowAreaAmount",lowAreaAmount);
        model.addAttribute("lowWarnAmount",lowWarnAmount);
        model.addAttribute("allowApiWithdraw",allowApiWithdraw.name());
        model.addAttribute("apiWithdrawMaxAmount",apiWithdrawMaxAmount);
        model.addAttribute("rechargeCost",rechargeCost);
        model.addAttribute("allowApiPayment",allowApiPayment);
        model.addAttribute("statusList",OpenStatusEnum.values());
        model.addAttribute("blackListSwitch",blackListSwitch);
        model.addAttribute("numberofBlackListByDay",numberofBlackListByDay);
        model.addAttribute("numberofBlackListByForever",numberofBlackListByForever);
        model.addAttribute("collectAlipayUserIdSwitch",collectAlipayUserIdSwitch);
        model.addAttribute("alipayAppId",alipayAppId);
        model.addAttribute("informationText",informationText);
        Dictionary dic = dictionaryService.getByCode(GlobalSettingService.GlobalSettingKey.PAY_API_URL.name());
        model.addAttribute("payApiUrl",dic.getAttributeValue());

        model.addAttribute("withdrawMaxCount",withdrawMaxCount);
        return "/admin/system_config/update";
}

    @RequestMapping("update")
    @LogOperation(name = "系统参数设置",module = "系统参数设置")
    public String update(Model model, int lowAreaAmount, int lowWarnAmount, int apiWithdrawMaxAmount,int withdrawMaxCount,BigDecimal rechargeCost,
                         OpenStatusEnum allowApiWithdraw,
                         OpenStatusEnum allowApiPayment,String blackListSwitch,int numberofBlackListByDay,int numberofBlackListByForever,
                         String collectAlipayUserIdSwitch,String alipayAppId,String informationText,String payApiUrl){

        globalSettingService.updateLowAreaAmount(lowAreaAmount*100);
        globalSettingService.updateAccountLowWarnAmount(lowWarnAmount*100);
        globalSettingService.updateApiWithdrawMaxAmount(apiWithdrawMaxAmount*100);
        globalSettingService.updateAllowApiWithdraw(allowApiWithdraw);
        globalSettingService.updateAllowApiPayment(allowApiPayment);
        globalSettingService.updateWithdrawMaxCount(withdrawMaxCount);
        globalSettingService.updateRechargeCost(RateUtils.percent2rate(rechargeCost));
        globalSettingService.updateBlackListSwitch(blackListSwitch);
        globalSettingService.updateNumberofBlacklistByDay(numberofBlackListByDay);
        globalSettingService.updateNumberofBlacklistByForever(numberofBlackListByForever);
        globalSettingService.updateCollectAlipayUserIdSwitch(collectAlipayUserIdSwitch);
        globalSettingService.updateAliPayAppId(alipayAppId);
        globalSettingService.updateInformationText(informationText);
        globalSettingService.updatePayApiUrl(payApiUrl);

        model.addAttribute("message","修改成功");
        return toUpdate(model);
    }

    @OperationAuth(name = "用户管理", authCode = "system_setting.user_admin", group = "用户管理")
    public void userAdmin(){
    }


}
