var merchant = {};

merchant.delMerchant = function (merchantId) {
    layer.confirm(
        "确定要删除吗?",
        {icon: 0, title:'提示'},
        function(index, layero){
            layer.close(index);
            window.location.href = getWebPath() + "/admin/agent/delete/" + merchantId ;
        }
    );
}
