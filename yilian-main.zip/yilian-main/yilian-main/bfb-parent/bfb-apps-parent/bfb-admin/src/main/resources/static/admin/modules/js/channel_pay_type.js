var channel_pay_type = {};

$(function () {
    $(".channel_rate_cls").each(function (index, el) {
        hippo.limitMoney(el.id);
    });

});

channel_pay_type.updateRate = function (channelPayTypeId) {
    var channelRate = $('#channel_rate_' + channelPayTypeId).val();
    var minAmount = $('#channel_minAmount_' + channelPayTypeId).val();
    var maxAmount = $('#channel_maxAmount_' + channelPayTypeId).val();
    var channelCode = $('#channel_code_' + channelPayTypeId).val();

    $.ajax({
        type : "POST", //提交方式
        url : getWebPath() + "/admin/channel_pay_type/update",//路径
        data : {
            id:channelPayTypeId,
            channelRatePercent:channelRate,
            minAmountYuan:minAmount,
            maxAmountYuan:maxAmount,
            channelCode:channelCode
        },
        success : function(result) {//返回数据根据结果进行相应的处理
            new $.zui.Messager(result.message, {
                type: 'success' //定义颜色主题
            }).show();
        }
    });

}

/**
 * 设置页面，切换通道状态
 * @param id
 */
channel_pay_type.switchStatus = function (el, channelPayTypeId) {
    var status = $(el).val();
    var switchActionUrl = getWebPath() + '/admin/channel_pay_type/switch_status/' + channelPayTypeId;
    $.ajax({
        type : "POST", //提交方式
        url : switchActionUrl,//路径
        data:JSON.stringify(status),
        contentType:"application/json",
        success : function(result) {//返回数据根据结果进行相应的处理
            hippo.msg(result.message);
        }
    });
}


/**
 * 商户设置页面，切换商户开通状态
 * @param id
 */
channel_pay_type.switchMerchantStatus = function (el, merchantId,channelPayTypeId) {
    var isChecked = $(el).prop('checked');
    var switchActionUrl = getWebPath() + '/admin/merchant_channel/channelToMerchant/turn_off/' + merchantId+"/"+channelPayTypeId;
    $("#switch_" + merchantId).html("关");
    if (isChecked) {
        switchActionUrl = getWebPath() + '/admin/merchant_channel/channelToMerchant/turn_on/' + merchantId+"/"+channelPayTypeId;
        $("#switch_" + merchantId).html("开");
    }

    $.ajax({
        type : "POST", //提交方式
        url : switchActionUrl,//路径
        data : {},
        success : function(result) {//返回数据根据结果进行相应的处理
            hippo.msg(result.message);
        }
    });
}

