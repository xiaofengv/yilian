package com.ajl.bfb.admin.sys.controller;

import com.ajl.bfb.itg.config.ItgExceptionHandlerAdvice;
import com.hippo.framework.web.ResponseCode;
import com.hippo.framework.web.ResponseResult;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@Controller
@RequestMapping(value="/admin/error")
public class AdminErrorController {

    private static final Logger logger = LogManager.getLogger(AdminErrorController.class);

    @RequestMapping(path = "/http500")
    @ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
    public String http500(HttpServletRequest request, HttpServletResponse response,Model model) {
        Object exception = request.getAttribute(ItgExceptionHandlerAdvice.EXCEPTION_KEY);
        model.addAttribute("errorMsg",exception == null?"": extractErrorMsg((Throwable)exception));
        return "/admin/sys/http500";
    }

    @RequestMapping(path = "/http404")
    @ResponseStatus(value = HttpStatus.NOT_FOUND)
    public String http404(HttpServletRequest request, HttpServletResponse response) {
        return "/admin/sys/http404";
    }

    @RequestMapping(path = "/ajax-http404")
    @ResponseBody
    public ResponseResult ajaxHttp404(HttpServletRequest request, HttpServletResponse response) {
        response.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
        ResponseResult r = new ResponseResult();
        r.setStatusCode(ResponseCode.UNKNOWN_EXCEPTION);
        r.setMessage("访问的地址不存在." );
        return r;
    }

    @RequestMapping(path = "/ajax-http500")
    @ResponseBody
    public ResponseResult ajaxHttp500(HttpServletRequest request, HttpServletResponse response) {
        Object exception = request.getAttribute(ItgExceptionHandlerAdvice.EXCEPTION_KEY);
        response.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
        ResponseResult r = new ResponseResult();
        r.setStatusCode(ResponseCode.UNKNOWN_EXCEPTION);
        r.setMessage(exception == null?"": extractErrorMsg((Throwable)exception));
        return r;
    }

    @RequestMapping(path = "/alipay-error")
    @ResponseBody
    public ResponseResult alipayError(HttpServletRequest request, HttpServletResponse response) {
        Object exception = request.getAttribute(ItgExceptionHandlerAdvice.EXCEPTION_KEY);
        ResponseResult r = new ResponseResult();
        r.setStatusCode(ResponseCode.FAIL);
        r.setMessage(exception == null?"": extractErrorMsg((Throwable)exception));
        return r;
    }

    private String extractErrorMsg(Throwable exception) {
        if (StringUtils.isNotBlank(exception.getMessage())) {
            return exception.getMessage();
        }
        return ExceptionUtils.getStackTrace(exception);
    }

}
