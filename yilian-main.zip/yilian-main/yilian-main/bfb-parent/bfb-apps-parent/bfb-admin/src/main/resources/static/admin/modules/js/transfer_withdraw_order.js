var TransferWithdrawOrder = {};

TransferWithdrawOrder.createOfflineWithdrawOrder = function (formId) {
    if (!hippo.validateForm(formId)) {
        return;
    }
    var url = $(formId).attr("action");
    $("#" + formId).ajaxSubmit( {
        url: url,
        type: 'POST',
        dataType: 'json',
        success: function (data) {
            if (data.statusCode == 'SUCCESS') {//进主页
                new $.zui.Messager(data.message, {
                    type: 'success' // 定义颜色主题
                }).show();
                window.setTimeout(function () {
                   window.location.href = getWebPath() + "/admin/transfer_withdraw/list";
                }, 1500);
            } else {
                hippo.warning(data.message);
            }
        }
    });
}


TransferWithdrawOrder.createOnlineWithdrawOrder = function (formId) {
    if (!hippo.validateForm(formId)) {
        return;
    }
    var url = $(formId).attr("action");
    $("#" + formId).ajaxSubmit( {
        url: url,
        type: 'POST',
        dataType: 'json',
        success: function (data) {
            if (data.statusCode == 'SUCCESS') {//进主页
                new $.zui.Messager(data.message, {
                    type: 'success' // 定义颜色主题
                }).show();
                window.setTimeout(function () {
                    window.location.href = getWebPath() + "/admin/transfer_withdraw/list";
                }, 1500);
            } else {
                hippo.warning(data.message);
            }
        }
        // clearForm: false,//禁止清楚表单
        // resetForm: false //禁止重置表单
    });
}



$(function () {
  hippo.limitInteger('amountYuan');
  hippo.limitInteger('payeeBankAccount');
    //默认绑定省
    ProviceBind();
    //绑定事件
    $("#province").change( function () {
        CityBind();
    })

});