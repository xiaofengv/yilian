package com.ajl.bfb.admin.merchant.controller;

import com.ajl.bfb.admin.merchant.vo.MerchantPayTypeVO;
import com.ajl.bfb.core.constants.MerchantUserTypeEnum;
import com.ajl.bfb.core.constants.RateTypeEnum;
import com.ajl.bfb.core.util.MoneyUtils;
import com.ajl.bfb.core.util.RateUtils;
import com.ajl.bfb.repo.merchant.MerchantException;
import com.ajl.bfb.repo.merchant.model.Merchant;
import com.ajl.bfb.repo.merchant.model.MerchantFindParam;
import com.ajl.bfb.repo.merchant.model.MerchantPayType;
import com.ajl.bfb.repo.merchant.service.IMerchantPayTypeService;
import com.ajl.bfb.repo.merchant.service.IMerchantService;
import com.ajl.bfb.repo.payment.model.PayType;
import com.ajl.bfb.repo.payment.service.IPayTypeService;
import com.github.pagehelper.PageInfo;
import com.hippo.framework.auth.admin.OperationAuth;
import com.hippo.framework.core.enums.SwitchEnum;
import com.hippo.framework.operation.log.LogOperation;
import com.hippo.framework.web.ResponseCode;
import com.hippo.framework.web.ResponseResult;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static java.util.stream.Collectors.groupingBy;


@Controller
@RequestMapping(value="/admin/merchant_pay_type")
public class MerchantPayTypeController {

    @Autowired
    private IMerchantPayTypeService merchantPayTypeService;
    @Autowired
    private IPayTypeService payTypeService;
    @Autowired
    private IMerchantService merchantService;

    @RequestMapping(value="/list/{merchantId}")
    @OperationAuth(name = "商户支付方式设置", authCode = "merchant.paytype_setting", group = "商户管理")
    public String list(@PathVariable("merchantId")int merchantId, Model model) {
        Merchant merchant = merchantService.findById(merchantId);
        List<MerchantPayType> merchantPayTypes = merchantPayTypeService.getMerchantPayTypes(merchantId);

        List<PayType> allPayTypes = payTypeService.getAll();
        Map<String, PayType> payTypeMap = allPayTypes.stream().collect(Collectors.toMap(PayType::getCode, p ->p));

        List merchantPayTypeVOS = new ArrayList<>();
        for (MerchantPayType type : merchantPayTypes) {
            MerchantPayTypeVO vo = new MerchantPayTypeVO();
            BeanUtils.copyProperties(type, vo);
            vo.setGlobalDefaultRatePercent(RateUtils.rate2percent(payTypeMap.get(type.getPayTypeCode()).getDefaultRate()));
            merchantPayTypeVOS.add(vo);
        }

        merchant.setMerchantPayTypeList(merchantPayTypeVOS);

        Map<String, String> rateTypeMap = Arrays.stream(RateTypeEnum.values()).collect(Collectors.toMap(RateTypeEnum::name, r -> r.getViewDesc()));
        model.addAttribute("payTypeMap", payTypeMap);
        model.addAttribute("rateTypeMap", rateTypeMap);
        model.addAttribute("merchant", merchant);
        return "/admin/merchant_pay_type/list";
    }

    @RequestMapping(value="/turn_on/{id}")
    @ResponseBody
    public ResponseResult turnOn(@PathVariable("id")int id) {
        try {
            merchantPayTypeService.updateStatus(id, SwitchEnum.ON);
        } catch (MerchantException e) {
            return new ResponseResult(ResponseCode.FAIL, "修改失败:" + e.getMessage(), null);
        }
        return new ResponseResult(ResponseCode.SUCCESS, "修改成功", null);
    }

    @RequestMapping(value="/turn_off/{id}")
    @ResponseBody
    public ResponseResult turnOff(@PathVariable("id")int id) {
        try {
            merchantPayTypeService.updateStatus(id, SwitchEnum.OFF);
        } catch (MerchantException e) {
            return new ResponseResult(ResponseCode.FAIL, "修改失败:" + e.getMessage(), null);
        }
        return new ResponseResult(ResponseCode.SUCCESS, "修改成功", null);
    }

    @RequestMapping(value="/update_rate")
    @ResponseBody
    @LogOperation(name = "下游费率设置",module = "费率设置")
    public ResponseResult updateRate(@RequestParam("id") int id, @RequestParam("rate") BigDecimal rate,
                                     @RequestParam("agentRate") BigDecimal agentRate,
                                     @RequestParam("minAmount") BigDecimal minAmount,
                                     @RequestParam("maxAmount") BigDecimal maxAmount) {

        merchantPayTypeService.updateRate(id, RateUtils.percent2rate(rate),
                RateUtils.percent2rate(agentRate),
                MoneyUtils.yuan2fee(minAmount).intValue(),
                MoneyUtils.yuan2fee(maxAmount).intValue());
        return new ResponseResult(ResponseCode.SUCCESS, "修改成功", "");
    }



    @RequestMapping(value="/to_switch_paytype")
    @OperationAuth(name = "商户支付方式设置", authCode = "merchant.paytype_setting", group = "商户管理")
    public String toSwitchPaytype(Model model, MerchantFindParam findParam) {
        findParam.setPageSize(200);
        findParam.setUserType(MerchantUserTypeEnum.MERCHANT);
        PageInfo<Merchant> page = merchantService.findPage(findParam);
        List<Merchant> merchants = page.getList();
        for (Merchant merchant : merchants) {
            List<MerchantPayType> merchantPayTypes = merchantPayTypeService.getMerchantPayTypes(merchant.getId());
            merchant.setMerchantPayTypeList(merchantPayTypes);
        }
        model.addAttribute("merchants",merchants);

        List<PayType> allPayTypes = payTypeService.getAll();
        Map<String, PayType> payTypeMap = allPayTypes.stream().collect(Collectors.toMap(PayType::getCode, p ->p));
        model.addAttribute("payTypeMap", payTypeMap);
        return "/admin/merchant/switch_paytype";
    }




    @RequestMapping(value="/to_switch_merchant")
    @OperationAuth(name = "商户支付方式设置", authCode = "merchant.paytype_setting", group = "商户管理")
    public String toSwitchMerchant(Model model, MerchantFindParam findParam) {

        findParam.setPageSize(200);
        findParam.setUserType(MerchantUserTypeEnum.MERCHANT);
        PageInfo<Merchant> page = merchantService.findPage(findParam);
        List<Merchant> merchants = page.getList();
        List<MerchantPayType> merchantPayTypes = new ArrayList<>();
        for (Merchant merchant : merchants) {
            merchantPayTypes.addAll(merchantPayTypeService.getMerchantPayTypes(merchant.getId()));
        }

        Map<String,List<MerchantPayType>> merchantPayTypeMap = merchantPayTypes.stream().collect(groupingBy(MerchantPayType::getPayTypeCode));
        model.addAttribute("merchantPayTypeMap",merchantPayTypeMap);

        Map<Integer,Merchant> merchantMap = merchants.stream().collect(Collectors.toMap(Merchant::getId,p->p));
        model.addAttribute("merchantMap",merchantMap);

        List<PayType> allPayTypes = payTypeService.getAll();
        Map<String, String> payTypeMap = allPayTypes.stream().collect(Collectors.toMap(PayType::getCode, PayType::getName));
        model.addAttribute("payTypeMap", payTypeMap);

        return "/admin/merchant_pay_type/switch_merchant";
    }
}
