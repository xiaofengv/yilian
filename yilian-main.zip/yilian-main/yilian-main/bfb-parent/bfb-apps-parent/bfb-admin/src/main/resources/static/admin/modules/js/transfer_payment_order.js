var TransferPaymentOrder = {};

TransferPaymentOrder.close = function(){
    $('.close',window.parent.document).trigger("click");
}

TransferPaymentOrder.rechargeBatchConfirm = function (formId) {
    if (!hippo.validateForm(formId)) {
        return;
    }
    if(!hippo.validateElement("file")){
        return;
    }
    var chk_orderid =[];
    $('input[name="orderIds"]:checked', parent.document).each(function(){
        chk_orderid.push($(this).val());
    });
    layer.confirm(
        "确定充值已到账？",
        {icon: 0, title:'提示'},
        function(index, layero){
            layer.close(index);


        $("#rechargeConfirmForm").ajaxSubmit({
            type : "POST", //提交方式
            data: { "orderIds": chk_orderid},
            success : function(result) {//返回数据根据结果进行相应的处理
                hippo.msg(result.message);
                if(result.statusCode=="SUCCESS"){
                    setTimeout((function() {
                        window.parent.location.href =  window.parent.document.getElementById('searchForm').action;
                    }), 2000);
                }
            }
        });

        });
}


TransferPaymentOrder.rechargeConfirm = function (formId) {
    if (!hippo.validateForm(formId)) {
        return;
    }
    if(!hippo.validateElement("file")){
        return;
    }
    $("#"+formId).ajaxSubmit(function(response) {
        if(response.statusCode=="SUCCESS"){
            $('#errorMsgDiv').hide();
            new $.zui.Messager(response.message, {
                type: 'success' // 定义颜色主题
            }).show();

            window.parent.location.href =  window.parent.document.getElementById('searchForm').action;
        }else{
            hippo.warning(response.message);
        }
    });

}

//根据下发订单创建中转充值订单
TransferPaymentOrder.createTransferPaymentOrder = function (formId) {
    if (!hippo.validateForm(formId)) {
        return;
    }
    // if(!hippo.validateElement("file")){
    //     return;
    // }

    var url = $(formId).attr("action");
    $("#" + formId).ajaxSubmit( {
        url: url,
        type: 'POST',
        dataType: 'json',
        success: function (data) {
            if (data.statusCode == 'SUCCESS') {//进主页
                new $.zui.Messager(data.message, {
                    type: 'success' // 定义颜色主题
                }).show();
                window.setTimeout(function () {
                   window.location.href = getWebPath() + "/admin/transfer_payment/list";
                }, 1500);
            } else {
                hippo.warning(data.message);
            }
        }
    });
}

//根据支付宝提现订单创建中转订单
TransferPaymentOrder.createTransferPaymentOrderByalipayWithdraw = function (formId) {
    if (!hippo.validateForm(formId)) {
        return;
    }

    var url = $(formId).attr("action");
    $("#" + formId).ajaxSubmit( {
        url: url,
        type: 'POST',
        dataType: 'json',
        success: function (data) {
            if (data.statusCode == 'SUCCESS') {//进主页
                new $.zui.Messager(data.message, {
                    type: 'success' // 定义颜色主题
                }).show();
                window.setTimeout(function () {
                    window.location.href = getWebPath() + "/admin/transfer_payment/alipay_list?currentMenuCode=alipay_transferPayment_list";
                }, 1500);
            } else {
                hippo.warning(data.message);
            }
        }
    });
}


TransferPaymentOrder.selectChannelAcc = function(el){
    var transferBankAccountOwner = $(el).find("option:selected").data('transferbankcardowner');
    var transferBankAccount = $(el).find("option:selected").data('transferbankcard');
    $("#transferBankAccountOwner").val(transferBankAccountOwner);
    $("#transferBankAccount").val(transferBankAccount);
}



// TransferPaymentOrder.selectChannelAcc = function(el){
//     var transferBankCardOwner = $(el).find("option:selected").data('transferbankcardowner');
//     var transferBankCard = $(el).find("option:selected").data('transferbankcard');
//     $("#transferBankAccountOwner").val(transferBankCardOwner);
//     $("#transferBankAccount").val(transferBankCard);
// }


TransferPaymentOrder.createTransferPaymentOrderByRechargeOrder = function (formId) {
    if (!hippo.validateForm(formId)) {
        return;
    }

    var url = $(formId).attr("action");
    $("#" + formId).ajaxSubmit( {
        url: url,
        type: 'POST',
        dataType: 'json',
        success: function (data) {
            if (data.statusCode == 'SUCCESS') {//进主页
                new $.zui.Messager(data.message, {
                    type: 'success' // 定义颜色主题
                }).show();
                window.setTimeout(function () {
                    window.location.href = getWebPath() + "/admin/transfer_withdraw/list";
                }, 1500);
            } else {
                hippo.warning(data.message);
            }
        }
    });
}


//会员充值订单中转金额计算（根据选中的订单的金额汇总）
TransferPaymentOrder.calcAmount=function (el) {
    var amount = 0;
    $('input[type=checkbox]').each(function(){
        if($(this).prop('checked')){
            amount+= $(this).data("amount");
        }
    })
    if(amount>0){
        $('#amountYuan').val(amount/100);
    }else{
        $('#amountYuan').val('');
    }
    //当前选中订单的通道自动赋值
    if($(el).prop('checked')){
        var channelAccountId = $(el).data("channelaccoutid");
        // $("#channelAccountId").val(channelAccountId);

        $('#channelAccountId').selectpicker('val', channelAccountId);//设置选中
        $('#channelAccountId').selectpicker('refresh');

        var transferBankAccountOwner = $('#channelAccountId').find("option:selected").data('transferbankcardowner');
        var transferBankAccount = $('#channelAccountId').find("option:selected").data('transferbankcard');
        $("#transferBankAccountOwner").val(transferBankAccountOwner);
        $("#transferBankAccount").val(transferBankAccount);
    }
}

//支付宝提现订单中转金额计算（根据选中的订单的金额汇总）
TransferPaymentOrder.calcAliWithdrawOrderTransferAmount=function (el) {
    var amount = 0;
    $('input[type=checkbox]').each(function(){
        if($(this).prop('checked')){
            amount+= $(this).data("amount");
        }
    })
    if(amount>0){
        $('#amountYuan').val(amount/100);
    }else{
        $('#amountYuan').val('');
    }
}



TransferPaymentOrder.transferAudit = function (orderId) {
    if (!hippo.validateForm("transferPaymentForm")) {
        return;
    }
    var showmsg="确定审核通过吗？";
    var auditRemark = $("#auditRemark").val().trim();
    var secondpwd = $("#_secondPasswordVerifier").val().trim();
    var transferBankAccount = $("#transferBankAccount").val().trim();
    var transferBankAccountOwner = $("#transferBankAccountOwner").val().trim();
    var channelAccountId = $("#channelAccountId").val().trim();

    layer.confirm(
        showmsg,
        {icon: 0, title:'提示'},
        function(index, layero){
            layer.close(index);
            var actionUrl = getWebPath() + "/admin/transfer_payment/transfer_audit/"+orderId;
            $.ajax({
                type : "POST", //提交方式
                url : actionUrl,//路径
                data : {
                    "transferBankAccount":transferBankAccount,
                    "transferBankAccountOwner":transferBankAccountOwner,
                    "channelAccountId":channelAccountId,
                    "_secondPasswordVerifier":secondpwd,
                    "auditRemark":auditRemark
        },
                success : function(result) {//返回数据根据结果进行相应的处理
                    hippo.msg(result.message);
                    if(result.statusCode=="SUCCESS"){
                        setTimeout((function() {
                            window.parent.location.href =getWebPath() + "/admin/transfer_payment/list";
                        }), 2000);
                    }
                }
            });
        }
    );
}


TransferPaymentOrder.transferAuditReject = function (orderId) {
    if (!hippo.validateForm("transferPaymentForm")) {
        return;
    }
    var showmsg="确定驳回吗？";
    var auditRemark = $("#auditRemark").val().trim();
    var secondpwd = $("#_secondPasswordVerifier").val().trim();
    var transferBankAccount = $("#transferBankAccount").val().trim();
    var transferBankAccountOwner = $("#transferBankAccountOwner").val().trim();
    var channelAccountId = $("#channelAccountId").val().trim();

    layer.confirm(
        showmsg,
        {icon: 0, title:'提示'},
        function(index, layero){
            layer.close(index);
            var actionUrl = getWebPath() + "/admin/transfer_payment/transfer_audit/"+orderId;
            $.ajax({
                type : "POST", //提交方式
                url : actionUrl,//路径
                data : {
                    "_secondPasswordVerifier":secondpwd,
                    "auditRemark":auditRemark
                },
                success : function(result) {//返回数据根据结果进行相应的处理
                    hippo.msg(result.message);
                    if(result.statusCode=="SUCCESS"){
                        setTimeout((function() {
                            window.parent.location.href =getWebPath() + "/admin/transfer_payment/list";
                        }), 2000);
                    }
                }
            });
        }
    );
}


TransferPaymentOrder.downStreamTransferAudit = function () {
    if (!hippo.validateForm("downStreamTransferAudit")) {
        return;
    }
    var showmsg="确定审核通过吗？";
    layer.confirm(
        showmsg,
        {icon: 0, title:'提示'},
        function(index, layero){
            layer.close(index);
            $("#downStreamTransferAudit").ajaxSubmit(function (response) {
                hippo.msg(response.message);
                if(response.statusCode=="SUCCESS"){
                    setTimeout((function() {
                        window.parent.location.href =getWebPath() + "/admin/transfer_payment/list";
                    }), 2000);
                }

            });
        }
    );

}


// TransferPaymentOrder.downStreamTransferAudit = function (orderId) {
//     if (!hippo.validateForm("transferPaymentForm")) {
//         return;
//     }
//     var showmsg="确定审核通过吗？";
//     var auditRemark = $("#auditRemark").val().trim();
//     var secondpwd = $("#_secondPasswordVerifier").val().trim();
//     var transferBankAccount = $("#transferBankAccount").val().trim();
//     var transferBankAccountOwner = $("#transferBankAccountOwner").val().trim();
//     var channelAccountId = $("#channelAccountId").val().trim();
//
//     layer.confirm(
//         showmsg,
//         {icon: 0, title:'提示'},
//         function(index, layero){
//             layer.close(index);
//             var actionUrl = getWebPath() + "/admin/transfer_payment/transfer_audit/"+orderId;
//             $.ajax({
//                 type : "POST", //提交方式
//                 url : actionUrl,//路径
//                 data : {
//                     "transferBankAccount":transferBankAccount,
//                     "transferBankAccountOwner":transferBankAccountOwner,
//                     "channelAccountId":channelAccountId,
//                     "_secondPasswordVerifier":secondpwd,
//                     "auditRemark":auditRemark
//                 },
//                 success : function(result) {//返回数据根据结果进行相应的处理
//                     hippo.msg(result.message);
//                     if(result.statusCode=="SUCCESS"){
//                         setTimeout((function() {
//                             window.parent.location.href =getWebPath() + "/admin/transfer_payment/list";
//                         }), 2000);
//                     }
//                 }
//             });
//         }
//     );
// }


TransferPaymentOrder.transfer = function (orderId) {
    if (!hippo.validateForm("transferPaymentForm")) {
        return;
    }
    var showmsg="确定中转完成吗？";
    // var transferCostYuan = $("#transferCostYuan").val().trim();
    // var secondpwd = $("#_secondPasswordVerifier").val().trim();
    layer.confirm(
        showmsg,
        {icon: 0, title:'提示'},
        function(index, layero){
            layer.close(index);
            var actionUrl = getWebPath() + "/admin/transfer_payment/transfer/"+orderId;
            $("#transferPaymentForm").ajaxSubmit(function(result) {//返回数据根据结果进行相应的处理
                    hippo.msg(result.message);
                    if(result.statusCode=="SUCCESS"){
                        setTimeout((function() {
                            window.parent.location.href =getWebPath() + "/admin/transfer_payment/alipay_list";
                        }), 2000);
                    }
                }
            );
        }
    );
}

TransferPaymentOrder.transferConfirm = function (orderId) {
    var showmsg="确认中转到账吗？";
    layer.confirm(
        showmsg,
        {icon: 0, title:'提示'},
        function(index, layero){
            layer.close(index);
            var actionUrl = getWebPath() + "/admin/transfer_payment/transfer_confirm/"+orderId;
            $.ajax({
                type : "POST", //提交方式
                url : actionUrl,//路径
                success : function(result) {//返回数据根据结果进行相应的处理
                    hippo.msg(result.message);
                    window.location.reload();
                }
            });
        }
    );
}

TransferPaymentOrder.auditPayment = function (status,orderId) {
    if (!hippo.validateForm("transferPaymentForm")) {
        return;
    }
    var showmsg="";
    if("SUCCESS"==status){
        showmsg="确定审核通过吗？";
    }else if ("FAIL"==status) {
        showmsg="确定驳回吗？";
    }
    var auditRemark = $("#auditRemark").val().trim();
    var secondpwd = $("#_secondPasswordVerifier").val().trim();
    layer.confirm(
        showmsg,
        {icon: 0, title:'提示'},
        function(index, layero){
            layer.close(index);
            var actionUrl = getWebPath() + "/admin/transfer_payment/confirmPayment/"+orderId;
            $.ajax({
                type : "POST", //提交方式
                url : actionUrl,//路径
                data : {
                    "orderId":orderId,
                    "auditStatus":status,
                    "auditRemark":auditRemark,
                    "_secondPasswordVerifier":secondpwd
                },
                success : function(result) {//返回数据根据结果进行相应的处理
                    hippo.msg(result.message);
                    if(result.statusCode=="SUCCESS"){
                        setTimeout((function() {
                            window.location.href =getWebPath() + "/admin/transfer_payment/list";
                        }), 2000);
                    }
                }
            });
        }
    );
}


TransferPaymentOrder.recharge = function (formId) {
    if (!hippo.validateForm(formId)) {
        return;
    }

    var url = $(formId).attr("action");
    $("#" + formId).ajaxSubmit( {
        url: url,
        type: 'POST',
        dataType: 'json',
        success: function (data) {
            if (data.statusCode == 'SUCCESS') {//进主页
                new $.zui.Messager(data.message, {
                    type: 'success' // 定义颜色主题
                }).show();
                window.setTimeout(function () {
                    window.parent.location.href = getWebPath() + "/admin/transfer_payment/list";
                }, 1500);
            } else {
                hippo.warning(data.message);
            }
        }
    });
}

TransferPaymentOrder.export = function () {
    $('#searchForm').attr("action",getWebPath() + "/admin/transfer_payment/export");
    $('#searchForm').submit();
}


$(function () {
  hippo.limitMoney('amountYuan');
  hippo.limitMoney('platformCostYuan');

});