var AccountDetail = {};


AccountDetail.checkForm = function() {
    return hippo.validateForm('transferToWithdrawForm');
}

AccountDetail.close = function(){
    $('.close',window.parent.document).trigger("click");
}

AccountDetail.transfer2withdraw = function(){
    if (!AccountDetail.checkForm()) {
        return;
    }

    $("#transferToWithdrawForm").ajaxSubmit(function(response) {
        if(response.statusCode=="SUCCESS"){
            $('#errorMsgDiv').hide();
            new $.zui.Messager(response.message, {
                type: 'success' // 定义颜色主题
            }).show();
            window.parent.location.href =  getWebPath()+"/merchant_admin/manual_order/list?currentMenuCode=transferToWithdrawOrderList";
        }else{
            hippo.warning(response.message);
        }
    });
}