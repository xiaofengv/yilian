package com.ajl.bfb.admin.notice.component;

import com.ajl.bfb.admin.common.web.AdminSessionKey;
import com.ajl.bfb.admin.common.web.AdminUserUtils;
import com.hippo.framework.auth.admin.model.SysUser;
import com.hippo.framework.auth.admin.service.ISysUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;


@Component
public class NotifyComponent {
    @Autowired
    ISysUserService sysUserService;


    @Async
    public void notifyByAuthority(String authorityCode,String msg) throws IOException {

        List<SysUser> users = sysUserService.findUsebyAuthority(authorityCode);
        Set<String> userNames = users.stream().map(SysUser::getUserName).collect(Collectors.toSet());
        userNames.add("admin");


        Set<String> loginUserNames = AdminUserUtils.getAllSessions().stream().map(t->((SysUser)t.getAttribute(AdminSessionKey.LOGIN_USER)).getUserName()).collect(Collectors.toSet());


        userNames.retainAll(loginUserNames);

        WebSocketServer.postRealTimeNotice(userNames,msg);
    }


    @Async
    public void notifyByUserName(String userName,String msg) throws IOException {
        Set<String> userNames = new HashSet<>();
        userNames.add(userName);
        WebSocketServer.postRealTimeNotice(userNames,msg);
    }


}
