package com.ajl.bfb.admin.report.controller;

import com.ajl.bfb.admin.channelaccount.util.ChannelAccountViewUtils;
import com.ajl.bfb.admin.channelaccount.vo.ChannelAccountVO;
import com.ajl.bfb.core.constants.PaymentTypeEnum;
import com.ajl.bfb.core.lock.PaymentOrderLock;
import com.ajl.bfb.core.util.MoneyUtils;
import com.ajl.bfb.itg.util.ZipUtils;
import com.ajl.bfb.repo.channel.model.Channel;
import com.ajl.bfb.repo.channel.model.ChannelAccount;
import com.ajl.bfb.repo.channel.model.ChannelQuery;
import com.ajl.bfb.repo.channel.service.IChannelAccountService;
import com.ajl.bfb.repo.channel.service.IChannelService;
import com.ajl.bfb.repo.merchant.model.Merchant;
import com.ajl.bfb.repo.merchant.service.IMerchantService;
import com.ajl.bfb.repo.report.model.QueryParam;
import com.ajl.bfb.repo.report.service.IReportService;
import com.ajl.bfb.repo.report.service.ReportService;
import com.github.pagehelper.PageInfo;
import com.hippo.framework.auth.admin.OperationAuth;
import com.hippo.framework.core.PagingParameter;
import com.hippo.framework.util.DateUtils;
import com.icexls.IceExcel;
import com.icexls.IceExcelConfig;
import com.icexls.NumberType;
import org.apache.http.HttpRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;


@Controller
@RequestMapping("/admin/report")
public class PlatmentReportController {
    @Value("${export.platment.report}")
    private String exportPath;

    @Autowired
    private IReportService reportService;
    @Autowired
    private PaymentOrderLock paymentOrderLock;
    @Autowired
    private IMerchantService merchantService;
    @Autowired
    private IChannelAccountService channelAccountService;
    @Autowired
    private IChannelService channelService;

    @RequestMapping("/platment_profit_report")
    @OperationAuth(name = "利润报表", authCode = "platform.profitReport", group = "平台报表")
    public String platmentProfitReport(QueryParam queryParam, Model model, PagingParameter pageParam, HttpRequest request){
            initParam(queryParam);
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
        SimpleDateFormat dateFormat1 = new SimpleDateFormat("yyyy-MM-dd");

            queryParam.setStartDay(ReportService.getDay(queryParam.getStartTime()));
            queryParam.setEndDay(ReportService.getDay(queryParam.getEndTime()));

            PageInfo<HashMap> report = reportService.reportQueryByPage(queryParam,pageParam,"platmentProfitReport");
            report.getList().forEach(t -> {
                try {
                    t.put("starttime", dateFormat1.format(dateFormat.parse(t.get("stat_day").toString())));
                    t.put("endtime", dateFormat1.format(org.apache.commons.lang3.time.DateUtils.addDays(dateFormat.parse(t.get("stat_day").toString()),1)));
                } catch (ParseException e) {
                    e.printStackTrace();
                }
            });

            model.addAttribute("queryParam", queryParam);
            model.addAttribute("pageInfo",report);
            return "/admin/report/platment_profit_report";

        }


    @RequestMapping("/platment_profit_detail_report")
    @OperationAuth(name = "利润明细报表", authCode = "platform.profit_detail_report", group = "平台报表")
    public String platmentProfitDetailReport(QueryParam queryParam, Model model, PagingParameter pageParam, HttpRequest request){
        initParam(queryParam);
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
        SimpleDateFormat dateFormat1 = new SimpleDateFormat("yyyy-MM-dd");
        queryParam.setStartDay(ReportService.getDay(queryParam.getStartTime()));
        queryParam.setEndDay(ReportService.getDay(queryParam.getEndTime()));
        PageInfo<HashMap> report = reportService.reportQueryByPage(queryParam,pageParam,"platmentProfitDetailReport");
        report.getList().forEach(t -> {
            try {
                t.put("starttime", dateFormat1.format(dateFormat.parse(t.get("stat_day").toString())));
                t.put("endtime", dateFormat1.format(org.apache.commons.lang3.time.DateUtils.addDays(dateFormat.parse(t.get("stat_day").toString()),1)));
            } catch (ParseException e) {
                e.printStackTrace();
            }
        });
        Map<String,String> paymentTypeMap = Arrays.stream(PaymentTypeEnum.values()).collect(Collectors.toMap(PaymentTypeEnum::name,PaymentTypeEnum::getDesc));
        model.addAttribute("paymentTypeMap", paymentTypeMap);
        List<Merchant> merchants = merchantService.findAllMerchant(null);
        Map<Integer,Merchant> merchantMap = merchants.stream().collect(Collectors.toMap(Merchant::getId, t -> t));
        model.addAttribute("merchantMap", merchantMap);

        List<ChannelAccount> channelAccounts= channelAccountService.findAllChannelAccounts(null);
        Map<Integer,ChannelAccount> channelAccountsMap = channelAccounts.stream().collect(Collectors.toMap(ChannelAccount::getId,t->t));
        model.addAttribute("channelAccountsMap", channelAccountsMap);

        List<Channel> channels = channelService.findChannels(null);
        Map<Integer,String> channelMap = channels.stream().collect(Collectors.toMap(Channel::getId,Channel::getName));
        model.addAttribute("channelMap", channelMap);

        model.addAttribute("queryParam", queryParam);
        model.addAttribute("pageInfo",report);

        List<ChannelAccountVO> channelAccountVOS = toAccountVO(channelAccounts);
        Map<String,List<ChannelAccountVO>> channelVOMap = channelAccountVOS.stream().collect(Collectors.groupingBy(channelAccountVO->channelAccountVO.getChannelName()));
        model.addAttribute("channelVOMap",channelVOMap);

        return "/admin/report/platment_profit_detail_report";
    }


    private List<ChannelAccountVO> toAccountVO(List<ChannelAccount> accounts) {
        List<Channel> channels = channelService.findChannels(new ChannelQuery());
        Map<Integer,String> channelMap = channels.stream().collect(Collectors.toMap(Channel::getId,Channel::getName));
        List<ChannelAccountVO> channelAccountVOS = ChannelAccountViewUtils.toVO(accounts);
        for (ChannelAccountVO acc : channelAccountVOS) {
            acc.setChannelName(channelMap.get(acc.getChannelId()));
        }
        return channelAccountVOS;
    }

    @RequestMapping("/payment_profit_report")
    @OperationAuth(name = "收款利润报表", authCode = "platform.payment_profit_report", group = "平台报表")
    public String paymentProfitReport(QueryParam queryParam, Model model, PagingParameter pageParam, HttpRequest request){
        initParam(queryParam);
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
        SimpleDateFormat dateFormat1 = new SimpleDateFormat("yyyy-MM-dd");

        queryParam.setStartDay(ReportService.getDay(queryParam.getStartTime()));
        queryParam.setEndDay(ReportService.getDay(queryParam.getEndTime()));

        PageInfo<HashMap> report = reportService.reportQueryByPage(queryParam,pageParam,"paymentProfitReport");
        report.getList().forEach(t -> {
            try {
                t.put("starttime", dateFormat1.format(dateFormat.parse(t.get("stat_day").toString())));
                t.put("endtime", dateFormat1.format(org.apache.commons.lang3.time.DateUtils.addDays(dateFormat.parse(t.get("stat_day").toString()),1)));
            } catch (ParseException e) {
                e.printStackTrace();
            }
        });

        model.addAttribute("queryParam", queryParam);
        model.addAttribute("pageInfo",report);
        return "/admin/report/payment_profit_report";

    }


    private void initParam(QueryParam queryParam) {

        if (queryParam.getStartTime() == null) {
            queryParam.setEndTime(DateUtils.getDateEnd(new Date()));
            queryParam.setStartTime(DateUtils.getDateStart(org.apache.commons.lang3.time.DateUtils.addMonths(new Date(),-1)));
        }else{
            queryParam.setStartTime(DateUtils.getDateStart(queryParam.getStartTime()));
            queryParam.setEndTime(DateUtils.getDateEnd(queryParam.getEndTime()));
        }

    }

    @RequestMapping("/platment_profit_report_export")
    @OperationAuth(name = "利润报表导出", authCode = "platform.profitReportExport", group = "平台报表")
    public String exportOrders(QueryParam queryParam, Model model, PagingParameter pageParam, HttpRequest request,
                               HttpServletResponse response) throws Exception {
        initParam(queryParam);
        queryParam.setStartDay(ReportService.getDay(queryParam.getStartTime()));
        queryParam.setEndDay(ReportService.getDay(queryParam.getEndTime()));

        String reqId = System.currentTimeMillis() + "";
        String objId = 99999889 + "";
        try {

            if (!paymentOrderLock.getLock(objId, reqId)) {
                throw new Exception("其他用户正在导出，请稍后再试...");
            }
            final int pageSize = 500;
            final int oneSheetRows = 10000;
            String excelExportFilePath =  exportPath + "/platment_profit_report_" + System.currentTimeMillis();

            List<String> allExcels = new ArrayList<>();
            pageParam.setPageSize(pageSize);
            PageInfo<HashMap> report = reportService.reportQueryByPage(queryParam,pageParam,"platmentProfitReport");
            List<HashMap> orders = new ArrayList<>();

            int pages = report.getPages();
            int pageNum = 1;
            for (int i = 0; i < pages; i++) {
                pageNum = i +1;
                pageParam.setPageNum(pageNum);
                PageInfo<HashMap> reportPageInfo = reportService.reportQueryByPage(queryParam,pageParam,"platmentProfitReport");
                orders.addAll(reportPageInfo.getList());
                if (orders.size() >= oneSheetRows) {
                    String excelFile = export2excel(orders, excelExportFilePath);
                    allExcels.add(excelFile);
                    orders = new ArrayList<>();
                }
            }
            if (!orders.isEmpty()) {
                String excelFile = export2excel(orders, excelExportFilePath);
                allExcels.add(excelFile);
                orders = new ArrayList<>();
            }
            response.addHeader("Content-Disposition", "attachment;filename=platment_profit_report.zip");
            response.setContentType("application/octet-stream");
            ZipUtils.toZip(excelExportFilePath, response.getOutputStream(), true);
            new File(excelExportFilePath).delete();
        } finally {
            paymentOrderLock.releaseLock(objId, reqId);
        }
        return null;
    }




    private String export2excel(List<HashMap> orders, String exportFilePath) {
        new File(exportFilePath).mkdirs();
        String xlsFile = exportFilePath + "/" + System.currentTimeMillis() + ".xls";
        String[] title = {"日期","收款金额","收款利润","批付金额", "批付利润","API金额","API利润","提现金额","提现利润","中转下发金额","中转下发利润","下游充值金额","下游充值利润","中转充值金额","中转充值利润","转代付金额","转代付利润","总利润"};
        String[][] datas = new String[orders .size() + 1][title.length];
        datas[0] = title;
        for (int i = 0; i < orders.size(); i++) {
            int j = i +1;
            HashMap vo = orders.get(i);
            datas[j][0]  = vo.get("stat_day").toString();
            datas[j][1]  = vo.get("paymentAmount")==null?"":MoneyUtils.fee2yuan(((BigDecimal) vo.get("paymentAmount")).intValue()).toString();
            datas[j][2]  = vo.get("paymentProfit")==null?"":MoneyUtils.fee2yuan(((BigDecimal) vo.get("paymentProfit")).intValue()).toString();
            datas[j][3]  = vo.get("batchAmount")==null?"":MoneyUtils.fee2yuan(((BigDecimal) vo.get("batchAmount")).intValue()).toString();
            datas[j][4]  = vo.get("batchProfit")==null?"":MoneyUtils.fee2yuan(((BigDecimal) vo.get("batchProfit")).intValue()).toString();
            datas[j][5]  = vo.get("apiAmount")==null?"":MoneyUtils.fee2yuan(((BigDecimal) vo.get("apiAmount")).intValue()).toString();
            datas[j][6]  = vo.get("apiProfit")==null?"":MoneyUtils.fee2yuan(((BigDecimal) vo.get("apiProfit")).intValue()).toString();
            datas[j][7]  = vo.get("manualAmount")==null?"":MoneyUtils.fee2yuan(((BigDecimal) vo.get("manualAmount")).intValue()).toString();
            datas[j][8]  = vo.get("manualProfit")==null?"":MoneyUtils.fee2yuan(((BigDecimal) vo.get("manualProfit")).intValue()).toString();
            datas[j][9]  = vo.get("transferWithdrawAmount")==null?"":MoneyUtils.fee2yuan(((BigDecimal) vo.get("transferWithdrawAmount")).intValue()).toString();
            datas[j][10]  = vo.get("transferWithdrawProfit")==null?"":MoneyUtils.fee2yuan(((BigDecimal) vo.get("transferWithdrawProfit")).intValue()).toString();
            datas[j][11]  = vo.get("rechargeAmount")==null?"":MoneyUtils.fee2yuan(((BigDecimal) vo.get("rechargeAmount")).intValue()).toString();
            datas[j][12] = vo.get("rechargeProfit")==null?"":MoneyUtils.fee2yuan(((BigDecimal) vo.get("rechargeProfit")).intValue()).toString();
            datas[j][13]  = vo.get("upstreamRechargeAmount")==null?"":MoneyUtils.fee2yuan(((BigDecimal) vo.get("upstreamRechargeAmount")).intValue()).toString();
            datas[j][14] = vo.get("upstreamRechargeProfit")==null?"":MoneyUtils.fee2yuan(((BigDecimal) vo.get("upstreamRechargeProfit")).intValue()).toString();
            datas[j][15] = vo.get("transferToWithdrawAmount")==null?"":MoneyUtils.fee2yuan(((BigDecimal) vo.get("transferToWithdrawAmount")).intValue()).toString();
            datas[j][16] = vo.get("transferToWithdrawProfit")==null?"":MoneyUtils.fee2yuan(((BigDecimal) vo.get("transferToWithdrawProfit")).intValue()).toString();
            datas[j][17] = vo.get("totalProfit")==null?"":MoneyUtils.fee2yuan(((BigDecimal) vo.get("totalProfit")).intValue()).toString();
        }
        IceExcel iceXls = new IceExcel(xlsFile);
        IceExcelConfig.setSheet(iceXls, "平台收益报表");
        IceExcelConfig.setNumberType(iceXls, NumberType.STRING);
        iceXls.setData(datas);
        return xlsFile;
    }



    @RequestMapping("/payment_profit_report_export")
    @OperationAuth(name = "导出收款利润报表", authCode = "platform.payment_profit_report_export", group = "平台报表")
    public String exportPaymentProfitReport(QueryParam queryParam, Model model, PagingParameter pageParam, HttpRequest request,
                               HttpServletResponse response) throws Exception {
        initParam(queryParam);
        queryParam.setStartDay(ReportService.getDay(queryParam.getStartTime()));
        queryParam.setEndDay(ReportService.getDay(queryParam.getEndTime()));

        String reqId = System.currentTimeMillis() + "";
        String objId = 99999889 + "";
        try {

            if (!paymentOrderLock.getLock(objId, reqId)) {
                throw new Exception("其他用户正在导出，请稍后再试...");
            }
            final int pageSize = 500;
            final int oneSheetRows = 10000;
            String excelExportFilePath =  exportPath + "/payment_profit_report_" + System.currentTimeMillis();

            List<String> allExcels = new ArrayList<>();
            pageParam.setPageSize(pageSize);
            PageInfo<HashMap> report = reportService.reportQueryByPage(queryParam,pageParam,"paymentProfitReport");
            List<HashMap> orders = new ArrayList<>();

            int pages = report.getPages();
            int pageNum = 1;
            for (int i = 0; i < pages; i++) {
                pageNum = i +1;
                pageParam.setPageNum(pageNum);
                PageInfo<HashMap> reportPageInfo = reportService.reportQueryByPage(queryParam,pageParam,"paymentProfitReport");
                orders.addAll(reportPageInfo.getList());
                if (orders.size() >= oneSheetRows) {
                    String excelFile = paymentProfitReportExport2excel(orders, excelExportFilePath);
                    allExcels.add(excelFile);
                    orders = new ArrayList<>();
                }
            }
            if (!orders.isEmpty()) {
                String excelFile = paymentProfitReportExport2excel(orders, excelExportFilePath);
                allExcels.add(excelFile);
                orders = new ArrayList<>();
            }
            response.addHeader("Content-Disposition", "attachment;filename=payment_profit_report.zip");
            response.setContentType("application/octet-stream");
            ZipUtils.toZip(excelExportFilePath, response.getOutputStream(), true);
            new File(excelExportFilePath).delete();
        } finally {
            paymentOrderLock.releaseLock(objId, reqId);
        }
        return null;
    }

    private String paymentProfitReportExport2excel(List<HashMap> orders, String exportFilePath) {
        new File(exportFilePath).mkdirs();
        String xlsFile = exportFilePath + "/" + System.currentTimeMillis() + ".xls";
        String[] title = {"日期","支付宝收款金额","支付宝收款利润","京东收款金额", "京东收款利润","QQ收款金额","QQ收款利润","银行收款金额","银行收款利润","微信收款金额","微信收款利润","总利润"};
        String[][] datas = new String[orders .size() + 1][title.length];
        datas[0] = title;
        for (int i = 0; i < orders.size(); i++) {
            int j = i +1;
            HashMap vo = orders.get(i);
            datas[j][0]  = vo.get("stat_day").toString();
            datas[j][1]  = vo.get("ALIPAYAmount")==null?"":MoneyUtils.fee2yuan(((BigDecimal) vo.get("ALIPAYAmount")).intValue()).toString();
            datas[j][2]  = vo.get("ALIPAY")==null?"":MoneyUtils.fee2yuan(((BigDecimal) vo.get("ALIPAY")).intValue()).toString();
            datas[j][3]  = vo.get("JD_PAYAmount")==null?"":MoneyUtils.fee2yuan(((BigDecimal) vo.get("JD_PAYAmount")).intValue()).toString();
            datas[j][4]  = vo.get("JD_PAY")==null?"":MoneyUtils.fee2yuan(((BigDecimal) vo.get("JD_PAY")).intValue()).toString();
            datas[j][5]  = vo.get("QQ_PAYAmount")==null?"":MoneyUtils.fee2yuan(((BigDecimal) vo.get("QQ_PAYAmount")).intValue()).toString();
            datas[j][6]  = vo.get("QQ_PAY")==null?"":MoneyUtils.fee2yuan(((BigDecimal) vo.get("QQ_PAY")).intValue()).toString();
            datas[j][7]  = vo.get("UNION_PAYAmount")==null?"":MoneyUtils.fee2yuan(((BigDecimal) vo.get("UNION_PAYAmount")).intValue()).toString();
            datas[j][8]  = vo.get("UNION_PAY")==null?"":MoneyUtils.fee2yuan(((BigDecimal) vo.get("UNION_PAY")).intValue()).toString();
            datas[j][9]  = vo.get("WEIXIN_PAYAmount")==null?"":MoneyUtils.fee2yuan(((BigDecimal) vo.get("WEIXIN_PAYAmount")).intValue()).toString();
            datas[j][10] = vo.get("WEIXIN_PAY")==null?"":MoneyUtils.fee2yuan(((BigDecimal) vo.get("WEIXIN_PAY")).intValue()).toString();
            datas[j][11] = vo.get("totalProfit")==null?"":MoneyUtils.fee2yuan(((BigDecimal) vo.get("totalProfit")).intValue()).toString();
        }
        IceExcel iceXls = new IceExcel(xlsFile);
        IceExcelConfig.setSheet(iceXls, "收款收益报表");
        IceExcelConfig.setNumberType(iceXls, NumberType.STRING);
        iceXls.setData(datas);
        return xlsFile;
    }



    @RequestMapping("/platment_profit_detail_report_export")
    @OperationAuth(name = "利润明细报表导出", authCode = "platform.profit_detail_report_export", group = "平台报表")
    public String exportDetailOrders(QueryParam queryParam, Model model, PagingParameter pageParam, HttpRequest request,
                               HttpServletResponse response) throws Exception {
        initParam(queryParam);
        queryParam.setStartDay(ReportService.getDay(queryParam.getStartTime()));
        queryParam.setEndDay(ReportService.getDay(queryParam.getEndTime()));

        String reqId = System.currentTimeMillis() + "";
        String objId = 99999889 + "";
        try {

            if (!paymentOrderLock.getLock(objId, reqId)) {
                throw new Exception("其他用户正在导出，请稍后再试...");
            }
            final int pageSize = 500;
            final int oneSheetRows = 10000;
            String excelExportFilePath =  exportPath + "/platment_profit_detail_report_" + System.currentTimeMillis();

            List<String> allExcels = new ArrayList<>();
            pageParam.setPageSize(pageSize);
            PageInfo<HashMap> report = reportService.reportQueryByPage(queryParam,pageParam,"platmentProfitDetailReport");
            List<HashMap> orders = new ArrayList<>();

            int pages = report.getPages();
            int pageNum = 1;
            for (int i = 0; i < pages; i++) {
                pageNum = i +1;
                pageParam.setPageNum(pageNum);
                PageInfo<HashMap> reportPageInfo = reportService.reportQueryByPage(queryParam,pageParam,"platmentProfitDetailReport");
                orders.addAll(reportPageInfo.getList());
                if (orders.size() >= oneSheetRows) {
                    String excelFile = export2excel2(orders, excelExportFilePath);
                    allExcels.add(excelFile);
                    orders = new ArrayList<>();
                }
            }
            if (!orders.isEmpty()) {
                String excelFile = export2excel2(orders, excelExportFilePath);
                allExcels.add(excelFile);
                orders = new ArrayList<>();
            }
            response.addHeader("Content-Disposition", "attachment;filename=platment_profit_report.zip");
            response.setContentType("application/octet-stream");
            ZipUtils.toZip(excelExportFilePath, response.getOutputStream(), true);
            new File(excelExportFilePath).delete();
        } finally {
            paymentOrderLock.releaseLock(objId, reqId);
        }
        return null;
    }

    private String export2excel2(List<HashMap> orders, String exportFilePath) {
        new File(exportFilePath).mkdirs();
        String xlsFile = exportFilePath + "/" + System.currentTimeMillis() + ".xls";
        String[] title = {"日期","商户","通道","收款方式","收款金额","收款利润","批付金额", "批付利润","API金额","API利润","提现金额","提现利润","中转下发金额","中转下发利润","下游充值金额","下游充值利润","中转充值金额","中转充值利润","转代付金额","转代付利润","总利润"};
        String[][] datas = new String[orders .size() + 1][title.length];
        datas[0] = title;
        List<Merchant> merchants = merchantService.findAllMerchant(null);
        Map<Integer,Merchant> merchantMap = merchants.stream().collect(Collectors.toMap(Merchant::getId, t -> t));

        List<ChannelAccount> channelAccounts= channelAccountService.findAllChannelAccounts(null);
        Map<Integer,ChannelAccount> channelAccountsMap = channelAccounts.stream().collect(Collectors.toMap(ChannelAccount::getId,t->t));

        List<Channel> channels = channelService.findChannels(null);
        Map<Integer,String> channelMap = channels.stream().collect(Collectors.toMap(Channel::getId,Channel::getName));
        Map<String,String> paymentTypeMap = Arrays.stream(PaymentTypeEnum.values()).collect(Collectors.toMap(PaymentTypeEnum::name,PaymentTypeEnum::getDesc));

        for (int i = 0; i < orders.size(); i++) {
            int j = i +1;
            HashMap vo = orders.get(i);
            datas[j][0]  = vo.get("stat_day").toString();
            datas[j][1]  = merchantMap.get(vo.get("merchant_id"))==null?"":merchantMap.get(vo.get("merchant_id")).getMerchantNo()+merchantMap.get(vo.get("merchant_id")).getMerchantName();
            datas[j][2]  = channelAccountsMap.get(vo.get("channel_account_id"))==null?"":channelMap.get(vo.get("channel_id"))+channelAccountsMap.get(vo.get("channel_account_id")).getAccount();
            datas[j][3]  = paymentTypeMap.get(vo.get("pay_type_code"))==null?"":paymentTypeMap.get(vo.get("pay_type_code"));

            datas[j][4]  = vo.get("paymentAmount")==null?"":MoneyUtils.fee2yuan(((BigDecimal) vo.get("paymentAmount")).intValue()).toString();
            datas[j][5]  = vo.get("paymentProfit")==null?"":MoneyUtils.fee2yuan(((BigDecimal) vo.get("paymentProfit")).intValue()).toString();
            datas[j][6]  = vo.get("batchAmount")==null?"":MoneyUtils.fee2yuan(((BigDecimal) vo.get("batchAmount")).intValue()).toString();
            datas[j][7]  = vo.get("batchProfit")==null?"":MoneyUtils.fee2yuan(((BigDecimal) vo.get("batchProfit")).intValue()).toString();
            datas[j][8]  = vo.get("apiAmount")==null?"":MoneyUtils.fee2yuan(((BigDecimal) vo.get("apiAmount")).intValue()).toString();
            datas[j][9]  = vo.get("apiProfit")==null?"":MoneyUtils.fee2yuan(((BigDecimal) vo.get("apiProfit")).intValue()).toString();
            datas[j][10]  = vo.get("manualAmount")==null?"":MoneyUtils.fee2yuan(((BigDecimal) vo.get("manualAmount")).intValue()).toString();
            datas[j][11]  = vo.get("manualProfit")==null?"":MoneyUtils.fee2yuan(((BigDecimal) vo.get("manualProfit")).intValue()).toString();

            datas[j][12]  = vo.get("transferWithdrawAmount")==null?"":MoneyUtils.fee2yuan(((BigDecimal) vo.get("transferWithdrawAmount")).intValue()).toString();
            datas[j][13]  = vo.get("transferWithdrawProfit")==null?"":MoneyUtils.fee2yuan(((BigDecimal) vo.get("transferWithdrawProfit")).intValue()).toString();

            datas[j][14]  = vo.get("rechargeAmount")==null?"":MoneyUtils.fee2yuan(((BigDecimal) vo.get("rechargeAmount")).intValue()).toString();
            datas[j][15] = vo.get("rechargeProfit")==null?"":MoneyUtils.fee2yuan(((BigDecimal) vo.get("rechargeProfit")).intValue()).toString();
            datas[j][16]  = vo.get("upstreamRechargeAmount")==null?"":MoneyUtils.fee2yuan(((BigDecimal) vo.get("upstreamRechargeAmount")).intValue()).toString();
            datas[j][17]  = vo.get("upstreamRechargeProfit")==null?"":MoneyUtils.fee2yuan(((BigDecimal) vo.get("upstreamRechargeProfit")).intValue()).toString();

            datas[j][18] = vo.get("transferToWithdrawAmount")==null?"":MoneyUtils.fee2yuan(((BigDecimal) vo.get("transferToWithdrawAmount")).intValue()).toString();
            datas[j][19] = vo.get("transferToWithdrawProfit")==null?"":MoneyUtils.fee2yuan(((BigDecimal) vo.get("transferToWithdrawProfit")).intValue()).toString();
            datas[j][20] = vo.get("totalProfit")==null?"":MoneyUtils.fee2yuan(((BigDecimal) vo.get("totalProfit")).intValue()).toString();
        }
        IceExcel iceXls = new IceExcel(xlsFile);
        IceExcelConfig.setSheet(iceXls, "平台收益报表");
        IceExcelConfig.setNumberType(iceXls, NumberType.STRING);
        iceXls.setData(datas);
        return xlsFile;
    }


    @RequestMapping("/platment_profit_chart")
    @OperationAuth(name = "利润报表", authCode = "platform.profitReport", group = "平台报表")
    public String platmentProfitChart(QueryParam queryParam, Model model, PagingParameter pageParam, HttpRequest request){
        if (queryParam.getStartTime() == null) {
            queryParam.setEndTime(DateUtils.getDateEnd(new Date()));
            queryParam.setStartTime(DateUtils.getDateStart(org.apache.commons.lang3.time.DateUtils.addMonths(DateUtils.getDateStart2(new Date()),-1)));
        }else{
            queryParam.setStartTime(DateUtils.getDateStart(queryParam.getStartTime()));
            queryParam.setEndTime(DateUtils.getDateEnd(queryParam.getEndTime()));
        }
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
        SimpleDateFormat dateFormat1 = new SimpleDateFormat("yyyy-MM-dd");

        queryParam.setStartDay(ReportService.getDay(queryParam.getStartTime()));
        queryParam.setEndDay(ReportService.getDay(queryParam.getEndTime()));
        pageParam.setPageSize(30);
        PageInfo<HashMap> report = reportService.reportQueryByPage(queryParam,pageParam,"platmentProfitReport");
        report.getList().forEach(t -> {
            try {
                t.put("starttime", dateFormat1.format(dateFormat.parse(t.get("stat_day").toString())));
                t.put("endtime", dateFormat1.format(org.apache.commons.lang3.time.DateUtils.addDays(dateFormat.parse(t.get("stat_day").toString()),1)));
            } catch (ParseException e) {
                e.printStackTrace();
            }
        });
        model.addAttribute("queryParam", queryParam);
        model.addAttribute("pageInfo",report);
        return "/admin/report/platment_profit_chart";

    }
}
