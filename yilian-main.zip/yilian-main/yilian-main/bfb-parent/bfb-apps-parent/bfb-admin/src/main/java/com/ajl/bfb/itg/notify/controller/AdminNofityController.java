package com.ajl.bfb.itg.notify.controller;

import com.ajl.bfb.admin.notice.component.NotifyComponent;
import com.hippo.framework.util.JsonUtils;
import com.hippo.framework.web.ResponseCode;
import com.hippo.framework.web.ResponseResult;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;


@Controller
@RequestMapping( "/admin_itg/nofity")
public class AdminNofityController {

    private static Logger logger = LogManager.getLogger(AdminNofityController.class);

    @Autowired
    private NotifyComponent notifyComponent;

    @RequestMapping( "/notifyByAuthority")
    @ResponseBody
    public ResponseResult notifyByAuthority(HttpServletRequest request, String authorityCode, String msg) {
        logger.info("收到通知::::::::" + JsonUtils.obj2String(request.getParameterMap()));
        if (authorityCode == null || msg == null) {
            return new ResponseResult(ResponseCode.FAIL, "参数为空","");
        }
        try {
            notifyComponent.notifyByAuthority(authorityCode, msg);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return new ResponseResult(ResponseCode.SUCCESS, "通知成功","");
    }

}
