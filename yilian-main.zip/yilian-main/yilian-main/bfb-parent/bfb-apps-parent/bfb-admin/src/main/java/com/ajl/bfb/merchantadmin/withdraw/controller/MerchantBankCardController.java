package com.ajl.bfb.merchantadmin.withdraw.controller;

import com.ajl.bfb.core.constants.BankCodeEnum;
import com.ajl.bfb.merchantadmin.common.web.MerchantAdminUserUtils;
import com.ajl.bfb.merchantadmin.withdraw.vo.MerchantBankCardVO;
import com.ajl.bfb.repo.merchant.model.Merchant;
import com.ajl.bfb.repo.withdraw.model.BankCardQueryParam;
import com.ajl.bfb.repo.withdraw.model.MerchantBankCard;
import com.ajl.bfb.repo.withdraw.service.IMerchantBankCardService;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.List;


@Controller
@RequestMapping(value="/merchant_admin/bankcard")
public class MerchantBankCardController {


    @Autowired
    private IMerchantBankCardService merchantBankCardService;

    @RequestMapping(value="/list")
    public String list(Model model, HttpServletRequest req) {
        BankCardQueryParam query = new BankCardQueryParam();
        query.setPageNum(1);
        query.setPageSize(1000);
        Merchant merchant = MerchantAdminUserUtils.getLoginMerchant(req);
        model.addAttribute("userType",merchant.getUserType());
        query.setMerchantId(merchant.getId());
        PageInfo list = merchantBankCardService.findList(query);
        list.setList(toVO(list.getList()));
        model.addAttribute("pageInfo", list);

        return "merchant_admin/card/list";
    }

    public static List<MerchantBankCardVO> toVO(List<MerchantBankCard> list) {
        List<MerchantBankCardVO> volist = new ArrayList<>();
        for (MerchantBankCard card : list) {
            volist.add(toVO(card));
        }
        return volist;
    }

    private static MerchantBankCardVO  toVO( MerchantBankCard card) {
        MerchantBankCardVO vo = new MerchantBankCardVO();
        BeanUtils.copyProperties(card, vo);
        return vo;
    }

    @RequestMapping(value="/toadd")
    public String toadd(Model model) {
        model.addAttribute("bankCodeEnums", BankCodeEnum.values());
        return "/merchant_admin/card/add";
    }

    @RequestMapping(value="/toupdate")
    public String toupdate(int id, Model model, HttpServletRequest request) {
        model.addAttribute("bankCodeEnums", BankCodeEnum.values());
        MerchantBankCard card = merchantBankCardService.findById(id);
        Merchant loginMerchant = MerchantAdminUserUtils.getLoginMerchant(request);
        if (card.getMerchantId().intValue() != loginMerchant.getId().intValue()) {
            throw new RuntimeException("警告,您的行为恶劣，再犯资金将被冻结。");
        }
        model.addAttribute("card",card);
        return "/merchant_admin/card/update";
    }


    @RequestMapping(value="/save")
    public String save(Model model, MerchantBankCard card, HttpServletRequest req) {
        card.setMerchantId(MerchantAdminUserUtils.getLoginMerchant(req).getId());
        merchantBankCardService.save(card);
        return "redirect:/merchant_admin/bankcard/list";
    }

    @RequestMapping(value="/update")
    public String update(Model model, MerchantBankCard card,HttpServletRequest req) {
        MerchantBankCard oldcard = merchantBankCardService.findById(card.getId());
        Merchant loginMerchant = MerchantAdminUserUtils.getLoginMerchant(req);
        if (oldcard.getMerchantId().intValue() != loginMerchant.getId().intValue()) {
            throw new RuntimeException("警告,您的行为恶劣，再犯资金将被冻结。");
        }
        merchantBankCardService.update(card);
        return "redirect:/merchant_admin/bankcard/list";
    }

    @RequestMapping(value="/del")
    public String del(int id) {
        merchantBankCardService.delete(id);
        return "redirect:/merchant_admin/bankcard/list";
    }

}
