package com.ajl.bfb.upstreamadmin.config;

import com.ajl.bfb.merchantadmin.common.web.MerchantAdminSessionKey;
import com.hippo.framework.web.servlet.AuthImageServlet;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;


@Configuration
public class UpstreamServletConfig {


    @Bean("upstreamLoginVerifyCodeImgServlet")
    public ServletRegistrationBean loginVerifyCodeImgRegistration() {
        ServletRegistrationBean registration = new ServletRegistrationBean(new AuthImageServlet());
        registration.addUrlMappings("/upstream-admin-login-verifycode");
        registration.addInitParameter("height", "30");
        registration.addInitParameter("width", "80");
        registration.addInitParameter("key", MerchantAdminSessionKey.LOGIN_VERIFY_CODE);
        registration.setName("upstreamLoginVerifyCodeImgServlet");
        return registration;
    }





}
