var platment_report = {};

platment_report.export1 = function () {
    $('#searchForm').attr("action",getWebPath() + "/admin/report/platment_profit_report_export");
    $('#searchForm').submit();
}

platment_report.export2 = function () {
    $('#searchForm').attr("action",getWebPath() + "/admin/report/payment_profit_report_export");
    $('#searchForm').submit();
}

platment_report.export3 = function () {
    $('#searchForm').attr("action",getWebPath() + "/admin/report/platment_profit_detail_report_export");
    $('#searchForm').submit();
}