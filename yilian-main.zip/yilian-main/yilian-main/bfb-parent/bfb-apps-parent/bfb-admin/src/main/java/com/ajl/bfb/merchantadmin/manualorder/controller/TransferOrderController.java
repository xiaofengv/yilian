package com.ajl.bfb.merchantadmin.manualorder.controller;

import com.ajl.bfb.core.constants.AuditStatusEnum;
import com.ajl.bfb.core.constants.ManualBizTypeEnum;
import com.ajl.bfb.core.constants.OrderStatusEnum;
import com.ajl.bfb.merchantadmin.common.web.MerchantAdminUserUtils;
import com.ajl.bfb.repo.manualorder.model.ManualOrder;
import com.ajl.bfb.repo.manualorder.model.ManualOrderQueryParam;
import com.ajl.bfb.repo.manualorder.service.IManualOrderService;
import com.ajl.bfb.repo.merchant.model.Merchant;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import java.util.Arrays;
import java.util.Map;
import java.util.stream.Collectors;


@Controller
@RequestMapping("/merchant_admin/manual_order")
public class TransferOrderController {

    @Autowired
    IManualOrderService manualOrderService;


    @RequestMapping("/list")
    public String getManualOrderList(HttpServletRequest request,ManualOrderQueryParam param,Model model){

        Merchant merchant = MerchantAdminUserUtils.getLoginMerchant(request);
        model.addAttribute("userType",merchant.getUserType());
        param.setMerchantAcc(merchant.getMerchantNo());
        param.setBizType(ManualBizTypeEnum.TRANSFER_TO_WITHDRAW.name());
        PageInfo<ManualOrder> pageInfo =  manualOrderService.getManualOrderList(param);

        model.addAttribute("orderStatusList", OrderStatusEnum.values());
        Map<String,String> orderStatusMap = Arrays.stream(OrderStatusEnum.values()).collect(Collectors.toMap(OrderStatusEnum::name, r -> r.getDesc()));
        model.addAttribute("orderStatusMap", orderStatusMap);

        model.addAttribute("auditStatusList", AuditStatusEnum.values());
        Map<String,String> auditStatusMap = Arrays.stream(AuditStatusEnum.values()).collect(Collectors.toMap(AuditStatusEnum::name, r -> r.getDesc()));
        model.addAttribute("auditStatusMap", auditStatusMap);

        model.addAttribute("pageInfo",pageInfo);
        model.addAttribute("queryParam",param);
        return "/merchant_admin/manual_order/list";
    }


}
