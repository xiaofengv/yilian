var BatchWithdrawOrder = {};


BatchWithdrawOrder.export = function () {
    $('#searchForm').attr("action",getWebPath() + "/merchant_admin/withdraw/export");
    $('#searchForm').submit();
}

BatchWithdrawOrder.exportBatchWithdrawOrder = function () {
    $('#searchForm').attr("action",getWebPath() + "/merchant_admin/withdraw/export_batch_withdraw");
    $('#searchForm').submit();
}


BatchWithdrawOrder.search = function () {
    $('#searchForm').attr("action",getWebPath() + "/merchant_admin/withdraw/batch_list");
    $('#searchForm').submit();
}