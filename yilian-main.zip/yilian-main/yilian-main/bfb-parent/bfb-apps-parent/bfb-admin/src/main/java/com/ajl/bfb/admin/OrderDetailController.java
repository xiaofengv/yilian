package com.ajl.bfb.admin;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.*;


@Controller
@RequestMapping("/admin/sys")
public class OrderDetailController {

    @RequestMapping("/order_detail")
    public String order(@RequestParam HashMap orderMap, Model model){
        model.addAttribute("order",orderMap);
        return "/order";
    }

    @RequestMapping("/add_order")
    public String addOrder(Model model){
        Map<String,String> formMap = new HashMap<>();
        formMap.put("orderno","订单号");
        formMap.put("ghr","购货人");
        formMap.put("zffs","支付方式");
        formMap.put("psfs","配送方式");
        formMap.put("fhdh","发货单号");
        formMap.put("xdsj","下单时间");
        formMap.put("fksj","付款时间");
        formMap.put("fhsj","发货时间");
        formMap.put("fptt","发票抬头");
        formMap.put("khly","客户给商家的留言");
        formMap.put("qhcl","缺货处理");
        formMap.put("bz","包装");
        formMap.put("hkzfy","贺卡祝福语");
        formMap.put("sjly","商家给客户的留言");
        formMap.put("fpn","发票内");
        formMap.put("fksj","付款时间");
        formMap.put("fhsj","发货时间");
        formMap.put("cksj","出库时间");
        formMap.put("dbsj","打包时间");
        formMap.put("ddly","订单来源");
        formMap.put("shr","收货人");
        formMap.put("dz","地址");
        formMap.put("dh","电话");
        formMap.put("bzxjz","标志性建筑");
        formMap.put("dzyx","电子邮箱");
        formMap.put("yb","邮编");
        formMap.put("sj","手机");
        formMap.put("zjshsj","最佳送货时间");
        formMap.put("spmc","商品名称");
        formMap.put("hph","货品号");
        formMap.put("dz","地址");
        formMap.put("yb","邮编");
        model.addAttribute("formMap",formMap);
        return "/add_order";
    }
}
