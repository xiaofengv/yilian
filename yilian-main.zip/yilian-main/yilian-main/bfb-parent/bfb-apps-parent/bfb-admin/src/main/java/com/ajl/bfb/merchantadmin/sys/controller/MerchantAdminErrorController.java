package com.ajl.bfb.merchantadmin.sys.controller;

import com.ajl.bfb.itg.config.ItgExceptionHandlerAdvice;
import com.hippo.framework.web.ResponseCode;
import com.hippo.framework.web.ResponseResult;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@Controller
@RequestMapping(value="/merchant_admin/error")
public class MerchantAdminErrorController {

    private static final Logger logger = LogManager.getLogger(MerchantAdminErrorController.class);

    @RequestMapping(path = "/http500")

    public String http500(HttpServletRequest request, HttpServletResponse response, Model model) {
        Object exception = request.getAttribute(ItgExceptionHandlerAdvice.EXCEPTION_KEY);
        model.addAttribute("errorMsg",exception == null?"": extractErrorMsg((Throwable)exception));
        return "/merchant_admin/sys/http500";
    }

    @RequestMapping(path = "/http404")

    public String http404(HttpServletRequest request, HttpServletResponse response) {
        return "/merchant_admin/sys/http404";
    }

    @RequestMapping(path = "/ajax-http404")
    @ResponseBody
    public ResponseResult ajaxHttp404(HttpServletRequest request, HttpServletResponse response) {
        response.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
        ResponseResult r = new ResponseResult();
        r.setStatusCode(ResponseCode.UNKNOWN_EXCEPTION);
        r.setMessage("访问的地址不存在." );
        return r;
    }

    @RequestMapping(path = "/ajax-http500")
    @ResponseBody
    public ResponseResult ajaxHttp500(HttpServletRequest request, HttpServletResponse response) {
        Object exception = request.getAttribute(ItgExceptionHandlerAdvice.EXCEPTION_KEY);
        response.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
        ResponseResult r = new ResponseResult();
        r.setStatusCode(ResponseCode.UNKNOWN_EXCEPTION);
        r.setMessage("未知的程序异常." + (exception == null?"": extractErrorMsg((Throwable)exception)));
        return r;
    }

    private String extractErrorMsg(Throwable exception) {
        if (StringUtils.isNotBlank(exception.getMessage())) {
            return exception.getMessage();
        }
        return ExceptionUtils.getStackTrace(exception);
    }

}
