package com.ajl.bfb.admin.channelpaytype.vo;

import com.ajl.bfb.core.constants.PaymentTypeEnum;
import com.ajl.bfb.core.util.MoneyUtils;
import com.ajl.bfb.core.util.RateUtils;
import com.ajl.bfb.repo.channel.model.ChannelPayType;

import java.math.BigDecimal;


public class ChannelPayTypeVO extends ChannelPayType {

    private BigDecimal channelRatePercent;

    private BigDecimal minAmountYuan;

    private BigDecimal maxAmountYuan;

    public String getChannelType() {
        return PaymentTypeEnum.valueOf(getPayTypeCode()).getChannelType();
    }

    public String getPayTypeStr() {
        return PaymentTypeEnum.valueOf(getPayTypeCode()).getDesc();
    }

    public String getRateTypeStr() {
        return RateUtils.getRateType(getPayTypeCode()).getViewDesc();
    }

    public BigDecimal getChannelRatePercent() {
        return channelRatePercent;
    }

    public void setChannelRatePercent(BigDecimal channelRatePercent) {
        this.channelRatePercent = channelRatePercent;

        setChannelRate(RateUtils.percent2rate(channelRatePercent));
    }

    public BigDecimal getMinAmountYuan() {
        return minAmountYuan;
    }

    public void setMinAmountYuan(BigDecimal minAmountYuan) {
        this.minAmountYuan = minAmountYuan;
        setMinAmount(MoneyUtils.yuan2fee(minAmountYuan).intValue());
    }

    public BigDecimal getMaxAmountYuan() {
        return maxAmountYuan;
    }

    public void setMaxAmountYuan(BigDecimal maxAmountYuan) {
        this.maxAmountYuan = maxAmountYuan;
        setMaxAmount(MoneyUtils.yuan2fee(maxAmountYuan).intValue());
    }
}
