var WithdrawOrder = {};

WithdrawOrder.addBankCardWhiteList = function (merchantNo,bankCard) {
    var actionUrl = getWebPath() + "/admin/merchant/add_bankcard_whiltelist";
    layer.confirm(
        "是否添加到白名单？",
        {icon: 0, title:'提示'},
        function(index, layero){
            $.ajax({
                type : "POST", //提交方式
                url : actionUrl,//路径
                data : {
                    "merchantNo":merchantNo,
                    "bankCard":bankCard
                },
                success : function(result) {//返回数据根据结果进行相应的处理
                    hippo.msg(result.message);
                    if(result.statusCode=="SUCCESS"){
                        setTimeout((function() {
                            window.location.reload();
                        }), 2000);
                    }
                }
            });
        }
    );
}


WithdrawOrder.addRequestIPWhiteList = function (merchantNo,requestIP) {
    var actionUrl = getWebPath() + "/admin/merchant/add_requestip_whiltelist";
    layer.confirm(
        "是否添加到白名单？",
        {icon: 0, title:'提示'},
        function(index, layero){
            $.ajax({
                type : "POST", //提交方式
                url : actionUrl,//路径
                data : {
                    "merchantNo":merchantNo,
                    "requestIP":requestIP
                },
                success : function(result) {//返回数据根据结果进行相应的处理
                    hippo.msg(result.message);
                    if(result.statusCode=="SUCCESS"){
                        setTimeout((function() {
                            window.location.reload();
                        }), 2000);
                    }
                }
            });
        }
    );
}

/**
 * 审核
 * @param status
 * @param orderId
 */
WithdrawOrder.auditWithdraw = function (status,orderId,withdrawType) {
    if (!hippo.validateForm("withdrawForm")) {
        return;
    }
    var showmsg="";
    if("SUCCESS"==status){
        showmsg="确定审核通过吗？";
    }else if ("FAIL"==status) {
        showmsg="确定驳回吗？";
    }
    var auditRemark = $("#auditRemark").val().trim();
    layer.confirm(
        showmsg,
        {icon: 0, title:'提示'},
        function(index, layero){
            layer.close(index);
            var actionUrl = getWebPath() + "/admin/withdraw/audit_withdraw_order";
            $.ajax({
                type : "POST", //提交方式
                url : actionUrl,//路径
                data : {
                        "withdrawId":orderId,
                        "auditStatus":status,
                        "auditRemark":auditRemark
                },
                success : function(result) {//返回数据根据结果进行相应的处理
                    hippo.msg(result.message);
                    if(result.statusCode=="SUCCESS"){
                        setTimeout((function() {
                            if(withdrawType=="MANUAL_ONLINE_TRANSFER"){
                                window.location.href =getWebPath() + "/admin/transfer_withdraw/list?currentMenuCode=transferWithdrawList";
                            }else if (withdrawType == 'MANUAL'){
                                window.location.href =getWebPath() + "/admin/withdraw/manual_withdraw_list";
                            }else{
                                window.location.href =getWebPath() + "/admin/withdraw/list";
                            }
                        }), 2000);
                    }
                }
            });
        }
    );
}

/**
 * 取消订单
 * @param remark
 * @param withdrawId
 */
WithdrawOrder.cannelWithdraw = function (withdrawId) {
    if (!hippo.validateForm('withdrawForm')) {
        return;
    }
    var remark = $("#orderStatusDesc").val().trim();
    var actionUrl = getWebPath() + "/admin/withdraw/cannel_withdraw_order";
    $.ajax({
        type : "POST", //提交方式
        url : actionUrl,//路径
        data : {
            "withdrawId":withdrawId,
            "orderResultDesc":remark
        },
        success : function(result) {//返回数据根据结果进行相应的处理
            hippo.msg(result.message);
            if(result.statusCode=="SUCCESS"){
                setTimeout((function() {
                    window.location.href =getWebPath() + "/admin/withdraw/list";
                }), 2000);
            }
        }
    });

}

WithdrawOrder.doWithdraw = function (withdrawId, channelAccountId) {
    var actionUrl = getWebPath() + "/admin/withdraw/do_withdarw";
    layer.confirm(
        '确认要代付吗?',
        {icon: 0, title:'提示'},
        function(index, layero){
            layer.close(index);
            $.ajax({
                type : "POST", //提交方式
                url : actionUrl,//路径
                data : {
                    "withdrawId":withdrawId,
                    "channelAccountId":channelAccountId
                },
                success : function(result) {//返回数据根据结果进行相应的处理
                    hippo.msg(result.message);
                    if(result.statusCode=="SUCCESS"){
                        setTimeout((function() {
                            window.location.href =getWebPath() + "/admin/withdraw/manual_withdraw_list";
                        }), 2000);
                    }
                }
            });
        }
    );
}


WithdrawOrder.doOfflineWithdraw = function (withdrawId, channelAccountId) {
    var actionUrl = getWebPath() + "/admin/withdraw/do_offline_withdarw";
    layer.confirm(
        '确认要代付吗?',
        {icon: 0, title:'提示'},
        function(index, layero){
            layer.close(index);
            $.ajax({
                type : "POST", //提交方式
                url : actionUrl,//路径
                data : {
                    "withdrawId":withdrawId,
                    "channelAccountId":channelAccountId
                },
                success : function(result) {//返回数据根据结果进行相应的处理
                    hippo.msg(result.message);
                    if(result.statusCode=="SUCCESS"){
                        setTimeout((function() {
                            window.location.href =getWebPath() + "/admin/withdraw/list";
                        }), 2000);
                    }
                }
            });
        }
    );
}


WithdrawOrder.syncOrderStatus = function (withdrawId) {
    var actionUrl = getWebPath() + "/admin/withdraw/sync_order_status";
    $.ajax({
        type : "POST", //提交方式
        url : actionUrl,//路径
        data : {
            "withdrawId":withdrawId
        },
        success : function(result) {//返回数据根据结果进行相应的处理
            hippo.msg(result.message);
            if(result.statusCode=="SUCCESS"){
                setTimeout((function() {
                    window.location.href =getWebPath() + "/admin/withdraw/order_detail/" +withdrawId;
                }), 2000);
            }
        }
    });

}

WithdrawOrder.modifyOrderStatus = function (withdrawId) {
    if (!hippo.validateForm("modifyWithdrawOrderForm")) {
        return;
    }
    $("#modifyWithdrawOrderForm").ajaxSubmit(function(response) {
        if(response.statusCode=="SUCCESS"){
            new $.zui.Messager(response.message, {
                type: 'success' // 定义颜色主题
            }).show();
            window.parent.location.href =  getWebPath() + "/admin/withdraw/order_detail/" +withdrawId;
        }else{
            hippo.warning(response.message);
        }
    });
}

WithdrawOrder.closeModifyOrderStatusWindow = function () {
    $('.close',window.parent.document).trigger("click");
}

WithdrawOrder.export = function () {
    $('#searchForm').attr("action",getWebPath() + "/admin/withdraw/export");
    $('#searchForm').submit();
}

WithdrawOrder.exportBatchWithdrawOrder = function () {
    $('#searchForm').attr("action",getWebPath() + "/admin/withdraw/export_batch_withdraw");
    $('#searchForm').submit();
}


WithdrawOrder.search = function () {
    $('#searchForm').attr("action",getWebPath() + "/admin/withdraw/batch_withdraw_list");
    $('#searchForm').submit();
}
WithdrawOrder.searchWithdraw = function () {
    $('#searchForm').attr("action",getWebPath() + "/admin/withdraw/manual_withdraw_list");
    $('#searchForm').submit();
}