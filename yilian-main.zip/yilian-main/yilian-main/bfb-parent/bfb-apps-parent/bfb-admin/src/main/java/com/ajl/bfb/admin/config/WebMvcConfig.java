package com.ajl.bfb.admin.config;

import com.ajl.bfb.admin.AdminConstants;
import com.ajl.bfb.admin.common.web.AdminSessionKey;
import com.ajl.bfb.admin.common.web.CurrentMenuInterceptor;
import com.ajl.bfb.admin.common.web.freemarker.Fee2yuanMethod;
import com.ajl.bfb.admin.common.web.freemarker.PercentMethod;
import com.ajl.bfb.admin.sys.interceptor.AdminOperationLogInterceptor;
import com.ajl.bfb.admin.sys.interceptor.SecondPwdVerifierInterceptor;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.alibaba.fastjson.support.config.FastJsonConfig;
import com.alibaba.fastjson.support.spring.FastJsonHttpMessageConverter;
import com.hippo.framework.auth.admin.web.support.DefaultAuthenticationInterceptor;
import com.hippo.framework.web.BasePathInterceptor;
import com.hippo.framework.web.converter.DateConverter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;
import org.springframework.core.convert.support.GenericConversionService;
import org.springframework.http.MediaType;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.web.bind.support.ConfigurableWebBindingInitializer;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerAdapter;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by admin on 2018-02-07 0007.
 */
@SuppressWarnings("ALL")
@Configuration
public class WebMvcConfig extends WebMvcConfigurerAdapter {
    //修改密码
    private static final String UPDATE_PWD  = "/admin/merchant/update_password/*";
    //手动冻结资金
    private static final String CREATE_FUND_FREEZE = "/admin/fundFreeze/create_merchant_fundfreeze";
    //手动解冻资金
    private static final String FUND_UNFREEZE = "/admin/fundFreeze/unfreeze_merchant_fund";
    //手工加减款
    private static final String CREATE_MANUL_ORDER = "/admin/manual_order/create";
    //手工订单审核
    private static final String AUDIT_MANUL_ORDER = "/admin/manual_order/audit";
    //手工订单处理
    private static final String PROCESS_MANUL_ORDER = "/admin/manual_order/process";
    //代付批量导入
//    private static final String IMPORT_WITHDRAW_ORDER = "/merchant_admin/withdraw/import_order";
    //充值审核
    private static final String MANUAL_RECHARGE_AUDIT = "/admin/manual_payment_order/audit";
    //充值收款确认
    private static final String MANUAL_RECHARGE_CONFIRM = "/admin/manual_payment_order/confirm";
    //上游中转充值收款确认
    private static final String TRANSFER_PAYMENT_CONFIRM = "/admin/transfer_payment/confirmPayment/*";




    @Autowired
    private RequestMappingHandlerAdapter handlerAdapter;
    @Autowired
    private freemarker.template.Configuration freeConfiguration;
    @Autowired
    private  SecondPwdVerifierInterceptor secondPwdVerifierInterceptor;
    @Autowired
    private AdminOperationLogInterceptor adminOperationLogInterceptor;


    @Value("${recharge_bill.upload.path}")
    private String uploadPath;
    @Value("${recharge_bill.upload.virtual_path}")
    private String virtualPath;


    @Value("${api_doc.path}")
    private String apiDocPath;
    @Value("${api_doc.virtual_path}")
    private String apiDocVirtualPath;

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        //给静态资源目录，访问的时候加个前缀 static 如 http://域名/static/......
        registry.addResourceHandler("/static/**")
                .addResourceLocations("classpath:/static/");

        //配置虚拟路径，handler为前台访问的虚拟目录，locations为files相对应的本地物理路径
        registry.addResourceHandler(virtualPath+"**").addResourceLocations("file:"+uploadPath);
        registry.addResourceHandler(apiDocVirtualPath+"**").addResourceLocations("file:"+apiDocPath);
    }


    /**
     * 配置拦截器
     * @author lance
     * @param registry
     */
    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(new BasePathInterceptor()).addPathPatterns("/**");
        //标识当前菜单的状态
        registry.addInterceptor(new CurrentMenuInterceptor()).addPathPatterns("/admin/**");
        //后台权限控制
        registry.addInterceptor(createManagerAuthInterceptor()).addPathPatterns("/admin/**")
                .excludePathPatterns("/admin/sys/**")
                .excludePathPatterns("/admin/error/**");
        registry.addInterceptor(secondPwdVerifierInterceptor)
                .addPathPatterns(UPDATE_PWD)
                .addPathPatterns(CREATE_FUND_FREEZE)
                .addPathPatterns(FUND_UNFREEZE)
                .addPathPatterns(CREATE_MANUL_ORDER)
                .addPathPatterns(AUDIT_MANUL_ORDER)
                .addPathPatterns(PROCESS_MANUL_ORDER)
//                .addPathPatterns(IMPORT_WITHDRAW_ORDER)
                .addPathPatterns(MANUAL_RECHARGE_AUDIT)
                .addPathPatterns(MANUAL_RECHARGE_CONFIRM)
                .addPathPatterns(TRANSFER_PAYMENT_CONFIRM);
        registry.addInterceptor(adminOperationLogInterceptor)
                .addPathPatterns("/admin/**")//操作日志拦截
                .addPathPatterns("/admin/sys/login");  //登录
    }

    private DefaultAuthenticationInterceptor createManagerAuthInterceptor() {
        DefaultAuthenticationInterceptor ai = new DefaultAuthenticationInterceptor();
        ai.setLoginUri(AdminConstants.LOGIN_URI);
        ai.setLoginUserSessionKey(AdminSessionKey.LOGIN_USER);
        ai.setNoPermissionRedirectUri(AdminConstants.NO_PERMISSION_URI);
        ai.setUserAuthoritiesSessionKey(AdminSessionKey.USER_AUTHORITY);
        return ai;
    }


    @Override
    public void addViewControllers(ViewControllerRegistry registry) {
        registry.addViewController("/sftlogin").setViewName("forward:/admin/sys/to-login");
        registry.setOrder(Ordered.HIGHEST_PRECEDENCE);
        super.addViewControllers(registry);
    }

    /**
     * 利用fastjson替换掉jackson，且解决中文乱码问题
     * @param converters
     */
    @Override
    public void configureMessageConverters(List<HttpMessageConverter<?>> converters) {
        FastJsonHttpMessageConverter fastConverter = new FastJsonHttpMessageConverter();
        FastJsonConfig fastJsonConfig = new FastJsonConfig();
        fastJsonConfig.setSerializerFeatures(SerializerFeature.PrettyFormat,
                SerializerFeature.DisableCircularReferenceDetect,//禁止循环引用
                SerializerFeature.WriteMapNullValue);//忽略null属性

        //处理中文乱码问题
        List<MediaType> fastMediaTypes = new ArrayList<>();
        fastMediaTypes.add(MediaType.APPLICATION_JSON_UTF8);
        fastConverter.setSupportedMediaTypes(fastMediaTypes);
        fastConverter.setFastJsonConfig(fastJsonConfig);
        converters.add(fastConverter);
    }

    @PostConstruct
    public void addConversionConfig() {
        //springmvc 转换器
        ConfigurableWebBindingInitializer initializer = (ConfigurableWebBindingInitializer)handlerAdapter.getWebBindingInitializer();
        if (initializer.getConversionService() != null) {
            GenericConversionService genericConversionService = (GenericConversionService)initializer.getConversionService();
            //注册日期转换器
            genericConversionService.addConverter(new DateConverter());
        }
        //freemarker增加自定义函数
        freeConfiguration.setSharedVariable("fee2yuan", new Fee2yuanMethod());
        freeConfiguration.setSharedVariable("topercent", new PercentMethod());
    }





}
