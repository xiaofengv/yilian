var ChannelAccountPayType = {};

$(function () {
    $(".rate_cls").each(function (index, el) {
        hippo.limitMoney(el.id);
    });


});

ChannelAccountPayType.updateRate = function (id) {
    var rate = $('#rate_' + id).val();
    var rateByTime = $('#rate_by_time_' + id).val();
    var introducerRate = $('#introducer_rate_' + id).val();
    $.ajax({
        type : "POST", //提交方式
        url : getWebPath() + "/admin/channel_account/update_rate/" + id,//路径
        data : {
            rate: rate,
            rateByTime:rateByTime,
            introducerRate:introducerRate
        },
        success : function(result) {//返回数据根据结果进行相应的处理
            hippo.msg(result.message);
        }
    });

}

ChannelAccountPayType.updateQuota = function (id) {
    var isWholeHundred = $('#isWholeHundred_' + id).val();
    var mixAmount = $('#mixAmount_' + id).val();
    var maxAmount = $('#maxAmount_' + id).val();
    var fixedAmount = $('#fixed_amount_' + id).val();
    if (isWholeHundred == "N"){
        var reg = /^[0-9,]*$/;
        if (!reg.test(fixedAmount)){
            alert("限额输入非法");
            return false;
        }
        if (fixedAmount.charAt(0) == ',' || fixedAmount.charAt(fixedAmount.length-1) == ',' ){
            alert("限额第一位或最后一位不能是,");
            return false;
        }
    }
    $.ajax({
        type : "POST", //提交方式
        url : getWebPath() + "/admin/channel_account/update_quota/" + id,//路径
        data : {
            isWholeHundred:isWholeHundred,
            minAmount: mixAmount,
            maxAmount: maxAmount,
            fixedAmount:fixedAmount
        },
        success : function(result) {//返回数据根据结果进行相应的处理
            hippo.msg(result.message);
        }
    });

}
ChannelAccountPayType.func = function (id) {
    var isWholeHundred = $('#isWholeHundred_' + id).val();
    if (isWholeHundred == 'N'){
        $('#mixAmount_td_' + id).hide();
        $('#maxAmount_td_' + id).hide();
        $('#fixed_amount_td_' + id).show();
    }else{
        $('#mixAmount_td_' + id).show();
        $('#maxAmount_td_' + id).show();
        $('#fixed_amount_td_' + id).hide();
    }
}