package com.ajl.bfb.admin.sys.exception;

public class SecondPwdVerifierException extends Exception {

    public SecondPwdVerifierException() {
    }

    public SecondPwdVerifierException(String message) {
        super(message);
    }

    public SecondPwdVerifierException(String message, Throwable cause) {
        super(message, cause);
    }

    public SecondPwdVerifierException(Throwable cause) {
        super(cause);
    }

    public SecondPwdVerifierException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
