package com.ajl.bfb.admin.report.controller;

import com.ajl.bfb.pay.IRecentPaymentOrderService;
import com.ajl.bfb.repo.channel.model.Channel;
import com.ajl.bfb.repo.channel.model.ChannelQuery;
import com.ajl.bfb.repo.channel.service.IChannelService;
import com.ajl.bfb.repo.payment.model.PayType;
import com.ajl.bfb.repo.payment.service.IPayTypeService;
import com.hippo.framework.auth.admin.OperationAuth;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;
import java.util.Map;


@Controller
@RequestMapping("/admin/report")
public class OrderSuccessRateController {

    @Autowired
    IRecentPaymentOrderService recentPaymentOrderService;

    @Autowired
    IChannelService channelService;

    @Autowired
    IPayTypeService payTypeService;

    @RequestMapping("/channel_success_rate")
    @OperationAuth(name = "通道成功率统计", authCode = "platform.channel_success_rate", group = "平台报表")
    public String successRateByChannel(String channelCode, Model model){
        List<Channel> channels= channelService.findChannels(new ChannelQuery());
        model.addAttribute("channels",channels);

        List<PayType> payTypes = payTypeService.getAll();
        model.addAttribute("payTypes",payTypes);

        model.addAttribute("channelCode",channelCode);
        Map<String,Map<String,Map<String,Map<String,Long>>>> statValue = recentPaymentOrderService.getSuccessRateByChannel();
        channelCode = channelCode==null?"ALL":channelCode;
        Map<String,Map<String,Map<String,Long>>> statrsult = statValue==null?null:statValue.get(channelCode);
        model.addAttribute("statValue",statrsult);
        return "/admin/report/channel_success_rate";
    }


    @RequestMapping("/paytype_success_rate")
    @OperationAuth(name = "收款方式成功率统计", authCode = "platform.paytype_success_rate", group = "平台报表")
    public String successRateByPayType(String payType, Model model){
        List<Channel> channels= channelService.findChannels(new ChannelQuery());
        model.addAttribute("channels",channels);

        List<PayType> payTypes = payTypeService.getAll();
        model.addAttribute("payTypes",payTypes);

        model.addAttribute("paytype",payType);
        Map<String,Map<String,Map<String,Map<String,Long>>>> statValue = recentPaymentOrderService.getSuccessRateByPayType();
        payType = payType==null?"ALL":payType;
        Map<String,Map<String,Map<String,Long>>> statrsult = statValue==null?null:statValue.get(payType);
        model.addAttribute("statValue",statrsult);
        return "/admin/report/paytype_success_rate";
    }
}
