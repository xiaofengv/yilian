package com.ajl.bfb.upstreamadmin.config;

import com.ajl.bfb.admin.common.web.CurrentMenuInterceptor;
import com.ajl.bfb.merchantadmin.MerchantAdminConstants;
import com.ajl.bfb.merchantadmin.common.web.MerchantAdminSessionKey;
import com.ajl.bfb.merchantadmin.sys.interceptor.MerchantSecondPwdVerifierInterceptor;
import com.hippo.framework.auth.admin.web.support.DefaultAuthenticationInterceptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

/**
 * Created by admin on 2018-02-07 0007.
 */
@SuppressWarnings("ALL")
@Configuration
public class UpstreamWebMvcConfig extends WebMvcConfigurerAdapter {
    @Autowired
    MerchantSecondPwdVerifierInterceptor merchantSecondPwdVerifierInterceptor;

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(new CurrentMenuInterceptor()).addPathPatterns("/upstream_admin/**");
        registry.addInterceptor(createManagerAuthInterceptor()).addPathPatterns("/upstream_admin/**")
                .excludePathPatterns("/upstream_admin/sys/**")
                .excludePathPatterns("/upstream_admin/error/**");
        registry.addInterceptor(merchantSecondPwdVerifierInterceptor)
                .addPathPatterns("/upstream_admin/withdraw/import_order");
    }

    private DefaultAuthenticationInterceptor createManagerAuthInterceptor() {
        DefaultAuthenticationInterceptor ai = new DefaultAuthenticationInterceptor();
        ai.setLoginUri("/upstream_admin/sys/to-login");
        ai.setLoginUserSessionKey(MerchantAdminSessionKey.LOGIN_USER);
        ai.setNoPermissionRedirectUri(MerchantAdminConstants.NO_PERMISSION_URI);
//        ai.setUserAuthoritiesSessionKey(MerchantAdminSessionKey.USER_AUTHORITY);
        return ai;
    }


    @Override
    public void addViewControllers(ViewControllerRegistry registry) {
        registry.addViewController("/upstream_admin").setViewName("forward:/upstream_admin/sys/to-login");
        registry.setOrder(Ordered.HIGHEST_PRECEDENCE);
        super.addViewControllers(registry);
    }




}
