function login() {
    //校验
    if ($("#userName").val().trim() == "") {
        hippo.warning("请输入用户名")
        return false;
    }

    if ($("#password").val().trim()  == "") {
        hippo.warning("请输入密码")
        return false;
    }

    if ($("#verifyCode").val().trim()  == "") {
        hippo.warning("请输入验证码")
        return false;
    }

    //提交表单
    $("#loginForm").ajaxSubmit( {
        url: getWebPath() + '/merchant_admin/sys/login',
        type: 'POST',
        dataType: 'json',
        success: function (data) {
            debugger
            if (data.statusCode == 'SUCCESS') {//进主页
                new $.zui.Messager(data.message, {
                    type: 'success' // 定义颜色主题
                }).show();
                window.location.href = getWebPath() + "/merchant_admin/common/parent_home";
            } else {
                new $.zui.Messager(data.message, {
                    type: 'warning' // 定义颜色主题
                }).show();
                //换验证码
                changeVerifyCode();
            }
        }
        // clearForm: false,//禁止清楚表单
        // resetForm: false //禁止重置表单
    });
}


/**
 * 换一张验证码
 */
function changeVerifyCode() {
    $("#verifyCodeImg").attr("src", $("#verifyCodeImg").attr("src")+ "1");
}