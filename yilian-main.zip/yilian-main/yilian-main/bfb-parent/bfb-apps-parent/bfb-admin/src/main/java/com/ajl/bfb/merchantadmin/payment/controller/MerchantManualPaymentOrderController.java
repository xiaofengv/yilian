package com.ajl.bfb.merchantadmin.payment.controller;

import com.ajl.bfb.admin.manualorder.controller.ManualRechargeOrderController;
import com.ajl.bfb.admin.notice.component.NotifyComponent;
import com.ajl.bfb.common.payment.model.CreatePaymentOrderRequest;
import com.ajl.bfb.core.constants.*;
import com.ajl.bfb.core.exception.ParameterVerificationException;
import com.ajl.bfb.core.util.MoneyUtils;
import com.ajl.bfb.core.util.RateUtils;
import com.ajl.bfb.core.util.SignUtils;
import com.ajl.bfb.merchantadmin.common.web.MerchantAdminSessionKey;
import com.ajl.bfb.merchantadmin.common.web.MerchantAdminUserUtils;
import com.ajl.bfb.merchantadmin.payment.vo.CreatePaymentOrderRequestVO;
import com.ajl.bfb.merchantadmin.payment.vo.CreatePaymentOrderResponseVO;
import com.ajl.bfb.merchantadmin.payment.vo.FormParamVO;
import com.ajl.bfb.pay.IPayLogService;
import com.ajl.bfb.pay.payment.IPaymentFacade;
import com.ajl.bfb.pay.payment.IPaymentService;
import com.ajl.bfb.pay.payment.model.CreatePaymentOrderResult;
import com.ajl.bfb.repo.channel.service.IGlobalSettingService;
import com.ajl.bfb.repo.manualorder.model.ManualOrder;
import com.ajl.bfb.repo.manualorder.model.ManualOrderQueryParam;
import com.ajl.bfb.repo.manualorder.service.ManualOrderService;
import com.ajl.bfb.repo.merchant.model.Merchant;
import com.ajl.bfb.repo.merchant.model.MerchantPayType;
import com.ajl.bfb.repo.merchant.service.IMerchantPayTypeService;
import com.ajl.bfb.repo.merchant.service.IMerchantService;
import com.ajl.bfb.repo.payment.model.PayType;
import com.ajl.bfb.repo.payment.service.IPayTypeService;
import com.ajl.bfb.repo.payment.service.IPaymentOrderService;
import com.hippo.framework.util.JsonUtils;
import com.hippo.framework.util.NumberUtils;
import com.hippo.framework.util.net.HttpUtils;
import com.hippo.framework.util.validation.ValidationUtils;
import com.hippo.framework.web.ResponseCode;
import com.hippo.framework.web.ResponseResult;
import com.hippo.framework.web.util.UploadUtils;
import com.hippo.framework.web.util.WebPathUtils;
import org.apache.commons.lang3.EnumUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.math.BigDecimal;
import java.text.ParseException;
import java.util.*;

import static com.ajl.bfb.core.util.MoneyUtils.yuan2fee;


@Controller
@RequestMapping(value="/merchant_admin/manual_payment_order")
public class MerchantManualPaymentOrderController {

    @Autowired
    private IPaymentOrderService paymentOrderService;
    @Autowired
    private ManualRechargeOrderController delegateController;
    @Autowired
    private ManualOrderService manualOrderService;
    @Value("${recharge_bill.upload.path}")
    private String uploadPath;
    @Value("${recharge_bill.upload.virtual_path}")
    private String virtualPath;
    @Autowired
    private NotifyComponent notifyComponent;
    @Autowired
    IGlobalSettingService globalSettingService;

    @Autowired
    IMerchantService merchantService;

    @Autowired
    private IPaymentService paymentService;

    @Autowired
    private IPaymentFacade paymentFacadeService;

    @Autowired
    private IPayLogService payLogService;

    @Autowired
    private IPayTypeService payTypeService;

    @Autowired
    private IMerchantPayTypeService merchantPayTypeService;

    @RequestMapping("/list")

    public String getManualOrderList(ManualOrderQueryParam param, Model model,HttpServletRequest request){

        String merchantAcc = MerchantAdminUserUtils.getLoginMerchantNo(request);
        Merchant merchant = MerchantAdminUserUtils.getLoginMerchant(request);
        model.addAttribute("userType",merchant.getUserType());
        param.setBizType(ManualBizTypeEnum.RECHARGE.name());
        param.setMerchantAcc(merchantAcc);
        PayType b2cPayType=payTypeService.findByCode(PaymentTypeEnum.B2C_RECHARGE);
        PayType manualPayType=payTypeService.findByCode(PaymentTypeEnum.MANUAL_RECHARGE);
        model.addAttribute("b2cPayType",b2cPayType);
        model.addAttribute("manualPayType",manualPayType);
        delegateController.manualRechargeOrderList(param, model);


        return "/merchant_admin/manual_payment_order/list";
    }



    @RequestMapping("/to_recharge")
    public String toRecharge(Model model,HttpServletRequest request){
        Integer merchantId = ((Merchant) request.getSession().getAttribute(MerchantAdminSessionKey.LOGIN_MERCHANT)).getId();
        MerchantPayType merchantPayType = merchantPayTypeService.getMerchantPayType(merchantId, PaymentTypeEnum.MANUAL_RECHARGE);
        int rechargeCost = globalSettingService.getRechargeCost();
        if (merchantPayType.getRate().intValue() > 0) {
            rechargeCost = merchantPayType.getRate().intValue();
        }
        model.addAttribute("rechargeCost",rechargeCost);
        return "/merchant_admin/manual_payment_order/create";
    }

    @RequestMapping("/to_recharge_b2c")
    public String toRechargeB2C(Model model,HttpServletRequest request){

        PayType b2cPayType=payTypeService.findByCode(PaymentTypeEnum.B2C_RECHARGE);
        int rechargeCost = b2cPayType.getMerchantDefaultRate();
        model.addAttribute("rechargeCost",rechargeCost);
        return "/merchant_admin/manual_payment_order/createrechargeb2c";
    }



    @RequestMapping("/b2c_recharge")
    @ResponseBody
    public ResponseResult rechargeB2C(HttpServletRequest request, ManualOrder order, Model model)throws IOException {
        order.setTarget(TargetTypeEnum.MERCHANT.name());
        order.setBizType(ManualBizTypeEnum.RECHARGE.name());


        CreatePaymentOrderRequestVO createPaymentOrderVO=getCreatePaymentOrderVO(request,order);
        Merchant merchant = preCheck(createPaymentOrderVO);
        final String secretKey = merchant.getSecretKey();
        final String mchId = createPaymentOrderVO.getMerchantNo();
        final String paymentType = createPaymentOrderVO.getPaymentType();
        final String clientIp = HttpUtils.getRemoteAddr(request);

        String serverPath = WebPathUtils.getWebBasePath(request);
        CreatePaymentOrderRequest orderRequest = createRequestParam(createPaymentOrderVO, clientIp,serverPath);
        CreatePaymentOrderResponseVO responseVO = null;

        CreatePaymentOrderResult orderResult=null;
        try {
            orderResult = paymentFacadeService.createOrderRecharge(orderRequest);
            responseVO = createReponse(secretKey, orderResult);

            payLogService.saveMerchantRequestLog(orderResult.getPlatformOrderNo(),
                    JsonUtils.obj2String(createPaymentOrderVO),
                    JsonUtils.obj2String(responseVO));
        } catch (Exception e) {
            e.printStackTrace();
            return new ResponseResult(ResponseCode.FAIL, "创建失败"+e.getMessage(), null);
        }
        return new ResponseResult(ResponseCode.SUCCESS, "创建成功！", null);


    }


    public CreatePaymentOrderRequestVO getCreatePaymentOrderVO(HttpServletRequest request,ManualOrder order){
        CreatePaymentOrderRequestVO param = new CreatePaymentOrderRequestVO();
        param.setPaymentType(PaymentTypeEnum.B2C_RECHARGE.name());
        param.setMchOrderNo(System.currentTimeMillis() + "");
        param.setGoodsName("B2C充值");
        param.setAmount(MoneyUtils.yuan2fee(order.getAmount())+"");
        param.setClientIp("127.0.0.9");
        param.setFrontReturnUrl("http://www.baidu.com");
        param.setNotifyUrl("http://www.baidu.com");
        param.setBuyerId("123");
        param.setBuyerName("张三");
        param.setGoodsInfo("B2C充值");
        param.setGoodsNum("1");
        param.setRemark(order.getRemark());
        param.setBuyerContact("13166666666");
        param.setOrderTime(DateFormatUtils.format(new Date(), "yyyyMMddHHmmss"));
        param.setAlipayAccId(1);
        Merchant merchant = MerchantAdminUserUtils.getLoginMerchant(request);
        param.setMerchantNo(merchant.getMerchantNo());
        param.setNonceStr(System.currentTimeMillis() + "");
        Merchant mch = merchantService.findByMerchantNo(param.getMerchantNo());
        String sign = SignUtils.createSign(mch.getSecretKey(), param);
        param.setSign(sign);

        return param;
    }


    @RequestMapping("/recharge")
    @ResponseBody

    public ResponseResult createManualOrder(HttpServletRequest request, ManualOrder order, Model model) throws IOException {
        order.setTarget(TargetTypeEnum.MERCHANT.name());
        order.setBizType(ManualBizTypeEnum.RECHARGE.name());
        String error = ValidationUtils.validate(order);
        if(StringUtils.isNotEmpty(error)){
            return new ResponseResult(ResponseCode.FAIL, "创建失败！"+error, null);
        }
        initManualOrder(request, order);

        manualOrderService.createManualPaymentOrder(order);

        notifyComponent.notifyByAuthority("manual_recharge.audit","您有一条新的充值订单待受理！");
        return new ResponseResult(ResponseCode.SUCCESS, "创建成功！", null);
    }



    @RequestMapping("/to_process/{id}")
    public String toProcessManualOrder(@PathVariable("id") Integer id, Model model){
        ManualOrder manualOrder = manualOrderService.selectByPrimaryKey(id);
        model.addAttribute("manualOrder",manualOrder);
        if(manualOrder.getPlatformOrderNo()!=null&&manualOrder.getPlatformOrderNo().length()>0) {
            String formParam = manualOrder.getForm_param_json();
            Map<String, String> jsonMap = JsonUtils.json2map(formParam);
            String formAction = jsonMap.get(PayParameterEnum.FORM_ACTION.name());
            jsonMap.remove(PayParameterEnum.FORM_ACTION.name());

            List<FormParamVO> params = new ArrayList<>();
            Set<Map.Entry<String, String>> entries = jsonMap.entrySet();
            for (Map.Entry<String, String> entry : entries) {
                FormParamVO vo = new FormParamVO();
                vo.setKey(entry.getKey());
                vo.setVal(entry.getValue());
                params.add(vo);
            }
            model.addAttribute("formParams", params);
            model.addAttribute("formAction", formAction);



            return "/merchant_admin/manual_payment_order/common_form_jump";
        }
        return "/merchant_admin/manual_payment_order/process";
    }



    @RequestMapping("/process_recharge")
    @ResponseBody
    public ResponseResult processRecharge(Integer id, String rechargeStatus, MultipartFile file, HttpServletRequest request) throws Exception {

        ManualOrder manualOrder = manualOrderService.selectByPrimaryKey(id);
        if(!OrderStatusEnum.SUCCESS.name().equals(manualOrder.getAuditStatus())){
            return new ResponseResult(ResponseCode.FAIL, "订单没有审核通过！", null);
        }
        if(!ManualOrder.RechargeStatus.PROCESSING.equals(manualOrder.getRechargeStatus())){
            return new ResponseResult(ResponseCode.FAIL, "订单已经被处理！", null);
        }
        if(!EnumUtils.isValidEnum(ManualOrder.RechargeStatus.class,rechargeStatus)){
            return new ResponseResult(ResponseCode.FAIL, "状态错误！", null);
        }
        String billUrl = "";
        String orderStatus = null;
        if(ManualOrder.RechargeStatus.RECHARGE.name().equals(rechargeStatus)){
            String fileName = UploadUtils.importFile(file,uploadPath);
            billUrl = virtualPath+fileName;
        }else if(ManualOrder.RechargeStatus.CANCEL.name().equals(rechargeStatus)){
            orderStatus = OrderStatusEnum.FAIL.name();
        }
        manualOrderService.processManualPaymentOrder(id,rechargeStatus,orderStatus,billUrl);

        notifyComponent.notifyByAuthority("manual_recharge.confirm","您有一条新的充值订单待确认！");
        return new ResponseResult(ResponseCode.SUCCESS, "处理完成！", null);
    }

    private void initManualOrder(HttpServletRequest request, ManualOrder order){
        Merchant merchant = MerchantAdminUserUtils.getLoginMerchant(request);
        order.setMerchantId(merchant.getId());
        order.setChannelAccountId(0);
        order.setAmount(yuan2fee(order.getAmount()));

        int rechargeCostRate = globalSettingService.getRechargeCost();
        BigDecimal bigDecimal = RateUtils.rate2percent(rechargeCostRate);
        BigDecimal mchCost = order.getAmount().multiply(bigDecimal).divide(new BigDecimal(100));

        order.setMerchantCost(mchCost);
        order.setStatus(OrderStatusEnum.PROCESSING.name());
        order.setAuditStatus(AuditStatusEnum.AUDITING.name());
        order.setRechargeStatus(ManualOrder.RechargeStatus.PROCESSING);
        order.setCreateTime(new Date());
    }

    private void initB2COrder(HttpServletRequest request, ManualOrder order){
        Merchant merchant = MerchantAdminUserUtils.getLoginMerchant(request);
        order.setMerchantId(merchant.getId());
        order.setChannelAccountId(0);
        order.setAmount(yuan2fee(order.getAmount()));
        order.setMerchantCost(yuan2fee(order.getMerchantCost()));
        order.setStatus(OrderStatusEnum.PROCESSING.name());
        order.setAuditStatus(AuditStatusEnum.SUCCESS.name());
        order.setRechargeStatus(ManualOrder.RechargeStatus.PROCESSING);
        order.setCreateTime(new Date());
    }

    private Merchant preCheck(CreatePaymentOrderRequestVO createPaymentOrderVO) throws ParameterVerificationException {
        String error = ValidationUtils.validate(createPaymentOrderVO);
        if (error != null) {
            throw new ParameterVerificationException("参数校验失败." + error);
        }
        if(!NumberUtils.isInteger(createPaymentOrderVO.getAmount())) {
            throw new ParameterVerificationException("参数校验失败.金额格式非法");
        }
        if (Integer.valueOf(createPaymentOrderVO.getAmount()) <= 0) {
            throw new ParameterVerificationException("参数校验失败.金额必须>0");
        }

        checkOrderTimeFormat(createPaymentOrderVO.getOrderTime());
        PaymentTypeEnum paymentType = EnumUtils.getEnum(PaymentTypeEnum.class, createPaymentOrderVO.getPaymentType());
        if (paymentType == null) {
            throw new ParameterVerificationException("参数校验失败.无法识别支付类型:" + createPaymentOrderVO.getPaymentType());
        }

        final String mchId = createPaymentOrderVO.getMerchantNo();
        final String sign = createPaymentOrderVO.getSign();

        Merchant merchant = paymentService.getMerchant(mchId);
        if (merchant == null) {
            throw new ParameterVerificationException("该商户不存在");
        }
        if (createPaymentOrderVO.getGoodsNum()!=null) {
            if(!NumberUtils.isInteger(createPaymentOrderVO.getGoodsNum())) {
                throw new ParameterVerificationException("参数校验失败.商品数量非法");
            }
        }


        if (StringUtils.isNotBlank(createPaymentOrderVO.getBankCode())) {
            BankCodeEnum bankCode = BankCodeEnum.valueOfCode(createPaymentOrderVO.getBankCode());
            if (bankCode == null) {
                throw new ParameterVerificationException("无法识别的银行编码");
            }
        }


        boolean checkSignResult = SignUtils.checkSign(merchant.getSecretKey(), createPaymentOrderVO, sign);
        if (!checkSignResult) {
            throw new ParameterVerificationException("签名校验失败");
        }
        return merchant;
    }

    private CreatePaymentOrderRequest createRequestParam(CreatePaymentOrderRequestVO payOrder,String clientIp, String serverPath) {
        CreatePaymentOrderRequest orderRequest = new CreatePaymentOrderRequest();
        orderRequest.setMerchantNo(payOrder.getMerchantNo());
        orderRequest.setPaymentType(PaymentTypeEnum.valueOf(payOrder.getPaymentType()));
        orderRequest.setOrderTime(new Date());
        orderRequest.setGoodsName(payOrder.getGoodsName());
        orderRequest.setAmount(Integer.valueOf(payOrder.getAmount()));
        orderRequest.setClientIp(clientIp);
        orderRequest.setFrontReturnUrl(payOrder.getFrontReturnUrl());
        orderRequest.setNotifyUrl(payOrder.getNotifyUrl());
        orderRequest.setMerchantOrderNo(payOrder.getMchOrderNo());
        orderRequest.setBuyerId(payOrder.getBuyerId());
        orderRequest.setBuyerName(payOrder.getBuyerName());
        orderRequest.setGoodsInfo(payOrder.getGoodsInfo());
        orderRequest.setAlipayAccId(payOrder.getAlipayAccId());
        if (StringUtils.isNotBlank(payOrder.getGoodsNum())) {
            orderRequest.setGoodsNum(Integer.valueOf(payOrder.getGoodsNum()));
        } else {
            orderRequest.setGoodsNum(1);
        }
        orderRequest.setRemark(payOrder.getRemark());
        orderRequest.setPlatformServerPath(serverPath);
        orderRequest.setBuyerContact(payOrder.getBuyerContact());
        if (StringUtils.isNotBlank(payOrder.getBankCode())) {
            orderRequest.setBankCode(BankCodeEnum.valueOfCode(payOrder.getBankCode()));
        }
        return orderRequest;
    }
    private CreatePaymentOrderResponseVO createReponse(String secretKey, CreatePaymentOrderResult orderResult) {
        CreatePaymentOrderResponseVO rsp = new CreatePaymentOrderResponseVO();
        rsp.setReturnCode(ReturnCodeEnum.SUCCESS.name());
        rsp.setReturnMsg("请求成功");

        rsp.setMchOrderNo(orderResult.getMerchantOrderNo());
        rsp.setPlatformOrderNo(orderResult.getPlatformOrderNo());
        rsp.setResultCode(orderResult.getResultCode().name());
        rsp.setResultDesc(orderResult.getResultDesc());
        rsp.setPayUrl(orderResult.getPayUrl());
        rsp.setUrlType(orderResult.getUrlType().name());

        rsp.setNonceStr(System.currentTimeMillis() + "");
        rsp.setSign(SignUtils.createSign(secretKey, rsp));
        return rsp;
    }

    public static boolean checkOrderTimeFormat(String timeStr) {
        try {
            DateUtils.parseDate(timeStr, new String[]{CreatePaymentOrderRequestVO.ORDER_TIME_FORMAT});
            return true;
        } catch (ParseException e) {
            throw new ParameterVerificationException("参数校验失败.订单时间格式有误.正确格式:" + CreatePaymentOrderRequestVO.ORDER_TIME_FORMAT);
        }
    }
}
