package com.ajl.bfb.admin.channelaccount.vo;

import com.ajl.bfb.core.constants.BizTypeEnum;
import com.ajl.bfb.core.constants.ReadyStatusEnum;
import com.ajl.bfb.core.constants.WithdrawCostModeEnum;
import com.ajl.bfb.core.util.MoneyUtils;
import com.ajl.bfb.repo.channel.model.ChannelAccount;
import com.ajl.bfb.repo.channel.model.MerchantChannelAccount;
import com.hippo.framework.core.enums.OpenStatusEnum;

import java.util.List;
import java.util.stream.Collectors;


public class ChannelAccountVO extends ChannelAccount {

    private String channelName;

    private Long dayMaxAmountYuan;

    private Long incomeTotalMaxYuan;
    /**
     * 余额
     */
    private Long cashBalance;

    private Integer withdrawRate;

    public String getWithdrawCostModeStr() {
        return WithdrawCostModeEnum.valueOf(getWithdrawCostMode()).getDesc();
    }



    public String getMerchantListStr() {
        List<MerchantChannelAccount> list = getMerchantChannelAccounts();
        if (list == null || list.isEmpty()) {
            return "无";
        }
        return list.stream().map(mac -> mac.getMerchant().getMerchantName()+ "[" +BizTypeEnum.valueOf(mac.getBizType()).getDesc() + "]" )
                .sorted().collect(Collectors.joining("</br>"));
    }

    public String getIsLowAreaStr() {
        return OpenStatusEnum.valueOf(getIsLowArea()).getDesc();
    }

    public String getStatusStr() {
        return ReadyStatusEnum.valueOf(getStatus()).getDesc();
    }

    public String getIsRateUseChannelCfgStr() {
        return OpenStatusEnum.valueOf(getIsRateUseChannelCfg()).getDesc();
    }

    public Long getDayMaxAmountYuan() {
        return dayMaxAmountYuan;
    }

    public void setDayMaxAmountYuan(Long dayMaxAmountYuan) {
        this.dayMaxAmountYuan = dayMaxAmountYuan;
        setDayMaxAmount(MoneyUtils.yuan2fee(dayMaxAmountYuan).longValue());
    }

    public Long getIncomeTotalMaxYuan() {
        return incomeTotalMaxYuan;
    }

    public void setIncomeTotalMaxYuan(Long incomeTotalMaxYuan) {
        this.incomeTotalMaxYuan = incomeTotalMaxYuan;
        setIncomeTotalMax(MoneyUtils.yuan2fee(incomeTotalMaxYuan).longValue());
    }

    public String getChannelName() {
        return channelName;
    }

    public void setChannelName(String channelName) {
        this.channelName = channelName;
    }

    public Long getCashBalance() {
        return cashBalance;
    }

    public void setCashBalance(Long cashBalance) {
        this.cashBalance = cashBalance;
    }

    public Integer getWithdrawRate() {
        return withdrawRate;
    }

    public void setWithdrawRate(Integer withdrawRate) {
        this.withdrawRate = withdrawRate;
    }
}
