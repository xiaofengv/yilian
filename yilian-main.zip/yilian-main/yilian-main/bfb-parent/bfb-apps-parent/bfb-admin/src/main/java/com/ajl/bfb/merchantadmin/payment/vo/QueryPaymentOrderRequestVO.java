package com.ajl.bfb.merchantadmin.payment.vo;



public class QueryPaymentOrderRequestVO extends BaseRequestVO {

    private String mchOrderNo;

    public String getMchOrderNo() {
        return mchOrderNo;
    }

    public void setMchOrderNo(String mchOrderNo) {
        this.mchOrderNo = mchOrderNo;
    }
}
