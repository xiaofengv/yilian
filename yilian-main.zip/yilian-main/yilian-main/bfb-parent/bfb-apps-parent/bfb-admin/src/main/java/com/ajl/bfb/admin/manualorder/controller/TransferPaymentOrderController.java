package com.ajl.bfb.admin.manualorder.controller;

import com.ajl.bfb.admin.channelaccount.controller.ChannelAccountController;
import com.ajl.bfb.admin.channelaccount.util.ChannelAccountViewUtils;
import com.ajl.bfb.admin.channelaccount.vo.ChannelAccountVO;
import com.ajl.bfb.admin.common.web.AdminUserUtils;
import com.ajl.bfb.admin.manualorder.vo.TransferPaymentOrderVO;
import com.ajl.bfb.admin.notice.component.NotifyComponent;
import com.ajl.bfb.admin.withdraw.vo.WithdrawOrderVO;
import com.ajl.bfb.core.constants.AuditStatusEnum;
import com.ajl.bfb.core.constants.BankCodeEnum;
import com.ajl.bfb.core.constants.MerchantUserTypeEnum;
import com.ajl.bfb.core.constants.OrderStatusEnum;
import com.ajl.bfb.core.util.MoneyUtils;
import com.ajl.bfb.pay.service.ITransferPaymentService;
import com.ajl.bfb.repo.channel.model.Channel;
import com.ajl.bfb.repo.channel.model.ChannelAccount;
import com.ajl.bfb.repo.channel.model.ChannelQuery;
import com.ajl.bfb.repo.channel.service.IChannelAccountService;
import com.ajl.bfb.repo.channel.service.IChannelService;
import com.ajl.bfb.repo.export.service.TransferPaymentOrderExportService;
import com.ajl.bfb.repo.manualorder.model.ManualOrder;
import com.ajl.bfb.repo.manualorder.service.IManualOrderService;
import com.ajl.bfb.repo.merchant.model.Merchant;
import com.ajl.bfb.repo.merchant.model.MerchantAccountDetail;
import com.ajl.bfb.repo.merchant.model.MerchantFindParam;
import com.ajl.bfb.repo.merchant.service.IMerchantAccountService;
import com.ajl.bfb.repo.merchant.service.IMerchantService;
import com.ajl.bfb.repo.payment.TransferPaymentException;
import com.ajl.bfb.repo.payment.model.TransferPaymentOrder;
import com.ajl.bfb.repo.payment.model.TransferPaymentOrderQueryParam;
import com.ajl.bfb.repo.payment.service.ITransferPaymentOrderService;
import com.ajl.bfb.repo.stat.model.OrderStat;
import com.ajl.bfb.repo.withdraw.TransferException;
import com.ajl.bfb.repo.withdraw.model.BankCardQueryParam;
import com.ajl.bfb.repo.withdraw.model.MerchantBankCard;
import com.ajl.bfb.repo.withdraw.model.WithdrawOrder;
import com.ajl.bfb.repo.withdraw.model.WithdrawOrderQueryParam;
import com.ajl.bfb.repo.withdraw.service.IMerchantBankCardService;
import com.ajl.bfb.repo.withdraw.service.ITransferWithdrawOrderService;
import com.ajl.bfb.repo.withdraw.service.IWithdrawOrderService;
import com.github.pagehelper.PageInfo;
import com.hippo.framework.auth.admin.OperationAuth;
import com.hippo.framework.auth.admin.model.SysUser;
import com.hippo.framework.auth.admin.service.ISysUserService;
import com.hippo.framework.operation.log.LogOperation;
import com.hippo.framework.util.validation.AssertUtils;
import com.hippo.framework.util.validation.ValidationUtils;
import com.hippo.framework.web.ResponseCode;
import com.hippo.framework.web.ResponseResult;
import com.hippo.framework.web.util.UploadUtils;
import net.sf.json.JSONArray;
import org.apache.commons.lang3.EnumUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.Assert;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Collectors;

import static com.ajl.bfb.repo.payment.model.TransferPaymentOrder.OrderSourceType.ALIPAY_WITHDRAW;
import static com.ajl.bfb.repo.payment.model.TransferPaymentOrder.OrderSourceType.OTC_WITHDRAW;


@Controller
@RequestMapping("/admin/transfer_payment")
public class TransferPaymentOrderController {
    private static final Logger logger = LogManager.getLogger(TransferPaymentOrderController.class);

    @Autowired
    IWithdrawOrderService withdrawOrderService;
    @Autowired
    IMerchantService merchantService;
    @Autowired
    ITransferPaymentService transferPaymentService;
    @Autowired
    IChannelAccountService channelAccountService;
    @Autowired
    IChannelService channelService;
    @Autowired
    private ITransferPaymentOrderService transferPaymentOrderService;
    @Autowired
    private NotifyComponent notifyComponent;
    @Autowired
    private IManualOrderService manualOrderService;
    @Autowired
    private ISysUserService sysUserService;
    @Autowired
    private ITransferWithdrawOrderService transferWithdrawOrderService;
    @Autowired
    private ChannelAccountController channelAccountController;
    @Autowired
    private TransferPaymentOrderExportService transferPaymentOrderExportService;
    @Autowired
    private IMerchantAccountService merchantAccountService;
    @Autowired
    private IMerchantBankCardService merchantBankCardService;

    @Value("${recharge_bill.upload.path}")
    private String uploadPath;
    @Value("${recharge_bill.upload.virtual_path}")
    private String virtualPath;


    @RequestMapping("/list")
    @OperationAuth(name = "订单查看", authCode = "transfer_payment.list", group = "上游中转充值")
    public String list(TransferPaymentOrderQueryParam param,Model model,HttpServletRequest request){
        try {
            PageInfo<TransferPaymentOrder> page = transferPaymentOrderService.findPage(param);
            page.setList(toVO(page.getList()));
            model.addAttribute("pageInfo", page);
            List<Integer> userIds = page.getList().stream().map(TransferPaymentOrder::getCreateUserId).distinct().collect(Collectors.toList());
            List<Integer> confirmUserIds = page.getList().stream().map(TransferPaymentOrder::getAuditUserid).distinct().collect(Collectors.toList());

            OrderStat orderStat = transferPaymentOrderService.queryOrderTotal(param);
            model.addAttribute("orderStat", orderStat);


            Map<Integer, String> userMap = sysUserService.findAll().stream().filter(sysuser -> userIds.contains(sysuser.getId())).collect(Collectors.toMap(SysUser::getId, sysuser -> sysuser.getUserName()));
            model.addAttribute("userMap", userMap);

            Map<Integer, String> confirmUserMap = sysUserService.findAll().stream().filter(sysuser -> userIds.contains(sysuser.getId())).collect(Collectors.toMap(SysUser::getId, sysuser -> sysuser.getUserName()));
            model.addAttribute("userMap", userMap);

            model.addAttribute("queryParam", param);
            model.addAttribute("auditStatusList", AuditStatusEnum.values());
            model.addAttribute("orderSourceList", TransferPaymentOrder.OrderSourceType.values());
            SysUser currentUser = AdminUserUtils.getCurrentLoginUser(request);
            model.addAttribute("currenSysUserId", currentUser.getId());


            List<ChannelAccount> channelAccounts = channelAccountService.findAllChannelAccounts(null);
            Map<Integer, String> channelAccoutMap = channelAccounts.stream().collect(Collectors.toMap(ChannelAccount::getId, ChannelAccount::getName));
            model.addAttribute("channelAccoutMap", channelAccoutMap);

            List<ChannelAccountVO> channelAccountVOS = toAccountVO(channelAccounts);
            Map<String, List<ChannelAccountVO>> channelVOMap = channelAccountVOS.stream().collect(Collectors.groupingBy(channelAccountVO -> channelAccountVO.getChannelName()));
            model.addAttribute("channelVOMap", channelVOMap);


        }catch (Exception e){
            e.printStackTrace();
        }
        return "/admin/transfer_payment_order/list";
    }


    @RequestMapping("/alipay_list")
    @OperationAuth(name = "支付宝提现充值订单查看", authCode = "transfer_payment.alipay_list", group = "上游中转充值")
    public String alipyList(TransferPaymentOrderQueryParam param,Model model,HttpServletRequest request){
        param.setOrderSource(ALIPAY_WITHDRAW.name());
        SysUser sysUser = AdminUserUtils.getCurrentLoginUser(request);
        param.setCreateUserId(sysUser.getId());
        PageInfo<TransferPaymentOrder> page = transferPaymentOrderService.findPage(param);
        page.setList(toVO(page.getList()));
        model.addAttribute("pageInfo", page);
        List<Integer> userIds = page.getList().stream().map(TransferPaymentOrder::getCreateUserId).distinct().collect(Collectors.toList());


        Map<Integer,String> userMap = sysUserService.findAll().stream().filter(sysuser->userIds.contains(sysuser.getId())).collect(Collectors.toMap(SysUser::getId,sysuser->sysuser.getUserName()));
        model.addAttribute("userMap",userMap);

        model.addAttribute("queryParam", param);
        model.addAttribute("auditStatusList", AuditStatusEnum.values());
        model.addAttribute("orderSourceList", TransferPaymentOrder.OrderSourceType.values());
        SysUser currentUser = AdminUserUtils.getCurrentLoginUser(request);
        model.addAttribute("currenSysUserId",currentUser.getId());
        return "/admin/transfer_payment_order/alipay_list";
    }

    @RequestMapping("/to_add_transfer_payment_order")
    @OperationAuth(name = "上游中转充值", authCode = "transfer_payment.add_transfer_payment_order", group = "上游中转充值")
    public String toAddTransferPaymentOrderByWithdraw(Model model,HttpServletRequest request){

        SysUser sysUser = AdminUserUtils.getCurrentLoginUser(request);
        Merchant merchant = merchantService.findByUserId(sysUser.getId());
        WithdrawOrderQueryParam withdrawOrderQueryParam = new WithdrawOrderQueryParam();
        withdrawOrderQueryParam.setMerchantId(merchant.getId());
        withdrawOrderQueryParam.setOrderStatus(OrderStatusEnum.SUCCESS);
        List<WithdrawOrder> withdrawOrders = transferWithdrawOrderService.findUnPaymentTransferWithdrawList(withdrawOrderQueryParam);
        model.addAttribute("transferWithdrawList",toWithdrawOrderVO(withdrawOrders));


        List<Channel> channels = channelService.findChannels(null);
        Set<Integer> channelIds = channels.stream().distinct().filter(channel->channel.getType().equals(Channel.ChannelType.WITHDRAW)).map(Channel::getId).collect(Collectors.toSet());

        List<ChannelAccount> channelAccounts = channelAccountService.findChannelAccounts(null).stream().filter(acc->channelIds.contains(acc.getChannelId())).collect(Collectors.toList());

        List<ChannelAccountVO> channelAccountVOS = channelAccountController.toAccountVO(channelAccounts, true);
        Map<String,List<ChannelAccountVO>> channelVOMap = channelAccountVOS.stream().collect(Collectors.groupingBy(channelAccountVO->channelAccountVO.getChannelName()));

        model.addAttribute("channelVOMap",channelVOMap);

        Map channelMap = channels.stream().distinct().collect(Collectors.toMap(Channel::getId,Channel::getName));
        model.addAttribute("channelMap",channelMap);

        Map channelAccountMap = channelAccounts.stream().distinct().collect(Collectors.toMap(ChannelAccount::getId,ChannelAccount::getName));
        model.addAttribute("channelAccountMap",channelAccountMap);

        return "/admin/transfer_payment_order/add_transfer_payment_order";
    }




    @RequestMapping(value="/add_transfer_payment_order")
    @ResponseBody
    @OperationAuth(name = "上游中转充值", authCode = "transfer_payment.add_transfer_payment_order", group = "上游中转充值")
    @LogOperation(name = "下发订单中转充值",module = "中转订单")
    public ResponseResult addTransferPaymentOrder(TransferPaymentOrderVO order,MultipartFile file,HttpServletRequest request) throws TransferPaymentException, IOException {
        try {

            int [] orderIds = order.getTransferWithdrawOrderId();
            for (int orderId : orderIds) {
                WithdrawOrder withdrawOrder = withdrawOrderService.findById(orderId);
                Integer paymentOrderId = withdrawOrder.getTransferPaymentOrderId();
                if(!ObjectUtils.isEmpty(paymentOrderId)){
                    throw new TransferException(String.format("订单:%s已经充值!",withdrawOrder.getPlatformOrderNo()));
                }
            }


            String transferBillImgUrl = "";
            String fileName = UploadUtils.importFile(file,uploadPath);
            transferBillImgUrl = virtualPath+fileName;

            SysUser sysUser = AdminUserUtils.getCurrentLoginUser(request);
            AssertUtils.objectNotNull(sysUser,"获取用户信息失败");
            Integer currentUserId = sysUser.getId();
            Merchant merchant = merchantService.findByUserId(currentUserId);
            order.setTransferInMerchantId(merchant.getId());
            order.setTransferInMerchantNo(merchant.getMerchantNo());
            order.setCreateUserId(currentUserId);
            order.setAmount(MoneyUtils.yuan2fee(order.getAmountYuan()).intValue());
            order.setTransferBillUrl(transferBillImgUrl);
            order.setTransferCost(0);

            order.setRechargeCost(MoneyUtils.yuan2fee(order.getRechargeCostYuan()).intValue());

            order.setOrderSource(TransferPaymentOrder.OrderSourceType.TRANSFER_WITHDRAW);
            order.setCreateTime(new Date());


            AssertUtils.objectNotNull(order.getAmount(),"金额不能为空！");
            transferPaymentService.createTransferPaymentOrder(order);


            notifyComponent.notifyByAuthority("transfer_payment.confirmPayment","您有一条新的中转充值订单待确认！");

            return new ResponseResult(ResponseCode.SUCCESS, "添加成功","");
        } catch (TransferException e) {
            logger.error("", e);
            return new ResponseResult(ResponseCode.FAIL, "添加失败:" + e.getMessage(),"");
        } catch (Exception e) {
            e.printStackTrace();
            return new ResponseResult(ResponseCode.FAIL, "添加失败:" + e.getMessage(),"");
        }
    }



    @RequestMapping("/to_add_transfer_payment_order_by_recharge")
    @OperationAuth(name = "对公卡中转", authCode = "transfer_payment.transfer", group = "上游中转充值")
    public String toAddTransferPaymentOrderByRecharge(Model model,HttpServletRequest request){

        SysUser sysUser = AdminUserUtils.getCurrentLoginUser(request);
        List<ManualOrder> manualOrders =  manualOrderService.findUnTransferManualRechargeOrderList(sysUser.getId());
        Map<Integer,List<ManualOrder>>manualOrderGroupMap =  manualOrders.stream().collect(Collectors.groupingBy(ManualOrder::getRechargeChannelAccout));
        model.addAttribute("manualOrderGroupMap",manualOrderGroupMap);

        List<Integer> merchantIds = manualOrders.stream().map(order->order.getMerchantId()).distinct().collect(Collectors.toList());
        List<Merchant> merchants = merchantService.findByIds(merchantIds);
        Map<Integer,Merchant> merchantMap = merchants.stream().collect(Collectors.toMap(Merchant::getId, t -> t));
        model.addAttribute("merchantMap", merchantMap);


        List<Channel> channels = channelService.findChannels(null);
        Set<Integer> channelIds = channels.stream().distinct().filter(channel->channel.getType().equals(Channel.ChannelType.WITHDRAW)).map(Channel::getId).collect(Collectors.toSet());

        List<ChannelAccount> channelAccounts = channelAccountService.findChannelAccounts(null).stream().filter(acc->channelIds.contains(acc.getChannelId())).collect(Collectors.toList());

        List<ChannelAccountVO> channelAccountVOS = channelAccountController.toAccountVO(channelAccounts, true);
        Map<String,List<ChannelAccountVO>> channelVOMap = channelAccountVOS.stream().collect(Collectors.groupingBy(channelAccountVO->channelAccountVO.getChannelName()));

        model.addAttribute("channelVOMap",channelVOMap);

        Map channelMap = channels.stream().distinct().collect(Collectors.toMap(Channel::getId,Channel::getName));
        model.addAttribute("channelMap",channelMap);

        Map channelAccountMap = channelAccounts.stream().distinct().collect(Collectors.toMap(ChannelAccount::getId,ChannelAccount::getName));
        model.addAttribute("channelAccountMap",channelAccountMap);

        return "/admin/transfer_payment_order/add_transfer_payment_order_by_recharge";
    }


    @RequestMapping(value="/add_transfer_payment_order_by_recharge")
    @ResponseBody
    @OperationAuth(name = "对公卡中转", authCode = "transfer_payment.transfer", group = "上游中转充值")
    @LogOperation(name = "会员充值订单中转充值",module = "中转订单")
    public ResponseResult addTransferPaymentOrderByRecharge(TransferPaymentOrderVO order,MultipartFile file,HttpServletRequest request) throws TransferPaymentException, IOException {
        try {

            int [] orderIds = order.getManualRechargeOrderId();
            for (int orderId : orderIds) {
                ManualOrder manualOrder = manualOrderService.selectByPrimaryKey(orderId);
                Integer paymentOrderId = manualOrder.getTransferPaymentOrderId();
                if(!ObjectUtils.isEmpty(paymentOrderId)){
                    throw new TransferException(String.format("订单:%s已经被中转充值!",manualOrder.getId()));
                }
            }


            String transferBillImgUrl = "";
            String fileName = UploadUtils.importFile(file,uploadPath);
            transferBillImgUrl = virtualPath+fileName;

            SysUser sysUser = AdminUserUtils.getCurrentLoginUser(request);
            AssertUtils.objectNotNull(sysUser,"获取中转人信息失败!");
            Integer currentUserId = sysUser.getId();
            Merchant merchant = merchantService.findByUserId(currentUserId);
            order.setTransferInMerchantId(merchant.getId());
            order.setTransferInMerchantNo(merchant.getMerchantNo());
            order.setCreateUserId(currentUserId);
            order.setAmount(MoneyUtils.yuan2fee(order.getAmountYuan()).intValue());
            order.setTransferCost(0);
            order.setRechargeCost(MoneyUtils.yuan2fee(order.getRechargeCostYuan()).intValue());
            order.setCreateTime(new Date());
            order.setOrderSource(TransferPaymentOrder.OrderSourceType.MANUAL_RECHARGE);
            order.setTransferBillUrl(transferBillImgUrl);
            String error = ValidationUtils.validate(order);
            if (error != null) {
                throw new TransferException(error);
            }

            transferPaymentService.createByRechargeOrder(order);

            return new ResponseResult(ResponseCode.SUCCESS, "充值完成","");
        } catch (Exception e) {
            logger.error("", e);
            return new ResponseResult(ResponseCode.FAIL, "充值失败:" + e.getMessage(),"");
        }
    }






    @RequestMapping(value="/to_audit/{orderId}")
    public String toAudit(Model model,@PathVariable("orderId") Integer orderId){
        TransferPaymentOrder transferPaymentOrder = transferPaymentOrderService.findById(orderId);
        model.addAttribute("order",toVO(transferPaymentOrder));
        List<Channel> channels = channelService.findChannels(null);
        Set<Integer> channelIds = channels.stream().distinct().filter(channel->channel.getType().equals(Channel.ChannelType.WITHDRAW)).map(Channel::getId).collect(Collectors.toSet());
        List<ChannelAccount> channelAccounts = channelAccountService.findChannelAccounts(null).stream().filter(acc->channelIds.contains(acc.getChannelId())).collect(Collectors.toList());
        List<ChannelAccountVO> channelAccountVOS = channelAccountController.toAccountVO(channelAccounts, true);
        Map<String,List<ChannelAccountVO>> channelVOMap = channelAccountVOS.stream().collect(Collectors.groupingBy(channelAccountVO->channelAccountVO.getChannelName()));
        model.addAttribute("channelVOMap",channelVOMap);
        MerchantFindParam findParam = new MerchantFindParam();
        findParam.setUserType(MerchantUserTypeEnum.MERCHANT);
        List<Merchant> merchants = merchantService.findAllMerchant(findParam);
        Map<Integer,Merchant> merchantMap = merchants.stream().collect(Collectors.toMap(Merchant::getId,t->t));
        List<MerchantAccountDetail> merchantAccountDetails = new ArrayList<>();
        for (Merchant merchant : merchants) {
            MerchantAccountDetail merchantAccountDetail = merchantAccountService.getMerchantAccountDetail(merchant.getId());
            merchantAccountDetails.add(merchantAccountDetail);
        }
        merchantAccountDetails = merchantAccountDetails.stream().filter(t->t.getWithdrawBalance()>transferPaymentOrder.getAmount()).collect(Collectors.toList());
        model.addAttribute("merchantAccountDetails",merchantAccountDetails);
        model.addAttribute("merchantMap",merchantMap);
        BankCardQueryParam query = new BankCardQueryParam();
        query.setPageNum(1);
        query.setPageSize(1000);
        List<MerchantBankCard> cards = merchantBankCardService.findList(query).getList();
        List<BankCodeEnum> banks = EnumUtils.getEnumList(BankCodeEnum.class);
        Map<String,String> bankMap = banks.stream().collect(Collectors.toMap(BankCodeEnum::getCode,BankCodeEnum::getBankName));
        cards.stream().forEach(t->t.setPayeeBankName(bankMap.get(t.getPayeeBankCode())));
        String jsonDocumentList = JSONArray.fromObject(cards).toString();
        model.addAttribute("cardList", jsonDocumentList);
        return "/admin/transfer_payment_order/audit";
    }



    @RequestMapping(value="/transfer_audit/{orderId}")
    @ResponseBody
    @OperationAuth(name = "中转充值", authCode = "transfer_payment.recharge", group = "上游中转充值")
    public ResponseResult transferAudit(@PathVariable("orderId") Integer orderId, TransferPaymentOrderVO order,HttpServletRequest request) throws TransferPaymentException, IOException {
        try {
            AssertUtils.objectNotNull(order.getTransferBankAccount(),"银行卡号不能为空!");
            TransferPaymentOrder transferPaymentOrder = transferPaymentOrderService.findById(orderId);
            if(!AuditStatusEnum.AUDITING.name().equals(transferPaymentOrder.getAuditStatus())){
                return new ResponseResult(ResponseCode.FAIL, String.format("充值订单：%s已经被审核！",transferPaymentOrder.getPlatformOrderNo()),"");
            }
            SysUser sysUser = AdminUserUtils.getCurrentLoginUser(request);
            AssertUtils.objectNotNull(sysUser,"获取用户信息失败");
            Integer currentUserId = sysUser.getId();
            if(!OTC_WITHDRAW.name().equals(transferPaymentOrder.getOrderSource().name())) {
                Merchant currentMerchant = merchantService.findByUserId(currentUserId);
                AssertUtils.objectNotNull(currentMerchant, "当前用户账户没有初始化！");
            }
            order.setTransferTarget(TransferPaymentOrder.TransferTarget.CHANNEL.name());
            transferPaymentService.transferAudit(orderId,currentUserId,order);

            if(ALIPAY_WITHDRAW.equals(transferPaymentOrder.getOrderSource())){
                SysUser createUser = sysUserService.findById(transferPaymentOrder.getCreateUserId());
                notifyComponent.notifyByUserName(createUser.getUserName(),"您的充值订单已受理！");
            }
            return new ResponseResult(ResponseCode.SUCCESS, "审核成功","");
        } catch (TransferPaymentException e) {
            logger.error("", e);
            return new ResponseResult(ResponseCode.FAIL, "审核失败:" + e.getMessage(),"");
        }
    }




    @RequestMapping(value="/downstream_transfer_audit/{orderId}")
    @ResponseBody
    @OperationAuth(name = "中转充值", authCode = "transfer_payment.recharge", group = "上游中转充值")
    public ResponseResult downstreamTransferAudit(@PathVariable("orderId") Integer orderId, TransferPaymentOrderVO order,HttpServletRequest request) throws TransferPaymentException, IOException {
        try {
            AssertUtils.objectNotNull(order.getBankCardId(),"银行卡号不能为空!");
            AssertUtils.objectNotNull(order.getTransferTargetId(),"下发商户不能为空!");
            TransferPaymentOrder transferPaymentOrder = transferPaymentOrderService.findById(orderId);
            if(!AuditStatusEnum.AUDITING.name().equals(transferPaymentOrder.getAuditStatus())){
                return new ResponseResult(ResponseCode.FAIL, String.format("充值订单：%s已经被审核！",transferPaymentOrder.getPlatformOrderNo()),"");
            }
            SysUser sysUser = AdminUserUtils.getCurrentLoginUser(request);
            AssertUtils.objectNotNull(sysUser,"获取用户信息失败");
            Integer currentUserId = sysUser.getId();
            if(!OTC_WITHDRAW.name().equals(transferPaymentOrder.getOrderSource().name())) {
                Merchant currentMerchant = merchantService.findByUserId(currentUserId);
                AssertUtils.objectNotNull(currentMerchant, "当前用户账户没有初始化！");
            }
            order.setTransferTarget(TransferPaymentOrder.TransferTarget.MERCHANT.name());
            transferPaymentService.transferAudit(orderId,currentUserId,order);

            if(ALIPAY_WITHDRAW.equals(transferPaymentOrder.getOrderSource())){
                SysUser createUser = sysUserService.findById(transferPaymentOrder.getCreateUserId());
                notifyComponent.notifyByUserName(createUser.getUserName(),"您的充值订单已受理！");
            }
            return new ResponseResult(ResponseCode.SUCCESS, "审核成功","");
        } catch (TransferPaymentException e) {
            logger.error("", e);
            return new ResponseResult(ResponseCode.FAIL, "审核失败:" + e.getMessage(),"");
        }
    }


    @RequestMapping(value="/to_transfer/{orderId}")
    public String toTransfer(Model model,@PathVariable("orderId") Integer orderId){
        TransferPaymentOrder transferPaymentOrder = transferPaymentOrderService.findById(orderId);
        model.addAttribute("order",toVO(transferPaymentOrder));
        return "/admin/transfer_payment_order/transfer";
    }



    @RequestMapping(value="/transfer/{orderId}")
    @ResponseBody
    @OperationAuth(name = "对公卡中转", authCode = "transfer_payment.transfer", group = "上游中转充值")
    public ResponseResult transfer(@PathVariable("orderId") Integer orderId, MultipartFile file,TransferPaymentOrderVO order,HttpServletRequest request) throws Exception {
        try {
            TransferPaymentOrder transferPaymentOrder = transferPaymentOrderService.findById(orderId);
            if(!TransferPaymentOrder.OrderStatusEnum.PROCESSING.name().equals(transferPaymentOrder.getOrderStatus())){
                return new ResponseResult(ResponseCode.FAIL, String.format("充值订单：%s已经被审核！",transferPaymentOrder.getPlatformOrderNo()),"");
            }

            SysUser sysUser = AdminUserUtils.getCurrentLoginUser(request);
            AssertUtils.objectNotNull(sysUser,"获取用户信息失败");
            Integer currentUserId = sysUser.getId();
            if(!transferPaymentOrder.getCreateUserId().equals(currentUserId)){
                return new ResponseResult(ResponseCode.FAIL, "该笔订单您没有权限中转！","");
            }

            BigDecimal transferCostYuan = order.getTransferCostYuan();
            int transferCost = MoneyUtils.yuan2fee(transferCostYuan).intValue();



            String transferBillImgUrl = "";
            String fileName = UploadUtils.importFile(file,uploadPath);
            transferBillImgUrl = virtualPath+fileName;

            transferPaymentOrder.setTransferCost(transferCost);
            transferPaymentOrder.setTransferBillUrl(transferBillImgUrl);
            if(ALIPAY_WITHDRAW.equals(transferPaymentOrder.getOrderSource())&& TransferPaymentOrder.TransferTarget.MERCHANT.name().equals(transferPaymentOrder.getTransferTarget())){
                transferPaymentOrder.setOrderStatus(TransferPaymentOrder.OrderStatusEnum.RECHARGE.name());
            }else{
                transferPaymentOrder.setOrderStatus(TransferPaymentOrder.OrderStatusEnum.TRANSFER.name());
            }
            transferPaymentService.transfer(transferPaymentOrder);

            if(ALIPAY_WITHDRAW.equals(transferPaymentOrder.getOrderSource())){
                SysUser createUser = sysUserService.findById(transferPaymentOrder.getAuditUserid());
                notifyComponent.notifyByUserName(createUser.getUserName(),"有一笔充值订单已转账，请确认收款！");
            }

            return new ResponseResult(ResponseCode.SUCCESS, "中转成功","");
        } catch (TransferPaymentException e) {
            logger.error("", e);
            return new ResponseResult(ResponseCode.FAIL, "中转失败:" + e.getMessage(),"");
        }
    }



    @RequestMapping(value="/to_transfer_confirm/{orderId}")
    public String toTransferConfirm(Model model,@PathVariable("orderId") Integer orderId){
        TransferPaymentOrder transferPaymentOrder = transferPaymentOrderService.findById(orderId);
        model.addAttribute("order",toVO(transferPaymentOrder));
        return "/admin/transfer_payment_order/transfer_confirm";
    }



    @RequestMapping(value="/transfer_confirm/{orderId}")
    @ResponseBody
    @OperationAuth(name = "中转充值", authCode = "transfer_payment.recharge", group = "上游中转充值")
    public ResponseResult transferConfirm(@PathVariable("orderId") Integer orderId, HttpServletRequest request) throws TransferPaymentException {
    try {
        TransferPaymentOrder transferPaymentOrder = transferPaymentOrderService.findById(orderId);
        SysUser sysUser = AdminUserUtils.getCurrentLoginUser(request);
        AssertUtils.objectNotNull(sysUser,"获取用户信息失败");
        Assert.isTrue(transferPaymentOrder.getAuditUserid().equals(sysUser.getId()),"当前用户没有权限确认中转到账！");
        Integer currentUserId = sysUser.getId();
        {
            transferPaymentService.transferConfirm(orderId,currentUserId,TransferPaymentOrder.OrderStatusEnum.TRANSFER_CONFIRM.name());
        }

        return new ResponseResult(ResponseCode.SUCCESS, "确认成功","");
        } catch (TransferPaymentException e) {
            logger.error("", e);
            return new ResponseResult(ResponseCode.FAIL, "确认失败:" + e.getMessage(),"");
        }
    }

    @RequestMapping(value="/to_recharge/{orderId}")
    public String toRecharge(Model model,@PathVariable("orderId") Integer orderId){
        TransferPaymentOrder transferPaymentOrder = transferPaymentOrderService.findById(orderId);
        model.addAttribute("order",toVO(transferPaymentOrder));

        TransferPaymentOrder.OrderSourceType sourceType = transferPaymentOrder.getOrderSource();

        List<Channel> channels = channelService.findChannels(null);
        Set<Integer> channelIds = channels.stream().distinct().filter(channel->channel.getType().equals(Channel.ChannelType.WITHDRAW)).map(Channel::getId).collect(Collectors.toSet());

        List<ChannelAccount> channelAccounts = channelAccountService.findChannelAccounts(null).stream().filter(acc->channelIds.contains(acc.getChannelId())).collect(Collectors.toList());

        List<ChannelAccountVO> channelAccountVOS = channelAccountController.toAccountVO(channelAccounts, true);
        Map<String,List<ChannelAccountVO>> channelVOMap = channelAccountVOS.stream().collect(Collectors.groupingBy(channelAccountVO->channelAccountVO.getChannelName()));

        model.addAttribute("channelVOMap",channelVOMap);

        return "/admin/transfer_payment_order/recharge";
    }



    @RequestMapping(value="/order_recharge/{orderId}")
    @ResponseBody
    @OperationAuth(name = "中转充值", authCode = "transfer_payment.recharge", group = "上游中转充值")
    public synchronized ResponseResult orderRecharge(@PathVariable("orderId") Integer orderId, TransferPaymentOrderVO order,HttpServletRequest request) throws TransferPaymentException {
        try {
            TransferPaymentOrder transferPaymentOrder = transferPaymentOrderService.findById(orderId);
            if(TransferPaymentOrder.OrderStatusEnum.SUCCESS.name().equals(transferPaymentOrder.getOrderStatus())){
                return new ResponseResult(ResponseCode.FAIL, String.format("充值订单：%s已经被充值！",transferPaymentOrder.getPlatformOrderNo()),"");
            }
            SysUser sysUser = AdminUserUtils.getCurrentLoginUser(request);
            AssertUtils.objectNotNull(sysUser,"获取用户信息失败");
            Integer currentUserId = sysUser.getId();
            if(!transferPaymentOrder.getAuditUserid().equals(currentUserId)){
                return new ResponseResult(ResponseCode.FAIL, "该笔订单您没有权限充值！","");
            }

            BigDecimal rechargeCostYuan = order.getRechargeCostYuan();
            int rechargeCost = MoneyUtils.yuan2fee(rechargeCostYuan).intValue();
            transferPaymentOrder.setRechargeCost(rechargeCost);
            transferPaymentOrder.setTransferBankAccount(order.getTransferBankAccount());
            transferPaymentOrder.setTransferBankAccountOwner(order.getTransferBankAccountOwner());
            transferPaymentOrder.setOrderStatus(TransferPaymentOrder.OrderStatusEnum.RECHARGE.name());
            transferPaymentService.recharge(transferPaymentOrder);
            return new ResponseResult(ResponseCode.SUCCESS, "充值成功","");
        } catch (Exception e) {
            logger.error("", e);
            return new ResponseResult(ResponseCode.FAIL, "充值失败:" + e.getMessage(),"");
        }
    }


    @RequestMapping(value="/order_detail/{orderId}")
    public String toOrderDetail(HttpServletRequest request,Model model,@PathVariable("orderId") Integer orderId){
        TransferPaymentOrder transferPaymentOrder = transferPaymentOrderService.findById(orderId);
        model.addAttribute("order",toVO(transferPaymentOrder));

        TransferPaymentOrder.OrderSourceType sourceType = transferPaymentOrder.getOrderSource();
        if(TransferPaymentOrder.OrderSourceType.TRANSFER_WITHDRAW.equals(sourceType)){
            WithdrawOrderQueryParam withdrawOrderQueryParam = new WithdrawOrderQueryParam();
            withdrawOrderQueryParam.setTransferPaymentOrderId(orderId);
            PageInfo<WithdrawOrder> page = transferWithdrawOrderService.findTransferWithdrawList(withdrawOrderQueryParam);
            model.addAttribute("transferWithdrawList",toWithdrawOrderVO(page.getList()));
        }else if(TransferPaymentOrder.OrderSourceType.MANUAL_RECHARGE.equals(sourceType)){

            List<ManualOrder> manualOrders =  manualOrderService.findTransferManualRechargeOrderList(orderId);
            model.addAttribute("manualOrders",manualOrders);
            List<Integer> merchantIds = manualOrders.stream().map(order->order.getMerchantId()).distinct().collect(Collectors.toList());
            List<Merchant> merchants = merchantService.findByIds(merchantIds);
            Map<Integer,String> merchantMap = merchants.stream().collect(Collectors.toMap(Merchant::getId, t -> t.getMerchantNo()));
            model.addAttribute("merchantMap", merchantMap);

        }
        return "/admin/transfer_payment_order/order_detail";
    }

    private List toVO(List<TransferPaymentOrder> list) {
        List<Integer> mchIds = list.stream().map(TransferPaymentOrder::getTransferOutMerchantId).distinct().collect(Collectors.toList());
        List<Merchant> merchantList = merchantService.findByIds(mchIds);
        Map<Integer, Merchant> merchantMap = merchantList.stream().collect(Collectors.toMap(Merchant::getId, m -> m));
        List volist = new ArrayList();
        for (TransferPaymentOrder order : list) {
            TransferPaymentOrderVO vo = new TransferPaymentOrderVO();
            BeanUtils.copyProperties(order, vo);
            if(order.getOrderSource()==OTC_WITHDRAW){

            }else {
                vo.setMerchantName(merchantMap.get(order.getTransferOutMerchantId()).getMerchantName());
            }
            volist.add(vo);
        }
        return volist;
    }

    private TransferPaymentOrderVO toVO(TransferPaymentOrder order) {
        List<TransferPaymentOrderVO> list = toVO(Arrays.asList(order));
        return list.get(0);
    }

    private List toWithdrawOrderVO(List<WithdrawOrder> list) {
        List<Integer> mchIds = list.stream() .map(WithdrawOrder::getMerchantId).distinct().collect(Collectors.toList());
        List<Merchant> merchantList = merchantService.findByIds(mchIds);
        Map<Integer, Merchant> merchantMap = merchantList.stream().collect(Collectors.toMap(Merchant::getId, m -> m));
        List volist = new ArrayList();
        for (WithdrawOrder order : list) {
            WithdrawOrderVO vo = new WithdrawOrderVO();
            BeanUtils.copyProperties(order, vo);
            vo.setMerchantName(merchantMap.get(order.getMerchantId()).getMerchantName());
            volist.add(vo);
        }
        return volist;
    }



    @RequestMapping(value="/to_batch_confirm_recharge")
    @OperationAuth(name = "充值确认", authCode = "transfer_payment.recharge", group = "上游中转充值")
    public String toBatchConfirmRecharge(){
        return  "/admin/transfer_payment_order/recharge_batch_confirm";

    }

    @RequestMapping(value="/batch_confirm_recharge")
    @OperationAuth(name = "充值确认", authCode = "transfer_payment.recharge", group = "上游中转充值")
    @ResponseBody
    public synchronized ResponseResult batchConfirmRecharge(MultipartFile file, HttpServletRequest request) {
        try{

            String confirmImgUrl = "";
            String fileName = UploadUtils.importFile(file,uploadPath);
            confirmImgUrl = virtualPath+fileName;

            String[] orderIds = request.getParameterValues("orderIds[]");
            for (String orderId : orderIds) {
                rechargeConfirm(request, confirmImgUrl, new Integer(orderId));
            }

            return new ResponseResult(ResponseCode.SUCCESS, "充值确认成功！","");
        } catch (Exception e) {
            logger.error("", e);
            return new ResponseResult(ResponseCode.FAIL, "充值确认失败:" + e.getMessage(),"");
        }
    }


    @RequestMapping(value="/to_confirm_recharge/{orderId}")
    public String toConfirmRecharge(Model model,@PathVariable("orderId") Integer orderId){
        TransferPaymentOrder transferPaymentOrder = transferPaymentOrderService.findById(orderId);
        model.addAttribute("order",toVO(transferPaymentOrder));
        return  "/admin/transfer_payment_order/recharge_confirm";

    }


    @RequestMapping(value="/to_update_transferBillUrl/{orderId}")
    public String toUpdateTransferBillUrl(Model model,@PathVariable("orderId") Integer orderId){
        TransferPaymentOrder transferPaymentOrder = transferPaymentOrderService.findById(orderId);
        model.addAttribute("order",toVO(transferPaymentOrder));
        return  "/admin/transfer_payment_order/update_transferbillurl";
    }

    @RequestMapping(value="/update_transferBillUrl/{orderId}")
    @OperationAuth(name = "修改转账票据", authCode = "transfer_payment.transfer", group = "上游中转充值")
    @ResponseBody
    public ResponseResult updateByTransferBillUrl(@PathVariable("orderId") Integer orderId, MultipartFile file, HttpServletRequest request){
        try{

            String imgUrl = "";
            String fileName = UploadUtils.importFile(file,uploadPath);
            imgUrl = virtualPath+fileName;

            TransferPaymentOrder transferPaymentOrder = transferPaymentOrderService.findById(orderId);
            transferPaymentOrder.setTransferBillUrl(imgUrl);
            transferPaymentOrderService.updateByTransferBillUrl(transferPaymentOrder);

            return new ResponseResult(ResponseCode.SUCCESS, "修改转账票据成功！","");
        } catch (Exception e) {
            logger.error("", e);
            return new ResponseResult(ResponseCode.FAIL, "修改转账票据失败:" + e.getMessage(),"");
        }
    }


    @RequestMapping(value="/to_update_confirm/{orderId}")
    public String toUpdateConfirm(Model model,@PathVariable("orderId") Integer orderId){
        TransferPaymentOrder transferPaymentOrder = transferPaymentOrderService.findById(orderId);
        model.addAttribute("order",toVO(transferPaymentOrder));
        return  "/admin/transfer_payment_order/update_recharge_confirm";
    }

    @RequestMapping(value="/update_confirm/{orderId}")
    @OperationAuth(name = "修改到账确认截图", authCode = "transfer_payment.transfer", group = "上游中转充值")
    @ResponseBody
    public ResponseResult updateByConfirmImgUrl(@PathVariable("orderId") Integer orderId, MultipartFile file, HttpServletRequest request){
        try{

            String confirmImgUrl = "";
            String fileName = UploadUtils.importFile(file,uploadPath);
            confirmImgUrl = virtualPath+fileName;

            TransferPaymentOrder transferPaymentOrder = transferPaymentOrderService.findById(orderId);
            transferPaymentOrder.setConfirmImgUrl(confirmImgUrl);
            transferPaymentOrderService.updateByConfirmImgUrl(transferPaymentOrder);

            return new ResponseResult(ResponseCode.SUCCESS, "修改到账确认截图成功！","");
        } catch (Exception e) {
            logger.error("", e);
            return new ResponseResult(ResponseCode.FAIL, "修改到账确认截图失败:" + e.getMessage(),"");
        }
    }

    @RequestMapping(value="/confirm_recharge/{orderId}")
    @OperationAuth(name = "中转充值", authCode = "transfer_payment.recharge", group = "上游中转充值")
    @ResponseBody
    public synchronized ResponseResult confirmRecharge(@PathVariable("orderId") Integer orderId, MultipartFile file, HttpServletRequest request) {
    try{

        String confirmImgUrl = "";
        String fileName = UploadUtils.importFile(file,uploadPath);
        confirmImgUrl = virtualPath+fileName;

        rechargeConfirm(request, confirmImgUrl, orderId);

        return new ResponseResult(ResponseCode.SUCCESS, "充值确认成功！","");
       } catch (Exception e) {
           logger.error("", e);
           return new ResponseResult(ResponseCode.FAIL, "充值确认失败:" + e.getMessage(),"");
       }
    }


    private void rechargeConfirm(HttpServletRequest request, String confirmImgUrl, Integer orderId) throws TransferPaymentException {
        TransferPaymentOrder transferPaymentOrder = transferPaymentOrderService.findById(orderId);
        if(TransferPaymentOrder.OrderStatusEnum.SUCCESS.name().equals(transferPaymentOrder.getOrderStatus())){
            throw new TransferPaymentException( String.format("充值订单：%s已经确认到账！",transferPaymentOrder.getPlatformOrderNo()));
        }


        SysUser sysUser = AdminUserUtils.getCurrentLoginUser(request);
        AssertUtils.objectNotNull(sysUser,"获取用户信息失败");
        Integer currentUserId = sysUser.getId();

        transferPaymentService.rechargeConfirm(orderId,currentUserId,confirmImgUrl);
    }

    private List<ChannelAccountVO> toAccountVO(List<ChannelAccount> accounts) {
        List<Channel> channels = channelService.findChannels(new ChannelQuery());
        Map<Integer,String> channelMap = channels.stream().collect(Collectors.toMap(Channel::getId,Channel::getName));
        List<ChannelAccountVO> channelAccountVOS = ChannelAccountViewUtils.toVO(accounts);
        for (ChannelAccountVO acc : channelAccountVOS) {
            acc.setChannelName(channelMap.get(acc.getChannelId()));
        }
        return channelAccountVOS;
    }


    @RequestMapping(value="/export")
    @OperationAuth(name = "导出", authCode = "transfer_payment.export", group = "上游中转充值")
    public void export(Model model, TransferPaymentOrderQueryParam param, HttpServletResponse response) throws Exception {
        logger.info("中转充值报表报表导出开始...");

        PageInfo<TransferPaymentOrder> page = transferPaymentOrderService.findPage(param);
        param.setTotal(page.getTotal());
        long start = System.currentTimeMillis();
        transferPaymentOrderExportService.export(response,param);
        logger.info("中转充值报表导出结束...共耗时:" + (System.currentTimeMillis() - start)/1000 + "s");
    }

}
