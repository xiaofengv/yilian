package com.ajl.bfb.merchantadmin.withdraw.vo;

import com.ajl.bfb.core.constants.BankCodeEnum;
import com.ajl.bfb.repo.withdraw.model.MerchantBankCard;

import java.io.Serializable;


public class MerchantBankCardVO extends MerchantBankCard implements Serializable {

    public String getPayeeBankName() {
        return BankCodeEnum.valueOfCode(getPayeeBankCode()).getBankName();
    }
}
