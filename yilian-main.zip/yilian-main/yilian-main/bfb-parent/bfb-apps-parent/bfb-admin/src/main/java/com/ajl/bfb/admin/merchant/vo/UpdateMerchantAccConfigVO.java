package com.ajl.bfb.admin.merchant.vo;

import java.io.Serializable;
import java.util.List;


public class UpdateMerchantAccConfigVO implements Serializable {

    private List<Integer> accountIdList;
    private Integer merchantId;
    private String bizType;

    public String getBizType() {
        return bizType;
    }

    public void setBizType(String bizType) {
        this.bizType = bizType;
    }

    public List<Integer> getAccountIdList() {
        return accountIdList;
    }

    public void setAccountIdList(List<Integer> accountIdList) {
        this.accountIdList = accountIdList;
    }

    public Integer getMerchantId() {
        return merchantId;
    }

    public void setMerchantId(Integer merchantId) {
        this.merchantId = merchantId;
    }
}