package com.ajl.bfb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.data.neo4j.Neo4jDataAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;
import org.springframework.boot.autoconfigure.transaction.TransactionAutoConfiguration;
import org.springframework.boot.web.servlet.ServletComponentScan;
import org.springframework.boot.web.support.SpringBootServletInitializer;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.context.annotation.ImportResource;
import org.springframework.context.annotation.PropertySource;
import org.springframework.scheduling.annotation.EnableScheduling;




@SuppressWarnings("ALL")
@SpringBootApplication(scanBasePackages = {"com.hippo.framework", "com.ajl.bfb"})
@EnableAutoConfiguration(exclude = {
        DataSourceAutoConfiguration.class,
        Neo4jDataAutoConfiguration.class,
        TransactionAutoConfiguration.class,
        HibernateJpaAutoConfiguration.class
})
@PropertySource(value = {
        "classpath:/env/${spring.profiles.active}/jdbc.properties",
        "classpath:/env/${spring.profiles.active}/redis.properties",
}, encoding = "utf-8")
@ImportResource(value = {
        "classpath:spring-transaction.xml"

})
@EnableAspectJAutoProxy(proxyTargetClass = true)
@ServletComponentScan
@EnableScheduling
public class AdminApplicationStarter extends SpringBootServletInitializer {

    public static void main(String[] args) {
        SpringApplication.run(AdminApplicationStarter.class, args);
    }
}
