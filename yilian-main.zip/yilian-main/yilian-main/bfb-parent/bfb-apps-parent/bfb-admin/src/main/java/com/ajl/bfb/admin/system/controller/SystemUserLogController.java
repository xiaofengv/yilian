package com.ajl.bfb.admin.system.controller;

import com.ajl.bfb.repo.system.model.QuerySystemUserLog;
import com.ajl.bfb.repo.system.model.SystemUserLog;
import com.ajl.bfb.repo.system.service.ISystemUserLogService;
import com.github.pagehelper.PageInfo;
import com.hippo.framework.auth.admin.OperationAuth;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;

@Controller
@RequestMapping("/admin/system/user_operation_log")
public class SystemUserLogController {

    @Autowired
    private ISystemUserLogService systemUserLogService;


    @RequestMapping("/list")
    @OperationAuth(name = "查看用户操作日志", authCode = "user_operation_log.list", group = "系统管理")
    public String list(HttpServletRequest request, QuerySystemUserLog queryParam, Model model) {
        PageInfo<SystemUserLog> pageInfo=systemUserLogService.findList(queryParam);
        model.addAttribute("pageInfo", pageInfo);
        model.addAttribute("queryParam", queryParam);
        return "/admin/system/user_operation_log/list";
    }


}