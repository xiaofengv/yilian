var channel = {};
//通道开关切换
channel.switchStatus = function (el, id) {
        var isChecked = $(el).prop('checked');
        var switchActionUrl = getWebPath() + '/admin/channel/turn_off/' + id;

        $("#switch_" + id).html("关");
        if (isChecked) {
            switchActionUrl = getWebPath() + '/admin/channel/turn_on/' + id;
            $("#switch_" + id).html("开");
        }

        $.ajax({
            type : "POST", //提交方式
            url : switchActionUrl,//路径
            data : {},
            success : function(result) {//返回数据根据结果进行相应的处理
                new $.zui.Messager(result.message, {
                    type: 'success' // 定义颜色主题
                }).show();
            }
        });
    }

    //删除通道
channel.delete = function (id) {
    layer.confirm(
        "确定要删除吗?",
        {icon: 0, title:'提示'},
        function(index, layero){
            layer.close(index);

            window.location.href = getWebPath() + '/admin/channel/delete/' + id;
        }
    );
}

//通道新增或更新保存
channel.save = function(){
    $("#addChannelForm").ajaxSubmit(function(response) {
        if(response.statusCode=="SUCCESS"){
            $('#errorMsgDiv').hide();
            if(response.data!=null){
                $('#channelId').val(response.data);
            }
            new $.zui.Messager(response.message, {
                type: 'success' // 定义颜色主题
            }).show();
            // hippo.goback();
            window.location.href = getWebPath()  + "/admin/channel/list";
        }else{
            $('#errorMsgDiv').show();
            $('#errorMsg').html(response.message);
        }
    });
}


$(function () {
    $(".channel-amount input").each(function (index, el) {
        hippo.limitInteger(el.id);
    });
});








