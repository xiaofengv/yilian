package com.ajl.bfb.admin.test;

import com.google.zxing.*;
import com.google.zxing.client.j2se.BufferedImageLuminanceSource;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.common.HybridBinarizer;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletResponse;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Hashtable;
@Controller
@RequestMapping("/qrtest")
public class QrTest {
    private static final Logger logger = LoggerFactory.getLogger(QrTest.class);

    @RequestMapping("/createqr")
    public void createQr(HttpServletResponse httpServletResponse){
        try {
            byte [] qrcode = createQRCode("http://192.168.0.67:8080/qrtest/forwardurl");

            httpServletResponse.setDateHeader("Expires", 0L);
            httpServletResponse.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
            httpServletResponse.addHeader("Cache-Control", "post-check=0, pre-check=0");
            httpServletResponse.setHeader("Pragma", "no-cache");
            httpServletResponse.setContentType("image/jpeg");
            OutputStream fos = httpServletResponse.getOutputStream();
            fos.write(qrcode);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }



    @RequestMapping("/createqr1")
    public void createVeriferQr(HttpServletResponse httpServletResponse){
        try {
            byte [] qrcode = createQRCode("http://baidu.com?uuid=asdfsdfsdfsd");

            httpServletResponse.setDateHeader("Expires", 0L);
            httpServletResponse.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
            httpServletResponse.addHeader("Cache-Control", "post-check=0, pre-check=0");
            httpServletResponse.setHeader("Pragma", "no-cache");
            httpServletResponse.setContentType("image/jpeg");
            OutputStream fos = httpServletResponse.getOutputStream();
            fos.write(qrcode);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    //生成跳转二维码
    @RequestMapping("/forwardurl")
    public String forwardurl() throws IOException, NotFoundException {
        File file = new File("D:\\pay\\hippo\\code\\bfb-parent\\bfb-apps-parent\\bfb-admin\\src\\main\\java\\com\\ajl\\bfb\\admin\\test\\a.png");
        String forwardurl = anlaysisQRCode(file,".");
        return "redirect:"+forwardurl;
    }

    @RequestMapping("/forwardurl100")
    public String pay100() throws IOException, NotFoundException {
        File file = new File("D:\\pay\\hippo\\code\\bfb-parent\\bfb-apps-parent\\bfb-admin\\src\\main\\java\\com\\ajl\\bfb\\admin\\test\\a.png");
        String forwardurl = anlaysisQRCode(file,".");
        return "redirect:"+forwardurl;
    }

    @RequestMapping("/forwardurl200")
    public String pay200() throws IOException, NotFoundException {
        File file = new File("D:\\pay\\hippo\\code\\bfb-parent\\bfb-apps-parent\\bfb-admin\\src\\main\\java\\com\\ajl\\bfb\\admin\\test\\a.png");
        String forwardurl = anlaysisQRCode(file,".");
        return "redirect:"+forwardurl;
    }

    public static byte [] createQRCode(String url) throws IOException {
        int width = 500;
        int height = 500;
        String format = "png";
        Hashtable hints = new Hashtable();
        hints.put(EncodeHintType.CHARACTER_SET, "utf-8");
        hints.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.M);
        hints.put(EncodeHintType.MARGIN, 2);
        try {
            BitMatrix bitMatrix = new MultiFormatWriter().encode(url, BarcodeFormat.QR_CODE, width, height, hints);
            BufferedImage image = MatrixToImageWriter.toBufferedImage(bitMatrix);
            ByteArrayOutputStream os = new ByteArrayOutputStream();//新建流。
            ImageIO.write(image, format, os);//利用ImageIO类提供的write方法，将bi以png图片的数据模式写入流。
            return os.toByteArray();//从流中获取数据数组。
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
        }
        return null;
    }


    public static String anlaysisQRCode(File file,String fileDirectory) throws NotFoundException {
        MultiFormatReader formatReader=new MultiFormatReader();
        BufferedImage image=null;
        try {
            image = ImageIO.read(file);
            BinaryBitmap binaryBitmap =new BinaryBitmap(new HybridBinarizer(new BufferedImageLuminanceSource(image)));
            Hashtable hints=new Hashtable();
            hints.put(EncodeHintType.CHARACTER_SET, "utf-8");
            Result result=formatReader.decode(binaryBitmap,hints);
            return result.getText();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }finally {
        }
        return null;
    }

    @RequestMapping("/to_pay")
    public String toPay(){
        return "/pay";
    }

    @RequestMapping("/pay")
    public String dopayment(int amount,String paytype){
        if(amount==1){
            return "forward:/qrtest/forwardurl100";
        }else{
            return "forward:/qrtest/forwardurl200";
        }
    }

}