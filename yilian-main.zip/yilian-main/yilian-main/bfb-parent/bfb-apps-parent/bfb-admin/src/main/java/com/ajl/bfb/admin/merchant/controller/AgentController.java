package com.ajl.bfb.admin.merchant.controller;

import com.ajl.bfb.core.constants.ClearCycleEnum;
import com.ajl.bfb.core.constants.MerchantUserTypeEnum;
import com.ajl.bfb.repo.merchant.MerchantException;
import com.ajl.bfb.repo.merchant.model.Merchant;
import com.ajl.bfb.repo.merchant.model.MerchantFindParam;
import com.ajl.bfb.repo.merchant.model.MerchantInfo;
import com.ajl.bfb.repo.merchant.service.IAgentService;
import com.hippo.framework.auth.admin.OperationAuth;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;


@Controller
@RequestMapping("/admin/agent")
public class AgentController {

    private static final String LIST_URI = "redirect:/admin/agent/list";

    @Autowired
    private MerchantController merchantController;
    @Autowired
    private IAgentService agentService;

    @RequestMapping(value="/to_add")
    public String toAdd(Model model) {
        merchantController.toAdd(model);
        return "admin/agent/add";
    }

    @RequestMapping(value="/add")
    @OperationAuth(name = "新增代理商", authCode = "agent.add", group = "代理商管理")
    public String save(MerchantInfo merchantInfo, Model model) {
        agentService.save(merchantInfo);
        return LIST_URI;
    }

    @RequestMapping(value="/list")
    @OperationAuth(name = "查询代理商", authCode = "agent.query", group = "代理商管理")
    public String list(Model model,MerchantFindParam findParam) {
        if (findParam == null) {
            findParam = new MerchantFindParam();
        }
        findParam.setUserType(MerchantUserTypeEnum.AGENT);
        merchantController.list(model, findParam);
        return "admin/agent/list";
    }

    @RequestMapping(value="/to_update/{id}")
    @OperationAuth(name = "修改代理商", authCode = "agent.update", group = "代理商管理")
    public String toUpdate(@PathVariable("id")int id, Model model) {
        merchantController.toUpdate(id, model);
        model.addAttribute("clearCycleList", ClearCycleEnum.values());
        return "/admin/agent/update";
    }

    @RequestMapping(value="/update/{id}")
    @OperationAuth(name = "修改代理商", authCode = "agent.update", group = "代理商管理")
    public String update(@PathVariable("id")int id, MerchantInfo merchantInfo) {
        agentService.update(id, merchantInfo);
        return LIST_URI;
    }

    @RequestMapping(value="/to_update_password/{id}")
    @OperationAuth(name = "修改密码", authCode = "agent.updatePassWord", group = "代理商管理")
    public String toUpdatePassword(@PathVariable("id")int id, Model model) {
        Merchant merchant = agentService.findById(id);
        model.addAttribute("merchant", merchant);
        return "/admin/agent/update_password";
    }

    @RequestMapping(value="/update_password/{id}")
    @OperationAuth(name = "修改密码", authCode = "agent.updatePassWord", group = "代理商管理")
    public String updatePassword(@PathVariable("id")int id, @RequestParam("newPassword") String newPassword) {
        agentService.updateMerchantPassword(id, newPassword);
        return LIST_URI;
    }

    @RequestMapping(value="/turnon")
    @OperationAuth(name = "启用", authCode = "agent.start", group = "代理商管理")
    public String trunon(int id) throws MerchantException {
        merchantController.turnOn(id);
        return LIST_URI;
    }

    @RequestMapping(value="/turnoff")
    @OperationAuth(name = "停用", authCode = "agent.stop", group = "代理商管理")
    public String turnOff(int id) throws MerchantException {
        merchantController.turnOff(id);
        return LIST_URI;
    }

    @RequestMapping(value="/delete/{id}")
    @OperationAuth(name = "删除代理商", authCode = "agent.delete", group = "代理商管理")
    public String delete(@PathVariable("id")int id) {
        agentService.delete(id);
        return LIST_URI;
    }


}
