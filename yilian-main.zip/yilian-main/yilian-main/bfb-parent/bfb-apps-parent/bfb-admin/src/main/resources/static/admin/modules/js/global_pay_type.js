var global_pay_type = {};

$(function () {
    $(".rate_cls").each(function (index, el) {
        hippo.limitMoney(el.id);
    });

});

global_pay_type.switchStatus = function (el, payTypeCode) {
    var isChecked = $(el).prop('checked');
    var switchActionUrl = getWebPath() + '/admin/global_pay_type/turn_off/' + payTypeCode;

    $("#switch_" + payTypeCode).html("关");
    if (isChecked) {
        switchActionUrl = getWebPath() + '/admin/global_pay_type/turn_on/' + payTypeCode;
        $("#switch_" + payTypeCode).html("开");
    }

    $.ajax({
        type : "POST", //提交方式
        url : switchActionUrl,//路径
        data : {},
        success : function(result) {//返回数据根据结果进行相应的处理
            /*new $.zui.Messager(result.message, {
                type: 'success' // 定义颜色主题
            }).show();*/
            hippo.msg(result.message);
        }
    });
}


global_pay_type.switchMonStatus = function (el, payTypeCode) {
    var isChecked = $(el).prop('checked');
    var switchActionUrl = getWebPath() + '/admin/system/merchant/turn_off_paytype/' + payTypeCode;

    $("#switch_" + payTypeCode).html("关");
    if (isChecked) {
        switchActionUrl = getWebPath() + '/admin/system/merchant/turn_on_paytype/' + payTypeCode;
        $("#switch_" + payTypeCode).html("开");
    }

    $.ajax({
        type : "POST", //提交方式
        url : switchActionUrl,//路径
        data : {},
        success : function(result) {//返回数据根据结果进行相应的处理
            /*new $.zui.Messager(result.message, {
             type: 'success' // 定义颜色主题
             }).show();*/
            hippo.msg(result.message);
        }
    });
}

global_pay_type.updateRate = function (payTypeCode) {
    var minAmount = $('#minAmount_' + payTypeCode).val();
    var maxAmount = $('#maxAmount_' + payTypeCode).val();
    var rate = $('#rate_' + payTypeCode).val();
    var merchantRate = $('#merchant_rate_' + payTypeCode).val();

    $.ajax({
        type : "POST", //提交方式
        url : getWebPath() + "/admin/global_pay_type/update_default_rate",//路径
        data : {
            payTypeCode:payTypeCode,
            minAmount:minAmount,
            maxAmount:maxAmount,
            rate: merchantRate,
            merchantRate:merchantRate
        },
        success : function(result) {//返回数据根据结果进行相应的处理
            /*new $.zui.Messager(result.message, {
                type: 'success' //定义颜色主题
            }).show();*/
            hippo.msg(result.message);
        }
    });

}

global_pay_type.syncNewPaymentType = function(){

    $.ajax({
        type : "POST", //提交方式
        url : getWebPath() + "/admin/channel_pay_type/sync_pay_type",//路径
        data : {},
        success : function(result) {
            hippo.msg(result.message);
        }
    });

}