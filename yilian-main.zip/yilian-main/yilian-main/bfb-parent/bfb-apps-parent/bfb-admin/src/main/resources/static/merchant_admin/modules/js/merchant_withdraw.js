var MerchantWithdraw = {};

//全选
MerchantWithdraw.selectall = function(el){
    var selected = $(el).prop("checked");
    if(selected){
        $('input[name="orderIds"]').not(':disabled').each(function(){
            $(this).prop("checked",true);
        });
    }else{
        $('input[name="orderIds"]').each(function(){
            $(this).prop("checked",false);
        });
    }
}


MerchantWithdraw.cancelWithdrawOrder = function(id) {

    var url = getWebPath() + "/merchant_admin/withdraw/cancel_order/" + id;
    $.ajax({
        type : "POST", //提交方式
        url : url,//路径
        data : {},
        success : function(result) {//返回数据根据结果进行相应的处理
            new $.zui.Messager(result.message, {
                type: 'success' // 定义颜色主题
            }).show();
        }
    });

}

MerchantWithdraw.createWithdrawOrder = function (formId) {
    if (!hippo.validateForm(formId)) {
        return;
    }
    var url = $(formId).attr("action");
    $("#" + formId).ajaxSubmit( {
        url: url,
        type: 'POST',
        dataType: 'json',
        success: function (data) {
            if (data.statusCode == 'SUCCESS') {//进主页
                new $.zui.Messager(data.message, {
                    type: 'success' // 定义颜色主题
                }).show();
                window.setTimeout(function () {
                   window.location.href = getWebPath() + "/merchant_admin/withdraw/list";
                }, 1500);
            } else {
                hippo.warning(data.message);
            }
        }
        // clearForm: false,//禁止清楚表单
        // resetForm: false //禁止重置表单
    });
}

MerchantWithdraw.downloadTemplate = function () {
    $('#importOrderForm').attr("action",getWebPath() + "/merchant_admin/withdraw/download_template");
    $('#importOrderForm').submit();
}

MerchantWithdraw.importOrder = function () {
    if (!hippo.validateForm("importOrderForm")) {
        return;
    }
    //检验导入的文件是否为Excel文件
    var uploadFile = $("input[name='file']").val();
    if(uploadFile == null || uploadFile == ''){
        alert("请选择要上传的Excel文件");
        return;
    }else{
        var fileExtend = uploadFile.substring(uploadFile.lastIndexOf('.')).toLowerCase();
        if(fileExtend == '.xlsx'){
        }else{
            alert("文件格式需为'.xlsx'格式");
            return;
        }
    }

    layer.confirm(
        "确定导入批付订单？",
        {icon: 0, title:'提示'},
        function(index, layero){
            layer.close(index);
            //提交表单
            $('#importOrderForm').attr("action",getWebPath() + "/merchant_admin/withdraw/import_order");
            $('#importOrderForm').submit();
            $(':input', '#importOrderForm')
                .not(':button, :submit, :reset, :hidden')
                .val('')
                .removeAttr('checked')
                .removeAttr('selected');
            $("#uploadBtn").attr('disabled',true);
            var loading = Ladda.create( document.querySelector( '#uploadBtn' ) );
            loading.start();
            loading.setProgress(1000 );
        }
    );

}

MerchantWithdraw.batchImportOrder = function () {
    if (!hippo.validateForm("importOrderForm")) {
        return;
    }
    //检验导入的文件是否为Excel文件
    var uploadFile = $("input[name='file']").val();
    if(uploadFile == null || uploadFile == ''){
        alert("请选择要上传的Excel文件");
        return;
    }else{
        var fileExtend = uploadFile.substring(uploadFile.lastIndexOf('.')).toLowerCase();
        if(fileExtend == '.xlsx'){
        }else{
            alert("文件格式需为'.xlsx'格式");
            return;
        }
    }

    layer.confirm(
        "确定导入批付订单？",
        {icon: 0, title:'提示'},
        function(index, layero){
            layer.close(index);
            //提交表单
            $('#importOrderForm').attr("action",getWebPath() + "/merchant_admin/withdraw/batch_import_order");
            $('#importOrderForm').submit();
            $(':input', '#importOrderForm')
                .not(':button, :submit, :reset, :hidden')
                .val('')
                .removeAttr('checked')
                .removeAttr('selected');
            $("#uploadBtn").attr('disabled',true);
            var loading = Ladda.create( document.querySelector( '#uploadBtn' ) );
            loading.start();
            loading.setProgress(1000 );
        }
    );

}


MerchantWithdraw.batchWithdraw = function () {
    if($('input[name="orderIds"]:checked').length==0){
        hippo.toast("最少选择一条记录!");
        return;
    }

    var chk_orderid =[];
    $('input[name="orderIds"]:checked').each(function(){
        chk_orderid.push($(this).val());
    });
    layer.confirm(
        "确定要批付吗？",
        {icon: 0, title:'提示'},
        function(index, layero){
            layer.close(index);

            $.ajax({
                type : "POST", //提交方式
                data: { "orderIds": chk_orderid},
                url : getWebPath() + "/merchant_admin/withdraw/batch_withdraw",//路径
                success : function(result) {//返回数据根据结果进行相应的处理
                    hippo.msg(result.message);

                    window.setTimeout(function () {
                        window.location.reload();
                    }, 1500);
                }
            });

            $("#batchWithdraw").attr('disabled',true);
            var loading = Ladda.create( document.querySelector( '#batchWithdraw' ) );
            loading.start();
            loading.setProgress(1000 );

        });
}


MerchantWithdraw.deleteImportedOrder = function (orderid) {
    layer.confirm(
        "确定要删除吗？",
        {icon: 0, title:'提示'},
        function(index, layero){
            layer.close(index);
            $.ajax({
                type : "POST", //提交方式
                url : getWebPath() + "/merchant_admin/withdraw/delete_imported_order/"+orderid,//路径
                success : function(result) {//返回数据根据结果进行相应的处理
                    hippo.msg(result.message);
                    window.setTimeout(function () {
                        window.location.reload();
                    }, 1500);
                }
            });
        }
    );

}


MerchantWithdraw.deleteAllImportedOrder = function () {
    layer.confirm(
        "确定要删除吗？",
        {icon: 0, title:'提示'},
        function(index, layero){
            layer.close(index);
            $.ajax({
                type : "POST", //提交方式
                url : getWebPath() + "/merchant_admin/withdraw/delete_all_imported_order",//路径
                success : function(result) {//返回数据根据结果进行相应的处理
                    hippo.msg(result.message);
                    window.setTimeout(function () {
                        window.location.reload();
                    }, 1500);
                }
            });
        }
    );

}

$(function () {
  hippo.limitFloat('amountYuan');
  // hippo.limitInteger('payeeBankAccount');

    var proinveCode = $("#proinveCode").val();
    var cityCode = $("#cityCode").val();
    //默认绑定省
    ProviceBind(proinveCode, cityCode);
    //绑定事件
    $("#province").change( function () {
        CityBind();
    })
   /* $("#City").change(function () {
        VillageBind();
    })*/

});