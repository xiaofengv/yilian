package com.ajl.bfb.merchantadmin.report;

import com.ajl.bfb.admin.common.web.AdminUserUtils;
import com.ajl.bfb.core.constants.MerchantUserTypeEnum;
import com.ajl.bfb.core.constants.PaymentTypeEnum;
import com.ajl.bfb.core.constants.StatBizTypeEnum;
import com.ajl.bfb.merchantadmin.common.web.MerchantAdminUserUtils;
import com.ajl.bfb.repo.channel.model.Channel;
import com.ajl.bfb.repo.channel.model.ChannelAccount;
import com.ajl.bfb.repo.channel.model.ChannelAccountDetail;
import com.ajl.bfb.repo.channel.model.ChannelQuery;
import com.ajl.bfb.repo.channel.service.IChannelAccountService;
import com.ajl.bfb.repo.channel.service.IChannelService;
import com.ajl.bfb.repo.channelstat.service.IChannelAccountInstanceService;
import com.ajl.bfb.repo.fund.service.IFinanceFacadeService;
import com.ajl.bfb.repo.merchant.model.Merchant;
import com.ajl.bfb.repo.merchant.model.MerchantAccount;
import com.ajl.bfb.repo.merchant.model.MerchantAccountDetail;
import com.ajl.bfb.repo.merchant.model.MerchantFindParam;
import com.ajl.bfb.repo.merchant.service.IMerchantAccountService;
import com.ajl.bfb.repo.merchant.service.IMerchantService;
import com.ajl.bfb.repo.payment.service.IPaymentOrderService;
import com.ajl.bfb.repo.stat.model.*;
import com.ajl.bfb.repo.stat.service.IMerchantAccountStatService;
import com.ajl.bfb.repo.stat.service.IPaymentOrderStatService;
import com.github.pagehelper.PageInfo;
import com.hippo.framework.auth.admin.OperationAuth;
import com.hippo.framework.auth.admin.model.SysUser;
import com.hippo.framework.util.DateUtils;
import org.apache.commons.lang3.EnumUtils;
import org.apache.http.HttpRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;


@Controller
@RequestMapping("/merchant_admin/report")
public class AgentReportController {
    @Autowired
    private IChannelService channelService;

    @Autowired
    private IMerchantService merchantService;

    @Autowired
    private IMerchantAccountStatService merchantAccountStatService;

    @Autowired
    IChannelAccountService channelAccountService;

    @Autowired
    private IPaymentOrderService paymentOrderService;

    @RequestMapping("/merchant_pay_success_rate")
    public String merchantPaySuccessRate(QueryMerchantPaySuccess param, Model model,HttpServletRequest request){
        param.setStartTime(DateUtils.plusDays(DateUtils.getDateStart2(new Date()), 0));
        param.setEndTime(DateUtils.getDateEnd2(new Date()));
        Merchant merchant = MerchantAdminUserUtils.getLoginMerchant(request);
        model.addAttribute("userType",merchant.getUserType());
        if (merchant.getUserType().equals(MerchantUserTypeEnum.AGENT.name())){
            param.setAgentid(merchant.getId());
        }
        List<QueryMerchantPaySuccess> list = paymentOrderService.merchantPaySuccessRate(param);
        model.addAttribute("list",list);
        model.addAttribute("queryParam",param);
        ChannelQuery channelQuery = new ChannelQuery();
//        channelQuery.setStatus("ON");
        List<Channel> channels = channelService.findChannels(channelQuery);
        model.addAttribute("channels", channels);
        model.addAttribute("paymentTypeList", PaymentTypeEnum.values());
        return "/merchant_admin/report/merchantPaySuccessRate";
    }
    @RequestMapping("/merchant_account_state_byday")
    public String merchantAccountStatByday(QueryMerchantAccountParam queryParam, Model model, HttpServletRequest request){
        queryParam.setStartTime(DateUtils.getDateStart(queryParam.getStartTime()));
        queryParam.setEndTime(DateUtils.getDateEnd(queryParam.getEndTime()));
        queryParam.setUserType(MerchantUserTypeEnum.MERCHANT.name());
        Merchant merchant = MerchantAdminUserUtils.getLoginMerchant(request);
        model.addAttribute("userType",merchant.getUserType());
        if (merchant.getUserType().equals(MerchantUserTypeEnum.AGENT.name())){
            queryParam.setAgentid(merchant.getId());
        }
        PageInfo<HashMap> merchantAccountStatPageInfo = merchantAccountStatService.merchantAccountStatByday(queryParam);
        model.addAttribute("pageInfo",merchantAccountStatPageInfo);
        model.addAttribute("queryParam",queryParam);
        List<Merchant> merchants = merchantService.findMerchant(null);
        Map<Integer,String> merchantMap =  merchants.stream().collect(Collectors.toMap(Merchant::getId,Merchant::getMerchantName));
        model.addAttribute("merchantMap",merchantMap);
        return "/merchant_admin/report/merchantAccountBillingReport";
    }

}
